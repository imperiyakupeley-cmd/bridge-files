"""WHITELIST point-read: умышленно УЖЕ, чем core/v3lite.

Разрешено (и то — только с allowlisted ID, проверяет gate):
  crm.deal.get            {ID}
  crm.contact.get         {ID}          — только related-ID из allowlist
  crm.company.get         {ID}          — только related-ID из allowlist
  crm.stagehistory.list   entityTypeId/entityId (или UPPER-форма
                          ENTITY_TYPE/ENTITY_ID), start, order[ID]=ASC
                          — точечная выборка по доказанному ID сделки.

Всё прочее — отказ. Три реестра причин:

  FORBIDDEN      — широкие листинги/сканы и телефонное расширение кластера
                   (основание NO-GO mwgvc3lkp2pa: dossier → crm.deal.list
                   FILTER[CONTACT_ID]; messages_cluster → широкие сканы).
  NOT_TESTABLE   — серверный УЗКИЙ фильтр не доказан в offline → метод
                   отключён до доказательства; широкий list вместо него
                   запрещён навсегда.
  мутаторы       — regex-запрет всегда, даже если кто-то допишет метод.
"""
from __future__ import annotations

import re

from .errors import NotTestable, Refused

# как в core/whitelist.py v3lite — абсолютный запрет мутаторов
_MUTATING = re.compile(
    r"\.(add|update|delete|set|import|register|send|force|merge|consent|"
    r"confirm|cancel|complete|forward|pin|read|mark|answer|call)\b",
    re.I)

# параметры, сами по себе расширяющие охват или тянущие PII
_FORBIDDEN_PARAM_KEYS = re.compile(
    r"(PHONE|EMAIL|NAME|TITLE|SEARCH|QUERY|FIND|FULL)", re.I)
_PHONE_VALUE = re.compile(r"^\+?[\d][\d\s\-()]{6,17}$")

_STAGEHISTORY_KEYS = {
    "entityTypeId", "entityId", "ENTITY_TYPE", "ENTITY_ID", "start", "order[ID]"}

METHOD_SPECS: dict[str, set[str]] = {
    "crm.deal.get": {"ID"},
    "crm.contact.get": {"ID"},
    "crm.company.get": {"ID"},
    "crm.stagehistory.list": set(_STAGEHISTORY_KEYS),
}

FORBIDDEN_METHODS = {
    "crm.deal.list": "широкий листинг сделок (NO-GO mwgvc3lkp2pa)",
    "crm.contact.list": "широкий листинг контактов",
    "crm.lead.list": "широкий листинг лидов",
    "crm.duplicate.findbycomm": "телефонное расширение кластера запрещено владельцем",
    "batch": "batch запрещён: плоский поштучный контроль бюджета",
    "crm.deal.contactitems.get": "связи подтягиваются только из allowlist related",
}

NOT_TESTABLE_METHODS = {
    "crm.activity.list": "нет доказанного серверного точечного фильтра по OWNER "
                         "(offline не доказать); широкий list запрещён — NOT_TESTABLE",
    "crm.activity.get": "точечный гет активностей не подключён: связка ID активностей "
                        "со сделкой без list-скана не доказана",
    "crm.imopenlines.crm.chat.get": "OL: серверные фильтры не доказаны в offline",
    "crm.imopenlines.crm.chat.getlastid": "OL: серверные фильтры не доказаны в offline",
    "im.dialog.messages.get": "OL-сообщения: точечная выборка по сделке не доказана",
    "voximplant.statistic.get": "телефония: точечная связка со сделкой не доказана",
}


def check_method(method: str) -> None:
    if not isinstance(method, str) or not re.fullmatch(r"[a-z0-9_.]+", method, re.I):
        raise Refused(f"некорректное имя метода: {method!r}", code="METHOD_MALFORMED")
    if _MUTATING.search(method):
        raise Refused(f"метод-мутатор запрещён всегда: {method}", code="METHOD_MUTATOR")
    if method in FORBIDDEN_METHODS:
        raise Refused(f"метод запрещён политикой point-read: {method} "
                      f"({FORBIDDEN_METHODS[method]})", code="METHOD_FORBIDDEN")
    if method in NOT_TESTABLE_METHODS:
        raise NotTestable(f"метод отключён до доказательства узкого фильтра: "
                          f"{method} — {NOT_TESTABLE_METHODS[method]}")
    if method not in METHOD_SPECS:
        raise Refused(f"метод вне whitelist point-read: {method}",
                      code="METHOD_NOT_WHITELISTED")


def check_params(method: str, params: dict) -> dict:
    """Строгая проверка ключей/значений. Возвращает чистую копию."""
    check_method(method)
    spec = METHOD_SPECS[method]
    out: dict = {}
    for k, v in (params or {}).items():
        if _FORBIDDEN_PARAM_KEYS.search(str(k)):
            raise Refused(f"параметр {k!r} запрещён (PII/расширение охвата) "
                          f"для {method}", code="PII_PARAM")
        if k not in spec:
            raise Refused(f"параметр {k!r} не разрешён для {method}",
                          code="PARAM_NOT_ALLOWED")
        if isinstance(v, str) and _PHONE_VALUE.match(v.strip()) and k not in ("order[ID]",):
            raise Refused(f"значение параметра {k!r} похоже на телефон — "
                          "телефонное связывание запрещено", code="PII_PARAM")
        out[k] = v

    if method == "crm.stagehistory.list":
        _check_stagehistory(out)
    elif method != "crm.stagehistory.list" and method.endswith(".get"):
        if set(out) != {"ID"} or not isinstance(out.get("ID"), int):
            raise Refused(f"{method}: разрешён ровно один параметр ID (int)",
                          code="PARAM_SHAPE")
    return out


def _check_stagehistory(params: dict) -> None:
    camel = "entityTypeId" in params and "entityId" in params
    upper = "ENTITY_TYPE" in params and "ENTITY_ID" in params
    if not (camel or upper):
        raise Refused("crm.stagehistory.list: обязателен точечный фильтр "
                      "entityTypeId+entityId (или UPPER-форма)", code="PARAM_SHAPE")
    if camel and upper:
        raise Refused("crm.stagehistory.list: смешение camelCase и UPPER-форм",
                      code="PARAM_SHAPE")
    if camel:
        if str(params.get("entityTypeId")) not in ("2", "deal"):
            raise Refused("crm.stagehistory.list: entityTypeId должен быть 2|deal",
                          code="PARAM_SHAPE")
    else:
        if params.get("ENTITY_TYPE") != "deal":
            raise Refused("crm.stagehistory.list: ENTITY_TYPE должен быть deal",
                          code="PARAM_SHAPE")
    start = params.get("start", 0)
    if not isinstance(start, int) or not (0 <= start <= 200):
        raise Refused("start: int в [0, 200] (кап пагинации)", code="PARAM_SHAPE")
    if "order[ID]" in params and params["order[ID]"] != "ASC":
        raise Refused("order[ID]: только ASC", code="PARAM_SHAPE")


def extract_entity_id(method: str, params: dict) -> tuple[str, int] | None:
    """(kind, id) сущности, к которой обращается вызов, если применимо."""
    if method == "crm.deal.get":
        return ("deal", int(params["ID"]))
    if method == "crm.contact.get":
        return ("contact", int(params["ID"]))
    if method == "crm.company.get":
        return ("company", int(params["ID"]))
    if method == "crm.stagehistory.list":
        if "entityId" in params:
            return ("deal", int(params["entityId"]))
        if "ENTITY_ID" in params:
            return ("deal", int(params["ENTITY_ID"]))
    return None
