"""Контейнер ошибок pointread. Все отказы — типизированные, без данных в тексте."""
from __future__ import annotations


class PointReadError(Exception):
    code = "POINTREAD_ERROR"

    def __init__(self, msg: str = "", *, code: str | None = None):
        super().__init__(msg or self.code)
        if code:
            self.code = code


# --- вход/политика (до любых чтений; бюджет НЕ расходуется) ---
class ConfigError(PointReadError):
    code = "CONFIG_INVALID"


class BadTypedId(PointReadError):
    code = "BAD_TYPED_ID"


class Refused(PointReadError):
    """Отказ гейта по политике (allowlist/whitelist/период/PII-параметр)."""
    code = "REFUSED"


class NotTestable(PointReadError):
    """Метод отключён: серверный точечный фильтр не доказан в offline."""
    code = "NOT_TESTABLE"


class ScopeChanged(PointReadError):
    """Конфиг/allowlist изменились посреди прогона — прогон недействителен."""
    code = "SCOPE_CHANGED"


# --- fail-closed во время прогона (прогон немедленно останавливается) ---
class FailClosed(PointReadError):
    code = "FAIL_CLOSED"


class BudgetExceeded(FailClosed):
    code = "BUDGET_EXCEEDED"


class RateLimitedFailClosed(FailClosed):
    """HTTP 429 / QUERY_LIMIT_EXCEEDED: без ретраев, немедленный стоп."""
    code = "RATE_LIMITED_FAIL_CLOSED"


class UnexpectedId(FailClosed):
    """Ответ сервера содержит не тот ID, что запрашивали."""
    code = "UNEXPECTED_ID"


# --- онлайн-заглушка ---
class OnlineBlocked(PointReadError):
    code = "ONLINE_BLOCKED"


class NoCredentialsWired(OnlineBlocked):
    """Даже с разблокировкой: код загрузки учётных данных умышленно отсутствует."""
    code = "NO_CREDENTIALS_WIRED"
