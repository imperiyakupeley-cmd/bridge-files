"""RunScope: пиннинг SHA256 конфигов на старте прогона.

Перед КАЖДЫМ чтением и на финализации хеши пересчитываются; изменение
allowlist/политики посреди прогона → ScopeChanged → прогон недействителен
(mid-run change of scope)."""
from __future__ import annotations

import hashlib
from pathlib import Path

from .errors import ScopeChanged


def _sha(path: str) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class RunScope:
    def __init__(self, *paths: str):
        if not paths:
            raise ValueError("RunScope: нужен хотя бы один файл")
        self.pinned = {p: _sha(p) for p in paths}

    def assert_unchanged(self) -> None:
        changed = [p for p, h in self.pinned.items() if _sha(p) != h]
        if changed:
            raise ScopeChanged(
                f"конфиг изменён во время прогона: {sorted(changed)} — "
                "прогон остановлен и недействителен")

    def to_json(self) -> dict:
        return {"pinned_sha256": dict(self.pinned)}
