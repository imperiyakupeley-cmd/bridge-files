"""Offline-транспорт: синтетические фикстуры, НОЛЬ сетевой активности.

Модуль не импортирует ни socket, ни urllib, ни requests — только json/os.
Умеет проигрывать сценарии (scripted events) для QA: http429, unexpected_id.
Формат ответов имитирует Б24: {"result": ...} / {"result": {"items": ...},
"total": n, "next": start+50} для stagehistory (live-факт 09.11: camelCase
+ result.items).
"""
from __future__ import annotations

import json
import os


class OfflineRateLimited(Exception):
    """Симуляция HTTP 429 / QUERY_LIMIT_EXCEEDED."""


class FixtureTransport:
    def __init__(self, fixtures_dir: str, script: list[dict] | None = None):
        self.fixtures_dir = os.path.expanduser(fixtures_dir)
        self.script = list(script or [])
        self.n_calls = 0
        self._deals = self._load("deals.json")
        self._contacts = self._load("contacts.json")
        self._companies = self._load("companies.json")
        self._stagehistory = self._load("stagehistory.json")

    def _load(self, name: str) -> dict:
        p = os.path.join(self.fixtures_dir, name)
        if not os.path.exists(p):
            return {}
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)

    # ------------------------------------------------------------------
    def call(self, method: str, params: dict) -> dict:
        self.n_calls += 1
        for ev in self.script:
            if ev.get("at_call") == self.n_calls:
                self._fire(ev)
        if method == "crm.deal.get":
            return self._get(self._deals, params.get("ID"), method)
        if method == "crm.contact.get":
            return self._get(self._contacts, params.get("ID"), method)
        if method == "crm.company.get":
            return self._get(self._companies, params.get("ID"), method)
        if method == "crm.stagehistory.list":
            return self._stage(params)
        raise OfflineRateLimited(f"offline: метод не поддержан фикстурами: {method}")

    def _fire(self, ev: dict) -> None:
        t = ev.get("type")
        if t == "http429":
            raise OfflineRateLimited("HTTP 429 (симуляция)")
        if t == "unexpected_id":
            self._unexpected = True  # обработает _get
            return
        raise AssertionError(f"неизвестный сценарий: {t}")

    def _get(self, table: dict, rid, method: str) -> dict:
        row = table.get(str(rid))
        if getattr(self, "_unexpected", False):
            self._unexpected = False
            other = next(iter(table)) if table else "0"
            row = dict(table.get(other) or {"ID": 1})
            row["ID"] = int(other) if other.isdigit() else 1
            if row["ID"] == int(rid):
                row["ID"] = int(rid) + 1
        if row is None:
            return {"error": "NOT_FOUND", "error_description": f"{method}: {rid}"}
        return {"result": row}

    def _stage(self, params: dict) -> dict:
        eid = params.get("entityId", params.get("ENTITY_ID"))
        items_all = self._stagehistory.get(str(eid), [])
        start = int(params.get("start", 0))
        page = items_all[start:start + 50]
        out: dict = {"result": {"items": page}, "total": len(items_all)}
        if start + 50 < len(items_all):
            out["next"] = start + 50
        return out
