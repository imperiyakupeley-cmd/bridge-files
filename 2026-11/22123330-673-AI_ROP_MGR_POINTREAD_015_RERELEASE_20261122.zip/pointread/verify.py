"""Оркестратор прогона point-read (offline-сборка): по одной сделке за раз.

Порядок на сделку: allowlist → crm.deal.get → период → stagehistory (точечно,
≤ max_stagehistory_pages) → related только из allowlist (crm.contact.get по
подтверждённому ID) → вердикт → PII-редакция всего отчёта.
Fail-closed (429 / неожиданный ID / бюджет / смена scope) останавливает ВЕСЬ
прогон немедленно; отказ на входе (REFUSED) budgets не расходует.
"""
from __future__ import annotations

import uuid

from . import FIX_TASK_ID
from .budget import ReadBudget
from .errors import BadTypedId, ConfigError
from .gate import Gate, _canonical_id
from .ids import parse_typed_id
from .policy import Allowlist, in_period
from .redact import redact
from .scope import RunScope
from .timeutil import fmt, now_msk, parse_dt
from .verdicts import VerdictResult, classify_deal


def run(allowlist: Allowlist, transport, deal_refs: list[str] | None = None) -> dict:
    report = {
        "tool": "pointread-staging", "task": "DEV-POINTREAD-STAGE-20261115-01",
        "fix_task": FIX_TASK_ID,
        "mode": "offline-synthetic", "run_id": str(uuid.uuid4()),
        "started_at": fmt(now_msk()),
        "results": [], "aborted": None, "no_manager_penalties": True,
    }
    scope = RunScope(allowlist.path)
    budget = ReadBudget(allowlist.policy.max_total_reads)
    gate = Gate(allowlist, budget, scope, transport)
    report["scope"] = scope.to_json()

    if deal_refs is None:
        deal_refs = [d.typed_id for d in allowlist.deals]
    if len(deal_refs) > allowlist.policy.max_deals:
        # D3 аудита 20261115: превышение потолка — ошибка конфигурации запроса,
        # а не формата typed-id → CONFIG_INVALID (ранее неверно: BAD_TYPED_ID)
        raise ConfigError(
            f"запрошено сделок больше лимита: {len(deal_refs)} > "
            f"{allowlist.policy.max_deals} — превышение потолка прогона")

    for ref in deal_refs:
        try:
            report["results"].append(_one(gate, allowlist, ref))
        except Exception as e:  # fail-closed: любой сбой = стоп прогона
            report["results"].append({
                "deal": str(ref), "verdict": "ABORTED",
                "reasons": [f"прогон остановлен: {getattr(e, 'code', type(e).__name__)}: "
                            f"{e}"],
                "no_manager_penalty": True,
            })
            report["aborted"] = {"code": getattr(e, "code", type(e).__name__),
                                 "reason": str(e)}
            break

    try:
        scope.assert_unchanged()  # повторная проверка на финализации
    except Exception as e:
        report["aborted"] = {"code": getattr(e, "code", type(e).__name__),
                             "reason": str(e)}

    report["finished_at"] = fmt(now_msk())
    report["budget"] = {"limit": budget.limit, "used": budget.used}
    report["api_reads"] = len(gate.calls)
    report["calls_made"] = list(gate.calls)
    return redact(report)


def _one(gate: Gate, allowlist: Allowlist, ref: str) -> dict:
    # 1) вход и allowlist — до первого чтения (бюджет не расходуется)
    try:
        _, num = parse_typed_id(ref, "deal")
    except BadTypedId as e:
        return {"deal": str(ref), "verdict": "REFUSED",
                "reasons": [f"некорректный typed id: {e}"],
                "no_manager_penalty": True}
    entry = allowlist.deal(num)
    if entry is None:
        return {"deal": str(ref), "verdict": "REFUSED",
                "reasons": ["ID не в allowlist — чтение запрещено "
                            "(ноль API-читений)"],
                "no_manager_penalty": True}

    # 2) карточка сделки (1 чтение). R2 DEV-POINTREAD-012: карточка без ID /
    #    с чужим ID / в неподтверждаемом формате отсекается гейтом
    #    (fail-closed UNEXPECTED_ID); сюда доходят либо валидная карточка,
    #    либо законный error (NOT_FOUND и т.п.) → UNKNOWN с причиной.
    resp = gate.call("crm.deal.get", {"ID": num})
    deal = resp.get("result") if isinstance(resp.get("result"), dict) else None
    if deal is None:
        err = resp.get("error", "нет result-объекта")
        return {"deal": entry.typed_id, "verdict": "UNKNOWN",
                "reasons": [f"сделка не найдена/недоступна (offline-фикстура: "
                            f"{err}) — данных нет, не штраф"],
                "no_manager_penalty": True}

    # 3) период — проверяется ДО любой детализации. D2 аудита 20261115:
    #    недоказуемое попадание в окно (DATE_CREATE отсутствует/пустая/
    #    нечитаема) = UNKNOWN, НЕ VERIFIED: без доказательства периода
    #    верификация невозможна, детализация не выполняется.
    created = deal.get("DATE_CREATE")
    if not (isinstance(created, str) and created.strip()):
        return {"deal": entry.typed_id, "verdict": "UNKNOWN",
                "reasons": ["DATE_CREATE отсутствует/пустая — попадание сделки "
                            "в разрешённый период не доказано; вердикт UNKNOWN, "
                            "детализация не выполнялась"],
                "coverage": {"period_proven": False, "detail_reads_done": False},
                "no_manager_penalty": True}
    try:
        created_dt = parse_dt(created)
    except ValueError:
        return {"deal": entry.typed_id, "verdict": "UNKNOWN",
                "reasons": [f"DATE_CREATE нечитаема ({created!r}) — попадание "
                            "сделки в разрешённый период не доказано; вердикт "
                            "UNKNOWN, детализация не выполнялась"],
                "coverage": {"period_proven": False, "detail_reads_done": False},
                "no_manager_penalty": True}
    if not in_period(allowlist.policy, created_dt):
        return {"deal": entry.typed_id, "verdict": "OUT_OF_PERIOD",
                "reasons": [f"создана {created} — вне разрешённого окна "
                            "01.10–14.11.2026 МСК; детализация не выполнялась"],
                "no_manager_penalty": True}

    # 4) stagehistory — точечно по доказанному ID, кап страниц из политики.
    #    R5 DEV-POINTREAD-012: исчерпание лимита страниц при живом курсоре =
    #    неполная история → VERIFIED невозможен (лимиты НЕ поднимаются).
    history: list[dict] = []
    history_complete = True
    pages_used = 0
    resp = {}
    for page in range(allowlist.policy.max_stagehistory_pages):
        params = {"entityTypeId": 2, "entityId": num, "start": page * 50}
        resp = gate.call("crm.stagehistory.list", params)
        pages_used += 1
        payload = resp.get("result") or {}
        items = payload.get("items", payload) if isinstance(payload, dict) else []
        if isinstance(items, list):
            history.extend(x for x in items if isinstance(x, dict))
        if not resp.get("next"):
            break
    history_complete = not resp.get("next")   # курсор жив → история усечена

    # 5) related — только подтверждённые источником (allowlist.related).
    #    R3 DEV-POINTREAD-012: NOT_FOUND/ошибка/пустая/нетипизированная
    #    карточка контакта НЕ попадает в related.verified — фиксируются
    #    причина и неполнота (PARTIAL, не VERIFIED; прогон не роняется).
    related_info: dict = {"verified": [], "unverified": [], "failed": []}
    contact_id = _canonical_id(deal.get("CONTACT_ID"))
    if contact_id is not None:
        if allowlist.related_ok(num, "contact", contact_id):
            cr = gate.call("crm.contact.get", {"ID": contact_id}, owner_deal=num)
            err = cr.get("error") if isinstance(cr, dict) else None
            row = (cr.get("result")
                   if isinstance(cr, dict) and isinstance(cr.get("result"), dict)
                   else None)
            if err:
                related_info["failed"].append(
                    {"kind": "contact", "id": contact_id,
                     "reason": f"crm.contact.get вернул ошибку: {err}"})
            elif row is None:
                related_info["failed"].append(
                    {"kind": "contact", "id": contact_id,
                     "reason": "crm.contact.get без карточки (NOT_FOUND/"
                               "пустой ответ)"})
            elif row.get("ID") is None or str(row.get("ID")) != str(contact_id):
                related_info["failed"].append(
                    {"kind": "contact", "id": contact_id,
                     "reason": "нетипизированная карточка контакта "
                               "(без ID / с несовпадающим ID)"})
            else:
                related_info["verified"].append(
                    {"kind": "contact", "id": contact_id,
                     "name": row.get("NAME", "")})
        else:
            related_info["unverified"].append({"kind": "contact", "id": contact_id})

    vr: VerdictResult = classify_deal(deal, history, allowlist.policy,
                                      related_info,
                                      history_complete=history_complete,
                                      history_pages=pages_used)
    out = vr.to_json()
    out["reads_used_so_far"] = len(gate.calls)
    out["coverage"] = {"period_proven": True, "detail_reads_done": True,
                       "history_complete": history_complete,
                       "history_pages_used": pages_used}
    return out
