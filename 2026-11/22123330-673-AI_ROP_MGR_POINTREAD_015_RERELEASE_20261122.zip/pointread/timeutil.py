"""Время: только МСК, только явные смещения или наивное → Europe/Moscow."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

MSK = timezone(timedelta(hours=3), name="MSK")


def parse_dt(value: str) -> datetime:
    """ISO/B24-строка → aware-datetime. Наивная строка трактуется как МСК."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"пустое время: {value!r}")
    s = value.strip().replace(" ", "T", 1) if " " in value and "T" not in value else value.strip()
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=MSK)
    return dt.astimezone(MSK)


def fmt(dt: datetime) -> str:
    return dt.astimezone(MSK).isoformat(timespec="seconds")


def now_msk() -> datetime:
    return datetime.now(tz=MSK)
