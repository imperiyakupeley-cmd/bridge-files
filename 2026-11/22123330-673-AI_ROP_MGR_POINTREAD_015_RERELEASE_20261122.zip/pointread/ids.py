"""Typed IDs: строгий разбор kind-префиксных идентификаторов.

Формат: ``deal:123``, ``contact:456``, ``company:789`` — 1..15 цифр, без
плюсов, ведущих нулей и прочих символов. Любой другой вид → BadTypedId
(fail-closed на входе, ни одного чтения).
"""
from __future__ import annotations

import re

from .errors import BadTypedId

_KINDS = {
    "deal": re.compile(r"^deal:([1-9][0-9]{0,14})$"),
    "contact": re.compile(r"^contact:([1-9][0-9]{0,14})$"),
    "company": re.compile(r"^company:([1-9][0-9]{0,14})$"),
}


def parse_typed_id(value: str, kind: str | None = None) -> tuple[str, int]:
    """``'deal:900000001'`` → ``('deal', 900000001)``. Строгий разбор."""
    if not isinstance(value, str):
        raise BadTypedId(f"typed id должен быть строкой, получен {type(value).__name__}")
    kinds = (kind,) if kind else tuple(_KINDS)
    for k in kinds:
        m = _KINDS[k].match(value)
        if m:
            return k, int(m.group(1))
    raise BadTypedId(
        f"некорректный typed id: {value!r} (ожидается {'|'.join(kinds)}:NNNN, только цифры)")


def parse_deal_id(value: str) -> int:
    kind, num = parse_typed_id(value, "deal")
    assert kind == "deal"
    return num
