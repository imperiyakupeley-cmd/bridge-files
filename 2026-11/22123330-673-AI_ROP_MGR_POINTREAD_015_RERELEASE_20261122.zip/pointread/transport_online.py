"""ОНЛАЙН-ТРАНСПОРТ — ЗАГЛУШКА. Сетевого кода здесь НЕТ и не было.

Последовательность блокировок (все три должны существовать одновременно,
и даже тогда вызов НЕ состоится):
  1. config: policy.online_enabled == true          (сейчас всегда false)
  2. env:     POINTREAD_ONLINE_UNLOCK == "I-REQUEST-LIVE-GO"
  3. CLI:     --allow-online
  4. далее — NoCredentialsWired: код загрузки учётных данных умышленно
     НЕ написан. Включение онлайн = отдельная одобренная правка кода
     после независимого аудита и явного GO собственника.

Ни при каких флагах этот модуль не открывает сеть: в нём нет ни одного
импорта сетевой библиотеки.
"""
from __future__ import annotations

import os

from .errors import NoCredentialsWired, OnlineBlocked

UNLOCK_ENV = "POINTREAD_ONLINE_UNLOCK"
UNLOCK_VALUE = "I-REQUEST-LIVE-GO"


class OnlineTransport:
    def __init__(self, *, online_enabled: bool, allow_online_flag: bool):
        if not online_enabled:
            raise OnlineBlocked(
                "онлайн запрещён конфигом (online_enabled=false). Live-проверки "
                "требуют независимого аудита и явного GO собственника "
                "(DEV-POINTREAD-STAGE-20261115-01: offline only)")
        if not allow_online_flag:
            raise OnlineBlocked("нужен флаг --allow-online")
        if os.environ.get(UNLOCK_ENV) != UNLOCK_VALUE:
            raise OnlineBlocked(f"нужна переменная окружения {UNLOCK_ENV}")
        raise NoCredentialsWired(
            "учётные данные умышленно не подключены в staging; активация "
            "онлайн — отдельная одобренная правка после аудита и GO")

    def call(self, method: str, params: dict):  # pragma: no cover — недостижимо
        raise NoCredentialsWired("онлайн-вызов невозможен в этой сборке")
