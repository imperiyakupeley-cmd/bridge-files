"""Политика point-read + загрузка allowlist (единый конфиг-файл).

Жёсткие потолки ЗАКОДАНЫ и не могут быть превышены конфигом:
  сделок ≤ 3, чтений всего ≤ 50 (включая попытки-ретраи), страниц
  stagehistory ≤ 5 на сделку, related-ID только с provenance.
Конфиг может лишь СУЖАТЬ. online_enabled в staging всегда false —
грузится, но transport_online остаётся заглушкой без учётных данных.
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, field

from .errors import ConfigError
from .ids import parse_typed_id
from .timeutil import parse_dt

HARD_MAX_DEALS = 3
HARD_MAX_READS = 50
HARD_MAX_PAGES = 5

DEFAULT_PERIOD = ("2026-10-01T00:00:00+03:00", "2026-11-14T23:59:59+03:00")
# разрешение собственника (ранее, отдельно): read-only 3 сделки 01.10–14.11.2026 МСК, без банка


@dataclass(frozen=True)
class RelatedId:
    kind: str
    id: int
    provenance: str


@dataclass(frozen=True)
class DealEntry:
    typed_id: str
    kind: str
    id: int
    provenance: str
    related: tuple[RelatedId, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class Policy:
    period_start: object
    period_end: object
    max_deals: int
    max_total_reads: int
    max_stagehistory_pages: int
    bot_user_ids: frozenset
    channel_map: dict
    online_enabled: bool
    min_manager_touchpoints: int = 2


@dataclass(frozen=True)
class Allowlist:
    deals: tuple[DealEntry, ...]
    policy: Policy
    path: str
    raw_sha256: str

    def deal(self, num: int) -> DealEntry | None:
        for d in self.deals:
            if d.id == num:
                return d
        return None

    def related_ok(self, deal_num: int, kind: str, rid: int) -> bool:
        d = self.deal(deal_num)
        return bool(d) and any(r.kind == kind and r.id == rid for r in d.related)


def load_allowlist(path: str) -> Allowlist:
    path = os.path.expanduser(path)
    try:
        raw = open(path, "rb").read()
    except OSError as e:
        raise ConfigError(f"не читается конфиг {path}: {e}") from e
    sha = hashlib.sha256(raw).hexdigest()
    try:
        cfg = json.loads(raw)
    except ValueError as e:
        raise ConfigError(f"конфиг не JSON: {e}") from e

    if cfg.get("schema") != "pointread-allowlist/1":
        raise ConfigError("schema должен быть pointread-allowlist/1")

    pol = cfg.get("policy") or {}
    period = (pol.get("period_start"), pol.get("period_end"))
    if period == (None, None):
        period = DEFAULT_PERIOD
    try:
        p_start, p_end = parse_dt(period[0]), parse_dt(period[1])
    except ValueError as e:
        raise ConfigError(f"период: {e}") from e
    if p_start >= p_end:
        raise ConfigError("period_start должен быть раньше period_end")

    def _cap(name: str, hard: int) -> int:
        v = pol.get(name, hard)
        if not isinstance(v, int) or isinstance(v, bool) or not (1 <= v <= hard):
            raise ConfigError(f"{name}: int в [1, {hard}] (конфиг может только сужать)")
        return v

    bots = pol.get("bot_user_ids", [])
    if not isinstance(bots, list) or not all(isinstance(b, int) for b in bots):
        raise ConfigError("bot_user_ids: список int")
    chmap = pol.get("channel_map", {})
    if not isinstance(chmap, dict) or not all(
            isinstance(k, str) and isinstance(v, str) for k, v in chmap.items()):
        raise ConfigError("channel_map: словарь str→str")

    policy = Policy(
        period_start=p_start, period_end=p_end,
        max_deals=_cap("max_deals", HARD_MAX_DEALS),
        max_total_reads=_cap("max_total_reads", HARD_MAX_READS),
        max_stagehistory_pages=_cap("max_stagehistory_pages", HARD_MAX_PAGES),
        bot_user_ids=frozenset(bots),
        channel_map=dict(chmap),
        online_enabled=bool(pol.get("online_enabled", False)),
        min_manager_touchpoints=max(1, int(pol.get("min_manager_touchpoints", 2))),
    )

    deals_raw = cfg.get("deals")
    if not isinstance(deals_raw, list) or not deals_raw:
        raise ConfigError("deals: непустой список")
    if len(deals_raw) > policy.max_deals:
        raise ConfigError(f"сделок в allowlist больше лимита: "
                          f"{len(deals_raw)} > {policy.max_deals}")
    deals: list[DealEntry] = []
    seen: set[int] = set()
    for i, d in enumerate(deals_raw):
        if not isinstance(d, dict):
            raise ConfigError(f"deals[{i}] должен быть объектом")
        try:
            kind, num = parse_typed_id(d.get("typed_id", ""), "deal")
        except Exception as e:
            raise ConfigError(f"deals[{i}].typed_id: {e}") from e
        if num in seen:
            raise ConfigError(f"дубликат deal id: {num}")
        seen.add(num)
        prov = d.get("provenance")
        if not isinstance(prov, str) or not prov.strip():
            raise ConfigError(f"deals[{i}].provenance обязателен (источник разрешения)")
        related: list[RelatedId] = []
        for r in d.get("related", []) or []:
            if not isinstance(r, dict) or not isinstance(r.get("provenance"), str):
                raise ConfigError(f"deals[{i}].related: нужно {{typed_id, provenance}}")
            try:
                rkind, rnum = parse_typed_id(r.get("typed_id", ""))
            except Exception as e:
                raise ConfigError(f"deals[{i}].related: {e}") from e
            related.append(RelatedId(rkind, rnum, r["provenance"]))
        deals.append(DealEntry(d["typed_id"], kind, num, prov.strip(), tuple(related)))

    return Allowlist(tuple(deals), policy, path, sha)


def in_period(policy: Policy, dt) -> bool:
    return policy.period_start <= dt <= policy.period_end
