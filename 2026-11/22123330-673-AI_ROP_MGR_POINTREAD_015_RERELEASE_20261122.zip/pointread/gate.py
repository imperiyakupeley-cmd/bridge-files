"""Гейт: единственная точка прохода любого вызова. Порядок проверок:

  1. RunScope.assert_unchanged()   — конфиг не менялся (иначе SCOPE_CHANGED)
  2. whitelist.check_params        — метод/параметры (иначе REFUSED/NOT_TESTABLE,
                                     бюджет НЕ расходуется)
  3. entity-ID ∈ allowlist         — сделка или related с provenance
                                     (иначе ID_NOT_ALLOWLISTED, бюджет НЕ расходуется)
  4. budget.acquire()              — КАЖДАЯ попытка тарифицируется ДО вызова
  5. транспорт                     — 429 → RATE_LIMITED_FAIL_CLOSED (без ретраев);
                                     ответ с чужим ID → UNEXPECTED_ID
                                     (D1 аудита 20261115: и для stagehistory.list —
                                     каждая запись обязана нести ENTITY_ID
                                     запрошенной сделки; чужой/отсутствующий
                                     ENTITY_ID либо неподтверждаемый формат
                                     ответа → fail-closed UNEXPECTED_ID);
                                     R2 DEV-POINTREAD-012: карточка сделки
                                     БЕЗ ID или в неподтверждаемом формате →
                                     fail-closed (deal:None/VERIFIED не
                                     выпускаются); ответ с error проходит
                                     дальше как «не найдена» → UNKNOWN
"""
from __future__ import annotations

from . import whitelist
from .budget import ReadBudget
from .errors import (FailClosed, RateLimitedFailClosed, Refused,
                     UnexpectedId)
from .policy import Allowlist
from .scope import RunScope
from .transport_offline import OfflineRateLimited


class Gate:
    def __init__(self, allowlist: Allowlist, budget: ReadBudget, scope: RunScope,
                 transport):
        self.allowlist = allowlist
        self.budget = budget
        self.scope = scope
        self.transport = transport
        self.calls: list[str] = []

    def call(self, method: str, params: dict | None = None, *,
             owner_deal: int | None = None) -> dict:
        """owner_deal — номер родительской сделки для related-вызовов
        (в params его протаскивать нельзя — whitelist режет лишние ключи)."""
        self.scope.assert_unchanged()
        clean = whitelist.check_params(method, params or {})

        ent = whitelist.extract_entity_id(method, clean)
        if ent is not None:
            kind, num = ent
            if kind == "deal":
                if self.allowlist.deal(num) is None:
                    raise Refused(f"ID не в allowlist: {kind}:{num}",
                                  code="ID_NOT_ALLOWLISTED")
            else:
                if not owner_deal or not self.allowlist.related_ok(
                        owner_deal, kind, num):
                    raise Refused(
                        f"related-ID не подтверждён источником для этой сделки: "
                        f"{kind}:{num}", code="RELATED_NOT_PROVEN")

        self.budget.acquire()
        self.calls.append(method)
        try:
            resp = self.transport.call(method, clean)
        except OfflineRateLimited as e:
            raise RateLimitedFailClosed(
                f"{method}: {e} — стоп без ретраев (fail-closed)") from e
        if isinstance(resp, dict) and resp.get("error") in (
                "QUERY_LIMIT_EXCEEDED", "RATE_LIMIT"):
            raise RateLimitedFailClosed(f"{method}: {resp['error']} — fail-closed")

        # ответ обязан быть про запрошенный ID
        if method == "crm.deal.get":
            # R2 DEV-POINTREAD-012: карточка первичной сделки без ID либо в
            # формате, где личность подтвердить нельзя, → fail-closed:
            # deal:None и VERIFIED не выпускаются ни при каких условиях.
            # Ответ с error (например NOT_FOUND) проходит дальше — verify
            # даст UNKNOWN с причиной, это не верификация.
            if isinstance(resp, dict) and resp.get("error"):
                pass
            elif not (isinstance(resp, dict)
                      and isinstance(resp.get("result"), dict)):
                raise UnexpectedId(
                    f"{method}: формат ответа не позволяет подтвердить карточку "
                    "сделки (нет result-объекта) — fail-closed")
            else:
                got = resp["result"].get("ID")
                want = clean.get("ID")
                if got is None:
                    raise UnexpectedId(
                        f"{method}: карточка без ID — принадлежность не доказана "
                        "(fail-closed; deal:None и VERIFIED не выпускаются)")
                if str(got) != str(want):
                    raise UnexpectedId(
                        f"{method}: запрошен {want}, получен {got} — fail-closed")
        elif (method.endswith(".get") and isinstance(resp, dict)
              and isinstance(resp.get("result"), dict)):
            # related-геты (contact/company): чужой ID — всегда fail-closed;
            # карточка без ID/пустая НЕ абсорбируется вызывающим кодом в
            # related.verified (R3, verify) — прогон не роняется.
            got = resp["result"].get("ID")
            want = clean.get("ID")
            if got is not None and str(got) != str(want):
                raise UnexpectedId(
                    f"{method}: запрошен {want}, получен {got} — fail-closed")
        if method == "crm.stagehistory.list":
            _assert_stagehistory_owned(resp, clean)
        return resp


def _canonical_id(value):
    """Strict REST numeric identity; reject bool, floats, padding, signs."""
    if type(value) is int and 1 <= value <= 999999999999999:
        return value
    if isinstance(value, str) and 1 <= len(value) <= 15 and value.isascii() and value.isdecimal() and value[0] != "0":
        return int(value)
    return None


def _assert_stagehistory_owned(resp: dict, clean: dict) -> None:
    """Fail closed for both documented REST OWNER_ID and fixture ENTITY_ID."""
    want = _canonical_id(clean.get("entityId", clean.get("ENTITY_ID")))
    result = resp.get("result") if isinstance(resp, dict) else None
    if want is None or not (isinstance(result, dict) and isinstance(result.get("items"), list)):
        raise UnexpectedId("crm.stagehistory.list: unproven requested ID or result.items")
    for i, item in enumerate(result["items"]):
        if not isinstance(item, dict):
            raise UnexpectedId(f"crm.stagehistory.list: non-object item #{i}")
        values = [item[k] for k in ("ENTITY_ID", "OWNER_ID") if k in item]
        if not values or any(_canonical_id(v) != want for v in values):
            raise UnexpectedId(f"crm.stagehistory.list: UNEXPECTED_ID item #{i}; ownership not proven")
        # Normalize only after both IDs, when present, have been proven.
        if "ENTITY_ID" not in item:
            item["ENTITY_ID"] = want


class GateSpy(Gate):
    """Гейт с подсчётом отказов для QA-сценариев (методы те же)."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.refusals: list[str] = []

    def call(self, method: str, params: dict | None = None, *,
             owner_deal: int | None = None) -> dict:
        try:
            return super().call(method, params, owner_deal=owner_deal)
        except FailClosed:
            raise
        except Exception as e:
            self.refusals.append(getattr(e, "code", type(e).__name__))
            raise
