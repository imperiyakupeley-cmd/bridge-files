"""PII-редакция: ВСЁ, что покидает инструмент (stdout/отчёт), проходит здесь.

- ключи-псевдонимы PII (NAME/EMAIL/PHONE/TITLE/...) → "[REDACTED:ключ]";
- телефоны в строках (+7…, 8-9XX…) → "+7[PHONE_REDACTED]";
- e-mail в строках → "[EMAIL_REDACTED]";
- ID, даты, стадии, счётчики — остаются (идентификаторы не PII).
"""
from __future__ import annotations

import re

PII_KEYS = {
    "NAME", "LAST_NAME", "SECOND_NAME", "EMAIL", "PHONE", "COMMENTS",
    "SOURCE_DESCRIPTION", "TITLE", "FULL_NAME", "ADDRESS", "WEB",
}

# значения этих ключей — хеши/идентификаторы прогона, не текст: не маскируются
SAFE_KEYS = {"config_sha256", "pinned_sha256", "sha256", "run_id"}

_HEX_ONLY = re.compile(r"^[0-9a-fA-F]{8,}$")

# телефон: +7 (разделители опциональны) либо 8 с ОБЯЗАТЕЛЬНЫМ разделителем —
# чтобы 11-значные цифровые/хешевые цепочки не мутировали в маску
_PHONE_IN_TEXT = re.compile(
    r"\+7[\s\-]?\(?\d{3}\)?[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}"
    r"|8[\s\-]\d{3}[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}")
_EMAIL_IN_TEXT = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")


def mask_text(s: str) -> str:
    if _HEX_ONLY.match(s):        # чистый hex (хеш) телефоном быть не может
        return s
    s = _EMAIL_IN_TEXT.sub("[EMAIL_REDACTED]", s)
    s = _PHONE_IN_TEXT.sub("[PHONE_REDACTED]", s)
    return s


def redact(obj):
    """Рекурсивная редакция объекта для вывода."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if str(k).upper() in PII_KEYS:
                out[k] = f"[REDACTED:{k}]"
            elif str(k) in SAFE_KEYS:
                out[k] = v
            else:
                out[k] = redact(v)
        return out
    if isinstance(obj, (list, tuple)):
        return [redact(v) for v in obj]
    if isinstance(obj, str):
        return mask_text(obj)
    return obj


def assert_no_pii(text: str, *, forbidden: list[str]) -> None:
    """Самопроверка вывода: сырые подстроки forbidden не должны встречаться."""
    for f in forbidden:
        if f and f in text:
            raise AssertionError(f"PII-утечка в выводе: {f[:4]}***")
