"""Бюджет чтений: ≤ N на ПРОГОН, каждая попытка (включая ретраи) тарифицируется
до вызова транспорта. Превышение = BudgetExceeded → fail-closed стоп прогона."""
from __future__ import annotations

from dataclasses import dataclass

from .errors import BudgetExceeded


@dataclass
class ReadBudget:
    limit: int
    used: int = 0

    def acquire(self) -> int:
        if self.used >= self.limit:
            raise BudgetExceeded(f"бюджет чтений исчерпан: {self.used}/{self.limit}")
        self.used += 1
        return self.used

    @property
    def left(self) -> int:
        return self.limit - self.used
