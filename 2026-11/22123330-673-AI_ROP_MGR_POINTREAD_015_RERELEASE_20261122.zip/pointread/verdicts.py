"""Вердикты point-read: ПРОВЕРЯЕМОСТЬ ДАННЫХ, не вина людей.

  VERIFIED      — сделка в периоде, канал отображён, касаний менеджера
                  достаточно, связанных сущностей нет или они подтверждены;
  PARTIAL       — проверено частично (например, связанный контакт не из
                  allowlist — данные неполны, НО это не штраф никому);
  UNKNOWN       — короткая история/недостижимость, неотображённый канал
                  (например, Avito без подтверждённого маппинга), нет данных;
  OUT_OF_PERIOD — вне 01.10–14.11.2026 МСК (исключается, не штраф);
  REFUSED / NOT_TESTABLE / ABORTED — уровни политики/прогона.

Касания ботов (bot_user_ids; PROVIDER_TYPE_ID=TASKS_TASK/CRM_WEBDAV_TASK —
урок C13/GC-1) исключаются из счётчика менеджера: бот ≠ менеджер, штрафов
нет по построению (полей вины в схеме не существует).

R4 DEV-POINTREAD-013 (§33 координатора): повторяющийся ID с КОНФЛИКТОМ
значимых полей (авторство/бот-признак, дата, принадлежность) — спорная
запись, исключается из подтверждённых касаний целиком; результат не зависит
от порядка строк. Точный повтор (значимые поля совпадают) считается один раз.
CREATED_BY_ID=0 и прочие недопустимые нативные ID касание менеджера не
доказывают; ответственный (ASSIGNED_BY_ID) автора не заменяет.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .policy import Policy, in_period
from .timeutil import parse_dt

BOT_PROVIDER_TYPES = {"TASKS_TASK", "CRM_WEBDAV_TASK"}


@dataclass
class VerdictResult:
    deal: str
    verdict: str
    reasons: list[str] = field(default_factory=list)
    channel: str | None = None
    touchpoints: dict = field(default_factory=dict)
    related: dict = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def to_json(self) -> dict:
        return {
            "deal": self.deal, "verdict": self.verdict, "reasons": self.reasons,
            "channel": self.channel, "touchpoints": self.touchpoints,
            "related": self.related, "notes": self.notes,
            "no_manager_penalty": True,
        }


def _item_dt(item: dict) -> object | None:
    for k in ("CREATED_DATE", "DATE_CREATE", "CREATED_TIME", "CREATED"):
        v = item.get(k)
        if isinstance(v, str) and v.strip():
            try:
                return parse_dt(v)
            except ValueError:
                continue
    return None


def _is_bot(item: dict, policy: Policy) -> bool:
    """Бот по НАСТОЯЩЕМУ автору записи (CREATED_BY_ID) либо по провайдеру.
    R4 DEV-POINTREAD-012: ASSIGNED_BY_ID (ответственный) автором записи
    не является и автора не заменяет — по нему бот не выводится.
    R4 DEV-POINTREAD-013: проверяется ДО валидности автора — доказанный
    бот (провайдер TASKS_TASK/CRM_WEBDAV_TASK) остаётся ботом и при
    недопустимом CREATED_BY_ID (0/отрицательный)."""
    who = item.get("CREATED_BY_ID")
    if (isinstance(who, int) and not isinstance(who, bool)
            and who in policy.bot_user_ids):
        return True
    prov = item.get("PROVIDER_TYPE_ID")
    return isinstance(prov, str) and prov.upper() in BOT_PROVIDER_TYPES


def _sig(item: dict, policy: Policy) -> tuple:
    """Сигнатура ЗНАЧИМЫХ для атрибуции касания полей записи (R4 013).

    Конфликт доказательства = разные сигнатуры у строк с одним ID.
    Значимые поля: авторство (CREATED_BY_ID только целого типа; остальные
    типы не доказывают автора), бот-признак (результат _is_bot: автор-бот или провайдер
    TASKS_TASK/CRM_WEBDAV_TASK в любом регистре), дата события (нормализованный
    момент; недоказанная/нечитаемая дата — один sentinel UNPROVEN — обе строки
    одинаково недоказуемы, конфликта нет), принадлежность (ENTITY_ID,
    ENTITY_TYPE_ID). Описательные поля (STAGE_ID и т.п.) на атрибуцию касания
    не влияют и конфликтом не считаются — их расхождение = точный повтор.
    """
    dt = "UNPROVEN"
    for k in ("CREATED_DATE", "DATE_CREATE", "CREATED_TIME", "CREATED"):
        v = item.get(k)
        if isinstance(v, str) and v.strip():
            try:
                dt = parse_dt(v).isoformat()   # parse_dt нормализует в МСК
                break
            except ValueError:
                continue
    author = item.get("CREATED_BY_ID")
    native_author = author if type(author) is int else None
    return (native_author,
            _is_bot(item, policy),
            dt,
            item.get("ENTITY_ID"),
            item.get("ENTITY_TYPE_ID"))


def classify_deal(deal: dict, history: list[dict], policy: Policy,
                  related_info: dict, *, history_complete: bool = True,
                  history_pages: int | None = None) -> VerdictResult:
    deal_id = deal.get("ID")
    res = VerdictResult(
        deal=f"deal:{deal_id}" if deal_id is not None else "deal:unproven-id",
        verdict="UNKNOWN")
    if deal_id is None:
        # R2 (страховочный слой): карточка без ID не доказывает личность
        # сделки — VERIFIED невозможен; гейт уже даёт fail-closed UNEXPECTED_ID.
        res.reasons.append("карточка без ID — личность сделки не доказана "
                           "(deal:None не выпускается)")
        return res

    # 1) период (по дате создания сделки). D2 аудита 20261115: пока попадание
    #    в окно НЕ доказано (DATE_CREATE отсутствует/нечитаема), вердикт не
    #    может быть VERIFIED/PARTIAL — только UNKNOWN с причиной и фиксацией
    #    неполноты coverage. (verify.py возвращает UNKNOWN ещё раньше, здесь —
    #    страховочный слой для любых других путей классификации.)
    created = deal.get("DATE_CREATE")
    period_proven = False
    if isinstance(created, str) and created.strip():
        try:
            if not in_period(policy, parse_dt(created)):
                res.verdict = "OUT_OF_PERIOD"
                res.reasons.append(
                    f"создана {created} — вне окна "
                    f"{policy.period_start.isoformat()}..{policy.period_end.isoformat()}")
                return res
            period_proven = True
        except ValueError:
            res.reasons.append(f"DATE_CREATE нечитаема ({created!r}) — попадание "
                               "в период не доказано")
    else:
        res.reasons.append("DATE_CREATE отсутствует/пустая — попадание в период "
                           "не доказано")

    # 2) канал. R1 DEV-POINTREAD-012: SOURCE_ID отсутствует/пуст/не отображён —
    #    канал НЕ подтверждён: причина фиксируется, вердикт UNKNOWN, не VERIFIED.
    src = deal.get("SOURCE_ID")
    channel_known = (isinstance(src, str) and bool(src.strip())
                     and src in policy.channel_map)
    res.channel = policy.channel_map[src] if channel_known else None
    if not channel_known:
        if src is None or (isinstance(src, str) and not src.strip()):
            res.reasons.append("SOURCE_ID отсутствует/пуст — канал не "
                               "подтверждён, атрибуция не проверяема "
                               "(догадки запрещены)")
        else:
            res.reasons.append(
                f"канал не отображён (SOURCE_ID={src} отсутствует в подтверждённом "
                "маппинге; например Avito) — канал не подтверждён, атрибуция "
                "не проверяема, догадки запрещены")

    # 3) касания: только ДОКАЗАННЫЕ записи. R4 DEV-POINTREAD-012:
    #    дубликаты (повторный ID) счётчик не увеличивают; записи без
    #    доказанной даты в окне или без нативного автора (CREATED_BY_ID)
    #    касаниями менеджера не считаются — ответственный ASSIGNED_BY_ID
    #    автора не заменяет; неполнота фиксируется причиной, ложный VERIFIED
    #    исключён.
    #    R4 DEV-POINTREAD-013 (§33, пограничные случаи): повторяющийся ID —
    #    это ОДНА запись, и её доказательство обязано быть внутренне
    #    согласовано. Конфликт значимых полей (авторство/бот-признак, дата,
    #    принадлежность — см. _sig) между строками с одним ID = спорная
    #    запись: исключается из подтверждённых касаний ЦЕЛИКОМ (и из
    #    менеджерских, и из бот-касаний), причина/неполнота фиксируются,
    #    результат НЕ зависит от порядка строк. Точный повтор (значимые
    #    поля совпадают) считается один раз. CREATED_BY_ID=0 и прочие
    #    недопустимые нативные ID (≤0) касание менеджера не доказывают;
    #    распознавание доказанного бота (автор-бот или провайдер) сохранено.
    by_id: dict[int, list[dict]] = {}
    id_order: list[int] = []
    no_id = 0
    for it in history:
        iid = it.get("ID")
        if not isinstance(iid, int) or isinstance(iid, bool):
            no_id += 1          # ID нет — единственность записи не доказана
            continue
        if iid not in by_id:
            by_id[iid] = []
            id_order.append(iid)
        by_id[iid].append(it)

    mgr_items: list[dict] = []
    bot_items: list[dict] = []
    dup_ignored = 0
    disputed_ids = 0
    disputed_rows = 0
    undated = 0
    no_author = 0
    invalid_author = 0
    out_win = 0
    for iid in id_order:
        rows = by_id[iid]
        if len(rows) > 1:
            signature = _sig(rows[0], policy)
            if any(_sig(row, policy) != signature for row in rows[1:]):
                # спорная запись: строки с одним ID противоречат друг другу
                # по значимым полям — атрибуция не доказана НИ одной из них
                disputed_ids += 1
                disputed_rows += len(rows)
                continue
            dup_ignored += len(rows) - 1    # точный повтор — учтён один раз
        it = rows[0]
        dt = _item_dt(it)
        if dt is None:
            undated += 1        # дата не доказана ни в окне, ни вне окна
            continue
        if not in_period(policy, dt):
            out_win += 1
            continue
        if _is_bot(it, policy):
            bot_items.append(it)
            continue
        author = it.get("CREATED_BY_ID")
        if not isinstance(author, int) or isinstance(author, bool):
            no_author += 1      # нативный автор не доказан
            continue
        if author <= 0:
            invalid_author += 1  # CREATED_BY_ID=0/отрицательный — не автор
            continue
        mgr_items.append(it)
    res.touchpoints = {
        "manager": len(mgr_items),
        "bot": len(bot_items),
        "outside_window_ignored": out_win,
        "duplicates_ignored": dup_ignored,
        "disputed_duplicate_ids": disputed_ids,
        "disputed_duplicate_rows": disputed_rows,
        "undated_unproven": undated,
        "no_native_author": no_author,
        "invalid_native_author": invalid_author,
        "no_id_unproven": no_id,
    }
    if dup_ignored:
        res.notes.append(f"дубликаты истории (повторный ID) учтены один раз: "
                         f"проигнорировано {dup_ignored}")
    if bot_items:
        res.notes.append("касания бота исключены из счётчика менеджера (бот ≠ менеджер)")
    if disputed_ids:
        res.reasons.append(
            f"{disputed_ids} записей истории спорны: повторяющийся ID с "
            f"конфликтом значимых полей ({disputed_rows} строк расходятся по "
            "авторству/бот-признаку, дате или принадлежности) — исключены из "
            "подтверждённых касаний; результат не зависит от порядка строк "
            "(неполнота истории)")
    if undated:
        res.reasons.append(
            f"{undated} записей истории без доказанной даты — попадание в окно "
            "не доказано, касанием менеджера не считается (неполнота истории)")
    if no_author:
        res.reasons.append(
            f"{no_author} записей без нативного автора (CREATED_BY_ID) — "
            "касанием менеджера не считается; ответственный по сделке автора "
            "не заменяет (неполнота истории)")
    if invalid_author:
        res.reasons.append(
            f"{invalid_author} записей с недопустимым нативным автором "
            "(CREATED_BY_ID=0/отрицательный — не нативный ID сотрудника) — "
            "касание менеджера не доказано; ответственный по сделке автора "
            "не заменяет (неполнота истории)")
    if no_id:
        res.reasons.append(
            f"{no_id} записей без ID — единственность не доказана, касанием "
            "не считается (неполнота истории)")

    # 3b) полнота истории. R5 DEV-POINTREAD-012: достигнут лимит страниц
    #     пагинации при живом курсоре → история неполна, VERIFIED невозможен
    #     (лимиты не поднимаются — это политика, не настройка).
    if not history_complete:
        pg = f" (использовано страниц: {history_pages})" if history_pages else ""
        res.reasons.append(
            "история неполна: достигнут лимит страниц пагинации" + pg +
            ", курсор не исчерпан — полнота касаний не доказана, VERIFIED "
            "невозможен")
        res.notes.append("coverage: история усечена лимитом страниц — "
                         "лимиты доступа не поднимаются")

    # 4) related-сущности. R3 DEV-POINTREAD-012: недоступный/ошибочный/
    #    нетипизированный связанный контакт не попадает в verified — фиксируется
    #    причина и неполнота (PARTIAL, не VERIFIED).
    res.related = related_info
    unverified = related_info.get("unverified", [])
    if unverified:
        res.reasons.append("связанные сущности вне allowlist — не запрашивались, "
                           "данные неполны")
    for f in related_info.get("failed", []):
        res.reasons.append(
            f"связанный {f.get('kind')}:{f.get('id')} не подтверждён чтением — "
            f"{f.get('reason', 'причина неизвестна')}; данные неполны")

    # 5) итоговый вердикт (приоритет: неизвестное важнее частичного)
    short = len(mgr_items) < policy.min_manager_touchpoints
    if short:
        res.reasons.append(
            f"касаний менеджера в окне {len(mgr_items)} < "
            f"{policy.min_manager_touchpoints} — короткая/недостижимая история, "
            "данных для проверки недостаточно (не штраф)")
    if not period_proven:
        res.verdict = "UNKNOWN"          # D2: период не доказан — не VERIFIED/PARTIAL
        res.notes.append("coverage: период не подтверждён — VERIFIED/PARTIAL "
                         "невозможны без доказательства попадания в окно")
    elif not channel_known:
        res.verdict = "UNKNOWN"          # R1: канал не подтверждён — атрибуция невозможна
    elif short:
        res.verdict = "UNKNOWN"
    elif res.reasons:
        res.verdict = "PARTIAL"
    else:
        res.verdict = "VERIFIED"
    return res
