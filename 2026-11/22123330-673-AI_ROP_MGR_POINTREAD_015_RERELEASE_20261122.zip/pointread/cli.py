"""CLI pointread (offline по умолчанию, онлайн заблокирован навсегда в этой сборке).

Команды:
  policy                       — действующая политика + пиннинг конфига
  verify [--deal deal:X ...]   — offline-прогон по allowlist (по умолчанию все)
  call METHOD --params JSON    — одиночный вызов ЧЕРЕЗ гейт (демонстрация отказов)
  budget                       — лимиты бюджета/потолки

Выход: 0 OK; 2 REFUSED/политика; 3 fail-closed/ABORTED; 4 NOT_TESTABLE; 1 разбор аргументов.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

from . import TASK_ID, __version__
from .errors import NotTestable, PointReadError, Refused
from .policy import load_allowlist
from .redact import redact

EXIT = {"REFUSED": 2, "CONFIG_INVALID": 2, "BAD_TYPED_ID": 2, "ONLINE_BLOCKED": 2,
        "NOT_TESTABLE": 4, "FAIL_CLOSED": 3, "BUDGET_EXCEEDED": 3,
        "RATE_LIMITED_FAIL_CLOSED": 3, "UNEXPECTED_ID": 3, "SCOPE_CHANGED": 3}

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_CONFIG = os.path.join(ROOT, "pointread", "allowlist.json")
DEFAULT_FIXTURES = os.path.join(ROOT, "fixtures")


def _emit(obj: dict) -> None:
    print(json.dumps(redact(obj), ensure_ascii=False, indent=2, sort_keys=True))


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="pointread",
                                description="point-read staging (OFFLINE ONLY)")
    p.add_argument("-c", "--config", default=DEFAULT_CONFIG)
    p.add_argument("--fixtures", default=DEFAULT_FIXTURES)
    p.add_argument("--transport", choices=["offline", "online"], default="offline")
    p.add_argument("--allow-online", action="store_true",
                   help="сам по себе НЕ включает онлайн (см. transport_online)")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("policy", help="показать действующую политику")
    v = sub.add_parser("verify", help="offline point-read по allowlist")
    v.add_argument("--deal", action="append", dest="deals",
                   help="typed id, напр. deal:900000001 (≤3)")
    sub.add_parser("budget", help="лимиты бюджета")
    c = sub.add_parser("call", help="одиночный вызов через гейт (offline)")
    c.add_argument("method")
    c.add_argument("--params", default="{}", help="JSON-параметры")

    a = p.parse_args(argv)
    try:
        return _dispatch(a)
    except NotTestable as e:
        _emit({"status": "NOT_TESTABLE", "code": e.code, "detail": str(e)})
        return EXIT.get(e.code, 4)
    except Refused as e:
        _emit({"status": "REFUSED", "code": getattr(e, "code", "REFUSED"),
               "detail": str(e)})
        return EXIT.get(getattr(e, "code", "REFUSED"), 2)
    except PointReadError as e:
        _emit({"status": "ERROR", "code": e.code, "detail": str(e)})
        return EXIT.get(e.code, 1)


def _dispatch(a) -> int:
    al = load_allowlist(a.config)

    if a.transport == "online":
        from .transport_online import OnlineTransport
        OnlineTransport(online_enabled=al.policy.online_enabled,
                        allow_online_flag=a.allow_online)  # всегда кинет ошибку

    if a.cmd == "policy":
        _emit({
            "tool": "pointread-staging", "version": __version__, "task": TASK_ID,
            "mode": "offline-synthetic",
            "policy": {
                "period": [al.policy.period_start.isoformat(),
                           al.policy.period_end.isoformat()],
                "max_deals": al.policy.max_deals,
                "max_total_reads": al.policy.max_total_reads,
                "max_stagehistory_pages": al.policy.max_stagehistory_pages,
                "bot_user_ids": sorted(al.policy.bot_user_ids),
                "channel_map": al.policy.channel_map,
                "online_enabled": al.policy.online_enabled,
                "hard_caps": {"deals": 3, "reads": 50, "pages": 5},
            },
            "allowlist": [d.typed_id for d in al.deals],
            "config_sha256": al.raw_sha256,
        })
        return 0

    if a.cmd == "budget":
        _emit({"budget_limit_per_run": al.policy.max_total_reads,
               "hard_cap": 50, "deals_cap": al.policy.max_deals,
               "note": "каждая попытка (включая ретраи) тарифицируется; "
                       "превышение = fail-closed"})
        return 0

    from .transport_offline import FixtureTransport
    tr = FixtureTransport(a.fixtures)

    if a.cmd == "verify":
        from .verify import run
        report = run(al, tr, deal_refs=a.deals)
        _emit(report)
        return 3 if report.get("aborted") else 0

    if a.cmd == "call":
        from .budget import ReadBudget
        from .gate import Gate
        from .scope import RunScope
        params = json.loads(a.params)
        gate = Gate(al, ReadBudget(al.policy.max_total_reads),
                    RunScope(al.path), tr)
        resp = gate.call(a.method, params)
        _emit({"status": "OK", "method": a.method, "response": resp})
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
