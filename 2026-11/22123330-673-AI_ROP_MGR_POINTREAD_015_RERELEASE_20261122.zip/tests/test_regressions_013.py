"""Регрессионная батарея DEV-POINTREAD-013-OFFLINE (v0.1.3, offline-синтетика).

Два пограничных дефекта R4 по вектору координатора (§33), воспроизведённые на
нетронутой 0.1.2 ДО исправления (репро /tmp/pr013_netblock/repro_013.py):
  1) две строки истории с одним ID и разными нативными авторами (сотрудник
     и бот) + одна отдельная достоверная строка сотрудника: 0.1.2 давала
     VERIFIED при сотруднике первым (manager=2) и UNKNOWN при боте первым
     (manager=1) — вердикт зависел от порядка строк;
  2) CREATED_BY_ID=0 считался касанием менеджера: 0.1.2 давала VERIFIED
     при единственном доказанном касании (manager=2 за счёт нулевого автора).
Инварианты 0.1.3: спорная запись (повторный ID с конфликтом значимых полей —
авторство/бот-признак, дата, принадлежность) исключается из подтверждённых
касаний ЦЕЛИКОМ с фиксацией причины/неполноты; результат НЕ зависит от
порядка строк; точный повтор считается один раз; CREATED_BY_ID=0/отрицательный
касание менеджера не доказывает, ответственный (ASSIGNED_BY_ID) автора не
заменяет; VERIFIED на неполном основании невозможен; распознавание
доказанного бота и прежние D1/D2/R1–R5 сохранены (перезапускаются общим
прогоном с tests/test_pointread.py и tests/test_regressions_012.py).
"""
from __future__ import annotations

import json
import os

from pointread.policy import load_allowlist
from pointread.transport_offline import FixtureTransport
from pointread.verify import run
from pointread.verdicts import classify_deal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG = os.path.join(ROOT, "pointread", "allowlist.json")
FIXTURES = os.path.join(ROOT, "fixtures")

NO_REL = {"verified": [], "unverified": [], "failed": []}

# конфликтная пара: один ID=301, автор-сотрудник против автора-бота
EMP_DUP = {"ID": 301, "ENTITY_ID": 900000001, "STAGE_ID": "NEW",
           "CREATED_BY_ID": 501, "CREATED_DATE": "2026-10-06T10:00:00+03:00"}
BOT_DUP = {"ID": 301, "ENTITY_ID": 900000001, "PROVIDER_TYPE_ID": "TASKS_TASK",
           "CREATED_BY_ID": 7001, "CREATED_DATE": "2026-10-06T10:00:00+03:00"}
# отдельная достоверная строка сотрудника (не участвует в конфликте)
EMP_OK = {"ID": 302, "ENTITY_ID": 900000001, "STAGE_ID": "NEW",
          "CREATED_BY_ID": 501, "CREATED_DATE": "2026-10-07T10:00:00+03:00"}
EMP_OK2 = {"ID": 303, "ENTITY_ID": 900000001, "STAGE_ID": "NEW",
           "CREATED_BY_ID": 501, "CREATED_DATE": "2026-10-08T10:00:00+03:00"}


def _al():
    return load_allowlist(CONFIG)


def _deal_a():
    with open(os.path.join(FIXTURES, "deals.json"), encoding="utf-8") as fh:
        return json.load(fh)["900000001"]


class StageOverride:
    """Фикстурный транспорт с подменой истории сделки A."""

    def __init__(self, items):
        self.base = FixtureTransport(FIXTURES)
        self.items = items

    def call(self, method, params):
        if method == "crm.stagehistory.list":
            start = int(params.get("start", 0))
            page = self.items[start:start + 50]
            out = {"result": {"items": page}, "total": len(self.items)}
            if start + 50 < len(self.items):
                out["next"] = start + 50
            return out
        return self.base.call(method, params)


# ============================ дефект 1: конфликтный дубль ID (обе порядка)
def test_r4c_conflicting_duplicate_employee_first_not_verified():
    """Дефект 1-негатив (сотрудник первым): в 0.1.2 — ложный VERIFIED
    (manager=2). В 0.1.3 спорный ID=301 исключён → manager=1 → UNKNOWN,
    конфликт зафиксирован причиной и счётчиками."""
    res = classify_deal(dict(_deal_a()), [EMP_DUP, BOT_DUP, EMP_OK],
                        _al().policy, NO_REL)
    assert res.verdict == "UNKNOWN", "конфликтный дубль ≠ VERIFIED"
    assert res.touchpoints["manager"] == 1          # только достоверный 302
    assert res.touchpoints["bot"] == 0              # спорная запись не бот-касание
    assert res.touchpoints["disputed_duplicate_ids"] == 1
    assert res.touchpoints["disputed_duplicate_rows"] == 2
    assert res.touchpoints["duplicates_ignored"] == 0
    assert any("спорны" in x and "не зависит от порядка" in x
               for x in res.reasons)


def test_r4c_conflicting_duplicate_bot_first_identical_result():
    """Дефект 1-негатив (бот первым): результат ПОБАЙТОВО тот же, что при
    сотруднике первым — независимость от порядка строк (в 0.1.2 здесь был
    UNKNOWN с manager=1/bot=1, т.е. другой вердикт-происхождение)."""
    pol = _al().policy
    order_a = classify_deal(dict(_deal_a()), [EMP_DUP, BOT_DUP, EMP_OK],
                            pol, NO_REL)
    order_b = classify_deal(dict(_deal_a()), [BOT_DUP, EMP_DUP, EMP_OK],
                            pol, NO_REL)
    assert order_b.verdict == "UNKNOWN"
    assert order_b.touchpoints == order_a.touchpoints
    assert order_b.reasons == order_a.reasons
    assert order_b.notes == order_a.notes


def test_r4c_conflicting_duplicate_excluded_from_bot_counter_too():
    """Дефект 1-доп: спорная запись не достаётся ни менеджеру, ни боту —
    даже если одна из строк дубля выглядит доказанным ботом."""
    res = classify_deal(dict(_deal_a()), [BOT_DUP, EMP_DUP],
                        _al().policy, NO_REL)
    assert res.touchpoints["manager"] == 0
    assert res.touchpoints["bot"] == 0              # бот-строка спорного ID не в счёт
    assert res.touchpoints["disputed_duplicate_ids"] == 1
    assert res.verdict == "UNKNOWN"


def test_r4c_conflict_fields_date_and_ownership():
    """Дефект 1-доп: конфликт значимых полей — не только автор: расходящиеся
    дата и принадлежность (ENTITY_ID) тоже делают запись спорной."""
    pol = _al().policy
    # тот же автор, разная дата
    date_conflict = [EMP_DUP,
                     dict(EMP_DUP, CREATED_DATE="2026-10-09T10:00:00+03:00")]
    res = classify_deal(dict(_deal_a()), date_conflict, pol, NO_REL)
    assert res.touchpoints["disputed_duplicate_ids"] == 1
    assert res.touchpoints["manager"] == 0
    # тот же автор и дата, другая принадлежность
    own_conflict = [EMP_DUP, dict(EMP_DUP, ENTITY_ID=900000002)]
    res2 = classify_deal(dict(_deal_a()), own_conflict, pol, NO_REL)
    assert res2.touchpoints["disputed_duplicate_ids"] == 1
    assert res2.touchpoints["manager"] == 0
    # у обеих дат нет доказательства → одинаковая недоказанность, НЕ конфликт
    undated_pair = [{k: v for k, v in EMP_DUP.items() if k != "CREATED_DATE"},
                    dict(EMP_DUP, CREATED_DATE="garbage")]
    res3 = classify_deal(dict(_deal_a()), undated_pair, pol, NO_REL)
    assert res3.touchpoints["disputed_duplicate_ids"] == 0
    assert res3.touchpoints["undated_unproven"] == 1   # точный повтор: один раз


# ================= дефект 1 (run-уровень): спорный дубль никогда не VERIFIED
def test_r4c_run_level_conflict_duplicate_partial_both_orders():
    """Дефект 1 run-уровень: доказанных касаний достаточно (2), но спорный
    дубль в истории → PARTIAL с причиной (VERIFIED на неполном основании
    исключён); оба порядка строк дают идентичный результат."""
    al = _al()
    hist_a = [EMP_DUP, BOT_DUP, EMP_OK, EMP_OK2]
    hist_b = [EMP_OK2, BOT_DUP, EMP_DUP, EMP_OK]
    ra = run(al, StageOverride(hist_a), ["deal:900000001"])
    rb = run(al, StageOverride(hist_b), ["deal:900000001"])
    for report in (ra, rb):
        r = report["results"][0]
        assert r["verdict"] == "PARTIAL", "спорный дубль блокирует VERIFIED"
        assert r["touchpoints"]["manager"] == 2
        assert r["touchpoints"]["disputed_duplicate_ids"] == 1
        assert any("спорны" in x for x in r["reasons"])
        assert report["aborted"] is None
        assert report["fix_task"] == "WORK-POINTREAD-014-OFFLINE"
    assert ra["results"][0]["touchpoints"] == rb["results"][0]["touchpoints"]
    assert ra["results"][0]["reasons"] == rb["results"][0]["reasons"]


# ================================== точный повтор: считается один раз
def test_r4c_exact_duplicate_counted_once_no_dispute():
    """Точный повтор (значимые поля совпадают; расхождение только в
    описательных полях типа STAGE_ID) — один раз, конфликтом НЕ является,
    VERIFIED чистой истории не блокирует."""
    pol = _al().policy
    exact = [EMP_DUP, dict(EMP_DUP),
             dict(EMP_DUP, STAGE_ID="PREPARATION"),      # не значимое поле
             EMP_OK]
    res = classify_deal(dict(_deal_a()), exact, pol, NO_REL)
    assert res.touchpoints["manager"] == 2
    assert res.touchpoints["duplicates_ignored"] == 2
    assert res.touchpoints["disputed_duplicate_ids"] == 0
    assert res.verdict == "VERIFIED"                 # точный повтор не портит данные
    assert any("учтены один раз" in n for n in res.notes)
    # run-уровень: то же самое через полный прогон
    report = run(_al(), StageOverride(exact), ["deal:900000001"])
    assert report["results"][0]["verdict"] == "VERIFIED"
    assert report["results"][0]["touchpoints"]["manager"] == 2


# ============================== дефект 2: CREATED_BY_ID=0 и прочие ≤0
def test_r4c_zero_author_is_not_a_manager_touch():
    """Дефект 2-негатив: CREATED_BY_ID=0 не доказывает касание менеджера
    (в 0.1.2 — manager=3 → ложный VERIFIED); неполнота отражена причиной,
    вердикт PARTIAL (не VERIFIED); ответственный автора не заменяет."""
    zero = {"ID": 311, "ENTITY_ID": 900000001, "STAGE_ID": "NEW",
            "CREATED_BY_ID": 0, "CREATED_DATE": "2026-10-06T10:00:00+03:00"}
    zero_assigned = {"ID": 312, "ENTITY_ID": 900000001,
                     "CREATED_BY_ID": 0, "ASSIGNED_BY_ID": 501,
                     "CREATED_DATE": "2026-10-09T10:00:00+03:00"}
    negative = {"ID": 313, "ENTITY_ID": 900000001,
                "CREATED_BY_ID": -7,
                "CREATED_DATE": "2026-10-10T10:00:00+03:00"}
    res = classify_deal(dict(_deal_a()),
                        [zero, zero_assigned, negative, EMP_OK, EMP_OK2],
                        _al().policy, NO_REL)
    assert res.touchpoints["manager"] == 2          # только доказанные 501
    assert res.touchpoints["invalid_native_author"] == 3
    assert res.touchpoints["no_native_author"] == 0
    assert res.verdict == "PARTIAL"                 # не VERIFIED: неполнота
    assert any("недопустимым нативным автором" in x for x in res.reasons)
    # только недопустимые авторы → касаний 0 → UNKNOWN (в 0.1.2 — VERIFIED)
    res2 = classify_deal(dict(_deal_a()), [zero, dict(negative, ID=314)],
                         _al().policy, NO_REL)
    assert res2.touchpoints["manager"] == 0
    assert res2.verdict == "UNKNOWN"


def test_r4c_run_level_zero_author_never_verified():
    """Дефект 2 run-уровень: нулевой автор в истории → VERIFIED невозможен
    (PARTIAL при достаточных доказанных касаниях), причина в отчёте."""
    al = _al()
    zero = {"ID": 311, "ENTITY_ID": 900000001, "STAGE_ID": "NEW",
            "CREATED_BY_ID": 0, "CREATED_DATE": "2026-10-06T10:00:00+03:00"}
    report = run(al, StageOverride([zero, EMP_OK, EMP_OK2]), ["deal:900000001"])
    r = report["results"][0]
    assert r["verdict"] == "PARTIAL"
    assert r["touchpoints"]["manager"] == 2
    assert r["touchpoints"]["invalid_native_author"] == 1
    assert any("недопустимым нативным автором" in x for x in r["reasons"])
    assert report["aborted"] is None


def test_r4c_proven_bot_with_zero_author_still_recognized():
    """Сохранившееся поведение: доказанный бот (провайдер TASKS_TASK/
    CRM_WEBDAV_TASK) распознаётся и при недопустимом авторе — не касание
    менеджера, не «недопустимый автор», а именно бот."""
    bot_zero_author = {"ID": 321, "ENTITY_ID": 900000001,
                       "PROVIDER_TYPE_ID": "CRM_WEBDAV_TASK",
                       "CREATED_BY_ID": 0,
                       "CREATED_DATE": "2026-10-06T10:00:00+03:00"}
    res = classify_deal(dict(_deal_a()), [bot_zero_author, EMP_OK, EMP_OK2],
                        _al().policy, NO_REL)
    assert res.touchpoints["bot"] == 1
    assert res.touchpoints["manager"] == 2
    assert res.touchpoints["invalid_native_author"] == 0
    assert res.verdict == "VERIFIED"                # бот распознан — данных достаточно
    assert any("бот ≠ менеджер" in n for n in res.notes)


# ==================================================== позитивный контроль
def test_r4c_positive_control_clean_history_all_new_counters_zero():
    """Позитивный контроль: чистая фикстурная история → VERIFIED, manager=3,
    bot=2; все новые счётчики 0.1.3 нулевые (споров/недопустимых авторов нет)."""
    with open(os.path.join(FIXTURES, "stagehistory.json"), encoding="utf-8") as fh:
        hist = json.load(fh)["900000001"]
    res = classify_deal(dict(_deal_a()), hist, _al().policy, NO_REL)
    assert res.verdict == "VERIFIED"
    tp = res.touchpoints
    assert tp["manager"] == 3 and tp["bot"] == 2
    assert tp["outside_window_ignored"] == 1
    assert tp["duplicates_ignored"] == 0
    assert tp["disputed_duplicate_ids"] == 0
    assert tp["disputed_duplicate_rows"] == 0
    assert tp["invalid_native_author"] == 0
