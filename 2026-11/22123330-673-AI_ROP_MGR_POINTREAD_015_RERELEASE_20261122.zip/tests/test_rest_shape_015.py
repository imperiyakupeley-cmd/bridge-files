"""Independent synthetic REST-shape regression; no CRM, no personal data."""
import unittest
from pointread.gate import _assert_stagehistory_owned, _canonical_id
from pointread.errors import UnexpectedId
from pointread.verdicts import _sig, classify_deal
from pointread.policy import load_allowlist

POL=load_allowlist('pointread/allowlist.json').policy
W={'entityId':900000001}

class RestShape(unittest.TestCase):
    def test_owner_only(self):
        r={'result':{'items':[{'OWNER_ID':'900000001','CREATED_TIME':'2026-11-02T12:00:00+03:00'}]}}
        _assert_stagehistory_owned(r,W)
        self.assertEqual(r['result']['items'][0]['ENTITY_ID'],900000001)
    def test_entity_only(self):
        _assert_stagehistory_owned({'result':{'items':[{'ENTITY_ID':900000001}]}},W)
    def test_both_matching(self):
        _assert_stagehistory_owned({'result':{'items':[{'OWNER_ID':'900000001','ENTITY_ID':900000001}]}},W)
    def test_foreign_owner(self):
        with self.assertRaises(UnexpectedId):
            _assert_stagehistory_owned({'result':{'items':[{'OWNER_ID':'900000002'}]}},W)
    def test_conflicting_ids(self):
        with self.assertRaises(UnexpectedId):
            _assert_stagehistory_owned({'result':{'items':[{'OWNER_ID':'900000001','ENTITY_ID':'900000002'}]}},W)
    def test_missing_ids(self):
        with self.assertRaises(UnexpectedId):
            _assert_stagehistory_owned({'result':{'items':[{'ID':'701'}]}},W)
    def test_invalid_owner_types(self):
        for bad in (True,0,-1,900000001.0,'0900000001','900000001 ','abc',None):
            with self.subTest(bad=bad), self.assertRaises(UnexpectedId):
                _assert_stagehistory_owned({'result':{'items':[{'OWNER_ID':bad}]}},W)
    def test_created_time(self):
        self.assertNotEqual(_sig({'CREATED_TIME':'2026-11-02T12:00:00+03:00'},POL)[2],'UNPROVEN')
    def test_bad_created_time(self):
        self.assertEqual(_sig({'CREATED_TIME':'not-a-date'},POL)[2],'UNPROVEN')
    def test_author_not_fabricated(self):
        self.assertIsNone(_sig({'ASSIGNED_BY_ID':501,'CREATED_TIME':'2026-11-02T12:00:00+03:00'},POL)[0])
    def test_contact_canonical(self):
        self.assertEqual(_canonical_id('910000001'),910000001)
        for bad in ('0910000001','9e8',' 910000001',False,910000001.0,0):
            self.assertIsNone(_canonical_id(bad))
    def test_foreign_related_identity(self):
        from pointread.gate import Gate
        from pointread.budget import ReadBudget
        from pointread.scope import RunScope
        al=load_allowlist('pointread/allowlist.json')
        class T:
            def call(self,method,params):return {'result':{'ID':'910000002'}}
        gate=Gate(al,ReadBudget(50),RunScope(al.path),T())
        with self.assertRaises(UnexpectedId):
            gate.call('crm.contact.get',{'ID':910000001},owner_deal=900000001)
    def test_no_author_no_false_verified(self):
        result=classify_deal({'ID':900000001},[{'ID':1,'ENTITY_ID':900000001,'CREATED_TIME':'2026-11-02T12:00:00+03:00'}],POL,{'verified':[],'unverified':[],'failed':[]})
        self.assertNotEqual(result.verdict,'VERIFIED')

if __name__=='__main__': unittest.main()
