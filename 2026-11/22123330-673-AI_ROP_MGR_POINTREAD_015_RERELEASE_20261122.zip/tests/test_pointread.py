"""Offline QA-батарея pointread (только синтетика, ноль сети).

Обязательные сценарии задачи DEV-POINTREAD-STAGE-20261115-01 (пп. 4):
  1 unauthorized ID; 2 bulk list; 3 unverified owner filter; 4 out-of-period;
  5 bot vs manager; 6 Avito unknown mapping; 7 excess API budget;
  8 PII in logs; 9 short/unreached UNKNOWN; 10 mid-run change of scope.
Дополнительно: 429-fail-closed, unexpected ID, phone-параметр, online-заглушка,
потолки allowlist, границы периода, smoke CLI.
Фикс-задача DEV-POINTREAD-FIX-QA-20261115-02 (аудит admin2):
  D1 test_21 — чужая/без-ENTITY_ID/неподтверждаемая stagehistory-запись;
  D2 test_22 — отсутствующая/нечитаемая DATE_CREATE → UNKNOWN, не VERIFIED;
  D3 test_23 — запрос >max_deals сделок → CONFIG_INVALID (не BAD_TYPED_ID).
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest.mock as mock

import pytest

from pointread import policy as P
from pointread import whitelist as W
from pointread.budget import ReadBudget
from pointread.errors import (BadTypedId, BudgetExceeded, ConfigError,
                              NotTestable, OnlineBlocked, NoCredentialsWired,
                              RateLimitedFailClosed, Refused, ScopeChanged,
                              UnexpectedId)
from pointread.gate import Gate
from pointread.ids import parse_typed_id
from pointread.policy import load_allowlist
from pointread.redact import mask_text, redact
from pointread.scope import RunScope
from pointread.timeutil import parse_dt
from pointread.transport_offline import FixtureTransport
from pointread.verify import run

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG = os.path.join(ROOT, "pointread", "allowlist.json")
FIXTURES = os.path.join(ROOT, "fixtures")


def make_gate(config=CONFIG, fixtures=FIXTURES, script=None):
    al = load_allowlist(config)
    budget = ReadBudget(al.policy.max_total_reads)
    gate = Gate(al, budget, RunScope(config), FixtureTransport(fixtures, script))
    return al, budget, gate


# ---------------------------------------------------------------- ids / redact
def test_ids_strict():
    assert parse_typed_id("deal:900000001") == ("deal", 900000001)
    assert parse_typed_id("contact:910000001") == ("contact", 910000001)
    for bad in ("deal:0", "deal:", "900000001", "deal:+7", "deal:abc",
                "deal:900000001 ", "phone:123", "deal:0123", ""):
        with pytest.raises(BadTypedId):
            parse_typed_id(bad)


def test_redact_masks():
    s = "клиент +7 900 000-00-01 почта client900000001@example.invalid"
    m = mask_text(s)
    assert "+7 900 000-00-01" not in m
    assert "client900000001@example.invalid" not in m
    obj = redact({"NAME": "Иван", "TITLE": "x", "ID": 5, "STAGE_ID": "NEW",
                  "PHONE": "+7 900 000-00-01"})
    assert obj["NAME"] == "[REDACTED:NAME]" and obj["TITLE"] == "[REDACTED:TITLE]"
    assert obj["ID"] == 5 and obj["STAGE_ID"] == "NEW"


# ------------------------------------------------------- обязательный сценарий 1
def test_1_unauthorized_id_refused():
    al, budget, gate = make_gate()
    report = run(al, gate.transport, ["deal:888888888"])
    r = report["results"][0]
    assert r["verdict"] == "REFUSED"
    assert report["api_reads"] == 0 and report["budget"]["used"] == 0


# ------------------------------------------------------- обязательный сценарий 2
def test_2_bulk_list_blocked():
    al, budget, gate = make_gate()
    with pytest.raises(Refused) as e:
        gate.call("crm.deal.list", {"start": 0})
    assert e.value.code == "METHOD_FORBIDDEN"
    assert gate.calls == []  # ни одного чтения
    with pytest.raises(Refused) as e2:
        gate.call("crm.contact.list", {})
    assert e2.value.code == "METHOD_FORBIDDEN"


# ------------------------------------------------------- обязательный сценарий 3
def test_3_unverified_owner_filter_not_testable():
    al, budget, gate = make_gate()
    with pytest.raises(NotTestable) as e:
        gate.call("crm.activity.list", {"filter": {"OWNER_ID": 900000001}})
    assert e.value.code == "NOT_TESTABLE"
    assert "OWNER" in str(e.value) and "доказательств" in str(e.value)
    assert gate.calls == []


def test_3b_unverified_related_not_chased():
    al, budget, gate = make_gate()
    # сделка B: CONTACT_ID=910000999 НЕ в related allowlist → crm.contact.get
    # по нему должен быть отказан
    with pytest.raises(Refused) as e:
        gate.call("crm.contact.get", {"ID": 910000999}, owner_deal=900000002)
    assert e.value.code == "RELATED_NOT_PROVEN"
    # а подтверждённый related для сделки A — разрешён
    resp = gate.call("crm.contact.get", {"ID": 910000001}, owner_deal=900000001)
    assert resp["result"]["ID"] == 910000001


# ------------------------------------------------------- обязательный сценарий 4
def test_4_out_of_period():
    al, budget, gate = make_gate()
    report = run(al, gate.transport, ["deal:900000003"])
    r = report["results"][0]
    assert r["verdict"] == "OUT_OF_PERIOD"
    assert report["api_reads"] == 1  # карточка и стоп: детализации не было


def test_4b_period_boundaries():
    pol = load_allowlist(CONFIG).policy
    assert P.in_period(pol, parse_dt("2026-10-01T00:00:00+03:00"))
    assert P.in_period(pol, parse_dt("2026-11-14T23:59:59+03:00"))
    assert not P.in_period(pol, parse_dt("2026-09-30T23:59:59+03:00"))
    assert not P.in_period(pol, parse_dt("2026-11-15T00:00:00+03:00"))


# ------------------------------------------------------- обязательный сценарий 5
def test_5_bot_vs_manager():
    al, budget, gate = make_gate()
    report = run(al, gate.transport, ["deal:900000001"])
    r = report["results"][0]
    assert r["verdict"] == "VERIFIED"
    tp = r["touchpoints"]
    assert tp["manager"] == 3          # 501 в окне (item #6 вне окна игнорируется)
    assert tp["bot"] == 2              # 7001 (TASKS_TASK) и 7002 (CRM_WEBDAV_TASK)
    assert tp["outside_window_ignored"] == 1
    assert any("бот" in n for n in r["notes"])
    # штрафов менеджерам не существует в схеме
    flat = json.dumps(r, ensure_ascii=False)
    for word in ("penalty", "fault", "винов", "штраф"):
        assert word not in flat.lower().replace("no_manager_penalty", "")


# ------------------------------------------------------- обязательный сценарий 6
def test_6_avito_unknown_mapping():
    al, budget, gate = make_gate()
    calls_before = 0
    report = run(al, gate.transport, ["deal:900000002"])
    r = report["results"][0]
    assert r["channel"] is None
    assert r["verdict"] == "UNKNOWN"
    assert any("канал не отображён" in x for x in r["reasons"])
    # никаких догадок/доп. чтений для разрешения канала
    assert report["api_reads"] == 2  # deal.get + 1 страница stagehistory
    assert calls_before == 0


# ------------------------------------------------------- обязательный сценарий 7
def test_7_budget_exceeded_fail_closed():
    # сужаем бюджет конфигом до 4 чтений (потолок 50 не трогаем) и скармливаем
    # транспорт с бесконечной пагинацией → стоп ровно на лимите
    with tempfile.TemporaryDirectory() as td:
        cfg = os.path.join(td, "allowlist.json")
        base = json.load(open(CONFIG, encoding="utf-8"))
        base["policy"]["max_total_reads"] = 4
        with open(cfg, "w", encoding="utf-8") as fh:
            json.dump(base, fh, ensure_ascii=False)
        al = load_allowlist(cfg)

        class EndlessPages:
            n = 0

            def call(self, method, params):
                self.n += 1
                if method == "crm.deal.get":
                    # корректная карточка: с D2 карточка без DATE_CREATE
                    # даёт ранний UNKNOWN без детализации (и бюджет бы не
                    # исчерпался) — цель теста: бесконечная пагинация vs бюджет
                    return {"result": {"ID": params.get("ID"),
                                       "DATE_CREATE": "2026-10-05T11:20:00+03:00",
                                       "SOURCE_ID": "SRC_SITE"}}
                # ENTITY_ID обязателен: гейт (D1) проверяет принадлежность
                # каждой записи запрошенной сделке — иначе UNEXPECTED_ID
                return {"result": {"items": [{"ID": self.n,
                                              "ENTITY_ID": params.get("entityId"),
                                              "CREATED_BY_ID": 501,
                                              "CREATED_DATE":
                                              "2026-10-05T10:00:00+03:00"}]},
                        "total": 10 ** 6, "next": (params.get("start", 0)) + 50}

        report = run(al, EndlessPages(), ["deal:900000001"])
        assert report["aborted"]["code"] == "BUDGET_EXCEEDED"
        assert report["budget"]["used"] == 4       # ровно лимит, ни чтением больше
        assert report["results"][-1]["verdict"] == "ABORTED"


# ------------------------------------------------------- обязательный сценарий 8
def test_8_no_pii_in_output():
    al, budget, gate = make_gate()
    report = run(al, gate.transport, ["deal:900000001"])
    text = json.dumps(report, ensure_ascii=False)
    for raw in ("+7 900 000-00-01", "client900000001@example.invalid",
                "Синтетиков", "Синтетов", "Синтетик"):
        assert raw not in text, f"PII-утечка: {raw}"
    assert "[REDACTED:" in text or "PHONE_REDACTED" in text


# ------------------------------------------------------- обязательный сценарий 9
def test_9_short_unreached_unknown():
    al, budget, gate = make_gate()
    # сделка B: канал неизвестен И 1 касание — UNKNOWN, не «провал менеджера»
    report = run(al, gate.transport, ["deal:900000002"])
    r = report["results"][0]
    assert r["verdict"] == "UNKNOWN"
    assert r["touchpoints"]["manager"] == 1
    assert any("недостаточно" in x or "короткая" in x for x in r["reasons"])
    # чистый случай короткой истории (канал отображён): подменим SOURCE_ID
    tr = FixtureTransport(FIXTURES)
    tr._deals["900000002"] = dict(tr._deals["900000002"], SOURCE_ID="SRC_MANUAL")
    report2 = run(al, tr, ["deal:900000002"])
    assert report2["results"][0]["verdict"] == "UNKNOWN"
    assert any("короткая" in x or "недостаточно" in x
               for x in report2["results"][0]["reasons"])


# ------------------------------------------------------- обязательный сценарий 10
def test_10_midrun_scope_change():
    with tempfile.TemporaryDirectory() as td:
        cfg = os.path.join(td, "allowlist.json")
        with open(CONFIG, "rb") as fh:
            data = fh.read()
        with open(cfg, "wb") as fh:
            fh.write(data)
        al = load_allowlist(cfg)
        tr = FixtureTransport(FIXTURES)
        budget = ReadBudget(al.policy.max_total_reads)
        scope = RunScope(cfg)
        gate = Gate(al, budget, scope, tr)
        # первая сделка проходит
        resp = gate.call("crm.deal.get", {"ID": 900000001})
        assert resp["result"]["ID"] == 900000001
        # «конфиг изменили посреди прогона»
        mutated = json.loads(data)
        mutated["deals"].append({"typed_id": "deal:900000099",
                                 "provenance": "mid-run injection", "related": []})
        with open(cfg, "wb") as fh:
            fh.write(json.dumps(mutated, ensure_ascii=False).encode())
        with pytest.raises(ScopeChanged):
            gate.call("crm.stagehistory.list",
                      {"entityTypeId": 2, "entityId": 900000001, "start": 0})


# ------------------------------------------------------------------ доп. fail-closed
def test_11_http429_fail_closed_no_retries():
    # событие №1 — standalone-вызов гейта, №2 — первый вызов внутри run()
    al, budget, gate = make_gate(script=[
        {"at_call": 1, "type": "http429"}, {"at_call": 2, "type": "http429"}])
    with pytest.raises(RateLimitedFailClosed):
        gate.call("crm.deal.get", {"ID": 900000001})
    assert len(gate.calls) == 1      # 429 тарифицирован, ретраев НЕТ
    report = run(al, gate.transport, ["deal:900000001"])
    assert report["aborted"]["code"] == "RATE_LIMITED_FAIL_CLOSED"


def test_12_unexpected_id_fail_closed():
    al, budget, gate = make_gate(script=[{"at_call": 1, "type": "unexpected_id"}])
    with pytest.raises(UnexpectedId):
        gate.call("crm.deal.get", {"ID": 900000001})


def test_13_phone_params_refused():
    al, budget, gate = make_gate()
    with pytest.raises(Refused) as e1:
        gate.call("crm.deal.get", {"ID": 900000001, "PHONE": "+7 900 000-00-01"})
    assert e1.value.code == "PII_PARAM"
    with pytest.raises(Refused) as e2:
        gate.call("crm.deal.get", {"ID": 900000001, "TITLE": "x"})
    assert e2.value.code == "PII_PARAM"
    with pytest.raises(Refused) as e3:
        gate.call("crm.duplicate.findbycomm",
                  {"TYPE": "PHONE", "VALUES[]": "79000000001"})
    assert e3.value.code == "METHOD_FORBIDDEN"
    with pytest.raises(Refused) as e4:
        gate.call("crm.deal.get", {"ID": "9000000111111111111"})
    assert e4.value.code == "PARAM_SHAPE" or e4.value.code == "PARAM_NOT_ALLOWED"


def test_14_online_stub_blocked_always():
    from pointread.transport_online import OnlineTransport
    with pytest.raises(OnlineBlocked):
        OnlineTransport(online_enabled=False, allow_online_flag=False)
    with pytest.raises(OnlineBlocked):
        OnlineTransport(online_enabled=True, allow_online_flag=False)
    with mock.patch.dict(os.environ, {"POINTREAD_ONLINE_UNLOCK": "I-REQUEST-LIVE-GO"}):
        with pytest.raises((OnlineBlocked, NoCredentialsWired)):
            OnlineTransport(online_enabled=True, allow_online_flag=True)
    # в модуле нет сетевых импортов
    import pointread.transport_online as T
    src = open(T.__file__, encoding="utf-8").read()
    for lib in ("socket", "urllib", "requests", "http.client"):
        assert f"import {lib}" not in src


def test_15_allowlist_caps_and_shape():
    with tempfile.TemporaryDirectory() as td:
        cfg = os.path.join(td, "a.json")
        base = json.load(open(CONFIG, encoding="utf-8"))
        # 4 сделки > max_deals=3 → CONFIG_INVALID
        bad = json.loads(json.dumps(base))
        bad["deals"].append({"typed_id": "deal:900000099", "provenance": "x",
                             "related": []})
        json.dump(bad, open(cfg, "w", encoding="utf-8"))
        with pytest.raises(ConfigError):
            load_allowlist(cfg)
        # max_total_reads нельзя поднять выше 50
        bad2 = json.loads(json.dumps(base))
        bad2["policy"]["max_total_reads"] = 500
        json.dump(bad2, open(cfg, "w", encoding="utf-8"))
        with pytest.raises(ConfigError):
            load_allowlist(cfg)
        # сделка без provenance → отказ
        bad3 = json.loads(json.dumps(base))
        del bad3["deals"][0]["provenance"]
        json.dump(bad3, open(cfg, "w", encoding="utf-8"))
        with pytest.raises(ConfigError):
            load_allowlist(cfg)
        # related без provenance → отказ
        bad4 = json.loads(json.dumps(base))
        bad4["deals"][0]["related"] = [{"typed_id": "contact:910000099"}]
        json.dump(bad4, open(cfg, "w", encoding="utf-8"))
        with pytest.raises(ConfigError):
            load_allowlist(cfg)


def test_16_full_run_shape_and_budget():
    al, budget, gate = make_gate()
    report = run(al, gate.transport)  # все 3 allowlisted
    verdicts = {r["deal"]: r["verdict"] for r in report["results"]}
    assert verdicts == {"deal:900000001": "VERIFIED",
                        "deal:900000002": "UNKNOWN",
                        "deal:900000003": "OUT_OF_PERIOD"}
    assert report["aborted"] is None
    assert report["budget"]["used"] <= 50
    assert 0 < report["api_reads"] <= 8
    assert report["mode"] == "offline-synthetic"
    assert report["no_manager_penalties"] is True


def test_17_stagehistory_strict_params():
    al, budget, gate = make_gate()
    ok = gate.call("crm.stagehistory.list",
                   {"entityTypeId": 2, "entityId": 900000001, "start": 0})
    assert ok["result"]["items"]
    with pytest.raises(Refused):  # без entity-фильтра
        gate.call("crm.stagehistory.list", {"start": 0})
    with pytest.raises(Refused):  # UPPER-форма ок, но чужой ENTITY_ID
        gate.call("crm.stagehistory.list",
                  {"ENTITY_TYPE": "deal", "ENTITY_ID": 888888888})
    with pytest.raises(Refused):  # не- deal тип
        gate.call("crm.stagehistory.list",
                  {"entityTypeId": 3, "entityId": 900000001})
    with pytest.raises(Refused):  # order не ASC
        gate.call("crm.stagehistory.list",
                  {"entityTypeId": 2, "entityId": 900000001, "order[ID]": "DESC"})


def test_18_mutator_never():
    al, budget, gate = make_gate()
    for m in ("crm.deal.update", "crm.deal.delete", "crm.deal.add",
              "user.consent", "im.message.add"):
        with pytest.raises(Refused) as e:
            gate.call(m, {})
        assert e.value.code == "METHOD_MUTATOR"


def test_20_hex_hashes_not_mangled():
    """Регрессия smoke-прогона: hex-хеш не должен превращаться в маску."""
    from pointread.redact import mask_text, redact
    h = "c779f5741bf99bc81234567890c0c5902ab6165a9b4fce959ec85cdd0f130ca7"
    assert mask_text(h) == h
    out = redact({"config_sha256": h,
                  "nested": {"pinned_sha256": {"/tmp/x": h}},
                  "txt": h + " обычный текст +7 900 000-00-03"})
    assert out["config_sha256"] == h
    assert out["nested"]["pinned_sha256"]["/tmp/x"] == h
    assert out["txt"].startswith(h)
    assert "+7 900 000-00-03" not in out["txt"]


# ------------------------------------------- D1 аудита: чужая stagehistory-запись
def test_21_foreign_stagehistory_record_fail_closed():
    """D1: чужая запись в ответе stagehistory.list (или запись без ENTITY_ID,
    либо формат, где принадлежность подтвердить нельзя) → UNEXPECTED_ID
    fail-closed — чужая история не усваивается ни при каких условиях."""
    al, _, _ = make_gate()
    base = FixtureTransport(FIXTURES)
    foreign = dict(base._stagehistory["900000002"][0])   # запись сделки B

    class ForeignMix:
        def call(self, method, params):
            resp = base.call(method, params)
            if method == "crm.stagehistory.list":
                resp["result"]["items"] = list(resp["result"]["items"]) + [foreign]
            return resp

    gate = Gate(al, ReadBudget(al.policy.max_total_reads),
                RunScope(CONFIG), ForeignMix())
    with pytest.raises(UnexpectedId):
        gate.call("crm.stagehistory.list",
                  {"entityTypeId": 2, "entityId": 900000001, "start": 0})

    # в полном прогоне — немедленный abort всего рана
    report = run(al, ForeignMix(), ["deal:900000001"])
    assert report["aborted"]["code"] == "UNEXPECTED_ID"
    assert report["results"][0]["verdict"] == "ABORTED"

    # запись без ENTITY_ID: принадлежность не доказана → отказ
    class NoEntityId:
        def call(self, method, params):
            resp = base.call(method, params)
            if method == "crm.stagehistory.list":
                item = dict(resp["result"]["items"][0])
                item.pop("ENTITY_ID", None)
                resp["result"]["items"] = [item]
            return resp

    gate2 = Gate(al, ReadBudget(al.policy.max_total_reads),
                 RunScope(CONFIG), NoEntityId())
    with pytest.raises(UnexpectedId):
        gate2.call("crm.stagehistory.list",
                   {"entityTypeId": 2, "entityId": 900000001, "start": 0})

    # формат без items-списка: подтвердить принадлежность нельзя → fail-closed
    class Unconfirmable:
        def call(self, method, params):
            if method == "crm.stagehistory.list":
                return {"result": {"total": 1}}
            return base.call(method, params)

    gate3 = Gate(al, ReadBudget(al.policy.max_total_reads),
                 RunScope(CONFIG), Unconfirmable())
    with pytest.raises(UnexpectedId):
        gate3.call("crm.stagehistory.list",
                   {"entityTypeId": 2, "entityId": 900000001, "start": 0})


# ---------------------------------- D2 аудита: DATE_CREATE отсутствует/нечитаема
def test_22_date_create_missing_or_invalid_unknown():
    """D2: без доказательства попадания в период вердикт UNKNOWN (не VERIFIED),
    детализация не выполняется, причина и coverage фиксируются."""
    al, _, _ = make_gate()

    # DATE_CREATE отсутствует
    tr = FixtureTransport(FIXTURES)
    tr._deals["900000001"] = {k: v for k, v in tr._deals["900000001"].items()
                              if k != "DATE_CREATE"}
    report = run(al, tr, ["deal:900000001"])
    r = report["results"][0]
    assert r["verdict"] == "UNKNOWN"
    assert any("DATE_CREATE" in x and "не доказано" in x for x in r["reasons"])
    assert r["coverage"]["period_proven"] is False
    assert report["api_reads"] == 1    # только карточка: детализации не было

    # DATE_CREATE нечитаема
    tr2 = FixtureTransport(FIXTURES)
    tr2._deals["900000001"] = dict(tr2._deals["900000001"],
                                   DATE_CREATE="garbage-not-a-date")
    r2 = run(al, tr2, ["deal:900000001"])["results"][0]
    assert r2["verdict"] == "UNKNOWN"
    assert any("нечитаема" in x for x in r2["reasons"])
    assert r2["coverage"]["period_proven"] is False

    # страховочный слой verdicts.classify_deal: даже с достаточными касаниями
    # и известным каналом VERIFIED без DATE_CREATE невозможен
    from pointread.verdicts import classify_deal
    with open(os.path.join(FIXTURES, "deals.json"), encoding="utf-8") as fh:
        deal = json.load(fh)["900000001"]
    with open(os.path.join(FIXTURES, "stagehistory.json"), encoding="utf-8") as fh:
        hist = json.load(fh)["900000001"]
    no_rel = {"verified": [], "unverified": []}
    good = classify_deal(dict(deal, DATE_CREATE="2026-10-05 11:20:00"),
                         hist, al.policy, no_rel)
    assert good.verdict == "VERIFIED"                  # позитивный контроль
    bad = classify_deal({k: v for k, v in deal.items() if k != "DATE_CREATE"},
                        hist, al.policy, no_rel)
    assert bad.verdict == "UNKNOWN"                    # D2: не VERIFIED
    assert any("не доказано" in x for x in bad.reasons)


# --------------------------------------------- D3 аудита: семантика кода отказа
def test_23_over_deal_cap_is_config_invalid():
    """D3: запрос > max_deals сделок — CONFIG_INVALID (ошибка конфигурации
    запроса), не BAD_TYPED_ID (формат ID здесь ни при чём)."""
    al, _, _ = make_gate()
    four = ["deal:900000001", "deal:900000002", "deal:900000003",
            "deal:900000099"]
    with pytest.raises(ConfigError) as e:
        run(al, FixtureTransport(FIXTURES), four)
    assert e.value.code == "CONFIG_INVALID"


# ------------------------------------------------------------------ smoke CLI
def _cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "pointread.cli", *args],
        cwd=ROOT, capture_output=True, text=True, timeout=60)


def test_19_cli_smoke():
    r = _cli("policy")
    assert r.returncode == 0 and "pointread-allowlist" not in r.stderr
    pol = json.loads(r.stdout)
    assert pol["policy"]["max_total_reads"] == 50
    assert pol["policy"]["online_enabled"] is False

    r = _cli("verify", "--deal", "deal:900000001")
    assert r.returncode == 0
    rep = json.loads(r.stdout)
    assert rep["results"][0]["verdict"] == "VERIFIED"
    assert "+7 900 000-00-01" not in r.stdout

    r = _cli("verify", "--deal", "deal:888888888")
    assert r.returncode == 0
    assert json.loads(r.stdout)["results"][0]["verdict"] == "REFUSED"

    r = _cli("call", "crm.deal.list", "--params", '{"start": 0}')
    assert r.returncode == 2 and "REFUSED" in r.stdout

    r = _cli("--transport", "online", "verify")
    assert r.returncode == 2 and "ONLINE_BLOCKED" in r.stdout
