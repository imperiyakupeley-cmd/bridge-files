"""Регрессионная батарея DEV-POINTREAD-012-OFFLINE (v0.1.2, offline-синтетика).

Пять воспроизведённых случаев ложного VERIFIED в 0.1.1 (R1–R5) + позитивные
контроли. Инвариант батареи: некачественные данные (отсутствующий канал,
карточка без ID, недоступный контакт, дубли/без-даты/без-автора, усечённая
пагинация) НИКОГДА не дают VERIFIED — только UNKNOWN / PARTIAL / ABORTED.
D1 (чужой/отсутствующий ENTITY_ID) и D2 (некорректная DATE_CREATE) закрыты
в 0.1.1 и перезапускаются штатной батареей tests/test_pointread.py
(test_21/test_22) в общем прогоне с этой батареей.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys

import pytest

from pointread import policy as P
from pointread.errors import UnexpectedId
from pointread.gate import Gate
from pointread.budget import ReadBudget
from pointread.policy import load_allowlist
from pointread.scope import RunScope
from pointread.transport_offline import FixtureTransport
from pointread.verify import run
from pointread.verdicts import classify_deal

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG = os.path.join(ROOT, "pointread", "allowlist.json")
FIXTURES = os.path.join(ROOT, "fixtures")

NO_REL = {"verified": [], "unverified": [], "failed": []}


def _al():
    return load_allowlist(CONFIG)


def _deal_a():
    with open(os.path.join(FIXTURES, "deals.json"), encoding="utf-8") as fh:
        return json.load(fh)["900000001"]


def _hist_a():
    with open(os.path.join(FIXTURES, "stagehistory.json"), encoding="utf-8") as fh:
        return json.load(fh)["900000001"]


class DealOverride:
    """Фикстурный транспорт с подменой карточки сделки A (R1/R2)."""

    def __init__(self, drop=(), **override):
        self.base = FixtureTransport(FIXTURES)
        self.drop = list(drop)
        self.override = override

    def call(self, method, params):
        if method == "crm.deal.get" and str(params.get("ID")) == "900000001":
            row = {k: v for k, v in self.base._deals["900000001"].items()
                   if k not in self.drop}
            row.update(self.override)
            return {"result": row}
        return self.base.call(method, params)


class ContactOverride:
    """Фикстурный транспорт с подменой ответа crm.contact.get (R3)."""

    def __init__(self, resp):
        self.base = FixtureTransport(FIXTURES)
        self.resp = resp

    def call(self, method, params):
        if method == "crm.contact.get":
            return self.resp
        return self.base.call(method, params)


class StageOverride:
    """Фикстурный транспорт с подменой истории сделки A (R4)."""

    def __init__(self, items):
        self.base = FixtureTransport(FIXTURES)
        self.items = items

    def call(self, method, params):
        if method == "crm.stagehistory.list":
            start = int(params.get("start", 0))
            page = self.items[start:start + 50]
            out = {"result": {"items": page}, "total": len(self.items)}
            if start + 50 < len(self.items):
                out["next"] = start + 50
            return out
        return self.base.call(method, params)


def _static(resp):
    class T:
        def call(self, method, params, _r=resp):
            return _r
    return T()


# ============================================================ R1: SOURCE_ID
def test_r1_source_id_missing_is_unknown_not_verified():
    """R1-негатив: SOURCE_ID отсутствует → причина «канал не подтверждён»
    и UNKNOWN. В 0.1.1 этот случай давал VERIFIED (channel_unknown=False
    при src=None)."""
    al = _al()
    report = run(al, DealOverride(drop=["SOURCE_ID"]), ["deal:900000001"])
    r = report["results"][0]
    assert r["verdict"] == "UNKNOWN", "отсутствующий SOURCE_ID ≠ VERIFIED"
    assert r["channel"] is None
    assert any("канал не подтверждён" in x for x in r["reasons"])
    assert report["aborted"] is None


def test_r1_source_id_empty_or_unrecognized_is_unknown():
    """R1-контроль полноты: пустой и нераспознанный SOURCE_ID — тоже UNKNOWN
    с причиной о неподтверждённом канале."""
    al = _al()
    for bad in ("", "   ", "SRC_WEIRD_42"):
        report = run(al, DealOverride(SOURCE_ID=bad), ["deal:900000001"])
        r = report["results"][0]
        assert r["verdict"] == "UNKNOWN"
        assert any("подтверждён" in x for x in r["reasons"]), bad


def test_r1_positive_control_known_channel_can_be_verified():
    """R1-позитив: отображённый SOURCE_ID (SRC_SITE в маппинге) верификации
    не мешает — прямой слой классификации."""
    al = _al()
    res = classify_deal(dict(_deal_a()), _hist_a(), al.policy, NO_REL)
    assert res.channel == "site"
    assert res.verdict == "VERIFIED"          # чистые данные → VERIFIED возможен


# ============================================== R2: карточка сделки без/с чужим ID
def test_r2_card_without_id_fail_closed_no_deal_none():
    """R2-негатив: карточка crm.deal.get без ID → fail-closed UNEXPECTED_ID,
    прогон ABORTED; «deal:None» и VERIFIED не выпускаются."""
    al = _al()

    class NoId:
        def __init__(self):
            self.base = FixtureTransport(FIXTURES)

        def call(self, method, params):
            resp = self.base.call(method, params)
            if method == "crm.deal.get":
                resp = {"result": {k: v for k, v in resp["result"].items()
                                   if k != "ID"}}
            return resp

    report = run(al, NoId(), ["deal:900000001"])
    assert report["aborted"]["code"] == "UNEXPECTED_ID"
    assert report["results"][0]["verdict"] == "ABORTED"
    # структурно: ни одна метка не «deal:None», ни один вердикт не VERIFIED
    assert all(x["deal"] != "deal:None" for x in report["results"])
    assert all(x["verdict"] != "VERIFIED" for x in report["results"])


def test_r2_gate_rejects_unconfirmable_or_mismatched_cards():
    """R2-негатив (гейт): пустая карточка, результат не-объект, чужой ID —
    всё fail-closed; законный error проходит (verify даст UNKNOWN)."""
    al = _al()
    gate = Gate(al, ReadBudget(al.policy.max_total_reads), RunScope(CONFIG),
                _static({"result": {}}))
    with pytest.raises(UnexpectedId):
        gate.call("crm.deal.get", {"ID": 900000001})     # пустая карточка

    for resp in ({"result": None}, {"result": [1, 2]}, {},
                 {"result": {"ID": 900000099}},          # чужой ID
                 {"result": {"ID": "abc"}}):             # некорректный ID
        g = Gate(al, ReadBudget(al.policy.max_total_reads), RunScope(CONFIG),
                 _static(resp))
        with pytest.raises(UnexpectedId):
            g.call("crm.deal.get", {"ID": 900000001})

    g_ok = Gate(al, ReadBudget(al.policy.max_total_reads), RunScope(CONFIG),
                _static({"error": "NOT_FOUND",
                         "error_description": "crm.deal.get: 900000001"}))
    assert g_ok.call("crm.deal.get", {"ID": 900000001})["error"] == "NOT_FOUND"


def test_r2_not_found_is_graceful_unknown_not_abort():
    """R2-контроль: NOT_FOUND — законный ответ «данных нет» → UNKNOWN
    с причиной (не ABORTED, не VERIFIED, детализации нет)."""
    al = _al()

    class ErrDeal:
        def __init__(self):
            self.base = FixtureTransport(FIXTURES)

        def call(self, method, params):
            if method == "crm.deal.get":
                return {"error": "NOT_FOUND",
                        "error_description": f"crm.deal.get: {params.get('ID')}"}
            return self.base.call(method, params)

    report = run(al, ErrDeal(), ["deal:900000001"])
    r = report["results"][0]
    assert r["verdict"] == "UNKNOWN"
    assert any("NOT_FOUND" in x for x in r["reasons"])
    assert report["aborted"] is None
    assert report["api_reads"] == 1                    # только карточка и стоп


def test_r2_classify_guard_card_without_id_never_verified():
    """R2-страховочный слой: classify_deal с карточкой без ID → UNKNOWN,
    метка «deal:None» не выпускается."""
    al = _al()
    bad = {k: v for k, v in _deal_a().items() if k != "ID"}
    res = classify_deal(bad, _hist_a(), al.policy, NO_REL)
    out = res.to_json()
    assert res.verdict == "UNKNOWN"
    assert out["deal"] != "deal:None"          # метка не «deal:None»
    assert out["verdict"] != "VERIFIED"


# ================================== R3: недоступный подтверждённый контакт
def test_r3_contact_failures_not_in_verified_related_partial():
    """R3-негатив: NOT_FOUND / ошибка / пустой ответ / нетипизированная
    карточка по подтверждённому allowlist-контакту → related.verified пуст,
    причина и неполнота отражены, VERIFIED нет (PARTIAL)."""
    al = _al()
    variants = {
        "not_found": {"error": "NOT_FOUND",
                      "error_description": "crm.contact.get: 910000001"},
        "other_error": {"error": "ACCESS_DENIED"},
        "no_result": {"result": None},
        "empty_card": {"result": {}},
        "untyped_card": {"result": {"NAME": "x", "LAST_NAME": "y"}},
    }
    for name, resp in variants.items():
        report = run(al, ContactOverride(resp), ["deal:900000001"])
        r = report["results"][0]
        assert r["verdict"] != "VERIFIED", name
        assert r["verdict"] == "PARTIAL", name   # остальное доказано → неполно
        assert r["related"]["verified"] == [], name
        assert len(r["related"]["failed"]) == 1, name
        assert any("не подтверждён чтением" in x for x in r["reasons"]), name
        assert report["aborted"] is None, name


def test_r3_positive_control_healthy_contact_verified():
    """R3-позитив: доступная типизированная карточка подтверждённого
    контакта попадает в related.verified и не мешает VERIFIED."""
    al = _al()
    report = run(al, FixtureTransport(FIXTURES), ["deal:900000001"])
    r = report["results"][0]
    assert r["verdict"] == "VERIFIED"
    assert len(r["related"]["verified"]) == 1
    assert r["related"]["verified"][0]["id"] == 910000001
    assert r["related"]["failed"] == []


# ==================== R4: дубли / без даты / без нативного автора
def test_r4_duplicates_do_not_inflate_counter():
    """R4-негатив: повторяющиеся записи с одним ID считаются один раз;
    счётчик не растёт, ложный VERIFIED исключён (здесь — UNKNOWN: касание 1<2)."""
    al = _al()
    base_item = dict(_hist_a()[0])                     # менеджерское касание ID=1
    dup_history = [dict(base_item), dict(base_item), dict(base_item)]
    res = classify_deal(dict(_deal_a()), dup_history, al.policy, NO_REL)
    assert res.touchpoints["manager"] == 1
    assert res.touchpoints["duplicates_ignored"] == 2
    assert res.verdict == "UNKNOWN"
    # run-уровень: 0.1.1 посчитал бы 3 касания и дал VERIFIED
    report = run(al, StageOverride(dup_history), ["deal:900000001"])
    assert report["results"][0]["verdict"] == "UNKNOWN"
    assert report["results"][0]["touchpoints"]["manager"] == 1


def test_r4_undated_entries_are_not_manager_touches():
    """R4-негатив: запись без доказанной даты касанием не считается;
    неполнота отмечена причиной; VERIFIED невозможен."""
    al = _al()
    undated = {"ID": 101, "ENTITY_ID": 900000001, "STAGE_ID": "NEW",
               "CREATED_BY_ID": 501}                    # даты нет вообще
    undated2 = {"ID": 105, "ENTITY_ID": 900000001,
                "CREATED_BY_ID": 501, "CREATED_DATE": "garbage-date"}
    # достаточно доказанных касаний + недатированная запись → PARTIAL, не VERIFIED
    res = classify_deal(dict(_deal_a()), _hist_a() + [undated], al.policy, NO_REL)
    assert res.touchpoints["manager"] == 3
    assert res.touchpoints["undated_unproven"] == 1
    assert res.verdict == "PARTIAL"
    assert any("без доказанной даты" in x for x in res.reasons)
    # только недатированные → касаний 0 → UNKNOWN (в 0.1.1 считались «в окне»)
    res2 = classify_deal(dict(_deal_a()), [undated, undated2], al.policy, NO_REL)
    assert res2.touchpoints["manager"] == 0
    assert res2.verdict == "UNKNOWN"


def test_r4_no_native_author_responsible_does_not_replace():
    """R4-негатив: записи без нативного автора (CREATED_BY_ID) — не касания
    менеджера; ответственный (ASSIGNED_BY_ID, даже бот) автора не заменяет."""
    al = _al()
    no_author = {"ID": 102, "ENTITY_ID": 900000001,
                 "CREATED_DATE": "2026-10-06T10:00:00+03:00"}          # автора нет
    assigned_only = {"ID": 103, "ENTITY_ID": 900000001,
                     "CREATED_DATE": "2026-10-07T10:00:00+03:00",
                     "ASSIGNED_BY_ID": 501}              # есть только ответственный
    assigned_bot = {"ID": 104, "ENTITY_ID": 900000001,
                    "CREATED_DATE": "2026-10-08T10:00:00+03:00",
                    "ASSIGNED_BY_ID": 7001}              # ответственный-бот
    res = classify_deal(dict(_deal_a()),
                        [no_author, assigned_only, assigned_bot], al.policy, NO_REL)
    assert res.touchpoints["manager"] == 0
    assert res.touchpoints["bot"] == 0          # по ASSIGNED бот не выводится
    assert res.touchpoints["no_native_author"] == 3
    assert res.verdict == "UNKNOWN"             # 0.1.1 считал бы 3 касания → VERIFIED
    assert any("нативного автора" in x for x in res.reasons)
    # смесь: доказанных достаточно, но есть записи без автора → PARTIAL
    res2 = classify_deal(dict(_deal_a()), _hist_a() + [no_author], al.policy, NO_REL)
    assert res2.touchpoints["manager"] == 3
    assert res2.touchpoints["no_native_author"] == 1
    assert res2.verdict == "PARTIAL"


def test_r4_no_id_entries_not_counted():
    """R4-негатив: запись без ID — единственность не доказана, касанием
    не считается, неполнота отмечена."""
    al = _al()
    no_id = {"ENTITY_ID": 900000001, "CREATED_BY_ID": 501,
             "CREATED_DATE": "2026-10-06T10:00:00+03:00"}
    res = classify_deal(dict(_deal_a()), _hist_a() + [no_id], al.policy, NO_REL)
    assert res.touchpoints["manager"] == 3
    assert res.touchpoints["no_id_unproven"] == 1
    assert res.verdict == "PARTIAL"


def test_r4_positive_control_clean_history_verified():
    """R4-позитив: чистая история (уникальные ID, даты в окне, авторы)
    → manager=3, VERIFIED; новые поля счётчика нулевые."""
    al = _al()
    res = classify_deal(dict(_deal_a()), _hist_a(), al.policy, NO_REL)
    assert res.verdict == "VERIFIED"
    tp = res.touchpoints
    assert tp["manager"] == 3 and tp["bot"] == 2
    assert tp["outside_window_ignored"] == 1
    assert tp["duplicates_ignored"] == 0
    assert tp["undated_unproven"] == 0
    assert tp["no_native_author"] == 0
    assert tp["no_id_unproven"] == 0


# ============================ R5: лимит страниц при живом курсоре
def test_r5_page_limit_with_live_cursor_no_verified():
    """R5-негатив: достигнут лимит страниц, курсор остался → история
    неполна, VERIFIED невозможен (PARTIAL); лимиты не поднимаются."""
    al = _al()
    max_pages = al.policy.max_stagehistory_pages

    class Endless:
        def call(self, method, params):
            if method == "crm.deal.get":
                return {"result": dict(_deal_a())}
            if method == "crm.contact.get":
                return FixtureTransport(FIXTURES).call(method, params)
            if method == "crm.stagehistory.list":
                start = int(params.get("start", 0))
                item = {"ID": 1000 + start,
                        "ENTITY_ID": params.get("entityId"),
                        "STAGE_ID": "NEW", "CREATED_BY_ID": 501,
                        "CREATED_DATE": "2026-10-06T10:00:00+03:00"}
                return {"result": {"items": [item]}, "total": 10 ** 6,
                        "next": start + 50}            # курсор всегда живой
            raise AssertionError(method)

    report = run(al, Endless(), ["deal:900000001"])
    r = report["results"][0]
    assert r["verdict"] == "PARTIAL"                    # не VERIFIED
    assert any("история неполна" in x and "лимит страниц" in x
               for x in r["reasons"])
    assert r["coverage"]["history_complete"] is False
    assert r["coverage"]["history_pages_used"] == max_pages
    assert r["touchpoints"]["manager"] == max_pages     # каждая страница учтена
    # чтений ровно по политике: карточка + максимум страниц + контакт
    assert report["api_reads"] == 1 + max_pages + 1


def test_r5_positive_control_complete_history_can_verify():
    """R5-позитив: курсор исчерпан на первой странице → history_complete=True,
    сделка A верифицируется; hard-капы не подняты относительно 0.1.1."""
    al = _al()
    report = run(al, FixtureTransport(FIXTURES), ["deal:900000001"])
    r = report["results"][0]
    assert r["verdict"] == "VERIFIED"
    assert r["coverage"]["history_complete"] is True
    assert r["coverage"]["history_pages_used"] == 1
    # «Не повышай лимиты»: потолки не изменены и конфигом не поднимаются
    assert P.HARD_MAX_DEALS == 3 and P.HARD_MAX_READS == 50 and P.HARD_MAX_PAGES == 5
    assert al.policy.max_deals <= P.HARD_MAX_DEALS
    assert al.policy.max_total_reads <= P.HARD_MAX_READS
    assert al.policy.max_stagehistory_pages <= P.HARD_MAX_PAGES


# ================================================= версия и инвариант батареи
def test_v014_version_and_no_false_verified_invariant():
    """Пин версии (обновляется с каждым релизом; 0.1.4 — WORK-POINTREAD-014):
    потолки не подняты, онлайн по-прежнему выключен."""
    r = subprocess.run([sys.executable, "-m", "pointread.cli", "policy"],
                       cwd=ROOT, capture_output=True, text=True, timeout=60)
    assert r.returncode == 0
    pol = json.loads(r.stdout)
    assert pol["version"] == "0.1.4"
    assert pol["policy"]["hard_caps"] == {"deals": 3, "reads": 50, "pages": 5}
    assert pol["policy"]["online_enabled"] is False
