"""Point-read 0.1.4. Mixed JSON types cannot validate an ambiguous history row."""

from pathlib import Path
import unittest

from pointread.policy import load_allowlist
from pointread.transport_offline import FixtureTransport
from pointread.verify import run

ROOT = Path(__file__).resolve().parents[1]
DEAL_ID = "900000001"


class AuthorTypeRegressions(unittest.TestCase):
    def setUp(self):
        self.allowlist = load_allowlist(ROOT / "pointread" / "allowlist.json")

    def execute(self, first_author, duplicate_author):
        transport = FixtureTransport(str(ROOT / "fixtures"))
        first, second = transport._stagehistory[DEAL_ID][:2]
        transport._stagehistory[DEAL_ID] = [
            dict(first, CREATED_BY_ID=first_author),
            dict(first, CREATED_BY_ID=duplicate_author),
            second,
        ]
        report = run(self.allowlist, transport, [f"deal:{DEAL_ID}"])
        self.assertIsNone(report["aborted"])
        return report["results"][0]

    def assert_disputed(self, native, invalid):
        original = self.execute(native, invalid)
        reversed_order = self.execute(invalid, native)
        self.assertEqual(original, reversed_order)
        self.assertEqual(original["verdict"], "UNKNOWN")
        self.assertEqual(original["touchpoints"]["manager"], 1)
        self.assertEqual(original["touchpoints"]["disputed_duplicate_ids"], 1)
        self.assertEqual(original["touchpoints"]["disputed_duplicate_rows"], 2)

    def test_boolean_is_not_positive_integer_author(self):
        self.assert_disputed(1, True)

    def test_float_is_not_integer_author(self):
        self.assert_disputed(501, 501.0)

    def test_malformed_object_is_not_integer_author(self):
        self.assert_disputed(501, {"id": 501})

    def test_equal_integer_authors_keep_one_touch(self):
        result = self.execute(501, 501)
        self.assertEqual(result["verdict"], "VERIFIED")
        self.assertEqual(result["touchpoints"]["manager"], 2)
        self.assertEqual(result["touchpoints"]["duplicates_ignored"], 1)
