# QA-отчёт фикса DEV-POINTREAD-FIX-QA-20261115-02 — 15.11.2026 (МСК)

Версия **0.1.0 → 0.1.1**. Закрыты D1/D2 аудита admin2 (mwgzhqetrbr7),
сделаны INFO-улучшения D3/D4, добавлены 3 негативных синтетических теста.
Прогон: полный сьют `tests/` (27 тестов) в **network-blocked** режиме —
`socket.connect/connect_ex/create_connection/getaddrinfo/gethostbyname`
заблокированы на уровне Python; `PYTHONDONTWRITEBYTECODE=1`,
`-p no:cacheprovider`. Python 3.15.0, pytest 9.2.0.
**Итог: 27 passed / 0 failed** (было 24/24 в 0.1.0; +3 новых, 0 удалено,
1 тест обновлён — см. ниже). Все данные синтетические; mock ≠ live.

## Как закрыты дефекты

### D1 (MEDIUM): stagehistory-запись не проверялась на принадлежность сделке
- `pointread/gate.py`: новый `_assert_stagehistory_owned()` вызывается для
  каждого `crm.stagehistory.list`-ответа рядом с существующей проверкой
  `*.get`. Каждая запись обязана нести `ENTITY_ID == entityId` (camelCase или
  UPPER-форма запроса); **чужой** ENTITY_ID и **отсутствующий** ENTITY_ID →
  `UNEXPECTED_ID` fail-closed (стоп всего прогона, бюджет попытки
  тарифицирован). **Неподтверждаемый формат** (нет `result`, нет
  `result.items`, items не список, элемент не объект) → тоже `UNEXPECTED_ID`
  fail-closed: неподтверждаемое ≠ пустое.
- Тест **test_21** (новый, негативный): (а) в ответ подмешана запись чужой
  сделки (ENTITY_ID=900000002 при запросе истории 900000001) — отказ на
  уровне гейта и ABORT всего рана с `UNEXPECTED_ID`; (б) запись без
  ENTITY_ID — отказ; (в) ответ без items-списка — отказ (fail-closed).

### D2: VERIFIED без доказательства попадания в период
- `pointread/verify.py` (`_one`, шаг 3): период теперь доказывается строго.
  `DATE_CREATE` отсутствует/пустая/нечитаема (`parse_dt` ValueError) →
  **UNKNOWN** (не VERIFIED/PARTIAL), детализация не выполняется, в reasons —
  причина, добавляется `coverage: {period_proven: false,
  detail_reads_done: false}`. Расход: 1 чтение (карточка).
- `pointread/verdicts.py` (`classify_deal`): страховочный слой — флаг
  `period_proven`; пока период не доказан, итоговый вердикт принудительно
  UNKNOWN (с reason и notes «coverage: период не подтверждён —
  VERIFIED/PARTIAL невозможны»), даже при достаточных касаниях и известном
  канале. Ранее отсутствующая DATE_CREATE вообще не попадала в reasons и
  давала VERIFIED; нечитаемая давала PARTIAL.
- Тест **test_22** (новый, негативный): (а) DATE_CREATE удалена из карточки →
  UNKNOWN, reason «не доказано», coverage.period_proven=false, api_reads=1
  (детализации нет); (б) DATE_CREATE="garbage-not-a-date" → UNKNOWN;
  (в) прямой вызов `classify_deal` без DATE_CREATE → UNKNOWN, при этом
  позитивный контроль с валидной датой → VERIFIED.

### D3 (INFO): BadTypedId при >3 сделках → семантический ConfigInvalid
- `pointread/verify.py`: превышение потолка сделок поднимает `ConfigError`
  (`CONFIG_INVALID`), не `BadTypedId`. Выходной код CLI не изменился (2).
- Тест **test_23** (новый): 4 deal-refs → `pytest.raises(ConfigError)`,
  `code == "CONFIG_INVALID"`.

### D4 (INFO): PYTHONDONTWRITEBYTECODE=1
- `bin/pointread`: `export PYTHONDONTWRITEBYTECODE=1`; команда pytest в
  README дополнена переменной и `-p no:cacheprovider`. После полного прогона
  в staging нет ни `__pycache__`, ни `.pytest_cache` (проверено find).

## Обновлённый существующий тест (не новый и не удалённый)

- **test_7 (бюджет)**: его синтетический пагинатор возвращал мусорную
  карточку сделки на `crm.deal.get` (без DATE_CREATE) — при семантике 0.1.0
  она молча пропускалась к детализации (иллюстрация сути D2). Теперь
  фикструра отдаёт корректную карточку + записи с ENTITY_ID (требование D1).
  Цель теста не изменилась: бесконечная пагинация vs бюджет →
  `BUDGET_EXCEEDED` ровно на лимите 4/4.

## Побочные эффекты / границы

- Изменённые файлы: `pointread/gate.py`, `pointread/verify.py`,
  `pointread/verdicts.py`, `pointread/__init__.py`, `bin/pointread`,
  `tests/test_pointread.py`, `README.md`, `SHA256SUMS.txt`, новый
  `qa/offline_report_fix_20261115.md`. Все правки — только внутри staging
  `~/AiRop/pointread_stage_20261115` (+ immutable-бэкап соседним каталогом).
- DAT main, patch01, PROD MGR/CRM/МАВИ, permissions исходных сервисов —
  **не тронуты**; реальных API-вызовов, сетевых импортов, токенов, PII,
  банковских/Avito/телефонии данных, GLM, платных помощников, субагентов —
  **0**.
- Версия 0.1.0 сохранена до правок: полный immutable-бэкап
  `~/AiRop/pointread_stage_20261115_v0.1.0_immutable` (режим только чтение,
  24/24 OK по исходному SHA256SUMS; персональных данных нет — только
  синтетика).
- `allowlist.json` не менялся (хэш конфига прежний); scope-пиннинг и все
  прежние гарантии (whitelist, бюджет, 429-fail-closed, PII-редакция)
  сохранены — все 24 прежних теста проходят без ослабления.

## Вердикт

**OFFLINE only.** LIVE/PROD — **NO-GO** до независимой повторной приёмки
версии 0.1.1 и отдельного разрешения собственника.

## Потребление GLM/квот

Исполнитель — основная сессия dev-агента; GLM-агенты, платные помощники,
субагенты, внешние сервисы — **0 вызовов, 0% квоты**.
