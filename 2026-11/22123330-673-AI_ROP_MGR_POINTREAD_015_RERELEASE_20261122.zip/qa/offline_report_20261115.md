# QA-отчёт offline-батареи — 15.11.2026 (МСК ~01:00–01:30)

Задача DEV-POINTREAD-STAGE-20261115-01. Прогон: `python3 -m pytest tests/ -q`
в `~/AiRop/pointread_stage_20261115` (Python 3.15.0, pytest 9.2.0).
**Итог: 24 passed / 0 failed.** Все данные синтетические; **mock ≠ live**:
успех батареи не является доказательством корректности серверных фильтров Б24
и не активирует онлайн.

## Обязательные сценарии (п.4 задачи)

| # | Сценарий | Тест | Вердикт |
|---|---|---|---|
| 1 | Unauthorized ID (не в allowlist) | test_1 | PASS: REFUSED, 0 API-читений |
| 2 | Bulk list (crm.deal.list / contact.list) | test_2 | PASS: METHOD_FORBIDDEN до сети, 0 чтений |
| 3 | Unverified owner filter (crm.activity.list OWNER_ID) | test_3 | PASS: NOT_TESTABLE (серверный узкий фильтр не доказан), 0 чтений |
| 3b | Related-ID без подтверждения источником | test_3b | PASS: RELATED_NOT_PROVEN; подтверждённый related — разрешён |
| 4 | Out-of-period (создана 20.09.2026) | test_4 | PASS: OUT_OF_PERIOD, детализация не выполнялась (1 чтение) |
| 4b | Границы периода | test_4b | PASS: 01.10 00:00 и 14.11 23:59:59 включительно; 30.09/15.11 — вне |
| 5 | Bot vs manager | test_5 | PASS: 2 бот-касания (TASKS_TASK/CRM_WEBDAV_TASK) исключены; полей вины в схеме нет |
| 6 | Avito unknown mapping | test_6 | PASS: UNKNOWN «канал не отображён», догадок/доп. чтений — 0 |
| 7 | Excess API budget | test_7 | PASS: ABORT ровно на лимите (сужен до 4), BUDGET_EXCEEDED |
| 8 | PII в выводе | test_8 | PASS: телефоны/email/имена замаскированы; сырых подстрок нет |
| 9 | Short/unreached → UNKNOWN | test_9 | PASS: UNKNOWN «касаний недостаточно», не штраф |
| 10 | Mid-run change of scope | test_10 | PASS: SCOPE_CHANGED, вызов заблокирован |

## Дополнительные fail-closed проверки

| Тест | Вердикт |
|---|---|
| test_11 HTTP 429 | PASS: немедленный стоп, ретраев 0, попытка тарифицирована |
| test_12 Unexpected ID в ответе | PASS: UNEXPECTED_ID fail-closed |
| test_13 Параметры-PII (PHONE/TITLE) | PASS: PII_PARAM до сети; findbycomm — METHOD_FORBIDDEN |
| test_14 Онлайн-заглушка | PASS: ONLINE_BLOCKED / NO_CREDENTIALS_WIRED; сетевых импортов в пакете нет |
| test_15 Потолки allowlist | PASS: >3 сделок, reads>50, запись без provenance — CONFIG_INVALID |
| test_16 Полный прогон 3 сделок | PASS: VERIFIED/UNKNOWN/OUT_OF_PERIOD; 6/50 чтений; без abort |
| test_17 Строгие параметры stagehistory | PASS: без entity-фильтра / чужой ENTITY_ID / не-deal / DESC — отказ |
| test_18 Мутаторы | PASS: add/update/delete/consent — METHOD_MUTATOR всегда |
| test_19 Smoke CLI | PASS: policy/verify/call/REFUSED/ONLINE_BLOCKED, выходные коды |
| test_20 Hex-хеши не маскируются | PASS (регрессия smoke: хеш конфига искажался маской телефона) |
| test_ids/test_redact | PASS: строгий typed-ID; маскирование |

## НЕИЗВЕСТНОЕ (зафиксировано, не «зелёное»)

- **stagehistory-фильтр по ENTITY сервером**: в offline НЕ доказан; метод
  включён в whitelist точечно, но live-поведение подтверждается только при
  будущей online-фазе (после аудита и GO).
- **OL / Avito / activity / telephony**: серверные узкие фильтры НЕ доказаны →
  NOT_TESTABLE, методы отключены. Широкие list-замены запрещены навсегда.
- **Поведение боевого REST** (формы конвертов, camelCase) имитировано по
  live-фактам v3lite от 09.11; реальность может отличаться.

## Потребление GLM/квот

Исполнитель — основная сессия агента, без GLM-субагентов и внешних сервисов:
**0% недельной квоты, 0 вызовов GLM**. Время: ~01:04–01:35 МСК 15.11.2026
(вне запрещённого окна 08:00–13:30).
