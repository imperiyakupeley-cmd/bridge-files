# AiRop v3 Lite — исходники для ревью (архив для ChatGPT)

Собрано: 2026-11-10 (задача моста mw9rnw2cx7au). Только исходники и контракты, только копия.

## Состав
- spec_v3lite_admin2.md — спека v3 Lite (адаптация admin2, §9-матрица инцидентов)
- v3lite/README.md, run.py, smoke_live.py, measure_live.py — корень стенда
- v3lite/core/ — ядро: источники Б24 (calls/leads/activities/clients/employees/openlines/owners/dossier), контракт, транспорт, канарейки, фильтры
- v3lite/messages/ — конвейер сообщений ОЛ v2 + avito-интерфейс (docs/), фикстуры (обезличены)
- v3lite/avito_adapter/ — адаптер прямого API Авито (adapter/, MAPPING_PROTOCOL.md, tools/, tests/)
- v3lite/staging/ — HTTP-стенд: airop_staging.py, mock_b24.py, integrated.py, a2a_adapter.py, env.template.sh (плейсхолдеры), фикстуры, ROLLBACK/SCHEMA_RECONCILIATION
- v3lite/qa/ — acceptance_admin2.py, reacceptance9.py, crm_golden_cases.md (эталоны-инциденты), негативные фикстуры v1.2 §9.7, results/*.md (release gate, вердикты)
- v3lite/tests/ — юнит-тесты ядра

## Секретов нет — проверено сканом копии
- Прод-секреты в рантайме читаются из внешних хранилищ (staging/secrets.py — только пути/маскирование, литералов нет)
- Все /rest/-URL в коде/тестах — localhost, *.example.test, *.invalid (синтетика)
- Фикстуры полностью синтетические: сотрудники 401/402/403 («Тестов Т.»), телефоны +7900000000x, email testov@example.invalid
- Телефоны в тестах — шаблонная синтетика (123-45-67 и т.п.); в qa/crm_golden_cases.md — только маски вида 7961***72
- Оговорка: в qa/crm_golden_cases.md один раз встречается домен портала Б24 (пример ручной сверки UI, без секретной части вебхука)

## Что исключено (политика безопасности)
.env и любые конфиги с реальными секретами; *.db/*.sqlite (calls.db, v3_cache.db, индексы avito, mock.db); все логи (*.jsonl, staging/logs, logs/sends); live-артефакты с данными клиентов (out/, results/*.json, state/); аудио/медиа; .git, __pycache__, .pytest_cache, .venv; *.bak-*; SHA256SUMS (файлы без расширения); каталог tg_stand (вне запрошенного набора).
