# v3 Lite core — read-only сборщик Битрикс24 (ИИ-РОП)

Ядро on-demand сборщика по спецификации `~/AiRop/spec_v3lite_admin2.md` (§3–§10).
**Изолировано**: живёт в `~/AiRop/v3lite/`, не импортирует боевые модули, не
пишет в `calls.db` (только читает через sqlite `mode=ro`), не меняет правила
РОПа, в production не подключён.

## Запуск

```bash
echo '{"intent":"leads_day","request_id":"<uuid>","from":"2026-11-06T00:00:00+03:00","to":"2026-11-07T00:00:00+03:00"}' \
  | python3 ~/AiRop/v3lite/run.py
```

Вебхук — из `~/AiRop/.env` (`BX_WEBHOOK`, Анна 17316, только crm.*/user.get/
voximpl-кросс-чек). Вебхук владельца ОЛ — только через env `V3_OL_WEBHOOK`
(core сам в ОЛ не ходит). `V3_CACHE=0` — отключить кэш-идемпотентность.

## Каталоги

```
v3lite/
  core/                 # ядро (пакет)
    config.py           # конфиг без побочных эффектов, лимиты/политики
    whitelist.py        # whitelist методов/параметров, запрет мутаторов
    filters.py          # локальная валидация фильтров (поля/операторы/даты)
    transport.py        # GET-транспорт (в тестах подменяется)
    client.py           # BitrixClient: rate-limit, ретраи 429/5xx, batch,
                        #   пагинация next/total, дедуп строк, coverage
    canaries.py         # filter/window/pagination/duplicate/author-канарейки
    contract.py         # валидация запроса (§3), сборка ответа (§4), статусы
    facts.py            # фабрика фактов, маскирование телефонов
    collect.py          # stdin/stdout вход + кэш-идемпотентность (v3_cache.db)
    sources/
      leads.py          # leads_day: crm.lead.list (DATE_CREATE) + batch
                        #   первых касаний по каждому лиду
      calls.py          # calls_day: voximpl через calls.db RO + кросс-чек
                        #   crm.activity.list TYPE_ID=2 (инцидент 05.08)
      activities.py     # get_activities/manager_day: индекс дня, TODO
                        #   TYPE_ID=6+PROVIDER_TYPE_ID, автор≠ответственный
      employees.py      # resolve_employee: user.get, боты из EXCLUDE_USERS
      clients.py        # resolve_client: crm.*.get + crm.duplicate.findbycomm
      openlines.py      # заглушка NOT_IMPLEMENTED — стык dev_agent
  tests/                # pytest, обезличенные фикстуры (FixturePortal)
  run.py                # CLI-обёртка
  smoke_live.py         # живой read-only прогон-канарейка (замеры)
  measure_live.py       # сквозные замеры всех интентов на реальном дне
  v3_cache.db          # sqlite кэш ответов (идемпотентность §9.5-3)
```

## Гарантии ядра

- **Только чтение**: whitelist-list/get; любой мутатор (`*.add/update/delete/
  set/import/...`) — отказ до сети. GET-only транспорт.
- **Ретраи**: 429/5xx/сеть/QUERY_LIMIT_EXCEEDED — экспоненциальный backoff
  (1s, 2s, 4s + jitter), максимум 3 ретрая, `Retry-After` уважается (кап 30с).
- **Rate limit**: токен-бакет ~1.8 rps, batch тарифицируется по числу команд.
- **Пагинация**: start/next/total, дедуп строк по ID, контроль усечения
  (page_limit=220, offset-окно ≈10 200, зацикливание, расхождение total).
- **Канарейки** (§7): filter (пустое пересечение → PASS/FAIL/ERROR),
  window ([from,to) по каждому факту), pagination (агрегация усечений),
  duplicate_guard (по (source, source_entity_id), счётчики после дедупа),
  author_crosscheck (manager_id vs RESPONSIBLE_ID у пары voximpl+activity).
- **Статусы честные** (§4): VERIFIED не выдаётся при непустых
  errors/warnings/FAIL-канарейке; ноль фактов при живых источниках = VERIFIED;
  ACCESS_DENIED/канарейка фильтра → факты источника отбрасываются (fail-closed).
- **Кэш**: повтор того же request_id — сохранённый ответ (1мс); ответы с
  транзиентными ошибками (429/5xx/сеть) не кэшируются; ключ включает версию
  ядра CORE_VERSION (фиксы инвалидируют старые ответы).

## Расширения контракта (задокументированные отступления от §4)

- `meta`: {cache, duration_ms, rest_calls} — замеры.
- `result` — для resolve_employee/resolve_client (facts пустые).
- `detectors.filter_canary_detail` — per-source PASS/FAIL/ERROR.
- код ошибки `NOT_IMPLEMENTED` — Open Lines/client_dossier (модуль dev_agent).
- `PHONE в фактах всегда маскирован` (****NNNN); телефоны в resolve_client —
  masked, нормализованный номер только для запроса к findbycomm.

## Стык с dev_agent (Open Lines) — §10

Core отдаёт activity-индекс TYPE_ID=6 с `payload.chat_ref`
(`{owner_type}:{owner_id}`). dev_agent:
1. разрешает чат `imopenlines.crm.chat.getlastid` (whitelist-заготовка есть),
   НИКОГДА через ASSOCIATED_ENTITY_ID (ловушка §5);
2. читает текст `im.dialog.messages.get` ПОСТРАНИЧНО (ловушка read_chat-200);
3. подтверждает роли авторов users-блоком (external_auth_id='imconnector');
4. регистрирует источник `core.sources.register_source(name, module)`.
Заглушка `openlines.stub_error()` держит manager_day в PARTIAL, пока модуля нет.

## Тесты

```bash
cd ~/AiRop/v3lite && python3 -m pytest tests/ -q   # 94 passed
```

Покрытие: whitelist/мутаторы, фильтры, пагинация/усечения, 429/5xx/Retry-After,
batch (обёртка result.result, список-при-числовых-ключах, цена>burst), контракт
(§3 обязательность, §4 статусы, [from,to)), канарейки, инциденты §9.1 (05.08 —
один звонок один факт) и §9.3 (15.08 — DATE_MODIFY не фильтр дня), §9.4 (дубли
контактов в warnings), идемпотентность кэша, calls.db только-чтение
(хэш файла не меняется).

## Известные ограничения

1. **Open Lines/тексты сообщений не реализованы** — модуль dev_agent; core
   отдаёт только индекс (chat_ref), manager_day = PARTIAL по дизайну.
2. **client_dossier** — NOT_IMPLEMENTED (нужен OL-модуль).
3. **voximpl**: читаем готовый сборщик через calls.db; если БД отстаёт >6ч от
   окна — честный PARTIAL (coverage.last_row), прямой выкачки voximplant.statistic
   нет (спека §5: не дублировать).
4. **Первые касания** — батч по ≤45 лидов; при сотнях лидов за день лимит
   скорости даёт ~25с на батч (честная тарификация batch).
5. **OFFSET-окно ~10 200** — глубже сервер не отдаёт, честный truncated.
6. **OWNER_TYPE_ID 1/2/3 = lead/contact/deal** — по [ФАКТ] спеки; live-проверено
   только OWNER=1 (lead 20288). Рекомендация admin2: проверить 2/3 на приёмке.
7. **Встречи/задачи/письма** (TYPE_ID 1/3/4/5) маппятся в task_todo/message с
   payload.kind — расширение enum без введения новых fact_type.
8. Права вебхука Анны на crm.activity чужих ответственных — частично [ФАКТ §6]:
   при ACCESS_DENIED core даёт FAILED с указанием источника, не PARTIAL.

## Замеры (живой портал, 08.11.2026, read-only)

| Сценарий | Статус | Факты | REST | Время |
|---|---|---|---|---|
| leads_day 06.11 (7 лидов + 7 первых касаний) | VERIFIED | 14 | 3 | 3.2с |
| leads_day повтор (кэш) | VERIFIED | 14 | 0 | 1мс |
| calls_day 06.11 (139 voximpl, кросс-чек 138 matched / 0 unmatched) | VERIFIED | 139 | 4 | 1.7с |
| manager_day 05.11→06.11 менеджер 20592 (38 звонков+48 сообщений+8 TODO) | PARTIAL (OL-заглушка) | 94 | 5 | 1.3с |
| resolve_employee | VERIFIED | — | 1 | 0.2с |
| resolve_client по телефону (findbycomm: 1 lead + 1 contact) | VERIFIED | — | 3 | 0.7с |
| канарейки фильтров activity/lead | PASS | — | 2 | ~0.3с каждая |

Менее секунды на источник в среднем; укладывается в оценку спеки «8–15 REST
вызовов на manager_day».

## Changelog

### 2026-11-09 — фикс КРИТИЧЕСКОГО инцидента integ-ld-1 (08.11): ложный VERIFIED при потере первых касаний
- **Причина (2 слоя):** (1) боевой batch-конверт: при плотных числовых
  cmd-ключах `result.result` приходит СПИСКОМ, `result_error` = `[]`; при
  ошибке команды — dict `{"0","2"}` + `result_error {"1"}` [ФАКТ: live-проба
  09.11, staging/logs/batch_live_*.json] — форма не разбиралась → все ответы
  MISSING_IN_BATCH; (2) leads_day глотал это молча → status VERIFIED без
  first-touch (нарушение fail-closed).
- **Фикс:** `core/client.py` — `_parse_batch_envelope()` (LIST/dict/плоский
  конверт + аномалии) и честный coverage `batch:<label>` = cmds/ok/cmd_errors/
  missing/envelope_anomalies; `core/sources/leads.py` — ошибка или потеря
  команды batch касаний → `errors[]` (SOURCE_ERROR, batch:crm.activity.list)
  → статус PARTIAL, счётчики cmd_error/cmd_missing в coverage;
  `CORE_VERSION` 0.2.0→0.2.1 (кэш старых leads_day без касаний инвалидирован);
  тестовый транспорт (conftest) и mock_b24 теперь отдают боевую форму
  (плотные ключи → LIST, разреженные → dict — раньше mock схлопывал
  разреженный map и ехала индексация).
- **Тесты:** 103 passed (было 94; +9 регресс: TestBatchBattleEnvelope,
  TestFirstTouchBattleRegression со строгими assert на известные касания
  9001/9002/9003 и fail-closed на cmd_error/cmd_missing).
- **Live-замер (read-only, 09.11):** batch из 3 cmd всё-ок (LIST-форма) →
  парсер ok=3/missing=0; batch с ошибкой одной команды (dict {"0","2"} +
  result_error {"1"}) → ok=2/error=1, индексация не съехала. Задержки:
  3,8с / 0,6с. Стенд: `staging/probe_batch_live.py`.
