"""Канарейка полноты через imopenlines.v2.Session.Stat.get (вспомогательный).

[ФАКТ, проверено 09.11 read-only]: метод работает ТОЛЬКО POST с JSON
{"sessionId": [ids]}, GET и dateFrom/dateTo дают HTTP 400. Формат ответа:
result.sessions = [{sessionId, messagesCount, messagesOperatorCount,
messagesClientCount, transfersCount, waitAnswer, waitClose, kpiFirstAnswer,
vote, voteHead}] — независимые счётчики сообщений по сессии (за всю сессию,
не по окну; системные сообщения в счётчики оператора/клиента не входят).

Семантика кросс-чека: сравниваем messagesCount с числом сообщений, полученных
из history.get ДО фильтра окна (fetched_count). Расхождение = история недобрана
(пагинация/обрыв) → warning + PARTIAL. Количества «сообщений в окне» и
«сообщений сессии» НЕ сравниваются — это разные величины (§правило: не
требовать ошибочно равенства разных видов сообщений).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .config import MsgConfig, TRANSFER_CHUNK
from .errors import MsgError

SOURCE = "imopenlines.v2.Session.Stat.get"


@dataclass
class StatResult:
    by_session: dict = field(default_factory=dict)  # sid -> {messagesCount,...}
    errors: list = field(default_factory=list)
    calls: int = 0

    def coverage(self) -> dict:
        return {"source": SOURCE, "sessions": len(self.by_session),
                "calls": self.calls,
                "errors": self.errors[:10]}


def fetch_stats(client, cfg: MsgConfig, session_ids: list[int]) -> StatResult:
    res = StatResult()
    ids = [s for s in session_ids if isinstance(s, int)]
    for i in range(0, len(ids), TRANSFER_CHUNK):
        chunk = ids[i:i + TRANSFER_CHUNK]
        try:
            env = client.post(SOURCE, {"sessionId": chunk})
            res.calls += 1
        except MsgError as e:
            res.errors.append(e.to_json())
            continue
        payload = env.get("result") if isinstance(env, dict) else None
        rows = payload.get("sessions") if isinstance(payload, dict) else None
        if not isinstance(rows, list):
            continue
        for row in rows:
            if isinstance(row, dict) and row.get("sessionId") is not None:
                try:
                    res.by_session[int(row["sessionId"])] = {
                        "messages": row.get("messagesCount"),
                        "operator": row.get("messagesOperatorCount"),
                        "client": row.get("messagesClientCount"),
                        "transfers": row.get("transfersCount"),
                    }
                except (TypeError, ValueError):
                    continue
    return res


def crosscheck(stat: StatResult, fetched_counts: dict[int, int],
               *, cap_hit_ids: frozenset[int] | set[int] = frozenset(),
               limit_warnings: int = 20) -> tuple[list[str], dict]:
    """Сравнение Stat.messagesCount ↔ fetched_count (ДО фильтра окна),
    с РАЗЛИЧЕНИЕМ направления (замечание приёмки 09.11: раньше любое
    расхождение называлось «история неполна», даже когда history > Stat —
    а это нормальная семантика: в history есть системные senderid=0,
    Stat их не считает; 25396: 152/143 при 11 системных).

    cap_hit_ids — сессии, где history упёрлась в LIMIT (эскалации исчерпаны):
    недобор против Stat у НИХ — вероятная потеря пагинации («проверьте лимиты»);
    недобор БЕЗ cap_hit (живой прогон 09.11: 27962: 10/11, LIMIT не задет) —
    метод отдал всё, что имеет: расхождение счётчиков, потеря не доказана.

    Возвращает (warnings, summary); summary также в coverage.stat_aux.
    """
    under: list[tuple[int, int, int]] = []   # (sid, got, expected) — недобор
    over: list[tuple[int, int, int]] = []    # history > Stat — семантика счётчиков
    for sid, s in sorted(stat.by_session.items()):
        expected = s.get("messages")
        got = fetched_counts.get(sid)
        if expected is None or got is None:
            continue
        try:
            expected, got = int(expected), int(got)
        except (TypeError, ValueError):
            continue
        if got < expected:
            under.append((sid, got, expected))
        elif got > expected:
            over.append((sid, got, expected))
    warnings: list[str] = []
    under_cap = [u for u in under if u[0] in cap_hit_ids]
    under_sem = [u for u in under if u[0] not in cap_hit_ids]
    if under_cap:
        examples = ", ".join(f"{sid}: {got}/{exp}" for sid, got, exp in under_cap[:5])
        warnings.append(
            f"stat_crosscheck: {len(under_cap)} сессий с НЕДОБОРОМ истории против "
            f"Stat.messagesCount И упором в LIMIT ({examples}) — хвост не добран, "
            f"проверьте лимиты history.get")
    if under_sem:
        examples = ", ".join(f"{sid}: {got}/{exp}" for sid, got, exp in under_sem[:5])
        warnings.append(
            f"stat_crosscheck: {len(under_sem)} сессий, где Stat больше history "
            f"({examples}) — LIMIT не задет, метод отдал всё, что имеет: "
            f"расхождение счётчиков (удалённые/семантика), потеря пагинацией "
            f"НЕ доказана")
    if over:
        examples = ", ".join(f"{sid}: {got}/{exp}" for sid, got, exp in over[:5])
        warnings.append(
            f"stat_crosscheck: {len(over)} сессий, где history > Stat "
            f"({examples}) — системные сообщения (senderid=0) в Stat не "
            f"считаются: потери НЕТ, расхождение семантики счётчиков")
    summary = {
        "under_sessions": len(under),
        "under_cap_hit": len(under_cap),
        "under_detail": [{"session_id": s, "got": g, "expected": e}
                         for s, g, e in under[:50]],
        "over_sessions": len(over),
        "over_detail": [{"session_id": s, "got": g, "expected": e}
                        for s, g, e in over[:50]],
    }
    return warnings, summary
