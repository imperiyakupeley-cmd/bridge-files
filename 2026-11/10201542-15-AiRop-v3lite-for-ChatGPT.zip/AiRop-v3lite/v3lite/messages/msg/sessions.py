"""Индекс кандидатов-сессий через imopenlines.v2.Session.list (offset-скан).

[ФАКТ, пробы 3–9 / 08.11 + probe2 09.11]: фильтры operatorId/dateCreateFrom/
dateCloseFrom/source МОЛЧА игнорируются сервером → листинг БЕЗ фильтров,
200/стр, фильтрация на клиенте. offset ≤ 10 000: глубже портал отвечает
HTTP 400 (error 100) → предзапросная проверка потолка, 400 не провоцируем.
Всего достижимо ≈ 10 200 строк (offset 10 000 + limit 200).

[ФАКТ о порядке, probe_fixes 09.11]: листинг НЕ отсортирован по датам — в
пределах одной страницы dateCreate перемешаны (диапазон ~2 нед свежести),
старые (2025-05) давно-созданные сессии вкраплены среди свежих. Значит
недостижимый хвост за потолком НЕЛЬЗЯ датировать — состав хвоста недоказуем;
для честной границы считаем плотность id (span минус увиденные).

Кандидат на окно [from, to): создана ДО to И (ещё открыта ИЛИ закрыта НЕ РАНЬШЕ from)
— «старые открытые» обязательны: их сообщения в окне появляются при создании
задолго до окна (проба 13). Без окна (кластер без дат) — все сессии кластера.

Полнота: скан идёт до естественного конца (пустая страница / hasNextPage=False).
Упор в потолок offset без естественного конца → ceiling_hit → truncated →
статус не выше PARTIAL «глубже окна API» (спека §6). Ранний стоп НЕ применяется:
старые открытые сессии разбросаны по всему листингу, доказать их отсутствие
за точкой останова нельзя (fail-closed).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from .config import (MsgConfig, OFFSET_MAX, OFFSET_WINDOW_HARD, SCAN_PAGE_LIMIT,
                     SESSION_PAGE_SIZE)
from .errors import SourceError
from .timeutil import parse_iso_loose

SOURCE = "imopenlines.v2.Session.list"


@dataclass
class SessionRow:
    id: int
    chat_id: int | None = None
    date_create: datetime | None = None
    date_close: datetime | None = None
    operator_id: int | None = None
    user_id: int | None = None          # клиентский «теневой» юзер сессии
    crm_type: str | None = None         # LEAD | DEAL | CONTACT (нормализуем)
    crm_id: int | None = None
    config_id: int | None = None        # линия (Авито=2, WA=6, TG=8, VK=10, MAX=12…)
    message_count: int | None = None
    queue_transfers: int | None = None
    bad_dates: bool = False             # битые даты — включён как кандидат, warning

    @property
    def binding(self) -> tuple[str, int] | None:
        if self.crm_type and self.crm_id:
            return (self.crm_type.lower(), int(self.crm_id))
        return None

    @property
    def is_open(self) -> bool:
        return self.date_close is None


def parse_session(raw: dict) -> SessionRow:
    dc = parse_iso_loose(raw.get("dateCreate"))
    dcl = parse_iso_loose(raw.get("dateClose"))
    crm_t = raw.get("crmEntityType")
    crm_i = raw.get("crmEntityId")
    try:
        crm_i = int(crm_i) if crm_i is not None else None
    except (TypeError, ValueError):
        crm_i = None
    sid = raw.get("id")
    if not isinstance(sid, int):
        raise SourceError(f"сессия без числового id: {sid!r}", source=SOURCE)
    return SessionRow(
        id=sid,
        chat_id=raw.get("chatId"),
        date_create=dc,
        date_close=dcl,
        operator_id=raw.get("operatorId"),
        user_id=raw.get("userId"),
        crm_type=str(crm_t).lower() if crm_t else None,
        crm_id=crm_i,
        config_id=raw.get("configId"),
        message_count=raw.get("messageCount"),
        queue_transfers=raw.get("queueTransfers"),
        bad_dates=(dc is None and (raw.get("dateCreate") is not None)) or
                  (dcl is None and (raw.get("dateClose") is not None)),
    )


@dataclass
class ScanResult:
    candidates: list[SessionRow] = field(default_factory=list)
    scanned_rows: int = 0
    unique_sessions: int = 0
    pages: int = 0
    stop_reason: str = "complete"     # complete | empty_page | ceiling | page_limit | error
    truncated: bool = False
    ceiling_hit: bool = False
    duplicate_rows: int = 0
    bad_date_rows: int = 0
    open_seen: int = 0
    oldest_create: datetime | None = None
    newest_create: datetime | None = None
    last_page_empty: bool = False
    error: dict | None = None
    # честная граница потолка (F4): плотность id + свежесть страниц
    id_min: int | None = None
    id_max: int | None = None

    @property
    def unreachable_tail_estimate(self) -> int | None:
        """Оценка СВЕРХУ числа сессий за потолком: id почти последовательны
        (автоинкремент), поэтому «всего ≈ id_max-id_min+1»; увидели
        unique_sessions; разница — хвост (удалённые id завышают оценку —
        потому и «сверху»). None, если id не встречены."""
        if self.id_min is None or self.id_max is None or self.id_max < self.id_min:
            return None
        span = self.id_max - self.id_min + 1
        return max(0, span - self.unique_sessions)

    def coverage(self) -> dict:
        ids_block = None
        if self.id_min is not None and self.id_max is not None:
            ids_block = {
                "min": self.id_min, "max": self.id_max,
                "seen": self.unique_sessions,
                "span": self.id_max - self.id_min + 1,
                "missing_in_span_estimate": self.unreachable_tail_estimate,
            }
        return {
            "source": SOURCE,
            "pages": self.pages,
            "rows_scanned": self.scanned_rows,
            "unique_sessions": self.unique_sessions,
            "candidates": len(self.candidates),
            "open_sessions_seen": self.open_seen,
            "duplicate_rows": self.duplicate_rows,
            "bad_date_rows": self.bad_date_rows,
            "oldest_create": self.oldest_create.isoformat() if self.oldest_create else None,
            "newest_create": self.newest_create.isoformat() if self.newest_create else None,
            "stop_reason": self.stop_reason,
            "last_page_empty": self.last_page_empty,
            "truncated": self.truncated,
            "ceiling_hit": self.ceiling_hit,
            "offset_limit": OFFSET_MAX,
            "reachable_rows_limit": OFFSET_WINDOW_HARD,
            "ids": ids_block,
            "error": self.error,
        }


def _is_candidate(s: SessionRow, frm: datetime | None, to: datetime | None,
                  cluster: set | None) -> tuple[bool, str]:
    if cluster is not None and s.binding not in cluster:
        return False, "cluster"
    if frm is None or to is None:
        return True, "match"          # без окна: все сессии кластера
    if s.date_create is None:
        return True, "unknown_dates"  # fail-closed: включаем, фильтр времени ниже
    if s.date_create >= to:
        return False, "created_after"
    if not s.is_open and s.date_close is not None and s.date_close < frm:
        return False, "closed_before"
    return True, "match"


def scan_sessions(client, cfg: MsgConfig, *, frm: datetime | None,
                  to: datetime | None, cluster: set | None = None) -> ScanResult:
    """Полный offset-скан листинга сессий (без серверных фильтров — они фиктивны).
    Потолок offset проверяется ДО запроса: offset > 10 000 портал отвечает
    HTTP 400 — не провоцируем, честно фиксируем ceiling (F4)."""
    res = ScanResult()
    seen: dict[int, SessionRow] = {}
    offset = 0
    while True:
        if res.pages >= SCAN_PAGE_LIMIT:
            res.stop_reason, res.truncated = "page_limit", True
            break
        # [ФАКТ probe2 09.11]: offset > 10000 → HTTP 400 → предзапросный потолок
        if offset > OFFSET_MAX:
            res.stop_reason, res.truncated, res.ceiling_hit = "ceiling", True, True
            break
        try:
            envelope = client.post(SOURCE, {"limit": SESSION_PAGE_SIZE, "offset": offset})
        except SourceError as e:
            res.stop_reason, res.truncated, res.error = "error", True, e.to_json()
            break
        res.pages += 1
        payload = envelope.get("result") if isinstance(envelope, dict) else None
        rows = payload.get("sessions") if isinstance(payload, dict) else None
        if not rows:
            res.stop_reason = "complete"   # пустая страница = естественный конец
            res.last_page_empty = True
            break
        has_next = payload.get("hasNextPage")
        for raw in rows:
            try:
                s = parse_session(raw)
            except SourceError:
                res.scanned_rows += 1
                continue
            res.scanned_rows += 1
            if s.id in seen:
                res.duplicate_rows += 1
                continue
            seen[s.id] = s
            if res.id_min is None or s.id < res.id_min:
                res.id_min = s.id
            if res.id_max is None or s.id > res.id_max:
                res.id_max = s.id
            if s.is_open:
                res.open_seen += 1
            if s.bad_dates:
                res.bad_date_rows += 1
            for d in (s.date_create,):
                if d is not None:
                    if res.oldest_create is None or d < res.oldest_create:
                        res.oldest_create = d
                    if res.newest_create is None or d > res.newest_create:
                        res.newest_create = d
            ok, _why = _is_candidate(s, frm, to, cluster)
            if ok:
                res.candidates.append(s)
        offset += len(rows)
        if has_next is False:
            break
        if len(rows) < SESSION_PAGE_SIZE:
            break
    res.unique_sessions = len(seen)
    return res
