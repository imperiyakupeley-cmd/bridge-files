"""Контракт запроса модуля messages (совместим со спекой admin2 §3).

Интенты модуля (предложение в спеку v1.1 — Open Lines делегирован из core):
  messages_period  — переписки ОЛ за окно [from, to): from/to обязательны;
                     employee_id/entity/cluster запрещены (окно общее).
  messages_cluster — переписки по клиентскому кластеру: cluster обязателен
                     (набор сущностей CRM); from/to опциональны (без них — вся
                     доступная история сессий кластера в пределах окна API);
                     employee_id запрещён.

Любой неизвестный ключ/значение → SchemaError → ответ FAILED c code=SCHEMA
ДО похода в REST (§3).
"""
from __future__ import annotations

import re
import uuid

from .errors import SchemaError
from .timeutil import TimeError, parse_iso

TZ_NAME = "Europe/Moscow"

KNOWN_INTENTS = {"messages_period", "messages_cluster"}

_COMMON_KEYS = {"intent", "request_id", "tz", "options", "from", "to"}
_OPTIONS_KEYS = {
    "index",               # scan | activity | activity+scan (default scan)
    "include_system",      # системные senderid=0 (default true)
    "sender_ids",          # локальный фильтр по senderid (список int)
    "lines",               # локальный фильтр по configId (список int)
    "max_messages_per_chat",
    "max_facts",
    "max_text_len",
    "activity_audit",      # аудит текстов по автологам в scan-режиме (default true)
    "sources_override",    # совместимость с §3 (должен быть пустым списком)
}
_ENTITY_TYPES = {"lead", "deal", "contact"}
_UUID_RE = re.compile(r"^[0-9a-zA-Z._:-]{1,128}$")


def _check_window(req: dict) -> tuple | None:
    if "from" in req or "to" in req:
        if "from" not in req or "to" not in req:
            raise SchemaError("from и to идут парой")
        try:
            frm = parse_iso(req["from"], field="from")
            to = parse_iso(req["to"], field="to")
        except TimeError as e:
            raise SchemaError(str(e)) from e
        if frm >= to:
            raise SchemaError("from должен быть раньше to (полуинтервал [from, to))")
        return frm, to
    return None


def _check_options(options: dict) -> dict:
    if not isinstance(options, dict):
        raise SchemaError("options должен быть объектом")
    bad = set(options) - _OPTIONS_KEYS
    if bad:
        raise SchemaError(f"неизвестные опции: {sorted(bad)}")
    if "index" in options and options["index"] not in {"scan", "activity", "activity+scan"}:
        raise SchemaError("options.index: scan | activity | activity+scan")
    for key in ("include_system", "activity_audit"):
        if key in options and not isinstance(options[key], bool):
            raise SchemaError(f"options.{key} должен быть bool")
    for key in ("sender_ids", "lines"):
        if key in options:
            if not isinstance(options[key], list) or not all(
                    isinstance(x, int) and not isinstance(x, bool) for x in options[key]):
                raise SchemaError(f"options.{key}: список целых")
    for key in ("max_messages_per_chat", "max_facts", "max_text_len"):
        if key in options:
            v = options[key]
            if not isinstance(v, int) or isinstance(v, bool) or v < 1 or v > 200_000:
                raise SchemaError(f"options.{key}: целое 1..200000")
    if "sources_override" in options and options["sources_override"] != []:
        raise SchemaError("sources_override не поддерживается модулем messages")
    return options


def _check_cluster(req: dict) -> list[dict] | None:
    cluster = req.get("cluster")
    if cluster is None:
        return None
    if not isinstance(cluster, dict) or set(cluster) != {"entities"}:
        raise SchemaError("cluster: {entities: [{type, id}, ...]}")
    ents = cluster["entities"]
    if not isinstance(ents, list) or not ents or len(ents) > 5000:
        raise SchemaError("cluster.entities: непустой список до 5000 сущностей")
    out = []
    for e in ents:
        if (not isinstance(e, dict) or set(e) != {"type", "id"}
                or e["type"] not in _ENTITY_TYPES
                or not isinstance(e["id"], int) or isinstance(e["id"], bool) or e["id"] < 1):
            raise SchemaError("cluster.entities[]: {type: lead|deal|contact, id: int>=1}")
        out.append({"type": e["type"], "id": e["id"]})
    return out


def validate_request(req: dict) -> dict:
    if not isinstance(req, dict):
        raise SchemaError("запрос должен быть JSON-объектом")
    unknown = set(req) - _COMMON_KEYS - {"cluster"}
    if unknown:
        raise SchemaError(f"неизвестные ключи запроса: {sorted(unknown)}")

    intent = req.get("intent")
    if intent not in KNOWN_INTENTS:
        raise SchemaError(f"неизвестный intent: {intent!r}")

    rid = req.get("request_id")
    if not rid or not isinstance(rid, str) or not _UUID_RE.match(rid):
        raise SchemaError("request_id обязателен (uuid4, до 128 символов)")
    try:
        uuid.UUID(str(rid), version=4)
    except (ValueError, AttributeError, TypeError):
        pass  # тип свободнее uuid4 (мосты добавляют суффиксы) — regex уже отфильтровал

    tz = req.get("tz", TZ_NAME)
    if tz != TZ_NAME:
        raise SchemaError(f"tz только {TZ_NAME}, получено {tz!r}")

    options = _check_options(req.get("options", {}))
    window = _check_window(req)
    cluster = _check_cluster(req)

    if intent == "messages_period":
        if window is None:
            raise SchemaError("messages_period: from/to обязательны")
        if cluster is not None:
            raise SchemaError("messages_period: cluster запрещён (окно общее)")
    else:  # messages_cluster
        if cluster is None:
            raise SchemaError("messages_cluster: cluster обязателен")

    return {
        "intent": intent,
        "request_id": rid,
        "from": window[0] if window else None,
        "to": window[1] if window else None,
        "cluster": cluster,
        "options": options,
    }


def default_request_id() -> str:
    return str(uuid.uuid4())
