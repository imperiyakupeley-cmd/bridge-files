"""Выкачка историй сессий: imopenlines.session.history.get по SESSION_ID.

[ФАКТ, пробы 08.11 + probe_fixes_20261109/probe2 09.11 — РЕАЛЬНАЯ схема]:
- без параметров метод отдаёт страницу 50 СВЕЖАЙШИХ сообщений (ключи message
  по убыванию id); курсор LAST_MESSAGE_ID сервером ИГНОРИРУЕТСЯ (проба:
  и с max_id, и с min_id возвращается та же страница 50) — старая курсорная
  догрузка не добирала НИЧЕГО (дефект F5: 45/595 сессий с недобором);
- параметр LIMIT работает: LIMIT=200 на сессии 25396 вернул 152/152
  (Stat.get при этом считает messagesCount=143 — счётчики разной семантики,
  в history есть системные senderid=0); LIMIT=5000 без потолка;
- серверные фильтры по senderid/date ФИКТИВНЫ — фильтруем локально;
- batch по 45 команд; per-key ошибки в result_error — не исключения (§5).

Схема полноты: LIMIT=history_limit (5000) одним вызовом; если страница
упёрлась в LIMIT (fetched == limit) — до двух эскалаций ×2; упор остаётся →
cap_hit: история НЕДОБРАНА поимённо (truncated, PARTIAL). Если метод отдал
меньше запрошенного — это ВСЁ, что он имеет: messageCount больше полученного
означает расхождение счётчиков (удалённые/семантика), а не потерю пагинации:
поимённое предупреждение count_mismatch, PARTIAL, но не «пагинация сломана».
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from .config import HISTORY_BATCH, HISTORY_LIMIT_ESC, MsgConfig
from .errors import SourceError
from .sessions import SessionRow
from .timeutil import parse_iso_loose

SOURCE = "imopenlines.session.history.get"
MAX_TEXT_KEEP = 4000        # жёсткий потолок хранения текста в памяти
MAX_PARAM_KEYS = 10
MAX_MISMATCH_WARN = 20      # поимённых count_mismatch в warnings (остальные в coverage)


def _connector_mid(params: dict) -> str | None:
    """params-ключ идентификатора сообщения коннектора. [ФАКТ, живой прогон
    09.11]: в history.get ключ приходит camelCase «connectorMid» (184/317
    сообщений окна 07.11), значение — скаляр ИЛИ список с одним элементом;
    значения двух видов: число == id сообщения Б24 и hex-32 (uuid коннектора,
    вероятно avito message id). В доках/событиях встречается CONNECTOR_MID —
    принимаем любые регистры и обе формы значения."""
    for k, v in params.items():
        if str(k).lower() in ("connector_mid", "connectormid"):
            if isinstance(v, list):
                v = v[0] if v else None
            if isinstance(v, (str, int)):
                return str(v)[:64]
    return None


@dataclass
class MessageRow:
    id: int
    session_id: int
    chat_id: int | None
    sender_id: int | None       # senderid (0 = системное)
    ts: datetime | None
    text: str
    params_keys: list
    has_files: bool
    bad_date: bool
    connector_mid: str | None   # params.CONNECTOR_MID — ключ склейки с Авито v3

    def to_json(self) -> dict:
        return {"id": self.id, "session_id": self.session_id, "chat_id": self.chat_id,
                "sender_id": self.sender_id,
                "ts": self.ts.isoformat() if self.ts else None,
                "text_len": len(self.text)}


@dataclass
class SessionHistory:
    session_id: int
    messages: list = field(default_factory=list)
    error: dict | None = None
    truncated: bool = False          # cap_hit: реальная потеря хвоста истории
    pages: int = 1
    expected_count: int | None = None
    fetched_count: int = 0           # получено ДО локальных фильтров окна
    dup_ids: int = 0
    cap_hit: bool = False            # упёрлись в LIMIT (включая эскалации)
    count_mismatch: bool = False     # messageCount > отданного при незадетом лимите
    limit_used: int = 0

    @property
    def ok(self) -> bool:
        return self.error is None


@dataclass
class HistoriesResult:
    by_session: dict = field(default_factory=dict)
    messages: list = field(default_factory=list)   # плоский список MessageRow
    duplicate_global: int = 0
    unknown_date: int = 0
    history_errors: int = 0
    truncated_sessions: list = field(default_factory=list)
    per_chat_counts: dict = field(default_factory=dict)
    underfetch: list = field(default_factory=list)     # [{sid, got, expected, limit}]
    count_mismatch: list = field(default_factory=list)  # [{sid, got, expected}]

    def coverage(self) -> dict:
        missing_total = sum(max(0, (u.get("expected") or 0) - u["got"])
                            for u in self.underfetch)
        return {
            "source": SOURCE,
            "sessions": len(self.by_session),
            "sessions_ok": sum(1 for h in self.by_session.values() if h.ok),
            "history_errors": self.history_errors,
            "messages_total": len(self.messages),
            "duplicate_global": self.duplicate_global,
            "unknown_date": self.unknown_date,
            "truncated_sessions": self.truncated_sessions,
            "underfetch_cap": {
                "sessions": len(self.underfetch),
                "messages_missing_total": missing_total,
                "detail": self.underfetch[:50],
            },
            "count_mismatch": {
                "sessions": len(self.count_mismatch),
                "detail": self.count_mismatch[:50],
            },
            "chats": len(self.per_chat_counts),
        }


def _parse_message(mid: str, raw: dict, session: SessionRow, *,
                   max_text_len: int) -> MessageRow | None:
    try:
        mid_int = int(mid)
    except (TypeError, ValueError):
        return None
    sid = raw.get("senderid")
    try:
        sid = int(sid) if sid is not None else None
    except (TypeError, ValueError):
        sid = None
    chat = raw.get("chatid") or session.chat_id
    try:
        chat = int(chat) if chat is not None else None
    except (TypeError, ValueError):
        chat = session.chat_id
    params = raw.get("params")
    pkeys = []
    has_files = False
    connector_mid = None
    if isinstance(params, dict):
        pkeys = [str(k) for k in list(params.keys())[:MAX_PARAM_KEYS]]
        has_files = any("FILE" in k.upper() for k in params.keys())
        connector_mid = _connector_mid(params)   # ключ склейки с Авито v3 (§5)
    text = raw.get("text")
    text = text if isinstance(text, str) else ""
    if len(text) > max_text_len:
        text = text[:min(max_text_len, MAX_TEXT_KEEP)]
    ts = parse_iso_loose(raw.get("date"))
    return MessageRow(id=mid_int, session_id=session.id, chat_id=chat,
                      sender_id=sid, ts=ts, text=text, params_keys=pkeys,
                      has_files=has_files, bad_date=ts is None,
                      connector_mid=connector_mid)


def _extract(env, session: SessionRow, *, max_text_len: int) -> tuple[list, int]:
    """env — результат одной команды: из batch (result-часть) или полный конверт
    client.call ({'result': {...}}); 'message' ищем на обоих уровнях.
    Возвращает (строки MessageRow, всего распарсено сырых записей)."""
    payload = env
    if isinstance(env, dict) and "message" not in env and isinstance(env.get("result"), dict):
        payload = env["result"]
    msgs = payload.get("message") if isinstance(payload, dict) else None
    out: list[MessageRow] = []
    parsed = 0
    if isinstance(msgs, dict):
        for mid, raw in msgs.items():
            if isinstance(raw, dict):
                parsed += 1
                m = _parse_message(mid, raw, session, max_text_len=max_text_len)
                if m is not None:
                    out.append(m)
    return out, parsed


def fetch_histories(client, cfg: MsgConfig, sessions: list[SessionRow], *,
                    max_text_len: int) -> dict[int, SessionHistory]:
    """Истории всех сессий батчами по 45 команд «SESSION_ID + LIMIT».
    Эскалация LIMIT ×2 (до двух раз) при упоре в лимит страницы.
    Возвращает {session_id: SessionHistory}."""
    out: dict[int, SessionHistory] = {}
    base_limit = max(1, int(cfg.history_limit))
    todo = [s for s in sessions if s.message_count is None or s.message_count > 0]
    skip_zero = len(sessions) - len(todo)

    for i in range(0, len(todo), HISTORY_BATCH):
        chunk = todo[i:i + HISTORY_BATCH]
        cmds = [(f"h{s.id}", SOURCE, {"SESSION_ID": s.id, "LIMIT": base_limit})
                for s in chunk]
        try:
            res, errs = client.batch(cmds)
        except SourceError as e:
            for s in chunk:  # весь батч упал — поимённо
                out[s.id] = SessionHistory(session_id=s.id, error=e.to_json())
            continue
        for (key, _m, _p), s in zip(cmds, chunk):
            hist = SessionHistory(session_id=s.id, expected_count=s.message_count,
                                  limit_used=base_limit)
            if key in errs:
                err = errs.get(key) or {}
                hist.error = {"code": "SOURCE_ERROR", "source": SOURCE,
                              "detail": str(err.get("error") or err)[:200]}
                out[s.id] = hist
                continue
            env = res.get(key) or {}
            # внутри batch результат уже result-часть команды: {"message": {...}}
            rows, parsed_total = _extract(env, s, max_text_len=max_text_len)
            seen_ids = {m.id for m in rows}
            pages = 1
            # ── эскалация LIMIT: страница упёрлась в лимит — просим больше ──
            limit = base_limit
            ok_limit = base_limit   # лимит ПОДТВЕРЖДЁННОГО успешного запроса
            for _ in range(HISTORY_LIMIT_ESC):
                if len(seen_ids) < limit:
                    break
                limit *= 2
                try:
                    cont = client.call(SOURCE, {"SESSION_ID": s.id, "LIMIT": limit})
                except SourceError:
                    # эскалация не ответила: полнота недоказуема → fail-closed
                    # (cap проверяем по подтверждённому ok_limit)
                    limit = ok_limit
                    break
                ok_limit = limit
                pages += 1
                more, _mp = _extract(cont, s, max_text_len=max_text_len)
                parsed_total += _mp
                new = [m for m in more if m.id not in seen_ids]
                for m in new:
                    seen_ids.add(m.id)
                    rows.append(m)
                if not new:
                    break
            hist.pages = pages
            hist.limit_used = limit
            hist.fetched_count = len(rows)
            hist.dup_ids = max(0, parsed_total - len(seen_ids))
            hist.messages = rows
            if hist.fetched_count >= ok_limit:
                hist.cap_hit = True      # даже эскалация не прошла — хвост недобран
                hist.truncated = True
            elif (s.message_count is not None
                  and hist.fetched_count < s.message_count):
                # метод отдал ВСЁ, что имеет (лимит не задет), но счётчик больше:
                # расхождение семантики/удалённые — не потеря пагинации
                hist.count_mismatch = True
            out[s.id] = hist

    for s in sessions:
        if s.id not in out and s.message_count == 0:
            out[s.id] = SessionHistory(session_id=s.id, messages=[],
                                       expected_count=0)
    return out


def apply_local_filters(result: HistoriesResult, histories: dict[int, SessionHistory],
                        sessions: list[SessionRow], *, frm, to, sender_ids,
                        include_system: bool, max_per_chat: int) -> dict[int, SessionHistory]:
    """Локальная фильтрация (серверная фиктивна): окно [from,to) по ВРЕМЕНИ
    сообщения, senderid, системные, потолок на чат. Меняет histories in-place
    и наполняет result-счётчики."""
    chat_budget: dict[int, int] = {}
    by_session = {s.id: s for s in sessions}
    for sid, hist in histories.items():
        kept = []
        sess = by_session.get(sid)
        for m in sorted(hist.messages, key=lambda x: (x.ts is None, x.ts)):
            if m.sender_id == 0 and not include_system:
                continue
            if sender_ids is not None and m.sender_id not in sender_ids:
                continue
            if frm is not None and to is not None:
                if m.ts is None:
                    result.unknown_date += 1  # держим (fail-closed), но считаем
                elif not (frm <= m.ts < to):
                    continue
            chat = m.chat_id
            if chat is not None and max_per_chat:
                used = chat_budget.get(chat, 0)
                if used >= max_per_chat:
                    hist.truncated = True
                    continue
                chat_budget[chat] = used + 1
            kept.append(m)
            result.messages.append(m)
            if m.chat_id is not None:
                result.per_chat_counts[m.chat_id] = result.per_chat_counts.get(m.chat_id, 0) + 1
        hist.messages = kept
        if hist.error is not None:
            result.history_errors += 1
        if hist.cap_hit:
            result.underfetch.append({
                "session_id": sid, "got": hist.fetched_count,
                "expected": hist.expected_count, "limit": hist.limit_used})
        if hist.count_mismatch:
            result.count_mismatch.append({
                "session_id": sid, "got": hist.fetched_count,
                "expected": hist.expected_count})
        if hist.truncated:
            result.truncated_sessions.append(sid)
        result.by_session[sid] = hist
    # глобальный дедуп по id сообщения (сессии одного чата не пересекаются,
    # но перестраховка §7.5 — счёт после дедупа)
    seen: set = set()
    uniq = []
    for m in result.messages:
        if m.id in seen:
            result.duplicate_global += 1
            continue
        seen.add(m.id)
        uniq.append(m)
    result.messages = uniq
    for sid, hist in result.by_session.items():
        hist.messages = [m for m in hist.messages if m.id in seen]
    return histories
