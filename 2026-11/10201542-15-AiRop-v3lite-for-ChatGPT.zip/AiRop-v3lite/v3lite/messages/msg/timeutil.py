"""Время модуля messages: Europe/Moscow (+03:00), ISO-8601 с офсетом.

Семантика повторяет core/timeutil (контракт §2): окно — полуинтервал [from, to),
дата факта — фактическое время события, не время создания записи.
Bitrix-фильтры crm.activity.list принимают 'dd.mm.yyyy HH:MM:SS'.
"""
from __future__ import annotations

import re
from datetime import date as _date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

TZ = ZoneInfo("Europe/Moscow")
OFFSET = timezone(timedelta(hours=3))  # МСК без перехода — стабилен круглый год

_ISO = re.compile(r"^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})([+-]\d{2}:\d{2})$")


class TimeError(ValueError):
    pass


def parse_iso(value: str, *, field: str = "time") -> datetime:
    """Строгий парсер 'YYYY-MM-DDTHH:MM:SS±HH:MM'. Без офсета — отказ."""
    if not isinstance(value, str) or not _ISO.match(value):
        raise TimeError(f"{field}: ожидался ISO-8601 с офсетом, получено {value!r}")
    return datetime.fromisoformat(value).astimezone(TZ)


def parse_iso_loose(value, *, field: str = "time") -> datetime | None:
    """Для данных ИСТОЧНИКА (OL v2 отдаёт ISO с офсетом): None при мусоре.

    Источник не обязан быть идеальным: битую дату не подставляем и не гадаем —
    возвращаем None и фиксируем в coverage (fail-closed по §4.5).
    """
    if value is None:
        return None
    if not isinstance(value, str):
        return None
    v = value.strip()
    if not v:
        return None
    try:
        dt = datetime.fromisoformat(v)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=OFFSET)  # портал отдаёт МСК
    return dt.astimezone(TZ)


def fmt_iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=OFFSET)
    return dt.astimezone(OFFSET).replace(microsecond=0).isoformat()


def now_msk() -> datetime:
    return datetime.now(TZ)


def day_bounds(day: str) -> tuple[datetime, datetime]:
    """'YYYY-MM-DD' → [T00:00+03:00, +24h)."""
    from datetime import date as _d
    try:
        dd = _d.fromisoformat(day)
    except ValueError as e:
        raise TimeError(f"day: {day!r} не YYYY-MM-DD") from e
    frm = datetime(dd.year, dd.month, dd.day, tzinfo=OFFSET)
    return frm, frm + timedelta(hours=24)


def to_bx_filter_date(dt: datetime) -> str:
    """datetime → 'dd.mm.yyyy HH:MM:SS' для FILTER[>CREATED] crm.activity.list."""
    return dt.astimezone(OFFSET).strftime("%d.%m.%Y %H:%M:%S")


def parse_bx_date(value: str | None) -> datetime | None:
    """'dd.mm.yyyy HH:MM:SS' (crm.activity.list CREATED) → datetime|None."""
    if not value or not isinstance(value, str):
        return None
    v = value.strip()
    for pat in ("%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M"):
        try:
            return datetime.strptime(v, pat).replace(tzinfo=OFFSET)
        except ValueError:
            continue
    return parse_iso_loose(v)
