"""Модуль messages ИИ-РОП v3 Lite: переписки Открытых линий on-demand.

Изолирован от core (DEV) и боевых скриптов ~/AiRop: не импортирует их,
не пишет в CRM/calls.db, только read-only REST (whitelist).
Контракт — spec_v3lite_admin2.md §3–4; интенты messages_period/messages_cluster
предложены в спеку v1.1 (Open Lines делегирован из core, см. core/contract.py).
"""
from .fetcher import fetch  # noqa: F401

__all__ = ["fetch"]
