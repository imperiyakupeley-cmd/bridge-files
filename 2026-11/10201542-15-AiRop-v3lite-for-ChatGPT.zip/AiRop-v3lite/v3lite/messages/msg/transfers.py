"""Передачи сессий между операторами: imopenlines.v2.Session.Transfer.list.

[ФАКТ, probe2_fixes_20261109 09.11 — РЕАЛЬНАЯ форма вызова, фикс D8]:
- параметр sessionId принимается ТОЛЬКО массивом: POST {"sessionId":[29666]}
  → 200; GET ?sessionId[]=29666 → 200; скаляр (GET/POST) → HTTP 400
  «Invalid value … Should be value of type array»; повторяющиеся ключи
  sessionId=1&sessionId=2 (старая форма модуля) → HTTP 400 — именно поэтому
  переносы не собирались (6×SOURCE_5XX на живом прогоне приёмки);
- ответ: {"result": {"transfers": [{sessionId, date, fromOperatorId,
  toOperatorId, fromConfigId, toConfigId, reason, mode, type, initiatorId}]}};
  на массив id приходит объединение по всем сессиям (проверено: 2 id → 2+).

Назначение в модуле: факт transfer + опора для атрибуции «чужих» авторов
после передачи (§6: сообщения ПОСЛЕ передачи у другого оператора — атрибуция
по фактическому senderid из history, не по оператору сессии).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from .config import TRANSFER_CHUNK, MsgConfig
from .errors import MsgError
from .timeutil import parse_iso_loose

SOURCE = "imopenlines.v2.Session.Transfer.list"


@dataclass
class TransferRow:
    session_id: int
    transfer_id: str
    ts: datetime | None
    from_user: int | None      # fromOperatorId [ФАКТ, probe2]
    to_user: int | None        # toOperatorId
    initiator_id: int | None   # initiatorId (кто перенёс)
    mode: str | None
    reason: str | None
    raw: dict


@dataclass
class TransfersResult:
    rows: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    calls: int = 0
    sessions_probed: int = 0

    def coverage(self) -> dict:
        return {"source": SOURCE, "transfers": len(self.rows),
                "sessions_probed": self.sessions_probed,
                "errors": self.errors[:10], "calls": self.calls}


def _norm_ts(raw: dict) -> datetime | None:
    for key in ("date", "dateCreate", "created"):
        if raw.get(key):
            dt = parse_iso_loose(raw.get(key))
            if dt is None:
                from .timeutil import parse_bx_date
                dt = parse_bx_date(raw.get(key))
            if dt is not None:
                return dt
    return None


def _to_int(v):
    try:
        return int(v) if v is not None else None
    except (TypeError, ValueError):
        return None


def fetch_transfers(client, cfg: MsgConfig, session_ids: list[int]) -> TransfersResult:
    """Переносы по списку сессий: POST {"sessionId": [чанк]} по 20 id
    (живая форма,probe2; скаляр/повторы ключей дают HTTP 400 → SOURCE_4XX)."""
    res = TransfersResult()
    ids = [s for s in session_ids if isinstance(s, int)]
    res.sessions_probed = len(ids)
    for i in range(0, len(ids), TRANSFER_CHUNK):
        chunk = ids[i:i + TRANSFER_CHUNK]
        try:
            env = client.post(SOURCE, {"sessionId": chunk})
            res.calls += 1
        except MsgError as e:
            res.errors.append(e.to_json())
            continue
        payload = env.get("result") if isinstance(env, dict) else None
        rows = []
        if isinstance(payload, dict):
            rows = payload.get("transfers") or payload.get("items") or []
        elif isinstance(payload, list):
            rows = payload
        if not isinstance(rows, list):
            continue
        for raw in rows:
            if not isinstance(raw, dict):
                continue
            tid = raw.get("id") or raw.get("ID") or len(res.rows)
            res.rows.append(TransferRow(
                session_id=_to_int(raw.get("sessionId") or raw.get("session_id")) or 0,
                transfer_id=str(tid),
                ts=_norm_ts(raw),
                from_user=_to_int(raw.get("fromOperatorId") or raw.get("fromUserId")),
                to_user=_to_int(raw.get("toOperatorId") or raw.get("toUserId")),
                initiator_id=_to_int(raw.get("initiatorId")),
                mode=raw.get("mode") if isinstance(raw.get("mode"), str) else None,
                reason=raw.get("reason") if isinstance(raw.get("reason"), str) else None,
                raw={k: v for k, v in raw.items() if isinstance(v, (str, int, float, bool))},
            ))
    return res
