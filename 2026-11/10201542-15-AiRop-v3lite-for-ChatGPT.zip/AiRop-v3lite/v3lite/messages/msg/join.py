"""Строгий exact-join Авито↔Б24 — директива владельца 09.11 (мост mw912x028ygf).

Прямой API Авито может перепутать клиентов, поэтому любые эвристики по
СОДЕРЖИМУ запрещены категорически: сшивка по тексту, по времени ±N минут,
по телефону, по имени/подписи — в том числе «только как кандидаты».
Движок структурно не читает text/имена/время при соединении: ключи —
только ID (доказывается тестом: затирание всех текстов не меняет результат).

Разрешённые ключи (все строгие):
  чат:       (account_user_id, chat_u2i) ↔ диалог Б24 по разбору entity_id
             `avito|{lineId}|{u2i}|{connector_user_id}` + проверенный индекс
             userCode→аккаунт (verified_index из v2.Session/адаптера).
             Fail-closed: u2i нет в индексе или сообщение пришло от другого
             аккаунта → привязки НЕТ (UNLINKED), выдумывать запрещено.
  сообщение: params.CONNECTOR_MID (Б24) == message id (Авито), 1:1 В ОБЕ
             стороны; дубль ключа с любой стороны → AMBIGUOUS без склейки.
  CRM:       entity_data_2 (LEAD|id|COMPANY|id|CONTACT|id|DEAL|id) с контролем
             взаимной однозначности: сущность в двух чатах (дубли лидов) →
             crm AMBIGUOUS, факты исключаются из досье ОБЕИХ кандидатов.

Статусы: join_status LINKED | UNLINKED | AMBIGUOUS; crm_status аналогично.
AMBIGUOUS не засчитывается никому (ни сотруднику, ни досье клиента) —
поимённый warning, статус ответа не выше PARTIAL.

Атрибуция сотрудника — ТОЛЬКО author_id Б24-копии (кроме 0, клиента-
коннектора чата, ботов и exclude_users). Интерпретация директивы «missing
ID → UNLINKED, не засчитывать сотруднику»: avito-факты без строгого ключа
сотруднику НЕ засчитываются никогда; Б24-копии несут родную атрибуцию
(собственные id Б24), но при AMBIGUOUS исключается и она. senderId Авито
идентификатором сотрудника Б24 НЕ является: employee_from_avito() всегда
отказ, числовое совпадение senderId с id сотрудника — канарейка-предупреждение.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .errors import SecurityError

# ── запрет эвристик на уровне API ────────────────────────────────────────────
# Ключи ниже нельзя даже ПЕРЕДАТЬ в join: директива 09.11 (mw912x028ygf).
FORBIDDEN_JOIN_OPTIONS = frozenset({
    "window_minutes", "fuzzy_window_min", "time_window_s", "time_window_minutes",
    "text_similarity", "min_similarity", "match_by_text", "match_by_phone",
    "match_by_name", "phone", "phones", "name", "names", "strip_signature",
    "signature_regex", "normalize_text", "fuzzy", "use_fuzzy",
})
ALLOWED_JOIN_OPTIONS: frozenset[str] = frozenset()  # у exact-join опций нет

LINKED, UNLINKED, AMBIGUOUS = "LINKED", "UNLINKED", "AMBIGUOUS"

CRM_TYPES = {"LEAD", "COMPANY", "CONTACT", "DEAL"}


def employee_from_avito(*_args, **_kwargs) -> int:
    """Запрещено директивой: senderId Авито ≠ идентификатор сотрудника Б24."""
    raise SecurityError(
        "senderId Авито не является идентификатором сотрудника Б24 "
        "(директива 09.11, exact-join)")


# ── разбор строгих ключей ────────────────────────────────────────────────────
def parse_entity_id(entity_id) -> tuple[int, str, int] | None:
    """`avito|{lineId}|{u2i}|{connector_user_id}` → (line, u2i, uid); иначе None."""
    if not isinstance(entity_id, str):
        return None
    parts = entity_id.split("|")
    if len(parts) != 4 or parts[0] != "avito":
        return None
    try:
        line, uid = int(parts[1]), int(parts[3])
    except ValueError:
        return None
    if line <= 0 or uid <= 0 or not parts[2]:
        return None
    return line, parts[2], uid


def parse_entity_data_2(raw) -> tuple[tuple[str, int], ...]:
    """`LEAD|3199|COMPANY|0|…` → ненулевые (('LEAD', 3199), …); малформа → ()."""
    if not isinstance(raw, str) or not raw:
        return ()
    parts = raw.split("|")
    out: list[tuple[str, int]] = []
    for i in range(0, len(parts) - 1, 2):
        etype, val = parts[i], parts[i + 1]
        try:
            vid = int(val)
        except ValueError:
            return ()
        if etype not in CRM_TYPES:
            return ()
        if vid > 0:
            out.append((etype, vid))
    return tuple(out)


def connector_mid_of(b24_msg: dict) -> str | None:
    """Значение params.CONNECTOR_MID (camelCase/snake, скаляр или список)."""
    params = b24_msg.get("params") or {}
    if not isinstance(params, dict):
        return None
    for key, val in params.items():
        if str(key).lower() in ("connector_mid", "connectormid"):
            if isinstance(val, list):
                val = val[0] if val else None
            if val is None:
                return None
            s = str(val).strip()
            return s[:64] or None
    return None


def normalize_users(rows) -> dict[int, dict]:
    """users-блок диалога (id/bot/connector) → {int_id: {bot, connector}}."""
    out: dict[int, dict] = {}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        raw_id = row.get("id", row.get("ID"))
        try:
            uid = int(raw_id)
        except (TypeError, ValueError):
            continue
        ext = str(row.get("external_auth_id", row.get("EXTERNAL_AUTH_ID")) or "")
        out[uid] = {
            "bot": bool(row.get("bot")) or ext == "bot",
            "connector": bool(row.get("connector")) or ext == "imconnector",
        }
    return out


# ── привязки чатов ───────────────────────────────────────────────────────────
@dataclass(frozen=True)
class ChatBinding:
    chat_u2i: str
    chat_id: int                 # Б24
    line_id: int                 # Б24 configId (из entity_id)
    connector_user_id: int       # клиент-коннектор Б24 (из entity_id)
    crm: tuple[tuple[str, int], ...]   # ненулевые привязки CRM
    accounts: frozenset[int]     # аккаунты Авито, владеющие чатом (проверенные)


@dataclass
class Bindings:
    by_u2i: dict[str, list[ChatBinding]] = field(default_factory=dict)
    by_chat: dict[int, ChatBinding] = field(default_factory=dict)
    crm_claims: dict[tuple[str, int], list[int]] = field(default_factory=dict)
    unparsed_chats: list[int] = field(default_factory=list)

    def owners_of(self, u2i: str) -> set[int]:
        out: set[int] = set()
        for b in self.by_u2i.get(u2i, []):
            out |= b.accounts
        return out


def build_bindings(dialog_rows: list[dict],
                   verified_index: dict[str, int]) -> Bindings:
    """Привязки из im.dialog.get + проверенный индекс userCode→аккаунт.

    Чат без записи в verified_index получает accounts=∅ → fail-closed:
    никакое авито-сообщение такого чата не связывается (unverified).
    """
    b = Bindings()
    for row in dialog_rows or []:
        try:
            chat_id = int(row.get("id"))
        except (TypeError, ValueError):
            continue
        parsed = parse_entity_id(row.get("entity_id"))
        if parsed is None:
            b.unparsed_chats.append(chat_id)
            continue
        line, u2i, conn_uid = parsed
        account = verified_index.get(u2i)
        binding = ChatBinding(chat_u2i=u2i, chat_id=chat_id, line_id=line,
                              connector_user_id=conn_uid,
                              crm=parse_entity_data_2(row.get("entity_data_2")),
                              accounts=frozenset({account}) if account else frozenset())
        b.by_u2i.setdefault(u2i, []).append(binding)
        b.by_chat[chat_id] = binding
    # взаимная однозначность сущность↔чат (дубли лидов)
    for binding in b.by_chat.values():
        for ent in binding.crm:
            b.crm_claims.setdefault(ent, []).append(binding.chat_id)
    return b


# ── результат ────────────────────────────────────────────────────────────────
@dataclass
class JoinedMessage:
    ref: str                     # "chat{N}#msg{M}" | "avito:{acct}:{u2i}#msg:{id}"
    origin: str                  # "b24" | "avito"
    chat_id: int | None          # Б24 (у avito-only None)
    chat_u2i: str | None
    account_user_id: int | None
    join_status: str             # LINKED | UNLINKED | AMBIGUOUS
    pair_ref: str | None = None
    reason: str = ""             # именованная причина статуса
    role: str = "CONNECTOR"      # WE | CLIENT | BOT | CONNECTOR | UNKNOWN
    employee_id: int | None = None   # ТОЛЬКО из author_id Б24-копии
    employee_source: str | None = None
    crm_status: str = UNLINKED   # LINKED | UNLINKED | AMBIGUOUS
    crm: tuple[tuple[str, int], ...] = ()

    def to_json(self) -> dict:
        return {
            "ref": self.ref, "origin": self.origin, "chat_id": self.chat_id,
            "chat_u2i": self.chat_u2i, "account_user_id": self.account_user_id,
            "join_status": self.join_status, "pair_ref": self.pair_ref,
            "reason": self.reason, "role": self.role,
            "employee_id": self.employee_id,
            "employee_source": self.employee_source,
            "crm_status": self.crm_status,
            "crm": [[t, i] for t, i in self.crm],
        }


@dataclass
class JoinResult:
    messages: list[JoinedMessage]
    warnings: list[dict]
    counts: dict
    recommended_status: str

    def employee_counts(self) -> dict[int, int]:
        """Засчитываемые сотруднику: origin=b24, атрибуция из author_id,
        статус не AMBIGUOUS (коллизия → никому)."""
        out: dict[int, int] = {}
        for m in self.messages:
            if (m.employee_source == "b24.author_id" and m.employee_id
                    and m.join_status != AMBIGUOUS):
                out[m.employee_id] = out.get(m.employee_id, 0) + 1
        return out

    def to_json(self) -> dict:
        return {
            "policy": "exact_ids_only (директива 09.11, mw912x028ygf)",
            "status": self.recommended_status,
            "messages": [m.to_json() for m in self.messages],
            "warnings": self.warnings,
            "counts": {**self.counts,
                       "employee": {str(k): v for k, v in self.employee_counts().items()}},
        }


# ── движок ───────────────────────────────────────────────────────────────────
def _b24_ref(chat_id, msg_id) -> str:
    return f"chat{chat_id}#msg{msg_id}"


def _avito_ref(account, u2i, msg_id) -> str:
    return f"avito:{account}:{u2i}#msg:{msg_id}"


def _b24_role_employee(author, binding: ChatBinding | None, users: dict,
                       exclude: set[int]) -> tuple[str, int | None]:
    if author in (None, 0):
        return "CONNECTOR", None
    info = users.get(author) or {}
    if info.get("connector"):
        return "CLIENT", None
    if binding and author == binding.connector_user_id:
        return "CLIENT", None
    if info.get("bot") or author in exclude:
        return "BOT", None
    return "WE", author


def _avito_role(direction, author, account) -> str:
    if direction == "out":
        return "WE" if author is not None and author == account else "UNKNOWN"
    return "CLIENT"


def join_exact(*, dialog_rows: list[dict], chat_messages: dict[int, list[dict]],
               avito_chats: list[dict], verified_index: dict[str, int],
               users: dict[int, dict] | None = None,
               exclude_users: set[int] | None = None,
               options: dict | None = None) -> JoinResult:
    """Строгий exact-join. Сети нет, контент (текст/имя/телефон/время) не читается.

    dialog_rows  — строки im.dialog.get (id, entity_id, entity_data_2);
    chat_messages — {chat_id Б24: [строки im.dialog.messages.get]};
    avito_chats  — [{account_user_id, chat_u2i, messages: [строки v3]}];
    verified_index — проверенный userCode→аккаунт ({u2i: account_user_id}).
    """
    if options:
        bad = set(options) & FORBIDDEN_JOIN_OPTIONS
        if bad:
            raise SecurityError(
                f"эвристики сшивки запрещены директивой 09.11: {sorted(bad)}")
        unknown = set(options) - ALLOWED_JOIN_OPTIONS
        if unknown:
            raise SecurityError(f"у exact-join опций нет: {sorted(unknown)}")

    users = users or {}
    exclude = exclude_users or set()
    bindings = build_bindings(dialog_rows or [], verified_index or {})
    warnings: list[dict] = []

    # коллизии чат-уровня
    u2i_collisions = {u: [b.chat_id for b in bs]
                      for u, bs in bindings.by_u2i.items() if len(bs) > 1}
    for u2i, chats in sorted(u2i_collisions.items()):
        warnings.append({"code": "chat_binding_collision",
                         "detail": f"u2i {u2i} заявлен чатами {sorted(chats)}"})
    crm_collisions = {ent: chats for ent, chats in bindings.crm_claims.items()
                      if len(chats) > 1}
    for ent, chats in sorted(crm_collisions.items()):
        warnings.append({"code": "duplicate_lead_crm",
                         "detail": f"{ent[0]} {ent[1]} привязан к чатам {sorted(chats)}"})
    if bindings.unparsed_chats:
        warnings.append({"code": "dialog_unparsed",
                         "detail": f"entity_id малформован у чатов {sorted(set(bindings.unparsed_chats))}"})

    def chat_crm_status(binding: ChatBinding | None) -> tuple[str, tuple]:
        if binding is None:
            return UNLINKED, ()
        if any(ent in crm_collisions for ent in binding.crm):
            return AMBIGUOUS, binding.crm
        if not binding.crm:
            return UNLINKED, ()
        return LINKED, binding.crm

    # индексы ключей сообщений (глобальные, для ловли кросс-чатовых дублей)
    mid_map: dict[str, list[tuple[int, str]]] = {}      # CONNECTOR_MID → (chat, msg)
    for chat_id, rows in (chat_messages or {}).items():
        for row in rows or []:
            mid = connector_mid_of(row)
            if mid:
                mid_map.setdefault(mid, []).append((chat_id, str(row.get("id"))))
    mid_dups = {m: refs for m, refs in mid_map.items() if len(refs) > 1}

    avito_id_map: dict[str, list[tuple[int, str, str, str]]] = {}  # id → (acct, u2i, id, dir)
    for pack in avito_chats or []:
        for row in pack.get("messages") or []:
            avito_id_map.setdefault(str(row.get("id")), []).append(
                (pack.get("account_user_id"), pack.get("chat_u2i"),
                 str(row.get("id")), str(row.get("direction") or "")))
    avito_id_dups = {i: refs for i, refs in avito_id_map.items() if len(refs) > 1}
    for mid, refs in sorted(avito_id_dups.items()):
        warnings.append({"code": "avito_message_id_dup",
                         "detail": f"avito id {mid} встречен {len(refs)} раз: {refs}"})

    messages: list[JoinedMessage] = []
    ambiguous_avito_refs: dict[str, str] = {}   # ref → причина
    linked_avito_refs: dict[str, str] = {}      # avito ref → b24 ref
    role_crosscheck: list[str] = []             # расхождение направления/роли пары

    # ── Б24-сторона ──────────────────────────────────────────────────────
    for chat_id, rows in sorted((chat_messages or {}).items()):
        binding = bindings.by_chat.get(chat_id)
        crm_status, crm = chat_crm_status(binding)
        u2i = binding.chat_u2i if binding else None
        for row in sorted(rows or [], key=lambda r: str(r.get("id"))):
            mid = row.get("id")
            ref = _b24_ref(chat_id, mid)
            author = row.get("author_id")
            try:
                author = int(author) if author is not None else None
            except (TypeError, ValueError):
                author = None
            role, employee = _b24_role_employee(author, binding, users, exclude)
            msg_mid = connector_mid_of(row)
            status, reason, pair = UNLINKED, "", None

            if binding is None:
                reason = "chat_binding_missing"
            elif binding.chat_u2i in u2i_collisions:
                status, reason = AMBIGUOUS, "chat_binding_collision"
            elif not binding.accounts:
                # аккаунт не проверен (нет в verified_index) → fail-closed отказ,
                # даже при формальном совпадении mid: доказательства нет
                reason = "chat_account_unverified"
            elif msg_mid and msg_mid in mid_dups:
                status, reason = AMBIGUOUS, "connector_mid_collision"
            elif msg_mid and msg_mid in avito_id_map:
                cands = avito_id_map[msg_mid]
                if len(cands) > 1:
                    status, reason = AMBIGUOUS, "connector_mid_collision"
                else:
                    acct, cand_u2i, cand_id, cand_dir = cands[0]
                    if cand_u2i != binding.chat_u2i or acct not in binding.accounts:
                        status, reason = AMBIGUOUS, "mid_cross_chat"
                    else:
                        status, reason, pair = LINKED, "exact_connector_mid", \
                            _avito_ref(acct, cand_u2i, cand_id)
                        linked_avito_refs[pair] = ref
                        if ((cand_dir == "in" and role == "WE")
                                or (cand_dir == "out" and role == "CLIENT")):
                            role_crosscheck.append(f"{ref} ↔ {pair}")
            elif msg_mid:
                reason = "no_exact_key"
            else:
                reason = "no_connector_mid"

            messages.append(JoinedMessage(
                ref=ref, origin="b24", chat_id=chat_id, chat_u2i=u2i,
                account_user_id=next(iter(binding.accounts)) if binding and binding.accounts else None,
                join_status=status, pair_ref=pair, reason=reason, role=role,
                employee_id=employee,
                employee_source="b24.author_id" if employee else None,
                crm_status=crm_status, crm=crm))

    if mid_dups:
        for mid, refs in sorted(mid_dups.items()):
            warnings.append({"code": "connector_mid_collision",
                             "detail": f"CONNECTOR_MID {mid} несут {sorted(refs)}"})
    if role_crosscheck:
        warnings.append({"code": "role_crosscheck",
                         "detail": (f"направление Авито расходится с ролью Б24: "
                                    f"{sorted(role_crosscheck)}; приоритет Б24")})

    # ── Авито-сторона ────────────────────────────────────────────────────
    senderid_overlap: set[int] = set()
    outside_account: list[str] = []
    for pack in avito_chats or []:
        acct = pack.get("account_user_id")
        u2i = pack.get("chat_u2i")
        cands = bindings.by_u2i.get(u2i, [])
        binding = cands[0] if len(cands) == 1 else None
        owner = (verified_index or {}).get(u2i)   # проверенный аккаунт-владелец
        crm_status, crm = chat_crm_status(binding)
        for row in sorted(pack.get("messages") or [],
                          key=lambda r: str(r.get("id"))):
            av_id = str(row.get("id"))
            ref = _avito_ref(acct, u2i, av_id)
            author = row.get("author_id")
            try:
                author = int(author) if author is not None else None
            except (TypeError, ValueError):
                author = None
            role = _avito_role(row.get("direction"), author, acct)
            if role == "UNKNOWN":
                outside_account.append(ref)
            if (author is not None and author != acct and author in users):
                senderid_overlap.add(author)   # канарейка, НЕ атрибуция

            if u2i in u2i_collisions:
                status, reason = AMBIGUOUS, "chat_binding_collision"
            elif av_id in avito_id_dups:
                status, reason = AMBIGUOUS, "avito_message_id_dup"
            elif ref in linked_avito_refs:
                status, reason = LINKED, "exact_connector_mid"
            elif av_id in mid_dups:
                status, reason = AMBIGUOUS, "connector_mid_collision"
            elif owner is None:
                status, reason = UNLINKED, "chat_account_unverified"
            elif acct != owner:
                status, reason = UNLINKED, "chat_owned_by_other_account"
            elif binding is None:
                status, reason = UNLINKED, "chat_binding_missing"
            else:
                status, reason = UNLINKED, "no_exact_key"

            messages.append(JoinedMessage(
                ref=ref, origin="avito", chat_id=binding.chat_id if binding else None,
                chat_u2i=u2i, account_user_id=acct,
                join_status=status,
                pair_ref=linked_avito_refs.get(ref) if status == LINKED else None,
                reason=reason, role=role,
                employee_id=None, employee_source=None,
                crm_status=crm_status, crm=crm))

    if senderid_overlap:
        warnings.append({"code": "senderid_numeric_overlap",
                         "detail": (f"авито senderId числово совпадает с id "
                                    f"пользователей Б24 {sorted(senderid_overlap)} — "
                                    f"атрибуцией НЕ является")})
    if outside_account:
        warnings.append({"code": "author_outside_account",
                         "detail": f"исходящие с чужим автором: {sorted(outside_account)}"})

    by_reason: dict[str, int] = {}
    counts = {"linked": 0, "unlinked_b24": 0, "unlinked_avito": 0, "ambiguous": 0}
    for m in messages:
        if m.join_status == LINKED:
            counts["linked"] += 1
        elif m.join_status == AMBIGUOUS:
            counts["ambiguous"] += 1
        elif m.origin == "b24":
            counts["unlinked_b24"] += 1
        else:
            counts["unlinked_avito"] += 1
        if m.join_status != LINKED:
            by_reason[m.reason] = by_reason.get(m.reason, 0) + 1
    counts["unlinked_by_reason"] = by_reason

    status = "VERIFIED" if not warnings else "PARTIAL"
    return JoinResult(messages=messages, warnings=warnings,
                      counts=counts, recommended_status=status)
