"""Быстрый индекс кандидатов через crm.activity.list TYPE_ID=6 (автологи ОЛ).

Зачем: полный offset-скан листинга сессий — ~26–52 с и ~52 вызова (пробы 08.11);
activity-индекс адресуется серверным фильтром по CREATED (фильтры crm.* РАБОТАЮТ,
канарейка живая — спека §7.1) и даёт кандидатов за 1–2 вызова на день
(≈ 316 автологов/день по порталу [ФАКТ 07.11]).

[ФАКТ, спека §5]: автологи сообщений ОЛ — TYPE_ID=6; ручные TODO тоже TYPE_ID=6,
отличать по PROVIDER_TYPE_ID=TODO (исключаем локально); ASSOCIATED_ENTITY_ID
автолога = ID СЕССИИ ОЛ (НЕ chat id — путать нельзя, ловушка comms_collector);
AUTHOR_ID всегда 1 (коннектор/владелец коннектора) — НЕ автор, игнорируется;
фактический отправитель исходящего = RESPONSIBLE_ID; OWNER_TYPE_ID 1/2/3 =
lead/contact/deal.

Полнота НЕ доказана для всех случаев (Авито/отправка из карточки могут не иметь
сессии; входящие могут логироваться иначе) → режим activity никогда не даёт
VERIFIED сам по себе: либо crosscheck со сканом (activity+scan), либо честный
PARTIAL с missed_source-предупреждениями.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from .config import MsgConfig
from .errors import SourceError
from .timeutil import parse_bx_date, to_bx_filter_date

SOURCE = "crm.activity.list"
OWNER_TYPES = {1: "lead", 2: "contact", 3: "deal"}
PAGE = 50          # crm.* листинги отдают по 50, пагинация start/next
PAGE_LIMIT = 200   # предохранитель 200*50=10000 строк на окно


@dataclass
class ActivityEntry:
    activity_id: int
    session_id: int | None      # ASSOCIATED_ENTITY_ID (для PROVIDER imopenlines)
    created: datetime | None
    responsible_id: int | None  # фактический отправитель исходящего
    author_id: int | None       # всегда 1 (коннектор) — не автор
    owner_type: str | None
    owner_id: int | None
    provider: str | None
    provider_type: str | None   # TODO | CONFIGURABLE | ...
    subject: str | None
    direction_out: bool | None  # True «Исходящее», False «Входящее», None неизвестно


@dataclass
class ActivityIndexResult:
    entries: list[ActivityEntry] = field(default_factory=list)
    session_ids: set = field(default_factory=set)
    filter_canary: str = "PASS"      # PASS | FAIL | ERROR
    canary_detail: str = ""
    pages: int = 0
    rows: int = 0
    truncated: bool = False
    error: dict | None = None

    def coverage(self) -> dict:
        return {
            "source": SOURCE,
            "pages": self.pages,
            "rows": self.rows,
            "sessions": len(self.session_ids),
            "filter_canary": self.filter_canary,
            "truncated": self.truncated,
            "error": self.error,
        }


def _parse_row(raw: dict) -> ActivityEntry | None:
    aid = raw.get("ID")
    if aid is None:
        return None
    prov = raw.get("PROVIDER_ID") or raw.get("PROVIDER") or ""
    ptype = raw.get("PROVIDER_TYPE_ID") or ""
    if str(ptype).upper() == "TODO":
        return None  # ручное дело TODO, не автолог сообщения
    assoc = raw.get("ASSOCIATED_ENTITY_ID")
    try:
        assoc = int(assoc) if assoc is not None else None
    except (TypeError, ValueError):
        assoc = None
    if assoc == 0:
        # [ФАКТ, замер 07.11 + живой прогон 09.11]: 266/288 автологов портала
        # имеют ASSOCIATED_ENTITY_ID=0 — чат не разрешён (Авито/карточка).
        # id сессии 0 не существует → None (= chat_unresolved), НЕ «сессия 0»
        assoc = None
    subject = raw.get("SUBJECT") or ""
    direction = None
    if isinstance(subject, str):
        if subject.lower().startswith("исходящ"):
            direction = True
        elif subject.lower().startswith("входящ"):
            direction = False
    ot = raw.get("OWNER_TYPE_ID")
    try:
        oid = int(raw.get("OWNER_ID")) if raw.get("OWNER_ID") is not None else None
    except (TypeError, ValueError):
        oid = None
    try:
        rid = int(raw.get("RESPONSIBLE_ID")) if raw.get("RESPONSIBLE_ID") is not None else None
    except (TypeError, ValueError):
        rid = None
    return ActivityEntry(
        activity_id=int(aid),
        session_id=assoc,  # ASSOCIATED_ENTITY_ID автолога ОЛ = ID сессии [ФАКТ §5]
        created=parse_bx_date(raw.get("CREATED")),
        responsible_id=rid,
        author_id=int(raw["AUTHOR_ID"]) if raw.get("AUTHOR_ID") else None,
        owner_type=OWNER_TYPES.get(ot) if isinstance(ot, int) else None,
        owner_id=oid,
        provider=str(prov) if prov else None,
        provider_type=str(ptype) if ptype else None,
        subject=subject if subject else None,
        direction_out=direction,
    )


def filter_canary(client) -> tuple[str, str]:
    """§7.1: парный запрос с заведомо пустым пересечением (CREATED > 2099).

    Ответ ≠ 0 строк → сервер игнорирует фильтры → FAIL: факты источника
    отбрасываются (fail-closed §4.1). Любая ошибка канарейки = FAIL.
    """
    try:
        data = client.call(SOURCE, {"start": 0,
                                    "FILTER[>CREATED]": "01.01.2099 00:00:00",
                                    "FILTER[TYPE_ID]": 6})
        rows = data.get("result") or data.get("_list") or []
        total = data.get("total", len(rows)) if isinstance(data, dict) else len(rows)
        if total == 0 and not rows:
            return "PASS", "пустое пересечение подтверждено"
        return "FAIL", f"фильтр игнорируется: {total} строк на заведомо пустом фильтре"
    except SourceError as e:
        return "FAIL", f"ошибка канарейки: {e.detail[:120]}"


def build_activity_index(client, cfg: MsgConfig, *, frm: datetime | None,
                         to: datetime | None, cluster: set | None = None,
                         with_canary: bool = True) -> ActivityIndexResult:
    res = ActivityIndexResult()
    if with_canary:
        res.filter_canary, res.canary_detail = filter_canary(client)
        if res.filter_canary == "FAIL":
            res.error = {"code": "FILTER_CANARY", "source": SOURCE,
                         "detail": res.canary_detail}
            return res

    flt = {"TYPE_ID": 6}
    if frm is not None:
        flt[">=CREATED"] = to_bx_filter_date(frm)
    if to is not None:
        flt["<CREATED"] = to_bx_filter_date(to)
    start = 0
    try:
        while True:
            params = {"start": start}
            for k, v in flt.items():
                params[f"FILTER[{k}]"] = v
            data = client.call(SOURCE, params)
            res.pages += 1
            rows = (data.get("result") or data.get("_list") or []) if isinstance(data, dict) else []
            if not rows:
                break
            for raw in rows:
                e = _parse_row(raw if isinstance(raw, dict) else {})
                if e is None:
                    continue
                res.rows += 1
                if cluster is not None and (e.owner_type, e.owner_id) not in cluster:
                    continue
                res.entries.append(e)
                if e.session_id is not None:
                    res.session_ids.add(e.session_id)
            start += len(rows)
            nxt = data.get("next")
            if nxt is None or start >= (data.get("total") or 0):
                break
            if res.pages >= PAGE_LIMIT:
                res.truncated = True
                break
    except SourceError as e:
        res.error = e.to_json()
        res.truncated = True
    return res
