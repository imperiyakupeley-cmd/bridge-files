"""Whitelist методов/параметров модуля messages: ТОЛЬКО read-only.

Жёстче core: глаголы-мутаторы запрещены регэкспом всегда; batch разрешён,
но каждый sub-method проходит тот же whitelist. Это структурная гарантия
«только безопасные read-only запросы» — мутация невозможна даже ошибкой.

[ФАКТ пробы 08.11]: фильтры imopenlines.v2.Session.list МОЛЧА игнорируются —
поэтому в whitelist для него НЕТ filter-ключей вовсе (нечему «работать»);
листинг полный + фильтрация на клиенте.
"""
from __future__ import annotations

import re

from .errors import SecurityError

# Мутаторы запрещены всегда, даже если имя попадёт в whitelist.
_MUTATING = re.compile(
    r"\.(add|update|delete|set|import|register|send|force|merge|confirm|cancel|"
    r"complete|forward|pin|read|mark|answer|call|start|join|leave|leave|transfer|"
    r"operator|message|chat\.create|dialog|consent|log|webhook|bot|impose)\b",
    re.I,
)
# ВАЖНО: transfer ЗАПРЕЩЁН как глагол-мутатор, но разрешён метод
# imopenlines.v2.Session.Transfer.list — читается отдельной точкой ниже,
# поэтому регэксп не должен резать '.Transfer.list' (проверка ниже).

_LITERALS = {
    "imopenlines.v2.Session.list": {"limit", "offset"},
    "imopenlines.session.history.get": {"SESSION_ID", "LIMIT", "LAST_MESSAGE_ID"},
    "imopenlines.v2.Session.Transfer.list": {"sessionId"},
    "imopenlines.v2.Session.Stat.get": {"sessionId", "dateFrom", "dateTo"},
    "imopenlines.config.list.get": set(),
    "imopenlines.crm.chat.getlastid": {"CRM_ENTITY_TYPE", "CRM_ENTITY_ID"},
    "imopenlines.crm.chat.get": {"CRM_ENTITY_TYPE", "CRM_ENTITY_ID"},
    "crm.activity.list": {"start", "order"},
    "user.get": {"ID"},
    "user.current": set(),
    "batch": {"cmd"},
}
_PREFIXES = {
    "crm.activity.list": ("FILTER[", "select["),
    "user.get": ("FILTER[",),
}

# Параметры-массивы (передаются как повторяющиеся ключи или список).
_ARRAY_OK = {"sessionId": True, "ID": True}


def check_method(method: str) -> None:
    if not isinstance(method, str) or not re.fullmatch(r"[A-Za-z0-9_.]+", method):
        raise SecurityError(f"некорректное имя метода: {method!r}")
    if method in _LITERALS:
        return  # явно разрешён (в т.ч. imopenlines.v2.Session.Transfer.list)
    # вне списка: даём понятную причину отказа, но отказ в любом случае
    probe = method.lower().replace("transfer.list", "#")  # не резать Transfer.list
    if _MUTATING.search(probe):
        raise SecurityError(f"метод запрещён (мутатор): {method}")
    raise SecurityError(f"метод вне whitelist: {method}")


def check_params(method: str, params: dict) -> dict:
    """Валидация ключей. Возвращает чистую копию params."""
    check_method(method)
    literals = _LITERALS.get(method, set())
    prefixes = _PREFIXES.get(method, ())
    out: dict = {}
    for k, v in (params or {}).items():
        base = k.replace("[]", "")
        if k in literals or base in literals:
            out[k] = v
            continue
        if any(k.startswith(p) for p in prefixes):
            out[k] = v
            continue
        raise SecurityError(f"параметр {k!r} не разрешён для {method}", source=method)
    return out


def check_batch_cmds(cmds: dict) -> dict:
    """batch.cmd: каждая команда 'method?k=v&k2=v2' — метод и ключи в whitelist."""
    if not isinstance(cmds, dict) or not cmds:
        raise SecurityError("batch: cmd должен быть непустым объектом")
    if len(cmds) > 50:
        raise SecurityError("batch: не больше 50 команд")
    out = {}
    for key, raw in cmds.items():
        if not isinstance(raw, str) or not raw or len(raw) > 2000:
            raise SecurityError(f"batch: некорректная команда {key!r}")
        method, _, qs = raw.partition("?")
        check_method(method)
        params = {}
        if qs:
            from urllib.parse import parse_qsl
            for k, v in parse_qsl(qs, keep_blank_values=True):
                params.setdefault(k, v) if k not in params else None
                # повторяющиеся ключи (массивы) схлопываем в список
                if k in params and params[k] != v:
                    if not isinstance(params[k], list):
                        params[k] = [params[k]]
                    params[k].append(v)
        params = check_params(method, params)
        out[key] = raw
    return out
