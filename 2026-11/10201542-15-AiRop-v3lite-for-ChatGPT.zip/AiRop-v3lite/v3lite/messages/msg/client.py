"""Клиент Bitrix REST модуля messages: троттлинг, ретраи, batch, таксономия ошибок.

Гарантии:
- только методы whitelist (whitelist.check_* до любого сетевого вызова);
- 2 rps с троттлингом, batch = 1 вызов;
- §7.6: максимум 3 ретрая с экспоненциальным backoff на 429/5xx/сеть,
  затем SourceError-подкласс → источник в errors, сборка продолжается;
- вебхук не попадает ни в логи, ни в ответы (маскируется в detail).
"""
from __future__ import annotations

import random
import time
import urllib.parse

from .config import BACKOFF_BASE_S, BACKOFF_CAP_S, MsgConfig
from .errors import (AccessDenied, ClientError, MsgError, NetworkError,
                     RateLimitError, SecurityError, ServerError, SourceError)
from .transport import Transport, build_get_url
from .whitelist import check_batch_cmds, check_params

RETRYABLE_HTTP = {429, 500, 502, 503, 504}
RETRYABLE_BX_CODES = {"QUERY_LIMIT_EXCEEDED", "INTERNAL_SERVER_ERROR"}


def _cmd_map(x, keys: list[str]) -> dict:
    """batch-результат LIST ↔ dict → карта по ключам cmd (PHP packed array).

    LIST возникает только при плотных числовых ключах (все команды
    отработали или все упали) — порядок элементов соответствует порядку
    cmd, маппинг позиционный. dict — как есть. Несовпадение длины —
    аномалия: отдаваем только то, что бьётся поэлементно (без догадок)."""
    if isinstance(x, dict):
        return x
    if isinstance(x, list):
        if len(x) == len(keys):
            return {keys[i]: x[i] for i in range(len(x))}
        n = min(len(x), len(keys))
        return {keys[i]: x[i] for i in range(n)}
    return {}


class CallStat:
    """Счётчик вызовов по методам — для coverage и измерений."""

    def __init__(self):
        self.calls: dict[str, int] = {}
        self.total = 0
        self.wall_s = 0.0

    def bump(self, method: str, dt: float) -> None:
        self.calls[method] = self.calls.get(method, 0) + 1
        self.total += 1
        self.wall_s += dt

    def to_json(self) -> dict:
        return {"calls": dict(sorted(self.calls.items())), "total": self.total,
                "sum_server_s": round(self.wall_s, 2)}


class BitrixClient:
    def __init__(self, config: MsgConfig, transport: Transport | None = None,
                 *, throttle: bool = True):
        self.cfg = config
        self.transport = transport or Transport()
        self.throttle = throttle
        self._last_ts = 0.0
        self.stat = CallStat()

    # ------------------------------------------------------------------ core
    def _wait_slot(self) -> None:
        if not self.throttle:
            return
        now = time.monotonic()
        wait = (1.0 / self.cfg.rate_rps) - (now - self._last_ts)
        if wait > 0:
            time.sleep(wait)
        self._last_ts = time.monotonic()

    def _hook(self, method: str, override: str | None = None) -> str:
        if override == "ol":
            hook = self.cfg.ol_webhook
        elif override == "crm":
            hook = self.cfg.webhook or self.cfg.ol_webhook
        else:
            hook = self.cfg.hook_for(method)
        if not hook:
            raise SourceError("вебхук не настроен (offline-конфиг): сетевые вызовы запрещены",
                              source=method)
        return hook

    # ---------------------------------------------------------------- calls
    def call(self, method: str, params: dict | None = None, *,
             array_params: dict | None = None, hook: str | None = None) -> dict:
        """GET-вызов (history.get, Transfer.list, Stat.get, user.get, crm.*).

        array_params — повторяющиеся ключи (sessionId=1&sessionId=2),
        urlencode(doseq=True) собирает их из списков.
        hook='ol' — принудительно вебхук владельца (скоуп-проверка листинга),
        hook='crm' — прод-вебхук. Возвращает ПОЛНЫЙ конверт ответа:
        {"result": ..., "total": n, "next": m} (total/next нужны пагинации crm.*).
        """
        params = check_params(method, params or {})
        merged: dict = dict(params)
        for k, v in (array_params or {}).items():
            if k not in merged:
                merged[k] = v  # список → doseq даст повторяющиеся ключи
        url = build_get_url(self._hook(method, hook), method, merged)
        return self._request_with_retries(method, url, get=True)

    def post(self, method: str, payload: dict) -> dict:
        """POST-вызов с JSON-телом (imopenlines.v2.*, batch).

        Возвращает полный конверт: {"result": ...} (+ total/next при наличии).
        """
        if method == "batch":
            payload = {"cmd": check_batch_cmds(payload.get("cmd") or {})}
        else:
            payload = check_params(method, payload or {})
        hook = self._hook(method)
        url = f"{hook.rstrip('/')}/{method}.json"
        return self._request_with_retries(method, url, get=False, payload=payload)

    def batch(self, cmds: list[tuple[str, str, dict]]) -> tuple[dict, dict]:
        """cmds: [(key, method, params)] → (result.result, result.result_error).

        [ФАКТ, спека §5]: ответ batch в result.result; per-key ошибки в
        result_error — они НЕ исключения, их обрабатывает вызывающий код.
        Боевая сериализация PHP: плотные числовые ключи 0..n-1 → LIST (в т.ч.
        когда упали ВСЕ команды — result_error приходит списком), разреженные
        → dict. LIST-форма result_error раньше молча терялась («пустой
        конверт» без поимённых ошибок) — нормализуем в карту по ключам cmd
        (приёмка admin2 09.11, «batch result_error LIST как ошибка per-cmd»).
        """
        if len(cmds) > 50:
            raise SecurityError("batch: не больше 50 команд")
        cmd = {}
        for key, method, params in cmds:
            qs = urllib.parse.urlencode(params or {}, doseq=True) if params else ""
            cmd[key] = f"{method}?{qs}" if qs else method
        raw = self.post("batch", {"cmd": cmd})
        res = raw.get("result") or {}
        keys = [k for k, _m, _p in cmds]
        return (_cmd_map(res.get("result"), keys),
                _cmd_map(res.get("result_error"), keys))

    # -------------------------------------------------------------- retries
    def _request_with_retries(self, method: str, url: str, *, get: bool,
                              payload: dict | None = None) -> dict:
        last_err: MsgError | None = None
        for attempt in range(self.cfg.retries_max + 1):
            self._wait_slot()
            t0 = time.monotonic()
            try:
                r = (self.transport.get(url, self.cfg.timeout_s) if get
                     else self.transport.post(url, payload or {}, self.cfg.timeout_s))
            except NetworkError as e:
                last_err = e
                self._backoff(attempt)
                continue
            dt = time.monotonic() - t0
            self.stat.bump(method, dt)
            if r.status in RETRYABLE_HTTP:
                retry_after = self._retry_after(r)
                last_err = (RateLimitError if r.status == 429 else ServerError)(
                    f"HTTP {r.status} (попытка {attempt + 1})", source=method)
                self._backoff(attempt, retry_after)
                continue
            if r.status != 200:
                # 4xx (кроме 429 выше) — ошибка запроса, не сервера (D8:
                # HTTP 400 у Transfer.list/Session.list ранее попадал в
                # SOURCE_5XX); 5xx — сервер
                if 400 <= r.status < 500:
                    raise ClientError(f"HTTP {r.status}", source=method)
                raise ServerError(f"HTTP {r.status}", source=method)
            try:
                body = r.json()
            except ValueError:
                last_err = SourceError("невалидный JSON в ответе", source=method)
                self._backoff(attempt)
                continue
            if body.get("error"):
                code = str(body.get("error"))
                desc = str(body.get("error_description", ""))[:300]
                if code in RETRYABLE_BX_CODES:
                    last_err = RateLimitError(f"{code}: {desc}", source=method)
                    self._backoff(attempt)
                    continue
                if code in ("ACCESS_DENIED", "ACCESS_ERROR", "insufficient_scope"):
                    raise AccessDenied(f"{code}: {desc}", source=method)
                raise SourceError(f"{code}: {desc}", source=method)
            result = body.get("result")
            if result is None and "result" not in body:
                return {}
            if not isinstance(result, dict):
                body = dict(body)
                body["_list"] = result  # списочные методы: result — массив
            return body
        raise last_err or SourceError("источник недоступен", source=method)

    def _retry_after(self, r) -> float | None:
        try:
            v = r.headers.get("Retry-After") or r.headers.get("retry-after")
            return float(v) if v else None
        except (TypeError, ValueError):
            return None

    def _backoff(self, attempt: int, retry_after: float | None = None) -> None:
        if attempt >= self.cfg.retries_max:
            return
        delay = min(self.cfg.backoff_base_s * (2 ** attempt) + random.uniform(0, 0.3),
                    self.cfg.backoff_cap_s)
        if retry_after:
            delay = min(max(delay, retry_after), self.cfg.backoff_cap_s)
        time.sleep(delay)
