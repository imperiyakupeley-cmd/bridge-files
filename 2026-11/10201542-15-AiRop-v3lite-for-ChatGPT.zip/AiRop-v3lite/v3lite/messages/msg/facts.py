"""Фабрика фактов модуля messages (контракт §4, подмножество сообщений ОЛ).

fact_type: message | transfer (остальные типы — зона core, не модуля).
author_role: WE | CLIENT | BOT | CONNECTOR (enum §4).
Внутреннее поле timestamp_dt сериализуется в ISO Europe/Moscow и удаляется.
Минимальные данные: текст усечён до max_text_len, медиа НЕ копируются
(только признак наличия файлов) — полная выкачка вложений вне контракта.
"""
from __future__ import annotations

from datetime import datetime

from .timeutil import fmt_iso

FACT_TYPES = {"message", "transfer"}
AUTHOR_ROLES = {"WE", "CLIENT", "BOT", "CONNECTOR"}


def make_fact(*, fact_type: str, source: str, source_entity_id: str,
              timestamp: datetime | None, author_id: int | None,
              author_role: str, crm_entity: dict | None = None,
              payload: dict | None = None, evidence: dict | None = None) -> dict:
    if fact_type not in FACT_TYPES:
        raise ValueError(f"fact_type {fact_type!r} вне enum контракта")
    if author_role not in AUTHOR_ROLES:
        author_role = "CONNECTOR"
    return {
        "fact_type": fact_type,
        "source": source,
        "source_entity_id": source_entity_id,
        "timestamp_dt": timestamp,
        "author_id": author_id,
        "author_role": author_role,
        "crm_entity": crm_entity,
        "payload": payload or {},
        "evidence": evidence or {},
    }


def serialize_facts(facts: list[dict]) -> list[dict]:
    out = []
    for f in facts:
        g = dict(f)
        dt = g.pop("timestamp_dt", None)
        g["timestamp"] = fmt_iso(dt)
        out.append(g)
    return out
