"""Атрибуция авторов сообщений ОЛ (спека §8 + пробы 13–16).

Правила (проверено):
- senderid = 0 → системное сообщение (author_role=CONNECTOR, system=true).
- Клиент = senderid совпадает с userId сессии (клиентский «теневой» юзер)
  ИЛИ EXTERNAL_AUTH_ID='imconnector' в user.get.
- Боты флота = EXCLUDE_USERS из .env (Анна 17316, Михаил 15780): BOT.
- Штатный сотрудник = WE.
- Имена: user.get по ID[] БЕЗ фильтра ACTIVE (уволенные/неактивные выпадают
  из выборки с ACTIVE='N' — нельзя фильтровать) [ФАКТ].
- Неразрешённый id: факт НЕ выбрасывается, автор остаётся числом,
  author_crosscheck=WARN (§7.3: неизвестный author_id — не молча).

AUTHOR_ID=1 из activity — коннектор, НЕ автор: в авторы не попадает никогда.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .config import MsgConfig, USER_BATCH
from .errors import SourceError

SOURCE = "user.get"


@dataclass
class UserInfo:
    id: int
    name: str
    external_auth_id: str | None
    active: str | None

    @property
    def is_connector_client(self) -> bool:
        return self.external_auth_id == "imconnector"

    @property
    def is_bot_marker(self) -> bool:
        return (self.external_auth_id or "").lower() in {"bot", "imconnector-bot", "bitrix24"}


@dataclass
class AuthorIndex:
    users: dict = field(default_factory=dict)   # id -> UserInfo
    unresolved: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    calls: int = 0

    def coverage(self) -> dict:
        return {
            "source": SOURCE,
            "users_resolved": len(self.users),
            "unresolved_ids": self.unresolved[:50],
            "errors": self.errors[:10],
        }


def fetch_users(client, cfg: MsgConfig, ids: set[int]) -> AuthorIndex:
    """user.get ID[] порциями по 25, БЕЗ ACTIVE (см. докстринг модуля)."""
    idx = AuthorIndex()
    uniq = sorted({i for i in ids if isinstance(i, int)})
    for i in range(0, len(uniq), USER_BATCH):
        chunk = uniq[i:i + USER_BATCH]
        try:
            env = client.call(SOURCE, array_params={"ID[]": chunk})
            idx.calls += 1
        except SourceError as e:
            idx.errors.append(e.to_json())
            idx.unresolved.extend(chunk)
            continue
        rows = env.get("result") if isinstance(env, dict) else None
        if rows is None and isinstance(env, dict):
            rows = env.get("_list")
        if not isinstance(rows, list):
            rows = []
        got = set()
        for u in rows:
            if not isinstance(u, dict) or u.get("ID") is None:
                continue
            try:
                uid = int(u["ID"])
            except (TypeError, ValueError):
                continue
            got.add(uid)
            name = " ".join(x for x in (u.get("NAME"), u.get("LAST_NAME")) if x).strip()
            idx.users[uid] = UserInfo(
                id=uid, name=name or f"user {uid}",
                external_auth_id=u.get("EXTERNAL_AUTH_ID"),
                active=u.get("ACTIVE"),
            )
        idx.unresolved.extend(x for x in chunk if x not in got)
    return idx


def role_of(sender_id: int | None, session_user_id: int | None,
            users: dict, cfg: MsgConfig) -> str:
    """WE | CLIENT | BOT | CONNECTOR по правилам §8 (без выбрасывания факта)."""
    if sender_id is None or sender_id == 0:
        return "CONNECTOR"           # системное/неизвестное — не человек
    if session_user_id is not None and sender_id == session_user_id:
        return "CLIENT"
    u = users.get(sender_id)
    if u is not None:
        if u.is_connector_client:
            return "CLIENT"
        if u.is_bot_marker or str(sender_id) in cfg.exclude_users:
            return "BOT"
        return "WE"
    # пользователь не разрешён: бот по конфигу → BOT, иначе честный CONNECTOR+WARN
    if str(sender_id) in cfg.exclude_users:
        return "BOT"
    return "CONNECTOR"


def author_name(sender_id: int | None, users: dict) -> str | None:
    if sender_id is None or sender_id == 0:
        return None
    u = users.get(sender_id)
    return u.name if u else None
