"""Коды ошибок и исключения модуля messages (ИИ-РОП v3 Lite, изолирован от core).

Коды совпадают с контрактом admin2 §4:
SCHEMA | SOURCE_429 | SOURCE_5XX | SOURCE_NET | SOURCE_ERROR |
ACCESS_DENIED | NOT_FOUND | NOT_IMPLEMENTED | FILTER_CANARY | LIMIT

Модуль живёт в ~/AiRop/v3lite/messages/, НЕ импортирует core (изоляция от DEV)
и не трогает боевые файлы ~/AiRop.
"""
from __future__ import annotations


class MsgError(Exception):
    code = "SOURCE_ERROR"

    def __init__(self, detail: str = "", *, source: str = ""):
        super().__init__(detail or self.code)
        self.detail = detail or self.code
        self.source = source

    def to_json(self) -> dict:
        # detail не должен содержать вебхук/токен: транспорт маскирует адрес.
        return {"code": self.code, "source": self.source, "detail": self.detail[:500]}


class SchemaError(MsgError):
    """Нарушение контракта запроса. Ответ FAILED ДО похода в REST."""
    code = "SCHEMA"


class SecurityError(MsgError):
    """Метод/параметр вне whitelist — запрет до любого сетевого вызова."""
    code = "SCHEMA"


class SourceError(MsgError):
    """Источник упал после всех ретраев."""
    code = "SOURCE_ERROR"


class RateLimitError(SourceError):
    code = "SOURCE_429"


class ClientError(SourceError):
    """HTTP 4xx (кроме 429): ошибка запроса/параметров, а не сервера.

    Расширение v1.1 по замечанию приёмки (D8): HTTP 400 ранее тарифицировался
    как SOURCE_5XX, что неверно описывало причину. Код SOURCE_4XX.
    """
    code = "SOURCE_4XX"


class ServerError(SourceError):
    code = "SOURCE_5XX"


class NetworkError(SourceError):
    code = "SOURCE_NET"


class AccessDenied(SourceError):
    code = "ACCESS_DENIED"


class LimitReached(SourceError):
    """Достигнут административный лимит (окно offset, max_facts)."""
    code = "LIMIT"
