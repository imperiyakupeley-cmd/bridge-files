"""Транспорт модуля messages: HTTP GET+POST, отделён от логики (подмена в тестах).

ОЛ v2 (Session.list, batch) требует POST с JSON-телом [ФАКТ, пробы 2–5];
history.get/Transfer.list/Stat.get/user.get/crm.* — GET с query.
Секрет не разглашается: в исключения попадает только метод и код статуса.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request

from .errors import NetworkError


class HttpResult:
    __slots__ = ("status", "headers", "body")

    def __init__(self, status: int, headers: dict, body: bytes):
        self.status = status
        self.headers = headers
        self.body = body

    def json(self):
        return json.loads(self.body.decode("utf-8"))


def build_get_url(webhook: str, method: str, params: dict | None) -> str:
    url = f"{webhook.rstrip('/')}/{method}.json"
    if params:
        clean = {k: v for k, v in params.items() if v is not None}
        if clean:
            url += "?" + urllib.parse.urlencode(clean, doseq=True)
    return url


class Transport:
    """Синхронный транспорт. FakeTransport в тестах подменяет этот класс."""

    name = "urllib"

    def get(self, url: str, timeout: float) -> HttpResult:
        req = urllib.request.Request(url, method="GET",
                                     headers={"User-Agent": "airop-v3lite-messages/0.1"})
        return self._open(req, timeout)

    def post(self, url: str, payload: dict, timeout: float) -> HttpResult:
        req = urllib.request.Request(
            url, method="POST", data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     "User-Agent": "airop-v3lite-messages/0.1"})
        return self._open(req, timeout)

    def _open(self, req: urllib.request.Request, timeout: float) -> HttpResult:
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return HttpResult(r.status, dict(r.headers), r.read())
        except urllib.error.HTTPError as e:
            return HttpResult(e.code, dict(e.headers or {}), e.read())
        except Exception as e:  # сеть/DNS/таймаут
            raise NetworkError(f"{type(e).__name__}: {e}", source=req.full_url.split('?')[0].split('/')[-1]) from e
