"""Оркестратор модуля messages: request → response по контракту §4.

Порядок: валидация → скоуп вебхука → индекс кандидатов (скан и/или activity,
в scan-режиме с окном — дополнительный activity-аудит текстов) → истории
сессий (batch, LIMIT-схема, локальные фильтры) → авторы/роли → линии →
Stat.get-канарейка → передачи (живая per-array форма) → поимённый missing_text
→ канарейки (filter/pagination/window/duplicate/author) → факты → статус.

Честность статусов (§4):
- VERIFIED — все источники отвечали, скан дошёл до естественного конца, канарейки
  PASS, усечений и предупреждений нет. Режим activity сам по себе VERIFIED не даёт:
  полнота activity-индекса не доказана (Авито/карточка) — только PARTIAL,
  либо VERIFIED в режиме activity+scan при полном совпадении.
- PARTIAL — есть факты, но есть хоть одно: ошибка/усечение/канарейка FAIL/
  missing_text/warning.
- FAILED — фактов нет И источник/контракт упал (schema/права/все источники).
- Ноль фактов при живых и полных источниках = VERIFIED с coverage.messages=0.
"""
from __future__ import annotations

from datetime import datetime

from .activity_index import build_activity_index
from .authors import author_name, fetch_users, role_of
from .client import BitrixClient
from .config import (MAX_FACTS_DEFAULT, MAX_MESSAGES_PER_CHAT_DEFAULT,
                     MAX_TEXT_LEN_DEFAULT, OFFSET_WINDOW_HARD, OWNER_USER_ID,
                     MsgConfig, load_config)
from .errors import MsgError, SchemaError
from .facts import make_fact, serialize_facts
from .history import HistoriesResult, apply_local_filters, fetch_histories
from .request import validate_request
from .sessions import SessionRow, scan_sessions
from .stats import crosscheck as crosscheck_stats
from .stats import fetch_stats
from .timeutil import fmt_iso, now_msk
from .transfers import fetch_transfers

HIST_SRC = "imopenlines.session.history.get"
MISSING_TEXT_WARN_LIMIT = 200   # поимённых missing_text в warnings (весь счёт в coverage)


def _failed(parsed: dict | None, err: Exception) -> dict:
    rid = (parsed or {}).get("request_id") or "unknown"
    intent = (parsed or {}).get("intent") or "unknown"
    detail = err.to_json() if isinstance(err, MsgError) else {
        "code": "SOURCE_ERROR", "source": "", "detail": str(err)[:500]}
    return {
        "request_id": rid, "intent": intent, "status": "FAILED",
        "as_of": fmt_iso(now_msk()), "facts": [], "coverage": {},
        "warnings": [], "errors": [detail],
        "detectors": {"filter_canary": "SKIP", "pagination_canary": "SKIP",
                      "window_canary": "SKIP", "author_crosscheck": "SKIP",
                      "duplicate_guard_dropped": 0},
    }


def fetch(request: dict, *, config: MsgConfig | None = None,
          client: BitrixClient | None = None) -> dict:
    """Главный вход. Ошибки НЕ бросаются наружу — всегда контрактный JSON."""
    parsed = None
    try:
        parsed = validate_request(request)
    except SchemaError as e:
        raw_id = request.get("request_id") if isinstance(request, dict) else None
        return _failed({"request_id": raw_id, "intent":
                        (request.get("intent") if isinstance(request, dict) else None)}, e)

    # cfg переданного клиента имеет приоритет (тесты уменьшают лимиты,
    # продакшн строит конфиг из env)
    cfg = config or (client.cfg if client is not None else load_config())
    frm, to = parsed["from"], parsed["to"]
    options = parsed["options"]
    warnings: list[str] = []
    errors: list[dict] = []
    coverage: dict = {}
    detectors = {"filter_canary": "SKIP", "pagination_canary": "PASS",
                 "window_canary": "PASS", "author_crosscheck": "SKIP",
                 "duplicate_guard_dropped": 0}
    index_mode = options.get("index", "scan")
    cluster = {(e["type"], e["id"]) for e in parsed["cluster"]} if parsed["cluster"] else None

    if client is None:
        if not cfg.ol_webhook:
            return _failed(parsed, SchemaError(
                "вебхук ОЛ не настроен (V3_OL_WEBHOOK): сетевые вызовы запрещены"))
        client = BitrixClient(cfg)

    # ── 0. скоуп вебхука: полный листинг ОЛ — только под владельцем ──────────
    # D10: user.current возвращает ID СТРОКОЙ ("1") — нормализуем int до
    # сравнения, иначе владелец ложно считался скоупированным на каждом прогоне
    scope_limited = False
    try:
        cur = client.call("user.current", hook="ol")
        u = cur.get("result") if isinstance(cur, dict) else None
        if isinstance(u, dict):
            raw_uid = u.get("ID")
            try:
                uid = int(raw_uid) if raw_uid is not None else None
            except (TypeError, ValueError):
                uid = None
            coverage["webhook_scope"] = {
                "user_id": uid,
                "user_name": " ".join(x for x in (u.get("NAME"), u.get("LAST_NAME")) if x),
                "full_listing_expected": uid == OWNER_USER_ID,
            }
            if uid is None:
                warnings.append("webhook_scope: user.current вернул некорректный ID "
                                f"({raw_uid!r}) — полнота листинга не подтверждена")
                scope_limited = True
            elif uid != OWNER_USER_ID:
                scope_limited = True
                warnings.append(
                    f"webhook_scope: листинг ОЛ под пользователем {uid} — "
                    f"скоупирован, полный листинг только под владельцем ({OWNER_USER_ID}); "
                    f"полнота не гарантирована")
        else:
            coverage["webhook_scope"] = {"user_id": None, "user_name": None,
                                         "full_listing_expected": False}
            warnings.append("webhook_scope: user.current не вернул пользователя — "
                            "полнота листинга не подтверждена")
            scope_limited = True
    except MsgError as e:
        coverage["webhook_scope"] = {"error": e.to_json()}
        warnings.append("webhook_scope: user.current недоступен")
        scope_limited = True

    # ── 1. индексы кандидатов ────────────────────────────────────────────────
    scan_res = None
    act_res = None
    audit_act = None      # activity-аудит в scan-режиме (для missing_text, F4)
    candidates: list[SessionRow] = []
    by_id: dict[int, SessionRow] = {}

    if index_mode in ("scan", "activity+scan"):
        scan_res = scan_sessions(client, cfg, frm=frm, to=to, cluster=cluster)
        coverage["sessions_scan"] = scan_res.coverage()
        if scan_res.error:
            errors.append(scan_res.error)
        if scan_res.truncated:
            if scan_res.ceiling_hit:
                tail = scan_res.unreachable_tail_estimate
                tail_txt = (f"оценка сверху ≈{tail} сессий за потолком "
                            f"(плотность id: span−виденные)" if tail is not None
                            else "объём хвоста неоценим (id не встречены)")
                warnings.append(
                    f"скан сессий усечён: потолок offset API (offset ≤ 10000, "
                    f"~{OFFSET_WINDOW_HARD} строк достижимо, глубже портал отвечает "
                    f"HTTP 400); {tail_txt}; порядок листинга недатирован — состав "
                    f"хвоста недоказуем, полнота за потолком НЕ заявляется")
            else:
                warnings.append(f"скан сессий усечён: {scan_res.stop_reason}; "
                                f"покрытие неполное")
        candidates = list(scan_res.candidates)
        by_id = {s.id: s for s in candidates}
        if scan_res.duplicate_rows:
            warnings.append(f"скан сессий: {scan_res.duplicate_rows} дубликатов строк "
                            f"в листинге (дедуп по id выполнен)")
        if scan_res.bad_date_rows:
            warnings.append(f"скан сессий: {scan_res.bad_date_rows} строк с битыми датами "
                            f"(включены как кандидаты, фильтр по времени сообщений ниже)")

    if index_mode in ("activity", "activity+scan"):
        act_res = build_activity_index(client, cfg, frm=frm, to=to, cluster=cluster)
        coverage["activity_index"] = act_res.coverage()
        if act_res.filter_canary == "FAIL":
            errors.append(act_res.error or {"code": "FILTER_CANARY",
                                            "source": "crm.activity.list",
                                            "detail": act_res.canary_detail})
            detectors["filter_canary"] = "FAIL"
            warnings.append("activity-индекс отброшен: фильтр crm.activity.list "
                            "игнорируется сервером (канарейка)")
            if index_mode == "activity":
                # fail-closed fallback: без индекса период понимаем только сканом
                warnings.append("activity-режим переключён на полный скан (fallback)")
                scan_res = scan_sessions(client, cfg, frm=frm, to=to, cluster=cluster)
                coverage["sessions_scan"] = scan_res.coverage()
                if scan_res.error:
                    errors.append(scan_res.error)
                if scan_res.truncated:
                    warnings.append("скан сессий усечён (fallback после отказа канарейки)")
                candidates = list(scan_res.candidates)
                by_id = {s.id: s for s in candidates}
                act_res = None
        elif act_res.error:
            errors.append(act_res.error)
        else:
            detectors["filter_canary"] = "PASS"
            if act_res.truncated:
                warnings.append("activity-индекс усечён по лимиту страниц")
            if index_mode == "activity":
                # стабы: метаданные сессии неизвестны без листинга
                for sid in act_res.session_ids:
                    if sid not in by_id:
                        stub = SessionRow(id=sid)
                        candidates.append(stub)
                        by_id[sid] = stub
            else:
                act_only = sorted(act_res.session_ids - set(by_id))
                if act_only:
                    warnings.append(
                        f"index_crosscheck: {len(act_only)} сессий есть в activity, "
                        f"нет в скане (вне окна листинга?) — примеры: {act_only[:10]}")
                for sid in act_only[:200]:
                    stub = SessionRow(id=sid)
                    candidates.append(stub)
                    by_id[sid] = stub

    # scan-режим с окном: activity-аудит текстов (D7) — дешёвый индекс автологов
    # для поимённых missing_text и добора сессий за потолком скана (F4)
    if (index_mode == "scan" and frm is not None and to is not None
            and options.get("activity_audit", True)):
        audit_act = build_activity_index(client, cfg, frm=frm, to=to, cluster=cluster)
        cov = audit_act.coverage()
        cov["mode"] = "text_audit"       # вспомогательный, не источник кандидатов
        coverage["activity_index"] = cov
        if audit_act.filter_canary == "FAIL":
            warnings.append("activity-аудит текстов недоступен: фильтр "
                            "crm.activity.list игнорируется (канарейка) — "
                            "missing_text не именуется, полнота текстов не проверена")
            audit_act = None
        elif audit_act.error:
            warnings.append("activity-аудит текстов упал — missing_text не именуется")
            audit_act = None
        else:
            # F4: сессии из автологов, недостижимые сканом (за потолком offset)
            if scan_res is not None and scan_res.ceiling_hit:
                act_only = sorted(audit_act.session_ids - set(by_id))
                added = 0
                for sid in act_only[:200]:
                    stub = SessionRow(id=sid)
                    candidates.append(stub)
                    by_id[sid] = stub
                    added += 1
                if added:
                    warnings.append(
                        f"скан за потолком offset: {added} сессий добраны из "
                        f"activity-аудита (примеры: {act_only[:5]}; без метаданных "
                        f"листинга, история получена по SESSION_ID) — это НЕ "
                        f"полнота, хвост остаётся недоказуем")

    act_any = act_res if act_res is not None else audit_act

    if not candidates and not scan_res and not act_res and not audit_act:
        return _finish(parsed, [], coverage, warnings, errors, detectors,
                       client, failed=True)

    # ── 2. истории сессий + локальные фильтры ────────────────────────────────
    sender_ids = set(options["sender_ids"]) if "sender_ids" in options else None
    include_system = options.get("include_system", True)
    max_per_chat = options.get("max_messages_per_chat", MAX_MESSAGES_PER_CHAT_DEFAULT)
    max_text_len = options.get("max_text_len", MAX_TEXT_LEN_DEFAULT)
    max_facts = options.get("max_facts", MAX_FACTS_DEFAULT)

    hist_map = fetch_histories(client, cfg, candidates, max_text_len=max_text_len)
    fetched_counts = {sid: h.fetched_count for sid, h in hist_map.items()}
    hist_res = HistoriesResult()
    apply_local_filters(hist_res, hist_map, candidates, frm=frm, to=to,
                        sender_ids=sender_ids, include_system=include_system,
                        max_per_chat=max_per_chat)
    coverage["history"] = hist_res.coverage()
    if hist_res.history_errors:
        err_ids = [sid for sid, h in hist_res.by_session.items() if h.error][:10]
        warnings.append(f"history.get: ошибки по {hist_res.history_errors} сессиям "
                        f"(примеры: {err_ids})")
    if hist_res.underfetch:
        detectors["pagination_canary"] = "FAIL"
        detail = ", ".join(
            f"сессия {u['session_id']}: {u['got']}/{u['expected']} (LIMIT={u['limit']})"
            for u in hist_res.underfetch[:10])
        missing = hist_res.coverage()["underfetch_cap"]["messages_missing_total"]
        warnings.append(
            f"history_underfetch: {len(hist_res.underfetch)} сессий: хвост истории "
            f"НЕ ДОБРАН (упёрлись в LIMIT, эскалации исчерпаны) — ориентировочно "
            f"~{missing} сообщений за лимитом; {detail}"
            + ("; …" if len(hist_res.underfetch) > 10 else ""))
    if hist_res.count_mismatch:
        detail = ", ".join(
            f"сессия {c['session_id']}: {c['got']} при messageCount {c['expected']}"
            for c in hist_res.count_mismatch[:10])
        warnings.append(
            f"history_count_mismatch: {len(hist_res.count_mismatch)} сессий: метод "
            f"отдал всё, что имеет (LIMIT не задет), но messageCount больше — "
            f"расхождение счётчиков (удалённые/семантика), потеря пагинацией "
            f"НЕ доказана; {detail}"
            + ("; …" if len(hist_res.count_mismatch) > 10 else ""))
    if hist_res.truncated_sessions:
        warnings.append(f"history.get: {len(hist_res.truncated_sessions)} сессий с "
                        f"усечением истории: {hist_res.truncated_sessions[:10]}")
    if hist_res.unknown_date:
        warnings.append(f"{hist_res.unknown_date} сообщений без распознанной даты — "
                        f"оставлены (fail-closed), проверка окна неприменима")
    if hist_res.duplicate_global:
        detectors["duplicate_guard_dropped"] = hist_res.duplicate_global

    # ── 3. авторы/роли ───────────────────────────────────────────────────────
    sender_set = {m.sender_id for m in hist_res.messages if m.sender_id}
    users_idx = fetch_users(client, cfg, sender_set)
    coverage["authors"] = users_idx.coverage()
    if users_idx.unresolved:
        warnings.append(f"не разрешены user.get: {users_idx.unresolved[:20]} — "
                        f"авторы оставлены числами (CONNECTOR/WARN)")
    if users_idx.errors:
        errors.extend(users_idx.errors[:3])

    # ── 4. линии (configId → имя) ────────────────────────────────────────────
    lines: dict = {}
    try:
        env = client.call("imopenlines.config.list.get")
        rows = env.get("result") if isinstance(env, dict) else None
        if isinstance(rows, list):
            for c in rows:
                if isinstance(c, dict) and c.get("ID") is not None:
                    lines[int(c["ID"])] = c.get("LINE_NAME") or c.get("TITLE") or ""
        coverage["lines"] = {"known": len(lines)}
    except MsgError as e:
        coverage["lines"] = {"error": e.to_json()}
        warnings.append("imopenlines.config.list.get недоступен: имена линий не подставлены")

    # ── 5. канарейка полноты Stat.get: messagesCount ↔ fetched_count ─────────
    stat_res = fetch_stats(client, cfg, [s.id for s in candidates])
    coverage["stat_aux"] = stat_res.coverage()
    if stat_res.errors:
        warnings.append(f"Stat.get: {len(stat_res.errors)} ошибок (aux, канарейка "
                        f"полноты недоступна — не блокирует)")
    cap_ids = frozenset(u["session_id"] for u in hist_res.underfetch)
    stat_warnings, stat_summary = crosscheck_stats(
        stat_res, fetched_counts, cap_hit_ids=cap_ids)
    coverage["stat_aux"]["crosscheck"] = stat_summary
    warnings.extend(stat_warnings)

    # ── 5b. передачи: живая форма — POST {"sessionId": [ids]} (D8) ───────────
    # кандидаты на запрос: queueTransfers>0 из листинга ∪ transfersCount>0 из Stat
    trans_set = {s.id for s in candidates if (s.queue_transfers or 0) > 0}
    for sid, st in stat_res.by_session.items():
        if (st.get("transfers") or 0) > 0:
            trans_set.add(sid)
    transfers_res = fetch_transfers(client, cfg, sorted(trans_set))
    coverage["transfers"] = transfers_res.coverage()
    if transfers_res.errors:
        warnings.append(f"Transfer.list: {len(transfers_res.errors)} ошибок (aux, "
                        f"не блокирует)")

    # ── 6. missing_text: активность без доступного текста (D7, поимённо) ─────
    missing_text: list[str] = []
    mt_reasons: dict[str, int] = {}
    if act_any is not None and act_any.filter_canary == "PASS":
        hist_msgs_by_session: dict[int, int] = {
            sid: len(h.messages) for sid, h in hist_res.by_session.items()}
        for e in act_any.entries:
            if frm is not None and to is not None and \
                    (e.created is None or not (frm <= e.created < to)):
                continue
            owner = f"{e.owner_type}#{e.owner_id}" if e.owner_type else "?"
            created_txt = fmt_iso(e.created) if e.created else "дата неизвестна"
            head = (f"missing_text: activity {e.activity_id} ({owner}, "
                    f"«{e.subject}», {created_txt})")
            if e.session_id is None:
                reason = "chat_unresolved"
                # ASSOCIATED_ENTITY_ID=0: чат не разрешён — Авито/карточка,
                # getlastid по таким коннекторам отвечает CRM_CHAT_EMPTY_CRM_DATA
                missing_text.append(
                    f"{head}: чат не разрешён (автолог без сессии ОЛ) — текст "
                    f"недоступен без второго источника (Авито messenger v3)")
            else:
                h = hist_res.by_session.get(e.session_id)
                if h is None:
                    reason = "not_probed"
                    # сессия не среди кандидатов скана (вне окна листинга /
                    # за потолком), историю по ней не запрашивали
                    missing_text.append(
                        f"{head}: сессия {e.session_id} не в индексе кандидатов — "
                        f"history не запрашивалась (вне листинга/потолка)")
                elif h.error is not None:
                    reason = "history_error"
                    missing_text.append(
                        f"{head}: сессия {e.session_id} — history.get с ошибкой, "
                        f"сообщения не получены")
                elif hist_msgs_by_session.get(e.session_id, 0) == 0:
                    reason = "no_ol_messages_in_window"
                    missing_text.append(
                        f"{head}: сессия {e.session_id} без сообщений ОЛ в окне — "
                        f"отправка вне истории ОЛ (Авито fallback/карточка)")
                else:
                    continue  # текст доступен через историю сессии
            mt_reasons[reason] = mt_reasons.get(reason, 0) + 1
        for m in missing_text[:MISSING_TEXT_WARN_LIMIT]:
            warnings.append(m)
        if len(missing_text) > MISSING_TEXT_WARN_LIMIT:
            warnings.append(f"missing_text: …и ещё {len(missing_text) - MISSING_TEXT_WARN_LIMIT} "
                            f"активностей без текста (полный счёт в coverage)")
        if missing_text:
            coverage["missing_text"] = {
                "count": len(missing_text),
                "by_reason": mt_reasons,
                "examples": [m for m in missing_text[:10]],
            }
            coverage["missed_source_count"] = len(missing_text)  # совм. со старым ключом

    # ── 7. факты ─────────────────────────────────────────────────────────────
    facts: list[dict] = []
    sess_by_id = {s.id: s for s in candidates}
    act_owner_by_session: dict[int, tuple[str, int]] = {}
    if act_any is not None:
        for e in act_any.entries:
            if e.session_id is not None and e.owner_type:
                act_owner_by_session.setdefault(e.session_id, (e.owner_type, e.owner_id))

    for sid, hist in hist_res.by_session.items():
        sess = sess_by_id.get(sid)
        binding = sess.binding if sess is not None else None
        if binding is None:
            binding = act_owner_by_session.get(sid)
        crm_entity = {"type": binding[0], "id": binding[1]} if binding else None
        line_id = sess.config_id if sess is not None else None
        line_name = lines.get(line_id) if line_id is not None else None
        for m in hist.messages:
            role = role_of(m.sender_id, sess.user_id if sess else None,
                           users_idx.users, cfg)
            payload = {"text": m.text, "system": m.sender_id == 0,
                       "chat_id": m.chat_id, "session_id": sid,
                       "line": {"id": line_id, "name": line_name},
                       "has_files": m.has_files,
                       "params_keys": m.params_keys}
            if m.connector_mid:
                # ключ склейки с Авито v3 (§5: CONNECTOR_MID == avito message id)
                payload["connector_mid"] = m.connector_mid
            facts.append(make_fact(
                fact_type="message", source=HIST_SRC,
                source_entity_id=f"chat{m.chat_id}#msg{m.id}" if m.chat_id else f"msg{m.id}",
                timestamp=m.ts,
                author_id=m.sender_id if m.sender_id else None,
                author_role=role, crm_entity=crm_entity,
                payload=payload,
                evidence={"query": f"SESSION_ID={sid}", "pages": hist.pages,
                          "author_name": author_name(m.sender_id, users_idx.users)},
            ))
    for t in transfers_res.rows:
        facts.append(make_fact(
            fact_type="transfer", source="imopenlines.v2.Session.Transfer.list",
            source_entity_id=f"session{t.session_id}#transfer{t.transfer_id}",
            timestamp=t.ts, author_id=t.from_user, author_role="WE",
            crm_entity=({"type": sess_by_id[t.session_id].binding[0],
                         "id": sess_by_id[t.session_id].binding[1]}
                        if t.session_id in sess_by_id and sess_by_id[t.session_id].binding else None),
            payload={"from_user": t.from_user, "to_user": t.to_user,
                     "session_id": t.session_id, "initiator_id": t.initiator_id,
                     "mode": t.mode, "reason": t.reason},
            evidence={"query": f"POST sessionId=[…{t.session_id}…]"},
        ))

    # window_canary: факт-сообщение вне окна отбрасывается (§7.3).
    # Переносы — отдельная семантика: Transfer.list отдаёт их за ВСЮ жизнь
    # сессии, внеокновые — ожидаемое, а не сбой фильтра: отбрасываем тихо
    # с подсчётом в coverage (живой прогон 09.11: 183/184 вне окна).
    if frm is not None and to is not None:
        kept = []
        dropped = 0
        xfer_out = 0
        for f in facts:
            ts = f.get("timestamp_dt")
            if ts is None:
                kept.append(f)
                continue
            if frm <= ts < to:
                kept.append(f)
                continue
            if f["fact_type"] == "transfer":
                xfer_out += 1          # данные атрибуции за жизнь сессии
                continue
            dropped += 1
            warnings.append(f"window_canary: факт {f['fact_type']}:"
                            f"{f['source_entity_id']} вне окна — отброшен")
        if xfer_out:
            coverage.setdefault("transfers", {})["out_of_window_dropped"] = xfer_out
        if dropped:
            detectors["window_canary"] = "FAIL"
        facts = kept

    # дедуп (source, source_entity_id) — §7.5
    seen: set = set()
    uniq = []
    for f in facts:
        key = (f["source"], f["source_entity_id"])
        if key in seen:
            detectors["duplicate_guard_dropped"] += 1
            continue
        seen.add(key)
        uniq.append(f)
    facts = uniq

    truncated_facts = False
    if len(facts) > max_facts:
        warnings.append(f"достигнут max_facts={max_facts}: выдано {max_facts} "
                        f"из {len(facts)} — усечение")
        facts = facts[:max_facts]
        truncated_facts = True

    # ── 8. author_crosscheck: семантический, БЕЗ сравнения количеств ─────────
    xwarn = 0
    if act_any is not None and act_any.filter_canary == "PASS":
        we_by_session: dict[int, set] = {}
        for f in facts:
            if f["fact_type"] == "message" and f["author_role"] == "WE":
                sid = f["payload"].get("session_id")
                if f.get("author_id"):
                    we_by_session.setdefault(sid, set()).add(f["author_id"])
        resp_by_session: dict[int, set] = {}
        for e in act_any.entries:
            if e.session_id is not None and e.direction_out and e.responsible_id:
                resp_by_session.setdefault(e.session_id, set()).add(e.responsible_id)
        for sid, resp in resp_by_session.items():
            we = we_by_session.get(sid, set())
            if resp - we:
                xwarn += 1
                if xwarn <= 10:
                    warnings.append(
                        f"author_crosscheck: сессия {sid}: activity RESPONSIBLE "
                        f"{sorted(resp - we)} не среди фактических отправителей {sorted(we) or '∅'} "
                        f"(семантика разная — количества НЕ сравниваются)")
        detectors["author_crosscheck"] = "WARN" if xwarn else "PASS"
        coverage["author_crosscheck_warn_sessions"] = xwarn

    coverage["api_calls"] = client.stat.to_json()
    coverage["facts"] = {"total": len(facts)}

    return _finish(parsed, facts, coverage, warnings, errors, detectors, client,
                   truncated_facts=truncated_facts, scan_res=scan_res,
                   hist_res=hist_res, scope_limited=scope_limited,
                   index_mode=index_mode, act_res=act_res,
                   missed=bool(missing_text))


def _finish(parsed, facts, coverage, warnings, errors, detectors, client, *,
            failed=False, truncated_facts=False, scan_res=None, hist_res=None,
            scope_limited=False, index_mode="scan", act_res=None, missed=False) -> dict:
    if failed:
        status = "FAILED"
    else:
        scan_bad = scan_res is not None and (scan_res.error is not None or scan_res.truncated)
        hist_bad = hist_res is not None and (hist_res.history_errors > 0 or
                                             hist_res.truncated_sessions)
        has_issues = bool(errors or warnings or truncated_facts or scope_limited
                          or missed or scan_bad or hist_bad
                          or detectors.get("filter_canary") == "FAIL"
                          or detectors.get("pagination_canary") == "FAIL"
                          or detectors.get("window_canary") == "FAIL")
        access_dead = any(e.get("code") == "ACCESS_DENIED" for e in errors)
        if not facts and (access_dead or (scan_res is not None and scan_res.error
                                          and not scan_res.candidates)):
            status = "FAILED"
        elif not facts and scan_res is not None and scan_res.error:
            status = "FAILED"
        elif has_issues:
            status = "PARTIAL"
        elif index_mode == "activity":
            # полнота activity-индекса не доказана — VERIFIED не даём (§4)
            status = "PARTIAL"
            warnings.append("activity-режим без crosscheck: полнота индекса не "
                            "доказана — статус понижен до PARTIAL")
        else:
            status = "VERIFIED"
    return {
        "request_id": parsed["request_id"],
        "intent": parsed["intent"],
        "status": status,
        "as_of": fmt_iso(now_msk()),
        "facts": serialize_facts(facts),
        "coverage": coverage,
        "warnings": warnings,
        "errors": errors,
        "detectors": detectors,
    }
