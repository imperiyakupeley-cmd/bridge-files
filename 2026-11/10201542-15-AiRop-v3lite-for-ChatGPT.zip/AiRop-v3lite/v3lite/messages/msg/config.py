"""Конфиг модуля messages. Изолирован: не импортирует core и прод-код.

Вебхуки (спека admin2 §10):
  V3_OL_WEBHOOK  — вебхук ВЛАДЕЛЬЦА портала для imopenlines.* (только env,
                   НЕ хардкод, НЕ коммит: листинг ОЛ скоупится на владельца
                   вебхука [ФАКТ, пробы 3–9]; прод-вебхук Анны видит не всё).
  V3_WEBHOOK / BX_WEBHOOK (~/AiRop/.env) — прод-вебхук для crm.*/user.get.

Боевой режим НЕ включён: без V3_OL_WEBHOOK модуль отвечает FAILED, ничего
не запрашивая по сети (offline-конфиг по умолчанию).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

_PROD_ENV = os.path.expanduser("~/AiRop/.env")

# --- проверенные константы портала (пробы 08–09.11, /tmp/ol2_probe*,
#     messages/tools/probe_fixes_20261109.py + probe2) -------------------------
SESSION_PAGE_SIZE = 200       # limit=200 для imopenlines.v2.Session.list [ФАКТ]
OFFSET_MAX = 10_000           # offset > 10000 → HTTP 400 [ФАКТ, проба2 09.11]
OFFSET_WINDOW_HARD = 10_200   # всего достижимо строк: offset_max + limit (10000+200)
SCAN_PAGE_LIMIT = 60          # предохранитель: 60*200 = 12 000 > окна API
HISTORY_BATCH = 45            # < 50 команд на batch [ФАКТ, проба 11]
HISTORY_LIMIT = 5_000         # LIMIT history.get: дефолт-страница 50 СВЕЖАХ,
                              # LIMIT работает (152/152 на 25396 при LIMIT>=200,
                              # 5000 без потолка) [ФАКТ, проба2 09.11];
                              # LAST_MESSAGE_ID сервером ИГНОРИРУЕТСЯ [ФАКТ]
HISTORY_LIMIT_ESC = 2         # эскалации LIMIT при упоре (×2 каждую, максимум 3 стр.)
USER_BATCH = 25               # user.get ID[] порциями [ФАКТ, проба 13]
TRANSFER_CHUNK = 20           # sessionId[] (массив!) на вызов Transfer.list
OWNER_USER_ID = 1             # владелец портала — полный листинг ОЛ [ФАКТ];
                              # user.current отдаёт ID СТРОКОЙ "1" [ФАКТ, D10]

RATE_RPS = 1.8                # Bitrix ≈ 2 req/s, держим ниже
TIMEOUT_S = 20.0
RETRIES_MAX = 3               # §7.6: максимум 3 ретрая с backoff
BACKOFF_BASE_S = 0.7
BACKOFF_CAP_S = 20.0

MAX_FACTS_DEFAULT = 20_000        # потолок фактов в памяти (мин. данные в RAM)
MAX_TEXT_LEN_DEFAULT = 1000       # усечение текста: полные тексты не копим
MAX_MESSAGES_PER_CHAT_DEFAULT = 5000  # как options.max_messages_per_chat §3


def _read_env_file(path: str) -> dict:
    env: dict[str, str] = {}
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env[k.strip()] = v.strip().strip('"').strip("'")
    except (FileNotFoundError, PermissionError):
        pass
    return env


@dataclass
class MsgConfig:
    ol_webhook: str = ""            # вебхук владельца: imopenlines.*, im.*
    webhook: str = ""               # прод-вебхук: crm.activity.list, user.get
    exclude_users: set = field(default_factory=set)  # боты флота (EXCLUDE_USERS)
    rate_rps: float = RATE_RPS
    timeout_s: float = TIMEOUT_S
    retries_max: int = RETRIES_MAX
    backoff_base_s: float = BACKOFF_BASE_S
    backoff_cap_s: float = BACKOFF_CAP_S
    history_limit: int = HISTORY_LIMIT   # LIMIT для history.get (тесты уменьшают)
    offline: bool = True            # True → сетевые вызовы запрещены

    def hook_for(self, method: str) -> str:
        """crm.*/user.get идут под прод-вебхуком, остальное — под владельцем."""
        if method.startswith(("crm.", "user.")) and self.webhook:
            return self.webhook
        return self.ol_webhook


def load_config(env: dict | None = None, environ: dict | None = None) -> MsgConfig:
    """env — содержимое .env (тесты), environ — os.environ-подобный словарь."""
    e = dict(_read_env_file(_PROD_ENV) if env is None else env)
    o = dict(os.environ if environ is None else environ)
    ol = o.get("V3_OL_WEBHOOK", "")
    bx = o.get("V3_WEBHOOK") or e.get("BX_WEBHOOK", "")
    excl = {u.strip() for u in (o.get("V3_EXCLUDE_USERS") or e.get("EXCLUDE_USERS", "")).split(",") if u.strip()}
    return MsgConfig(
        ol_webhook=ol,
        webhook=bx,
        exclude_users=excl,
        offline=not (ol or bx),   # нет ни одного вебхука → сетевых вызовов нет
    )
