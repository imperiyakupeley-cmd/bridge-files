"""Скан листинга сессий: кандидаты окна, старые открытые, потолок, дубли."""
from datetime import datetime, timedelta

from msg.config import MsgConfig
from msg.sessions import scan_sessions
from tests.conftest import OFF, iso, make_client

DAY = datetime(2026, 11, 7, tzinfo=OFF)
FRM, TO = DAY, DAY + timedelta(days=1)


def test_candidate_rule_created_in_window(portal, client):
    res = scan_sessions(client, MsgConfig(), frm=FRM, to=TO)
    ids = {s.id for s in res.candidates}
    assert 5001 in ids                      # создана в окне, открыта
    assert 5002 in ids                      # создана ДО окна, открыта (старая открытая)
    assert 5003 not in ids                  # закрыта до начала окна
    assert 5004 not in ids                  # создана после конца окна
    assert res.truncated is False
    assert res.stop_reason == "complete"


def test_cluster_filter(portal, client):
    res = scan_sessions(client, MsgConfig(), frm=FRM, to=TO,
                        cluster={("contact", 7002)})
    assert {s.id for s in res.candidates} == {5002}


def test_no_window_all_cluster_sessions(portal, client):
    # кластер без окна: берём все сессии привязки, независимо от дат
    res = scan_sessions(client, MsgConfig(), frm=None, to=None,
                        cluster={("contact", 7002)})
    assert {s.id for s in res.candidates} == {5002}


def test_duplicates_deduped(portal, client):
    portal.add_session(5001, chat=31001, created=DAY + timedelta(hours=10),
                       operator=20590, user_id=9001, crm=("lead", 7001))  # дубль-строка
    res = scan_sessions(client, MsgConfig(), frm=FRM, to=TO)
    ids = [s.id for s in res.candidates]
    assert len(ids) == len(set(ids))
    assert res.duplicate_rows == 1


def test_offset_ceiling_marks_truncation(portal, client):
    # 10 400 сессий → окно ~10 200: упор без естественного конца
    base = datetime(2026, 10, 1, tzinfo=OFF)
    for i in range(10_400):
        portal.sessions.append({
            "id": 100000 + i, "chatId": 200000 + i,
            "dateCreate": iso(base + timedelta(minutes=i)),
            "dateClose": None, "operatorId": 20590, "userId": 9002,
            "crmEntityType": "LEAD", "crmEntityId": 7000 + (i % 50),
            "configId": 6, "queueTransfers": 0, "messageCount": 0,
        })
    res = scan_sessions(client, MsgConfig(), frm=FRM, to=TO)
    assert res.ceiling_hit is True
    assert res.truncated is True
    assert res.stop_reason == "ceiling"
    assert res.unique_sessions >= 10_200     # дошли до окна
    assert res.unique_sessions <= 10_200 + 200


def test_scan_error_surfaced(portal, client):
    portal.deny_methods.add("imopenlines.v2.Session.list")
    res = scan_sessions(client, MsgConfig(), frm=FRM, to=TO)
    assert res.stop_reason == "error"
    assert res.error["code"] == "ACCESS_DENIED"


def test_empty_listing_is_complete(portal, client):
    portal.sessions.clear()
    res = scan_sessions(client, MsgConfig(), frm=FRM, to=TO)
    assert res.candidates == []
    assert res.truncated is False
    assert res.stop_reason == "complete"
