"""Безопасность: только read-only, мутаторы и лишние параметры — до сети."""
import pytest

from msg import whitelist
from msg.errors import SecurityError


def test_mutator_method_rejected(client, portal):
    with pytest.raises(SecurityError):
        client.call("crm.deal.update", {"ID": 1, "TITLE": "x"})
    with pytest.raises(SecurityError):
        client.post("imopenlines.session.send", {"text": "x"})
    with pytest.raises(SecurityError):
        client.call("im.message.add", {"DIALOG_ID": "chat1"})
    assert portal.calls == []


def test_unknown_method_rejected(client, portal):
    with pytest.raises(SecurityError):
        client.call("some.method", {})
    assert portal.calls == []


def test_session_list_filters_forbidden(client, portal):
    # [ФАКТ] фильтры Session.list игнорируются сервером — в whitelist их НЕТ:
    #_structural гарантия, что модуль не полагается на фиктивные фильтры
    with pytest.raises(SecurityError):
        client.post("imopenlines.v2.Session.list",
                    {"limit": 5, "filter": {"operatorId": 20590}})
    assert portal.calls == []


def test_history_extra_param_forbidden(client, portal):
    with pytest.raises(SecurityError):
        client.call("imopenlines.session.history.get",
                    {"SESSION_ID": 1, "senderId": 20590})  # фиктивный серверный фильтр
    assert portal.calls == []


def test_batch_subcommand_whitelisted(client, portal):
    with pytest.raises(SecurityError):
        client.batch([("k1", "crm.lead.delete", {"ID": 1})])
    with pytest.raises(SecurityError):
        client.batch([("k1", "imopenlines.v2.Session.list",
                       {"limit": 1, "offset": 0, "filter": {"x": 1}})])
    assert portal.calls == []


def test_transfer_list_allowed_despite_name(client, portal):
    # [ФАКТ probe2 09.11] живая форма: POST с sessionId-массивом (transfer —
    # имя разрешённого читающего метода, глагол-мутатор здесь не при чём)
    res = client.post("imopenlines.v2.Session.Transfer.list",
                      {"sessionId": [5001]})
    assert res["result"] == {"transfers": []}   # читающий метод разрешён
    assert portal.calls[-1][0] == "imopenlines.v2.Session.Transfer.list"


def test_more_than_50_batch_cmds_rejected(client, portal):
    cmds = [(f"k{i}", "user.current", {}) for i in range(51)]
    with pytest.raises(SecurityError):
        client.batch(cmds)
    assert portal.calls == []


def test_user_get_cannot_request_active(client, portal):
    with pytest.raises(SecurityError):
        client.call("user.get", {"ID": 20590, "ACTIVE": "Y"})  # без ACTIVE [ФАКТ]
    assert portal.calls == []
