"""Сквозная матрица модуля messages (задача 08.11 + спека §9).

Строки: чужие авторы, передачи, старые сессии, >200 сообщений, разрыв каналов,
время, отсутствие прав, кластер, 429, дубли, честность статусов, скоуп вебхука,
идемпотентность schema-отказов, ноль фактов = VERIFIED при живых источниках.
"""
import json
from datetime import datetime, timedelta

from msg.fetcher import fetch
from tests.conftest import OFF, period_req

DAY = datetime(2026, 11, 7, tzinfo=OFF)


def _msgs(resp):
    return [f for f in resp["facts"] if f["fact_type"] == "message"]


def _by_text(resp, text):
    return next(f for f in _msgs(resp) if f["payload"]["text"] == text)


# ---------------------------------------------------------------- базовый день
def test_baseline_day_verified(portal, client):
    resp = fetch(period_req(), client=client)
    assert resp["status"] == "VERIFIED", resp["warnings"]
    texts = {f["payload"]["text"] for f in _msgs(resp)}
    assert texts == {"Привет, есть наличие?", "Здравствуйте! Бот Анна.",
                     "Да, в наличии 2 шт", "Диалог завершён", "ответ в день окна"}
    by_text = {f["payload"]["text"]: f for f in _msgs(resp)}
    assert by_text["Привет, есть наличие?"]["author_role"] == "CLIENT"
    assert by_text["Здравствуйте! Бот Анна."]["author_role"] == "BOT"
    assert by_text["Да, в наличии 2 шт"]["author_role"] == "WE"
    assert by_text["Да, в наличии 2 шт"]["author_id"] == 20590
    assert by_text["Диалог завершён"]["author_role"] == "CONNECTOR"
    assert by_text["Диалог завершён"]["payload"]["system"] is True
    assert by_text["ответ в день окна"]["author_id"] == 11898   # уволенная — WE
    assert resp["coverage"]["sessions_scan"]["candidates"] == 2
    assert resp["detectors"]["window_canary"] == "PASS"


# ------------------------------------------------------------------ чужой автор
def test_foreign_operator_message_attributed_by_senderid(portal, client):
    portal.add_messages(5001, [
        (105, DAY + timedelta(hours=12), 30001, "вмешался чужой оператор"),
    ])
    s = next(r for r in portal.sessions if r["id"] == 5001)
    s["messageCount"] = 5
    resp = fetch(period_req(), client=client)
    f = _by_text(resp, "вмешался чужой оператор")
    assert f["author_id"] == 30001
    assert f["author_role"] == "WE"                       # штатный, хоть и чужой
    assert f["evidence"]["author_name"] == "Чужой Оператор"
    # оператор сессии (20590) не подменяет фактического отправителя
    assert resp["status"] == "VERIFIED"


# -------------------------------------------------------------------- передачи
def test_transfer_fact_and_attribution_around_it(portal, client):
    s = next(r for r in portal.sessions if r["id"] == 5002)
    s["queueTransfers"] = 1
    s["messageCount"] = 3
    portal.add_messages(5002, [(203, DAY + timedelta(hours=4), 20590, "до передачи")])
    # [ФАКТ probe2 09.11] живые ключи строк Transfer.list, id в строках НЕТ
    portal.transfers[5002] = [{
        "sessionId": 5002, "date": "2026-11-07T04:30:00+03:00",
        "fromOperatorId": 11898, "toOperatorId": 20590,
        "fromConfigId": 12, "toConfigId": 12,
        "reason": "уход с линии", "mode": "auto", "type": "transfer",
        "initiatorId": 11898,
    }]
    resp = fetch(period_req(), client=client)
    before = _by_text(resp, "до передачи")
    after = _by_text(resp, "ответ в день окна")
    assert before["author_id"] == 20590 and before["author_role"] == "WE"
    assert after["author_id"] == 11898 and after["author_role"] == "WE"
    tr = [f for f in resp["facts"] if f["fact_type"] == "transfer"]
    assert len(tr) == 1
    assert tr[0]["source_entity_id"].startswith("session5002#transfer")
    assert tr[0]["payload"]["from_user"] == 11898
    assert tr[0]["payload"]["to_user"] == 20590
    assert tr[0]["payload"]["initiator_id"] == 11898
    assert tr[0]["payload"]["mode"] == "auto"
    assert tr[0]["timestamp"] == "2026-11-07T04:30:00+03:00"
    # D8: живая форма вызова — POST с sessionId-МАССИВОМ (не скаляр/повторы)
    xfer_calls = [p for m, p in portal.calls
                  if m == "imopenlines.v2.Session.Transfer.list"]
    assert xfer_calls and all(isinstance(p.get("sessionId"), list) for p in xfer_calls)
    assert resp["coverage"]["transfers"]["sessions_probed"] == 1


# ---------------------------------------------------------------- >200 сообщений
def test_more_than_200_messages_full_history(portal, client):
    n = 450
    portal.add_session(6001, chat=36001, created=DAY + timedelta(hours=1),
                       operator=20590, user_id=9002, crm=("deal", 7601),
                       config=12, message_count=n)
    portal.add_messages(6001, [
        (900000 + i, DAY + timedelta(hours=1, seconds=i), 9002, f"волна {i}")
        for i in range(n)
    ])
    resp = fetch(period_req(), client=client)   # LIMIT=5000 одним вызовом
    wave = [f for f in _msgs(resp) if f["payload"]["text"].startswith("волна")]
    assert len(wave) == n
    assert resp["detectors"]["pagination_canary"] == "PASS"
    assert resp["status"] == "VERIFIED"


def test_history_cap_hit_is_partial_with_named_underfetch(portal, client):
    """F5: эскалации LIMIT исчерпаны, хвост не добран → поимённый
    history_underfetch + pagination FAIL + PARTIAL (не молчание)."""
    from tests.conftest import make_client
    portal.add_session(6002, chat=36002, created=DAY + timedelta(hours=1),
                       operator=20590, user_id=9002, crm=("deal", 7602),
                       config=12, message_count=1000)
    portal.add_messages(6002, [
        (910000 + i, DAY + timedelta(hours=1, seconds=i), 9002, f"обрыв {i}")
        for i in range(1000)
    ])
    c = make_client(portal, history_limit=100)   # 100 → 200 → 400, дальше нельзя
    resp = fetch(period_req(), client=c)
    assert resp["status"] == "PARTIAL"
    assert resp["detectors"]["pagination_canary"] == "FAIL"
    assert any(w.startswith("history_underfetch:") for w in resp["warnings"])
    uf = resp["coverage"]["history"]["underfetch_cap"]
    assert uf["sessions"] == 1
    assert uf["messages_missing_total"] == 600          # 400 получено из 1000
    assert uf["detail"][0]["session_id"] == 6002
    assert 6002 in resp["coverage"]["history"]["truncated_sessions"]
    # Stat-канарейка согласна: недобор С упором в LIMIT — «проверьте лимиты»
    assert any("stat_crosscheck" in w and "упором в LIMIT" in w
               for w in resp["warnings"])
    assert resp["coverage"]["stat_aux"]["crosscheck"]["under_cap_hit"] == 1


def test_history_count_mismatch_is_partial_but_not_pagination_fail(portal, client):
    """F5: метод отдал всё, что имеет, но messageCount больше — расхождение
    счётчиков, а НЕ потеря пагинации: поимённое предупреждение, канарейка PASS."""
    portal.add_session(6003, chat=36003, created=DAY + timedelta(hours=1),
                       operator=20590, user_id=9002, crm=("deal", 7603),
                       config=12, message_count=1000)
    portal.add_messages(6003, [
        (920000 + i, DAY + timedelta(hours=1, seconds=i), 9002, f"хвост {i}")
        for i in range(300)
    ])
    resp = fetch(period_req(), client=client)
    assert resp["status"] == "PARTIAL"
    assert any(w.startswith("history_count_mismatch:") for w in resp["warnings"])
    assert resp["detectors"]["pagination_canary"] == "PASS"
    cm = resp["coverage"]["history"]["count_mismatch"]
    assert cm["sessions"] == 1
    assert cm["detail"][0] == {"session_id": 6003, "got": 300, "expected": 1000}


# ------------------------------------------------------------- разрыв каналов
def test_missing_text_named_by_activity(portal, client):
    """D7: активность без доступного текста → поимённый missing_text с причиной,
    не молчание. Scan-режим: activity-аудит работает и без activity-индекса."""
    portal.add_activity(90005, session=5999, created=DAY + timedelta(hours=6),
                        responsible=20590, owner=("lead", 7999))
    portal.add_activity(90006, session=None, created=DAY + timedelta(hours=7),
                        responsible=20590, owner=("lead", 7998))
    resp = fetch(period_req(), client=client)   # дефолтный scan + аудит
    assert resp["status"] == "PARTIAL"          # НЕ VERIFIED при неполноте
    missed = [w for w in resp["warnings"] if w.startswith("missing_text:")]
    assert any("5999" in w for w in missed)
    assert any("чат не разрешён" in w for w in missed)
    mt = resp["coverage"]["missing_text"]
    assert mt["count"] == 2
    assert mt["by_reason"] == {"not_probed": 1, "chat_unresolved": 1}
    assert resp["coverage"]["missed_source_count"] == 2   # совместимый ключ


def test_activity_only_mode_is_partial_by_design(portal, client):
    resp = fetch(period_req(options={"index": "activity"}), client=client)
    assert resp["status"] == "PARTIAL"
    assert any("полнота индекса не доказана" in w for w in resp["warnings"])
    texts = {f["payload"]["text"] for f in _msgs(resp)}
    assert "Да, в наличии 2 шт" in texts       # сообщения получены по сессиям индекса


def test_activity_plus_scan_crosscheck_clean_is_verified(portal, client):
    resp = fetch(period_req(options={"index": "activity+scan"}), client=client)
    assert resp["status"] == "VERIFIED", resp["warnings"]
    assert "activity_index" in resp["coverage"]
    assert resp["coverage"]["activity_index"]["filter_canary"] == "PASS"


# ---------------------------------------------------------------------- время
def test_boundary_from_included_to_excluded(portal, client):
    portal.add_session(6100, chat=36100, created=DAY - timedelta(days=1),
                       operator=20590, user_id=9002, crm=("lead", 7610),
                       config=6, message_count=2)
    portal.add_messages(6100, [
        (1, DAY, 9002, "ровно from — включаем"),
        (2, DAY + timedelta(days=1), 9002, "ровно to — исключаем"),
    ])
    resp = fetch(period_req(), client=client)
    texts = {f["payload"]["text"] for f in _msgs(resp)}
    assert "ровно from — включаем" in texts
    assert "ровно to — исключаем" not in texts


# ------------------------------------------------------------------ права/429
def test_access_denied_on_listing_is_failed(portal, client):
    portal.deny_methods.add("imopenlines.v2.Session.list")
    resp = fetch(period_req(), client=client)
    assert resp["status"] == "FAILED"
    assert resp["errors"][0]["code"] == "ACCESS_DENIED"
    assert resp["facts"] == []


def test_activity_canary_fail_falls_back_to_scan(portal, client):
    portal.ignore_activity_filters = True
    resp = fetch(period_req(options={"index": "activity"}), client=client)
    assert resp["status"] == "PARTIAL"
    assert resp["detectors"]["filter_canary"] == "FAIL"
    assert any("переключён на полный скан" in w for w in resp["warnings"])
    # факты при этом собраны (fallback-скан жив)
    assert any(f["payload"]["text"] == "Да, в наличии 2 шт" for f in _msgs(resp))


def test_rate_limit_becomes_partial_and_keeps_facts(portal, client):
    for _ in range(4):
        portal.fail_next.append(("user.get", 429))
    resp = fetch(period_req(), client=client)
    codes = [e["code"] for e in resp["errors"]]
    assert "SOURCE_429" in codes
    assert resp["status"] == "PARTIAL"
    assert len(_msgs(resp)) == 5            # факты собраны, авторы не разрешены
    assert any("не разрешены" in w for w in resp["warnings"])


# --------------------------------------------------------------------- кластер
def test_cluster_fetch_by_binding(portal, client):
    req = period_req(intent="messages_cluster",
                     cluster={"entities": [{"type": "contact", "id": 7002}]})
    del req["from"], req["to"]
    resp = fetch(req, client=client)
    texts = {f["payload"]["text"] for f in _msgs(resp)}
    # без окна: вся история сессии контакта, включая старое сообщение
    assert texts == {"старое сообщение", "ответ в день окна"}
    assert resp["status"] == "VERIFIED"


def test_cluster_with_window_still_filters_time(portal, client):
    resp = fetch(period_req(intent="messages_cluster",
                            cluster={"entities": [
                                {"type": "contact", "id": 7002},
                                {"type": "lead", "id": 7001}]}), client=client)
    texts = {f["payload"]["text"] for f in _msgs(resp)}
    assert texts == {"ответ в день окна", "Привет, есть наличие?",
                     "Здравствуйте! Бот Анна.", "Да, в наличии 2 шт",
                     "Диалог завершён"}


# ------------------------------------------------------------------- честность
def test_zero_facts_healthy_sources_is_verified_empty(portal, client):
    portal.sessions = [r for r in portal.sessions if r["id"] == 5004]  # только завтра
    portal.activities = []
    resp = fetch(period_req(), client=client)
    assert resp["status"] == "VERIFIED"
    assert resp["facts"] == []
    assert resp["coverage"]["sessions_scan"]["candidates"] == 0


def test_webhook_scope_limited_is_partial(portal, client):
    portal.current_user = 20590            # вебхук не владельца — скоуп
    resp = fetch(period_req(), client=client)
    assert resp["status"] == "PARTIAL"
    assert any("webhook_scope" in w for w in resp["warnings"])
    assert resp["coverage"]["webhook_scope"]["full_listing_expected"] is False


def test_duplicate_session_rows_do_not_duplicate_facts(portal, client):
    dup = dict(next(r for r in portal.sessions if r["id"] == 5001))
    portal.sessions.append(dup)
    resp = fetch(period_req(), client=client)
    ids = [f["source_entity_id"] for f in _msgs(resp)]
    assert len(ids) == len(set(ids))
    assert any("дубликатов строк" in w for w in resp["warnings"])


def test_max_facts_truncation_is_partial(portal, client):
    resp = fetch(period_req(options={"max_facts": 2}), client=client)
    assert resp["status"] == "PARTIAL"
    assert len(resp["facts"]) == 2
    assert any("max_facts" in w for w in resp["warnings"])


def test_response_is_always_valid_json_serializable(portal, client):
    resp = fetch(period_req(), client=client)
    out = json.dumps(resp, ensure_ascii=False)
    assert "ownerhook" not in out and "prodhook" not in out   # секреты не утекли
    assert "rest/1" not in out                                 # вебхуки не утекли


def test_idempotent_same_request_same_facts(portal, client):
    r1 = fetch(period_req(), client=client)
    r2 = fetch(period_req(), client=client)
    assert [f["source_entity_id"] for f in r1["facts"]] == \
           [f["source_entity_id"] for f in r2["facts"]]


# ------------------------------------------------------- канарейка полноты Stat
def test_stat_crosscheck_match_keeps_verified(portal, client):
    """Stat.get согласован с history.get → канарейка молчит, статус не падает."""
    resp = fetch(period_req(), client=client)
    assert resp["status"] == "VERIFIED"
    assert resp["coverage"]["stat_aux"]["sessions"] >= 2   # 5001 и 5002
    assert resp["coverage"]["stat_aux"]["errors"] == []
    assert not any("stat_crosscheck" in w for w in resp["warnings"])


def test_stat_mismatch_downgrades_partial(portal, client):
    """history.get отдал меньше, чем считает Stat.get (сервер порезал выдачу,
    messageCount неизвестен) → предупреждение о НЕДОБОРЕ + PARTIAL."""
    portal.history_cap = 2               # сервер отдаёт максимум 2 за вызов
    for row in portal.sessions:          # messageCount скрыт → LIMIT не задет,
        row["messageCount"] = None       # cap не сработал — ловит только Stat
    resp = fetch(period_req(), client=client)
    assert resp["status"] == "PARTIAL"
    # LIMIT не задет → формулировка «расхождение счётчиков», не «проверьте лимиты»
    assert any("stat_crosscheck" in w and "расхождение счётчиков" in w
               for w in resp["warnings"])
    assert resp["coverage"]["stat_aux"]["sessions"] >= 2


def test_stat_over_is_semantics_not_loss(portal, client):
    """25396-сценарий: history 152 при Stat 143 (11 системных) — «сверху» это
    семантика счётчиков, НЕ потеря: предупреждение объясняет, количества не пугают."""
    s = next(r for r in portal.sessions if r["id"] == 5001)
    s["messageCount"] = None
    portal.add_messages(5001, [
        (106, DAY + timedelta(hours=12), 0, "Клиент оценил диалог на 5"),
        (107, DAY + timedelta(hours=12, seconds=5), 0, "Оценка принята"),
    ])
    # Stat продолжает считать все 6 сообщений, поэтому портим ТОЛЬКО Stat-канал:
    # эмулируем «Stat не считает системные» — у 5001 два системных сверх Stat
    orig = portal.dispatch

    def stat_shy(method, params, *, via="get"):
        if method == "imopenlines.v2.Session.Stat.get":
            env = orig(method, params, via=via)
            for row in env["sessions"]:
                if row["sessionId"] == 5001:
                    row["messagesCount"] -= 2     # системные не в счётчиках
            return env
        return orig(method, params, via=via)
    portal.dispatch = stat_shy
    resp = fetch(period_req(), client=client)
    xc = resp["coverage"]["stat_aux"]["crosscheck"]
    assert xc["over_sessions"] == 1
    assert xc["under_sessions"] == 0
    assert any("потери НЕТ" in w for w in resp["warnings"])


def test_stat_unavailable_is_warning_not_failure(portal, client):
    """Stat.get недоступен (aux): работоспособность сохранена, но полнота
    не сверена вторым каналом → PARTIAL по fail-closed, не FAILED."""
    portal.deny_methods.add("imopenlines.v2.Session.Stat.get")
    resp = fetch(period_req(), client=client)
    assert resp["status"] == "PARTIAL"
    assert len(_msgs(resp)) == 5          # факты собраны полностью
    assert any("Stat.get" in w for w in resp["warnings"])
