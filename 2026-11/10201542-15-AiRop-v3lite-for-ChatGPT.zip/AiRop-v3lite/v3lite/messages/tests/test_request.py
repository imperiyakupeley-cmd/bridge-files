"""Контракт запроса: любая схема-ошибка → FAILED SCHEMA ДО похода в REST (§3)."""
import pytest

from msg.fetcher import fetch
from tests.conftest import period_req


def _assert_schema_failed(resp, portal):
    assert resp["status"] == "FAILED"
    assert resp["errors"][0]["code"] == "SCHEMA"
    assert portal.calls == []          # ни одного сетевого вызова


def test_unknown_intent(client, portal):
    resp = fetch(period_req(intent="messages_everything"), client=client)
    _assert_schema_failed(resp, portal)


def test_period_requires_window(client, portal):
    req = period_req()
    del req["from"], req["to"]
    _assert_schema_failed(fetch(req, client=client), portal)


def test_period_forbids_cluster(client, portal):
    req = period_req(cluster={"entities": [{"type": "lead", "id": 1}]})
    _assert_schema_failed(fetch(req, client=client), portal)


def test_cluster_requires_cluster(client, portal):
    req = period_req(intent="messages_cluster")
    del req["from"], req["to"]
    _assert_schema_failed(fetch(req, client=client), portal)


def test_from_must_be_before_to(client, portal):
    _assert_schema_failed(fetch(period_req(
        **{"from": "2026-11-08T00:00:00+03:00", "to": "2026-11-07T00:00:00+03:00"}),
        client=client), portal)


def test_unknown_top_key(client, portal):
    _assert_schema_failed(fetch(period_req(employee_id=20590), client=client), portal)


def test_unknown_option(client, portal):
    _assert_schema_failed(fetch(period_req(options={"deep": 1}), client=client), portal)


def test_bad_option_index(client, portal):
    _assert_schema_failed(fetch(period_req(options={"index": "sphinx"}), client=client),
                          portal)


def test_bad_tz(client, portal):
    _assert_schema_failed(fetch(period_req(tz="Europe/Kaliningrad"), client=client),
                          portal)


def test_iso_without_offset_rejected(client, portal):
    resp = fetch(period_req(**{"from": "2026-11-07T00:00:00"}), client=client)
    _assert_schema_failed(resp, portal)


def test_sources_override_must_be_empty(client, portal):
    _assert_schema_failed(fetch(period_req(options={"sources_override": ["x"]}),
                                client=client), portal)


def test_cluster_entity_shape(client, portal):
    req = period_req(intent="messages_cluster",
                     cluster={"entities": [{"type": "company", "id": 5}]})
    del req["from"], req["to"]
    _assert_schema_failed(fetch(req, client=client), portal)


def test_missing_webhook_fails_offline():
    from msg.config import MsgConfig
    resp = fetch(period_req(), config=MsgConfig())  # offline, без вебхуков
    assert resp["status"] == "FAILED"
    assert resp["errors"][0]["code"] == "SCHEMA"
    assert "V3_OL_WEBHOOK" in resp["errors"][0]["detail"]


def test_not_json_input_still_contract():
    resp = fetch({"intent": 42})
    assert resp["status"] == "FAILED"
