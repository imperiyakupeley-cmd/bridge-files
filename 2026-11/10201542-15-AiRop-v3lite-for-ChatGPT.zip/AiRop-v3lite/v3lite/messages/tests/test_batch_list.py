"""batch result_error в форме LIST (PHP packed array) — ошибка per-cmd.

Приёмка admin2 09.11: когда в batch падают ВСЕ команды, Bitrix сериализует
result_error списком (плотные ключи 0..n-1), а не dict. До фикса LIST молча
терялся → сессии оставались «без ошибок» и ответ мог выглядеть VERIFIED.
"""
import json

import pytest

from msg.client import BitrixClient, _cmd_map
from msg.config import MsgConfig
from msg.transport import HttpResult, Transport
from tests.conftest import make_client


class _PackedTransport(Transport):
    """Отдаёт боевой PHP-конверт: результат/ошибки упакованы в LIST."""

    name = "packed"
    payloads: list[dict] = []

    def get(self, url: str, timeout: float) -> HttpResult:  # не используется
        raise AssertionError("GET не ожидается")

    def post(self, url: str, payload: dict, timeout: float) -> HttpResult:
        self.payloads.append(payload)
        body = {"result": {"result": [], "result_error": [
            {"error": "ACCESS_DENIED", "error_description": f"denied #{i}"}
            for i in range(len(payload.get("cmd") or {}))]}}
        return HttpResult(200, {}, json.dumps(body).encode())


class TestCmdMap:
    def test_list_full_len_maps_positionally(self):
        keys = ["h1", "h2", "h3"]
        assert _cmd_map(["a", "b", "c"], keys) == {"h1": "a", "h2": "b", "h3": "c"}

    def test_list_shorter_takes_prefix_only(self):
        # аномалия длины: без догадок, только поэлементно бьющееся
        assert _cmd_map(["a"], ["h1", "h2"]) == {"h1": "a"}

    def test_dict_passthrough(self):
        assert _cmd_map({"h2": "b"}, ["h1", "h2"]) == {"h2": "b"}

    def test_empty_list_and_garbage(self):
        assert _cmd_map([], ["h1"]) == {}
        assert _cmd_map(None, ["h1"]) == {}
        assert _cmd_map(42, ["h1"]) == {}


class TestBatchAllFailedList:
    def test_all_failed_errors_bound_to_each_cmd(self):
        cfg = MsgConfig(
            ol_webhook="https://portal.example.test/rest/1/ownerhook",
            webhook="https://portal.example.test/rest/1/prodhook",
            rate_rps=1000.0, timeout_s=5.0,
            backoff_base_s=0.001, backoff_cap_s=0.002, offline=False)
        t = _PackedTransport()
        c = BitrixClient(cfg, t, throttle=False)
        cmds = [("h101", "imopenlines.session.history.get", {"SESSION_ID": 101}),
                ("h102", "imopenlines.session.history.get", {"SESSION_ID": 102})]
        res, errs = c.batch(cmds)
        assert res == {}                       # успехов нет
        assert set(errs) == {"h101", "h102"}   # LIST развёрнут в карту per-cmd
        assert errs["h101"]["error"] == "ACCESS_DENIED"
        assert errs["h102"]["error_description"] == "denied #1"

    def test_history_marks_session_errors_not_silent(self, portal):
        """Сквозной эффект: сессия с LIST-ошибкой получает error в истории
        (PARTIAL), а не «тихая пустая история»."""
        from msg import history
        from msg.sessions import SessionRow
        client = make_client(portal)
        cfg = client.cfg

        def _packed_batch(cmds):
            keys = [k for k, _m, _p in cmds]
            errs = {k: {"error": "ACCESS_DENIED",
                        "error_description": "denied"} for k in keys}
            return {}, errs

        client.batch = _packed_batch
        s = SessionRow(id=901, message_count=3)
        out = history.fetch_histories(client, cfg, [s], max_text_len=200)
        h = out[901]
        assert h.error is not None
        assert h.error["code"] == "SOURCE_ERROR"
        assert "ACCESS_DENIED" in h.error["detail"]
