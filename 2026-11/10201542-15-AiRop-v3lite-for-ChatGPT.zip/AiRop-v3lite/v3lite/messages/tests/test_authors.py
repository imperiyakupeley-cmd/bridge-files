"""Авторы и роли: §8, AUTHOR_ID=1 — коннектор, user.get без ACTIVE."""
from datetime import datetime, timedelta

from msg.activity_index import build_activity_index
from msg.authors import author_name, fetch_users, role_of
from msg.config import MsgConfig
from tests.conftest import OFF, make_client

DAY = datetime(2026, 11, 7, tzinfo=OFF)
FRM, TO = DAY, DAY + timedelta(days=1)
CFG = MsgConfig(rate_rps=1000.0)


def test_roles_matrix(portal, client):
    users = fetch_users(client, CFG, {9001, 9002, 17316, 20590, 11898}).users
    assert role_of(0, None, users, CFG) == "CONNECTOR"             # система
    assert role_of(9001, 9001, users, CFG) == "CLIENT"             # userId сессии
    assert role_of(9002, None, users, CFG) == "CLIENT"             # imconnector
    assert role_of(17316, None, users, CFG) == "BOT"               # EXCLUDE_USERS
    assert role_of(20590, None, users, CFG) == "WE"
    assert role_of(99999, None, users, CFG) == "CONNECTOR"         # неразрешённый


def test_inactive_employee_still_we_and_named(portal, client):
    # [ФАКТ] user.get БЕЗ ACTIVE: уволенный 11898 разрешается и остаётся WE
    idx = fetch_users(client, CFG, {11898})
    assert 11898 in idx.users
    assert idx.users[11898].active == "N"
    assert role_of(11898, None, idx.users, CFG) == "WE"
    assert author_name(11898, idx.users) == "Светлана Тестова"


def test_user_get_never_sends_active(portal, client):
    fetch_users(client, CFG, {20590, 11898})
    calls = [(m, p) for m, p in portal.calls if m == "user.get"]
    assert calls, "user.get должен вызываться"
    for _m, p in calls:
        assert "ACTIVE" not in p
        assert "FILTER" not in str(p)


def test_unresolved_author_left_as_id_with_warning(portal, client):
    idx = fetch_users(client, CFG, {77777})
    assert 77777 in idx.unresolved
    assert 77777 not in idx.users


def test_activity_author_id_1_is_connector_not_author(portal, client):
    idx = build_activity_index(client, CFG, frm=FRM, to=TO)
    # все автологи имеют AUTHOR_ID=1 — коннектор; авторами не признаются
    assert idx.entries
    assert all(e.author_id == 1 for e in idx.entries)
    resp_owner = {e.responsible_id for e in idx.entries}
    assert resp_owner <= {20590, 11898}   # фактические отправители — RESPONSIBLE_ID


def test_todo_activities_excluded(portal, client):
    idx = build_activity_index(client, CFG, frm=FRM, to=TO)
    assert all((e.provider_type or "").upper() != "TODO" for e in idx.entries)


def test_activity_filter_canary_detects_ignoring_server(portal, client):
    portal.ignore_activity_filters = True
    idx = build_activity_index(client, CFG, frm=FRM, to=TO)
    assert idx.filter_canary == "FAIL"
    assert idx.entries == []              # fail-closed: индекс отброшен


def test_activity_index_respects_window_and_owner(portal, client):
    idx = build_activity_index(client, CFG, frm=FRM, to=TO,
                               cluster={("lead", 7001)})
    ids = {e.activity_id for e in idx.entries}
    assert 90001 in ids                   # исходящая 07.11, владелец lead#7001
    assert 90004 in ids                   # входящая той же сессии
    assert 90002 not in ids               # contact#7002 вне кластера
    assert 90003 not in ids               # TODO
    assert idx.session_ids == {5001}
