"""Истории: пагинация до конца, недобор против messageCount, локальные фильтры."""
from datetime import datetime, timedelta

from msg.config import MsgConfig
from msg.history import (HistoriesResult, apply_local_filters,
                         fetch_histories)
from msg.sessions import parse_session
from tests.conftest import OFF

DAY = datetime(2026, 11, 7, tzinfo=OFF)
FRM, TO = DAY, DAY + timedelta(days=1)
CFG = MsgConfig(rate_rps=1000.0)


def _rows(portal, sid):
    return [parse_session(r) for r in portal.sessions if r["id"] == sid]


def _big_session(portal, n=450, count=None, sid=7001, mid_base=100000):
    portal.add_session(sid, chat=41001, created=DAY + timedelta(hours=1),
                       operator=20590, user_id=9002, crm=("lead", 7101),
                       config=6, message_count=count if count is not None else n)
    portal.add_messages(sid, [
        (mid_base + i, DAY + timedelta(hours=1, minutes=i), 9002, f"msg {i}")
        for i in range(n)
    ])


def test_limit_escalation_fetches_full_history(portal, client):
    """[ФАКТ probe_fixes 09.11] пагинация = LIMIT-схема: страница отдаёт НОВЕЙШИЕ
    limit сообщений, LAST_MESSAGE_ID игнорируется. Упор в LIMIT → эскалация ×2
    (до двух раз) — 450 сообщений при базовом лимите 200 добираются полностью."""
    _big_session(portal, n=450)
    cfg = MsgConfig(rate_rps=1000.0, history_limit=200)
    hist = fetch_histories(client, cfg, _rows(portal, 7001), max_text_len=100)
    h = hist[7001]
    assert len(h.messages) == 450
    assert h.pages == 3                     # 200 (батч) + 400 + 800
    assert h.truncated is False
    assert h.cap_hit is False
    assert h.limit_used == 800


def test_cap_hit_after_escalation_exhausted(portal, client):
    """Эскалации исчерпаны (×2), страница всё ещё упирается в LIMIT → хвост
    НЕ ДОБРАН: cap_hit + truncated (F5) — реальная потеря, не семантика."""
    _big_session(portal, n=2000)
    cfg = MsgConfig(rate_rps=1000.0, history_limit=250)
    hist = fetch_histories(client, cfg, _rows(portal, 7001), max_text_len=100)
    h = hist[7001]
    assert h.fetched_count == 1000           # 250 → 500 → 1000, дальше нельзя
    assert h.cap_hit is True
    assert h.truncated is True
    res = HistoriesResult()
    apply_local_filters(res, hist, _rows(portal, 7001), frm=None, to=None,
                        sender_ids=None, include_system=True, max_per_chat=5000)
    assert res.underfetch == [{"session_id": 7001, "got": 1000,
                               "expected": 2000, "limit": 1000}]
    assert res.coverage()["underfetch_cap"]["messages_missing_total"] == 1000


def test_count_mismatch_is_not_pagination_loss(portal, client):
    """Метод отдал ВСЁ, что имеет (LIMIT не задет), но messageCount больше —
    расхождение счётчиков (удалённые/семантика), НЕ потеря пагинации (F5):
    поимённое count_mismatch, но cap_hit/truncated нет."""
    _big_session(portal, n=450, count=1000)   # реально есть только 450
    hist = fetch_histories(client, CFG, _rows(portal, 7001), max_text_len=100)
    h = hist[7001]
    assert h.fetched_count == 450
    assert h.cap_hit is False
    assert h.truncated is False
    assert h.count_mismatch is True
    res = HistoriesResult()
    apply_local_filters(res, hist, _rows(portal, 7001), frm=None, to=None,
                        sender_ids=None, include_system=True, max_per_chat=5000)
    assert res.count_mismatch == [{"session_id": 7001, "got": 450,
                                   "expected": 1000}]
    assert res.underfetch == []


def test_history_error_recorded_not_raised(portal, client):
    portal.add_session(7002, chat=41002, created=DAY + timedelta(hours=2),
                       operator=20590, user_id=9002, crm=("lead", 7102),
                       config=6, message_count=3)
    portal.history_errors[7002] = {"error": "ACCESS_DENIED"}
    hist = fetch_histories(client, CFG, _rows(portal, 7002), max_text_len=100)
    assert hist[7002].error is not None
    assert hist[7002].messages == []


def test_local_window_half_open(portal, client):
    # сообщение РОВНО на from — включено; РОВНО на to — исключено ([from, to))
    portal.add_session(7003, chat=41003, created=DAY - timedelta(days=1),
                       operator=20590, user_id=9002, crm=("lead", 7103),
                       config=6, message_count=3)
    portal.add_messages(7003, [
        (1, DAY, 9002, "ровно from"),
        (2, DAY + timedelta(hours=12), 9002, "внутри"),
        (3, DAY + timedelta(days=1), 9002, "ровно to"),
    ])
    sess = [s for s in portal.sessions if s["id"] == 7003]
    from msg.sessions import parse_session
    rows = [parse_session(r) for r in sess]
    hist = fetch_histories(client, CFG, rows, max_text_len=100)
    res = HistoriesResult()
    apply_local_filters(res, hist, rows, frm=FRM, to=TO,
                        sender_ids=None, include_system=True, max_per_chat=5000)
    texts = [m.text for m in res.messages]
    assert "ровно from" in texts
    assert "внутри" in texts
    assert "ровно to" not in texts


def test_local_sender_filter(portal, client):
    from msg.sessions import parse_session
    rows = [parse_session(r) for r in portal.sessions if r["id"] == 5001]
    hist = fetch_histories(client, CFG, rows, max_text_len=100)
    res = HistoriesResult()
    apply_local_filters(res, hist, rows, frm=None, to=None,
                        sender_ids={20590}, include_system=True, max_per_chat=5000)
    assert [m.text for m in res.messages] == ["Да, в наличии 2 шт"]


def test_max_per_chat_budget(portal, client):
    from msg.sessions import parse_session
    rows = [parse_session(r) for r in portal.sessions if r["id"] == 5001]
    hist = fetch_histories(client, CFG, rows, max_text_len=100)
    res = HistoriesResult()
    apply_local_filters(res, hist, rows, frm=None, to=None,
                        sender_ids=None, include_system=True, max_per_chat=2)
    assert len(res.messages) == 2


def test_zero_message_count_sessions_skipped_but_present(portal, client):
    from msg.sessions import parse_session
    portal.add_session(7004, chat=41004, created=DAY + timedelta(hours=5),
                       operator=20590, user_id=9002, crm=("lead", 7104),
                       config=6, message_count=0)
    rows = [parse_session(r) for r in portal.sessions if r["id"] == 7004]
    hist = fetch_histories(client, CFG, rows, max_text_len=100)
    assert 7004 in hist and hist[7004].messages == []
