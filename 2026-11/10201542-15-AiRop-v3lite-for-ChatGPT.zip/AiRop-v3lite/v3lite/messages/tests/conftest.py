"""Тестовое окружение модуля messages: FakePortal (мини-эмуляция Bitrix REST).

Все данные ОБЕЗЛИЧЕННЫЕ: вымышленные id/имена («Тестов Т.»), номера чатов
выдуманные, вебхуки-заглушки example.test. Ни одного реального токена.

Покрывает verified-поведение портала (пробы 08.11 + probe_fixes/probe2 09.11):
- Session.list: POST limit/offset, sessions+hasNextPage, фильтры игнорируются,
  offset > 10000 → HTTP 400 (потолок API);
- history.get: message={mid: {...}}, LIMIT-схема — страница = НОВЕЙШИЕ limit
  сообщений по убыванию id, LIMIT работает (по умолчанию 50), LAST_MESSAGE_ID
  ИГНОРИРУЕТСЯ (проверено probe_fixes: курсорная догрузка не добирала ничего);
  history_cap — серверный потолок выдачи (сценарий «метод отдал всё, что имеет»);
- batch: result.result/result_error, per-key ошибки; batch_list_form=True —
  PHP packed array: при плотных числовых ключах 0..n-1 result/result_error
  приходят LIST (в т.ч. когда упали ВСЕ команды);
- crm.activity.list: FILTER работает (start/50/total/next), флаг
  ignore_filters ломает канарейку; TODO-дела TYPE_ID=6 исключаются;
- user.get ID[] без ACTIVE; user.current — владелец/Анна, ID СТРОКОЙ
  («1» — факт D10 09.11, нормализуется в int на клиенте);
- Transfer.list: sessionId ТОЛЬКО массивом — POST {"sessionId":[...]} или GET
  sessionId[]=...; скаляр и повторяющиеся ключи без [] → HTTP 400
  (факт probe2 — прежняя форма вызова и роняла переносы);
- Stat.get: POST {"sessionId": [ids]} → result.sessions=[...];
- 429/ACCESS_DENIED по требованию (fail_next/deny_methods).
"""
from __future__ import annotations

import json
import os
import sys
import urllib.parse
from collections import deque
from datetime import datetime, timedelta, timezone

import pytest

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

from msg.client import BitrixClient                # noqa: E402
from msg.config import MsgConfig                   # noqa: E402
from msg.transport import HttpResult, Transport    # noqa: E402

OFF = timezone(timedelta(hours=3))


def iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S+03:00")


def bx(dt: datetime) -> str:
    return dt.strftime("%d.%m.%Y %H:%M:%S")


# --------------------------------------------------------------------- портал
class FakePortal:
    PAGE = 50

    def __init__(self):
        self.sessions = []            # v2-строки (см. пробы)
        self.histories = {}           # session_id -> {mid: msg}
        self.history_cap = None       # серверный потолок выдачи history (None = нет)
        self.activities = []          # crm-строки активностей
        self.users = {}               # id -> row
        self.current_user = 1
        self.transfers = {}           # session_id -> [rows] (живые ключи probe2)
        self.lines = [{"ID": 2, "LINE_NAME": "Авито Тест"},
                      {"ID": 6, "LINE_NAME": "WhatsApp Тест"},
                      {"ID": 12, "LINE_NAME": "MAX Тест"}]
        self.ignore_activity_filters = False
        self.deny_methods = set()
        self.fail_next = deque()      # (method_substr, http_status)
        self.history_errors = {}      # session_id -> error body (в batch)
        self.batch_list_form = False  # PHP packed array: LIST вместо dict
        self.calls = []               # журнал (method, params) для ассертов

    # ------------------------------------------------------------- фабрики
    def add_session(self, sid, *, chat=None, created=None, closed=None,
                    operator=20590, user_id=9001, crm=("lead", 7001),
                    config=6, message_count=None, transfers=0):
        row = {
            "id": sid, "chatId": chat if chat is not None else sid + 1000,
            "dateCreate": iso(created) if created else None,
            "dateClose": iso(closed) if closed else None,
            "operatorId": operator, "userId": user_id,
            "configId": config, "queueTransfers": transfers,
            "messageCount": message_count,
        }
        if crm:
            row["crmEntityType"] = crm[0].upper()
            row["crmEntityId"] = crm[1]
        self.sessions.append(row)
        return row

    def add_messages(self, sid, msgs):
        """msgs: [(mid, ts, senderid, text)] или (mid, ts, senderid, text, params)"""
        self.histories.setdefault(sid, {})
        for row in msgs:
            mid, ts, sender, text = row[:4]
            params = row[4] if len(row) > 4 else {}
            self.histories[sid][str(mid)] = {
                "senderid": sender, "date": iso(ts),
                "chatid": next((s["chatId"] for s in self.sessions
                                if s["id"] == sid), None),
                "text": text, "params": params,
            }

    def add_activity(self, aid, *, session=None, created=None, responsible=20590,
                     owner=("lead", 7001), subject="Исходящее сообщение",
                     provider_type="CONFIGURABLE"):
        self.activities.append({
            "ID": aid, "TYPE_ID": 6, "PROVIDER_ID": "imopenlines",
            "PROVIDER_TYPE_ID": provider_type,
            "ASSOCIATED_ENTITY_ID": session,
            "CREATED": bx(created), "RESPONSIBLE_ID": responsible,
            "AUTHOR_ID": 1,
            "OWNER_TYPE_ID": {"lead": 1, "contact": 2, "deal": 3}[owner[0]],
            "OWNER_ID": owner[1], "SUBJECT": subject,
        })

    # ------------------------------------------------------------- диспетчер
    def dispatch(self, method: str, params: dict, *, via: str = "get"):
        """Возвращает result-часть (или бросает PortalError с error-телом)."""
        self.calls.append((method, params))
        for sub, status in list(self.fail_next):
            if sub in method:
                self.fail_next.popleft()
                raise _HttpFail(status)
            break
        if method in self.deny_methods:
            raise _BxError("ACCESS_DENIED", "нет прав (тест)")
        if method == "user.current":
            # [ФАКТ D10, 09.11]: ID приходит СТРОКОЙ («1»)
            u = self.users.get(self.current_user, {"ID": self.current_user})
            return {"ID": str(u.get("ID")), "NAME": u.get("NAME", "Владелец"),
                    "LAST_NAME": u.get("LAST_NAME", "")}
        if method == "imopenlines.v2.Session.list":
            off = int(params.get("offset", 0))
            # [ФАКТ probe2, 09.11]: offset > 10000 → HTTP 400
            if off > 10_000:
                raise _HttpFail(400)
            rows = sorted(self.sessions,
                          key=lambda s: s.get("dateCreate") or "",
                          reverse=True)
            lim = int(params.get("limit", 50))
            page = rows[off:off + lim]
            return {"sessions": page, "hasNextPage": off + lim < len(rows)}
        if method == "imopenlines.session.history.get":
            sid = int(params.get("SESSION_ID"))
            if sid in self.history_errors:
                raise _BxError("SESSION_NOT_FOUND", "нет сессии (тест)")
            # [ФАКТ probe_fixes, 09.11]: страница = НОВЕЙШИЕ limit сообщений
            # (id по убыванию); LAST_MESSAGE_ID сервером ИГНОРИРУЕТСЯ
            try:
                limit = int(params.get("LIMIT", 50))
            except (TypeError, ValueError):
                limit = 50
            if self.history_cap is not None:
                limit = min(limit, self.history_cap)
            msgs = self.histories.get(sid, {})
            ids = sorted(int(k) for k in msgs)
            page_ids = set(ids[-limit:]) if limit > 0 else set()
            return {"message": {k: v for k, v in msgs.items()
                                if int(k) in page_ids}}
        if method == "imopenlines.v2.Session.Transfer.list":
            # [ФАКТ probe2, 09.11]: sessionId ТОЛЬКО массивом (POST JSON-список
            # или GET sessionId[]=); скаляр и повторяющиеся ключи без [] → 400
            if via == "post":
                raw = params.get("sessionId")
                if not isinstance(raw, list):
                    raise _HttpFail(400)   # POST-скаляр — тоже 400 (probe2)
            else:
                if "sessionId" in params and "sessionId[]" not in params:
                    raise _HttpFail(400)   # скаляр/повторы без [] — как живой
                raw = params.get("sessionId[]")
            if raw is None:
                raise _HttpFail(400)
            ids = raw if isinstance(raw, list) else [raw]
            out = []
            for sid in ids:
                try:
                    out.extend(self.transfers.get(int(sid), []))
                except (TypeError, ValueError):
                    continue
            return {"transfers": out}
        if method == "imopenlines.v2.Session.Stat.get":
            # [ФАКТ 09.11] POST {"sessionId": [ids]} → result.sessions=[...].
            # Счётчики считаем из реальных историй портала: клиент = senderid
            # == session.userId, оператор = прочие живые, системные (0) в
            # operator/client не входят, messagesCount — все сообщения.
            ids = params.get("sessionId") or []
            if not isinstance(ids, list):
                ids = [ids]
            rows = []
            for sid in ids:
                try:
                    sid = int(sid)
                except (TypeError, ValueError):
                    continue
                sess = next((s for s in self.sessions if s["id"] == sid), None)
                msgs = self.histories.get(sid, {})
                client = sum(1 for m in msgs.values()
                             if sess and m["senderid"] == sess["userId"])
                oper = sum(1 for m in msgs.values()
                           if m["senderid"] and (not sess
                                                 or m["senderid"] != sess["userId"]))
                rows.append({
                    "sessionId": sid, "messagesCount": len(msgs),
                    "messagesOperatorCount": oper, "messagesClientCount": client,
                    "transfersCount": len(self.transfers.get(sid, [])),
                    "waitAnswer": None, "waitClose": None,
                    "kpiFirstAnswer": None, "vote": None, "voteHead": None,
                })
            return {"sessions": rows}
        if method == "imopenlines.config.list.get":
            return self.lines
        if method == "user.get":
            ids = params.get("ID[]") or params.get("ID") or []
            if not isinstance(ids, list):
                ids = [ids]
            rows = [self.users[int(i)] for i in ids if int(i) in self.users]
            return rows
        if method == "crm.activity.list":
            rows = list(self.activities)
            if not self.ignore_activity_filters:
                flt = {k.split("[", 1)[1][:-1]: v for k, v in params.items()
                       if k.startswith("FILTER[")}

                def _d(s):
                    return datetime.strptime(s, "%d.%m.%Y %H:%M:%S")
                if ">CREATED" in flt:
                    rows = [r for r in rows if _d(r["CREATED"]) > _d(flt[">CREATED"])]
                if ">=CREATED" in flt:
                    rows = [r for r in rows if _d(r["CREATED"]) >= _d(flt[">=CREATED"])]
                if "<CREATED" in flt:
                    rows = [r for r in rows if _d(r["CREATED"]) < _d(flt["<CREATED"])]
                if "TYPE_ID" in flt:
                    rows = [r for r in rows if r["TYPE_ID"] == int(flt["TYPE_ID"])]
            rows.sort(key=lambda r: int(r["ID"]))
            start = int(params.get("start", 0))
            total = len(rows)
            page = rows[start:start + self.PAGE]
            return {"_page": page, "_total": total,
                    "_next": start + self.PAGE if start + self.PAGE < total else None}
        raise _BxError("UNKNOWN_METHOD", f"портал не знает {method}")


class _BxError(Exception):
    def __init__(self, code, desc):
        super().__init__(f"{code}: {desc}")
        self.code, self.desc = code, desc


class _HttpFail(Exception):
    def __init__(self, status):
        super().__init__(f"http {status}")
        self.status = status


class FakeTransport(Transport):
    name = "fake"

    def __init__(self, portal: FakePortal):
        self.portal = portal

    def get(self, url: str, timeout: float) -> HttpResult:
        method, params = self._parse(url.partition("?")[0], url.partition("?")[2])
        return self._serve(method, params, via="get")

    def post(self, url: str, payload: dict, timeout: float) -> HttpResult:
        method = url.rstrip("/").rpartition("/")[2].removesuffix(".json")
        return self._serve(method, payload or {}, via="post")

    @staticmethod
    def _parse(path: str, qs: str):
        method = path.rstrip("/").rpartition("/")[2].removesuffix(".json")
        params: dict = {}
        for k, v in urllib.parse.parse_qsl(qs, keep_blank_values=True):
            if k in params:
                if not isinstance(params[k], list):
                    params[k] = [params[k]]
                params[k].append(v)
            else:
                params[k] = v
        return method, params

    def _serve(self, method: str, params: dict, *, via: str = "get") -> HttpResult:
        try:
            if method == "batch":
                result, result_error = {}, {}
                cmd = params.get("cmd") or {}
                for key, raw in cmd.items():
                    m, _, qs = raw.partition("?")
                    sub = {}
                    for k, v in urllib.parse.parse_qsl(qs, keep_blank_values=True):
                        sub[k] = v
                    try:
                        result[key] = self.portal.dispatch(m, sub)
                    except _BxError as e:
                        result_error[key] = {"error": e.code,
                                             "error_description": e.desc}
                # [ФАКТ приёмки 09.11]: PHP packed array — при плотных числовых
                # ключах 0..n-1 result/result_error приходят LIST
                out_res: dict | list = result
                out_err: dict | list = result_error
                if self.portal.batch_list_form:
                    keys = list(cmd)
                    if keys and all(k == str(i) for i, k in enumerate(keys)):
                        out_res = [result.get(k) for k in keys]  # None = упала
                        if result_error:
                            out_err = [result_error[k] for k in keys]
                body = {"result": {"result": out_res, "result_error": out_err}}
                return HttpResult(200, {}, json.dumps(body).encode())
            data = self.portal.dispatch(method, params, via=via)
            body: dict = {"result": data}
            if isinstance(data, dict) and "_page" in data:
                body = {"result": data["_page"], "total": data["_total"],
                        "next": data["_next"]}
            return HttpResult(200, {}, json.dumps(body).encode())
        except _BxError as e:
            return HttpResult(200, {}, json.dumps(
                {"error": e.code, "error_description": e.desc}).encode())
        except _HttpFail as e:
            return HttpResult(e.status, {}, json.dumps(
                {"error": "HTTP_FAIL", "error_description": f"status {e.status}"}).encode())


# ------------------------------------------------------------------- фикстуры
@pytest.fixture
def portal():
    p = FakePortal()
    day = datetime(2026, 11, 7, 0, 0, tzinfo=OFF)
    # справочник пользователей (имена вымышленные)
    p.users = {
        1: {"ID": 1, "NAME": "Владелец", "LAST_NAME": "Тестов", "EXTERNAL_AUTH_ID": None, "ACTIVE": "Y"},
        20590: {"ID": 20590, "NAME": "София", "LAST_NAME": "Тестова", "EXTERNAL_AUTH_ID": None, "ACTIVE": "Y"},
        11898: {"ID": 11898, "NAME": "Светлана", "LAST_NAME": "Тестова", "EXTERNAL_AUTH_ID": None, "ACTIVE": "N"},
        17316: {"ID": 17316, "NAME": "Анна", "LAST_NAME": "Бот", "EXTERNAL_AUTH_ID": "bot", "ACTIVE": "Y"},
        9001: {"ID": 9001, "NAME": "Клиент", "LAST_NAME": "Авитов", "EXTERNAL_AUTH_ID": "imconnector", "ACTIVE": "Y"},
        9002: {"ID": 9002, "NAME": "Клиент", "LAST_NAME": "Максов", "EXTERNAL_AUTH_ID": "imconnector", "ACTIVE": "Y"},
        30001: {"ID": 30001, "NAME": "Чужой", "LAST_NAME": "Оператор", "EXTERNAL_AUTH_ID": None, "ACTIVE": "Y"},
    }
    # сессия дня: создана в окне, оператор 20590, клиент 9001, WA-линия 6
    p.add_session(5001, chat=31001, created=day + timedelta(hours=10),
                  operator=20590, user_id=9001, crm=("lead", 7001),
                  config=6, message_count=4)
    p.add_messages(5001, [
        (101, day + timedelta(hours=10), 9001, "Привет, есть наличие?"),
        (102, day + timedelta(hours=10, minutes=2), 17316, "Здравствуйте! Бот Анна."),
        (103, day + timedelta(hours=10, minutes=5), 20590, "Да, в наличии 2 шт"),
        (104, day + timedelta(hours=11), 0, "Диалог завершён"),
    ])
    # старая ОТКРЫТАЯ сессия (создана до окна) — сообщения внутри окна
    p.add_session(5002, chat=31002, created=day - timedelta(days=10),
                  operator=11898, user_id=9002, crm=("contact", 7002),
                  config=12, message_count=2)
    p.add_messages(5002, [
        (201, day - timedelta(days=10), 9002, "старое сообщение"),
        (202, day + timedelta(hours=3), 11898, "ответ в день окна"),
    ])
    # закрытая накануне окна — НЕ кандидат
    p.add_session(5003, chat=31003, created=day - timedelta(days=2),
                  closed=day - timedelta(days=1), operator=20590,
                  user_id=9002, crm=("deal", 7003), config=2, message_count=1)
    p.add_messages(5003, [(301, day - timedelta(days=2), 9002, "вне окна")])
    # сессия завтрашняя — НЕ кандидат
    p.add_session(5004, chat=31004, created=day + timedelta(days=1),
                  operator=20590, user_id=9002, crm=("lead", 7004),
                  config=6, message_count=1)
    p.add_messages(5004, [(401, day + timedelta(days=1, hours=1), 9002, "завтра")])
    # активности: две «исходящие» + TODO (должен быть исключён) + входящая
    p.add_activity(90001, session=5001, created=day + timedelta(hours=10, minutes=5),
                   responsible=20590, owner=("lead", 7001))
    p.add_activity(90002, session=5002, created=day + timedelta(hours=3),
                   responsible=11898, owner=("contact", 7002))
    p.add_activity(90003, created=day + timedelta(hours=9),
                   responsible=20590, owner=("lead", 7001),
                   provider_type="TODO")
    p.add_activity(90004, session=5001, created=day + timedelta(hours=10),
                   responsible=20590, owner=("lead", 7001),
                   subject="Входящее сообщение")
    return p


def make_client(portal: FakePortal, **cfg_kw) -> BitrixClient:
    cfg = MsgConfig(
        ol_webhook="https://portal.example.test/rest/1/ownerhook",
        webhook="https://portal.example.test/rest/1/prodhook",
        exclude_users={"17316"},
        rate_rps=1000.0, timeout_s=5.0,
        backoff_base_s=0.001, backoff_cap_s=0.002,
        offline=False, **cfg_kw,
    )
    return BitrixClient(cfg, FakeTransport(portal), throttle=False)


@pytest.fixture
def client(portal):
    return make_client(portal)


def period_req(**over):
    req = {
        "intent": "messages_period",
        "request_id": "11111111-2222-3333-4444-555555555555",
        "from": "2026-11-07T00:00:00+03:00",
        "to": "2026-11-08T00:00:00+03:00",
        "options": {},
    }
    req.update(over)
    return req
