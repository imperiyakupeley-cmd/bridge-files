"""Тесты строгого exact-join Авито↔Б24 (директива Алексея 09.11, mw912x028ygf).

Категорически запрещено сливать по тексту/времени/телефону/имени —
тесты доказывают это ловушками: одинаковые тексты двух клиентов,
подпись+окно ±10 мин у исходящих, числовое совпадение senderId с id
сотрудника Б24. Ключи — только строгие ID, коллизии → AMBIGUOUS,
отсутствие ключа → UNLINKED (сотруднику не засчитывается).
"""
from __future__ import annotations

import copy
import json
import os

import pytest

from msg.errors import SecurityError
from msg.join import (FORBIDDEN_JOIN_OPTIONS, employee_from_avito,
                      join_exact, normalize_users)

HERE = os.path.dirname(os.path.abspath(__file__))
FIX = os.path.join(HERE, "..", "fixtures")
STRICT = json.load(open(os.path.join(FIX, "dataset_join_strict_20261109.json")))
PAIR = json.load(open(os.path.join(FIX, "dataset_avito_b24_pair.json")))


def run_strict(scenario=None, **kw):
    s = scenario or STRICT["scenario"]
    return join_exact(
        dialog_rows=s["dialog_rows"],
        chat_messages={int(k): v for k, v in s["chat_messages"].items()},
        avito_chats=s["avito_chats"],
        verified_index=s["verified_index"],
        users=normalize_users(s["users"]),
        **kw)


def by_ref(res):
    return {m.ref: m for m in res.messages}


# ── запрет эвристик на уровне API ────────────────────────────────────────────
@pytest.mark.parametrize("opt", sorted(FORBIDDEN_JOIN_OPTIONS))
def test_forbidden_options_rejected(opt):
    with pytest.raises(SecurityError):
        run_strict(options={opt: True})


def test_any_unknown_option_rejected():
    with pytest.raises(SecurityError):
        run_strict(options={"similarity_threshold": 0.8})


def test_employee_from_avito_always_denied():
    with pytest.raises(SecurityError):
        employee_from_avito(999000)


# ── точная склейка и ловушки одинакового текста ─────────────────────────────
def test_linked_pairs_exact():
    res = run_strict()
    refs = by_ref(res)
    for b24_ref, av_ref in STRICT["expected"]["linked_pairs"]:
        assert refs[b24_ref].join_status == "LINKED", b24_ref
        assert refs[b24_ref].pair_ref == av_ref
        assert refs[av_ref].join_status == "LINKED"
        assert refs[av_ref].pair_ref == b24_ref
        assert refs[b24_ref].reason == "exact_connector_mid"


def test_identical_text_two_clients_no_cross_link():
    """Два клиента прислали ОДИНАКОВЫЙ текст в одну минуту — каждый сшился
    только со своим ключом, перекрёстной атрибуции нет."""
    s = STRICT["scenario"]
    a = next(m for m in s["chat_messages"]["30301"] if m["id"] == "3001")
    b = next(m for m in s["chat_messages"]["30302"] if m["id"] == "3101")
    assert a["text"] == b["text"]                      # предусловие ловушки
    res = run_strict()
    refs = by_ref(res)
    assert refs["chat30301#msg3001"].pair_ref.endswith("#msg:avA1")
    assert refs["chat30302#msg3101"].pair_ref.endswith("#msg:avB1")
    assert refs["chat30301#msg3001"].chat_id == 30301
    assert refs["chat30302#msg3101"].chat_id == 30302
    # клиентские роли не перепутались
    assert refs["chat30301#msg3001"].role == "CLIENT"
    assert refs["chat30302#msg3101"].role == "CLIENT"


def test_outgoing_fuzzy_trap_not_merged():
    """Подпись «Тестов Т.: » + совпадение текста после срезания + окно ±10 мин
    — прежний fuzzy-режим слил бы. Строгий join сливать ОБЯЗАН отказаться."""
    res = run_strict()
    refs = by_ref(res)
    b24 = refs["chat30301#msg3002"]
    av = refs["avito:111111111:u2i-TEST-joinA-0001#msg:avA2"]
    assert b24.join_status == "UNLINKED" and b24.pair_ref is None
    assert av.join_status == "UNLINKED" and av.pair_ref is None
    assert b24.reason == "no_exact_key"
    # при этом родная атрибуция Б24-копии сохранена (её автор известен из Б24)
    assert b24.employee_id == 402 and b24.employee_source == "b24.author_id"
    # авито-копия сотруднику НЕ засчитана
    assert av.employee_id is None and av.employee_source is None
    assert res.employee_counts() == {402: 1}


# ── коллизии → AMBIGUOUS, исключение из досье ────────────────────────────────
def test_mid_collision_ambiguous_excluded():
    res = run_strict()
    refs = by_ref(res)
    for ref in STRICT["expected"]["ambiguous"]:
        assert refs[ref].join_status == "AMBIGUOUS", ref
        assert refs[ref].pair_ref is None
    codes = {w["code"] for w in res.warnings}
    assert "connector_mid_collision" in codes
    # никому не засчитано
    assert res.counts["ambiguous"] == 3
    assert res.employee_counts() == {402: 1}


def test_duplicate_lead_crm_ambiguous():
    """LEAD 3199 привязан к двум чатам (дубли лидов): CRM-досье неоднозначно —
    факты обоих чатов исключаются из досье, авторство сотрудника сохраняется."""
    res = run_strict()
    refs = by_ref(res)
    for ref in STRICT["expected"]["crm_ambiguous_refs"]:
        assert refs[ref].crm_status == "AMBIGUOUS", ref
    assert any(w["code"] == "duplicate_lead_crm" for w in res.warnings)
    # у чата без дубля лидов crm другой
    assert refs["chat30302#msg3101"].crm_status == "UNLINKED"  # нули в entity_data_2


def test_u2i_two_b24_chats_collision():
    """Один u2i заявлен двумя чатами Б24 — все сообщения обоих чатов AMBIGUOUS."""
    s = copy.deepcopy(STRICT["scenario"])
    dup = copy.deepcopy(s["dialog_rows"][0])
    dup["id"] = "30311"
    s["dialog_rows"].append(dup)
    s["chat_messages"]["30311"] = [
        {"id": "3111", "chat_id": 30311, "author_id": 991, "text": "x",
         "params": {"CONNECTOR_MID": ["avA1"]}}]
    res = run_strict(s)
    refs = by_ref(res)
    assert refs["chat30301#msg3001"].join_status == "AMBIGUOUS"
    assert refs["chat30311#msg3111"].join_status == "AMBIGUOUS"
    assert refs["chat30301#msg3001"].reason == "chat_binding_collision"
    assert any(w["code"] == "chat_binding_collision" for w in res.warnings)


# ── multi-account и отсутствующий counterpart ────────────────────────────────
def test_multi_account_wrong_account_unlinked():
    """u2i-joinD принадлежит аккаунту 222222222; копия под 111111111
    не связывается (строгий ключ аккаунт+чат)."""
    res = run_strict()
    refs = by_ref(res)
    wrong = refs["avito:111111111:u2i-TEST-joinD-0004#msg:avD2"]
    assert wrong.join_status == "UNLINKED"
    assert wrong.reason == "chat_owned_by_other_account"
    assert wrong.chat_id is None


def test_chat_api_only_without_crm_counterpart_unlinked():
    """Сообщение есть только в Авито (прямой API), диалога Б24 нет:
    UNLINKED, сотруднику не засчитывается никогда."""
    res = run_strict()
    refs = by_ref(res)
    m = refs["avito:222222222:u2i-TEST-joinD-0004#msg:avD1"]
    assert m.join_status == "UNLINKED"
    assert m.reason == "chat_binding_missing"
    assert m.employee_id is None
    assert res.employee_counts() == {402: 1}


def test_no_crm_binding_crm_unlinked():
    res = run_strict()
    refs = by_ref(res)
    m = refs["chat30302#msg3101"]
    assert m.join_status == "LINKED"      # ключ сообщения точный
    assert m.crm_status == "UNLINKED"     # но CRM-привязки нет (нули)


def test_unverified_index_fail_closed():
    """u2i убрали из проверенного индекса → отказ даже при совпадении mid."""
    s = copy.deepcopy(STRICT["scenario"])
    s["verified_index"].pop("u2i-TEST-joinA-0001")
    res = run_strict(s)
    refs = by_ref(res)
    assert refs["chat30301#msg3001"].join_status == "UNLINKED"
    assert refs["chat30301#msg3001"].reason == "chat_account_unverified"
    assert refs["avito:111111111:u2i-TEST-joinA-0001#msg:avA1"].reason == \
        "chat_account_unverified"
    assert refs["avito:111111111:u2i-TEST-joinA-0001#msg:avA1"].join_status == "UNLINKED"


# ── senderId Авито ≠ сотрудник Б24 ───────────────────────────────────────────
def test_senderid_numeric_overlap_canary_not_attribution():
    """Авито author 402 числово совпадает с сотрудником Б24 402 и пишет
    исходящее — это НЕ атрибуция: employee_id None, только канарейка-WARN."""
    res = run_strict()
    refs = by_ref(res)
    m = refs["avito:111111111:u2i-TEST-joinB-0002#msg:avB2"]
    assert m.employee_id is None and m.employee_source is None
    assert m.role == "UNKNOWN"                      # out + чужой автор
    assert any(w["code"] == "senderid_numeric_overlap" for w in res.warnings)
    assert any(w["code"] == "author_outside_account" for w in res.warnings)
    assert res.employee_counts() == {402: 1}        # только настоящая Б24-копия


def test_no_employee_id_from_avito_side_structurally():
    res = run_strict()
    avito = [m for m in res.messages if m.origin == "avito"]
    assert avito
    assert all(m.employee_id is None and m.employee_source is None for m in avito)


# ── контент не участвует: затираем все тексты — результат неизменен ──────────
def test_texts_irrelevant_to_join():
    base = run_strict().to_json()

    def wipe(obj):
        if isinstance(obj, dict):
            out = {k: wipe(v) for k, v in obj.items()}
            if "text" in out:
                out["text"] = ""       # затираем ТОЛЬКО текст, id сохраняем
            return out
        if isinstance(obj, list):
            return [wipe(x) for x in obj]
        return obj

    s = wipe(copy.deepcopy(STRICT["scenario"]))
    assert run_strict(s).to_json() == base


# ── старая парная фикстура: fuzzy-ожидание out_matches ОТМЕНЕНО ─────────────
def test_pair_fixture_incoming_linked_outgoing_fuzzy_superseded():
    s = PAIR["methods"]
    dialog = s["im.dialog.get"]["rows"]
    msgs = s["im.dialog.messages.get"]["rows"]
    users = normalize_users(s["im.dialog.messages.get"]["users"])
    avito_rows = s["avito.v3.messages"]["rows"]
    u2i = s["avito.v3.messages"]["chat"]
    res = join_exact(
        dialog_rows=dialog,
        chat_messages={30300: msgs},
        avito_chats=[{"account_user_id": 999000, "chat_u2i": u2i,
                      "messages": avito_rows}],
        verified_index={u2i: 999000},
        users=users)
    refs = by_ref(res)
    # входящие 1:1 по CONNECTOR_MID — как и раньше
    for b24_id, av_id in PAIR["methods"]["expected_merge"]["in_matches"]:
        b24_ref, av_ref = f"chat30300#msg{b24_id}", f"avito:999000:{u2i}#msg:{av_id}"
        assert refs[b24_ref].join_status == "LINKED"
        assert refs[b24_ref].pair_ref == av_ref
    # исходящие: прежнее fuzzy-ожидание (text+time±10min) ОТМЕНЕНО — две копии
    b24 = refs["chat30300#msg1999005"]
    av = refs[f"avito:999000:{u2i}#msg:aa01bbccddeeffff00112233445566cc"]
    assert b24.join_status == "UNLINKED" and b24.pair_ref is None
    assert av.join_status == "UNLINKED" and av.pair_ref is None
    assert b24.role == "BOT" and b24.employee_id is None   # автор 401 — бот
    assert av.employee_id is None                          # senderId Авито ≠ сотрудник
    # сотруднику засчитывается только факт с родным author_id Б24 (402 в 1999006)
    assert res.employee_counts() == {402: 1}


# ── полное сравнение с ожиданиями фикстуры ───────────────────────────────────
def test_fixture_expected_full():
    exp = STRICT["expected"]
    res = run_strict()
    refs = by_ref(res)
    for ref, reason in exp["unlinked_b24"].items():
        assert refs[ref].join_status == "UNLINKED" and refs[ref].reason == reason, ref
        assert refs[ref].origin == "b24"
    for ref, reason in exp["unlinked_avito"].items():
        assert refs[ref].join_status == "UNLINKED" and refs[ref].reason == reason, ref
        assert refs[ref].origin == "avito"
    assert res.counts["linked"] == 2 * len(exp["linked_pairs"])
    assert {str(k): v for k, v in res.employee_counts().items()} == exp["employee_counts"]
    assert {w["code"] for w in res.warnings} == set(exp["warning_codes"])
    assert res.recommended_status == exp["recommended_status"]
    # честность: warnings без текстов сообщений
    assert all("text" not in w["detail"] for w in res.warnings)
