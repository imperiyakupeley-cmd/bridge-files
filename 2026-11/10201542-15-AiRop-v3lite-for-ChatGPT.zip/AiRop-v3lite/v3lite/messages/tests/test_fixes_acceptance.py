"""Регрессии приёмки admin2 09.11 (F4/F5/D7/D8/D10) — по одному блоку на дефект.

Каждый тест привязан к факту, доказанному read-only пробами на живом портале
(probe_fixes_20261109 / probe2_fixes_20261109), а не к гипотезе.
"""
from datetime import datetime, timedelta

import pytest

from msg.errors import ClientError
from msg.fetcher import fetch
from msg.sessions import scan_sessions
from msg.config import MsgConfig
from tests.conftest import OFF, iso, make_client, period_req

DAY = datetime(2026, 11, 7, tzinfo=OFF)
HIST = "imopenlines.session.history.get"
XFER = "imopenlines.v2.Session.Transfer.list"
LIST = "imopenlines.v2.Session.list"


def _msgs(resp):
    return [f for f in resp["facts"] if f["fact_type"] == "message"]


# ============================================================ F5: history.get
def test_history_limit_recovers_long_chat_25396_scenario(portal, client):
    """Живой кейс 25396: messageCount 143, реально в history 152 (11 системных),
    LIMIT=5000 → полный недобор НЕ воспроизводится: 152/152, канарейки чистые."""
    n_client, n_system = 141, 11
    portal.add_session(6101, chat=36101, created=DAY + timedelta(hours=1),
                       operator=20590, user_id=9001, crm=("lead", 7101),
                       config=6, message_count=143)       # как в листинге
    rows = [(1000 + i, DAY + timedelta(hours=1, minutes=i // 3), 9001, f"к{i}")
            for i in range(n_client)]
    rows += [(2000 + i, DAY + timedelta(hours=2, minutes=i // 2), 0, f"сис{i}")
             for i in range(n_system)]
    portal.add_messages(6101, rows)
    # Stat.get считает 143 (как живой: системные не в счётчиках)
    orig = portal.dispatch

    def stat_143(method, params, *, via="get"):
        env = orig(method, params, via=via)
        if method == "imopenlines.v2.Session.Stat.get":
            for row in env["sessions"]:
                if row["sessionId"] == 6101:
                    row["messagesCount"] = 143
        return env
    portal.dispatch = stat_143
    resp = fetch(period_req(), client=client)
    chat = [f for f in _msgs(resp) if f["payload"]["session_id"] == 6101]
    assert len(chat) == 152                           # было 50 — недобор F5
    hist = resp["coverage"]["history"]
    assert hist["underfetch_cap"]["sessions"] == 0
    assert hist["count_mismatch"]["sessions"] == 0    # 152 > 143 — не mismatch
    assert resp["detectors"]["pagination_canary"] == "PASS"
    xc = resp["coverage"]["stat_aux"]["crosscheck"]
    assert xc["over_sessions"] == 1 and xc["under_sessions"] == 0
    assert any("потери НЕТ" in w for w in resp["warnings"])   # семантика, не потеря
    assert not any("НЕДОБОРОМ" in w for w in resp["warnings"])


def test_last_message_id_is_ignored_by_portal(portal, client):
    """[ФАКТ probe_fixes] курсор LAST_MESSAGE_ID сервером игнорируется: с ним и
    без него приходит одна и та же страница свежайших — схема LIMIT, не курсор."""
    plain = client.call(HIST, {"SESSION_ID": 5001})
    with_cursor = client.call(HIST, {"SESSION_ID": 5001, "LAST_MESSAGE_ID": 102})
    assert plain["result"]["message"] == with_cursor["result"]["message"]


def test_history_default_page_is_50_newest(portal, client):
    """Без LIMIT метод отдаёт 50 СВЕЖАЙШИХ (id по убыванию) — не первых."""
    portal.add_session(6102, chat=36102, created=DAY + timedelta(hours=1),
                       operator=20590, user_id=9001, crm=("lead", 7102),
                       config=6, message_count=120)
    portal.add_messages(6102, [
        (i, DAY + timedelta(hours=1, minutes=i), 9001, f"m{i}")
        for i in range(1, 121)
    ])
    env = client.call(HIST, {"SESSION_ID": 6102})     # без LIMIT
    ids = {int(k) for k in env["result"]["message"]}
    assert len(ids) == 50
    assert min(ids) == 71                              # свежейшие 71..120


# ============================================================ D8: Transfer.list
def test_transfer_wrong_forms_are_http_400_client_error(portal, client):
    """Скаляр (GET/POST) и повторяющиеся ключи без [] → HTTP 400 → SOURCE_4XX
    (не SOURCE_5XX). Ровно эти формы и роняли переносы на живом прогоне."""
    portal.transfers[5001] = [{"sessionId": 5001, "date": iso(DAY),
                               "fromOperatorId": 1, "toOperatorId": 20590}]
    with pytest.raises(ClientError) as ei:
        client.call(XFER, {"sessionId": 5001})                 # GET-скаляр
    assert ei.value.code == "SOURCE_4XX"
    with pytest.raises(ClientError):
        client.call(XFER, array_params={"sessionId": [5001]})  # повторы без []
    with pytest.raises(ClientError):
        client.post(XFER, {"sessionId": 5001})                 # POST-скаляр
    # живые рабочие формы: POST JSON-массив и GET sessionId[]
    ok_post = client.post(XFER, {"sessionId": [5001]})
    assert len(ok_post["result"]["transfers"]) == 1
    ok_get = client.call(XFER, {"sessionId[]": 5001})
    assert len(ok_get["result"]["transfers"]) == 1


def test_http_4xx_is_not_retried(portal, client):
    """4xx — ошибка запроса: без ретраев, сразу ClientError (§7.6 ретраит только
    429/5xx/сеть)."""
    portal.fail_next.append((LIST, 400))
    with pytest.raises(ClientError):
        client.post(LIST, {"limit": 1, "offset": 0})
    assert sum(1 for m, _ in portal.calls if m == LIST) == 1


# ============================================================ D10: user.current
def test_owner_string_id_is_normalized_no_false_warning(portal, client):
    """[ФАКТ D10] user.current возвращает ID строкой («1») — после нормализации
    владелец узнаётся, ложный скоуп-warning не возникает."""
    env = client.call("user.current", hook="ol")
    assert env["result"]["ID"] == "1"                  # строка, как в проде
    resp = fetch(period_req(), client=client)
    assert not any("webhook_scope" in w for w in resp["warnings"])
    assert resp["coverage"]["webhook_scope"]["user_id"] == 1      # int
    assert resp["coverage"]["webhook_scope"]["full_listing_expected"] is True
    assert resp["status"] == "VERIFIED"


def test_current_id_garbage_is_warning_not_crash(portal, client):
    portal.current_user = "admin"                      # некорректный ID
    resp = fetch(period_req(), client=client)
    assert resp["status"] == "PARTIAL"
    assert any("некорректный ID" in w for w in resp["warnings"])


# ============================================================ D7: missing_text
def test_missing_text_reasons_history_error_and_no_ol(portal, client):
    """Обе оставшиеся причины поимённо: сессия с ошибкой history и сессия без
    сообщений ОЛ в окне (отправка вне истории ОЛ)."""
    portal.add_session(6201, chat=36201, created=DAY - timedelta(days=1),
                       operator=20590, user_id=9001, crm=("lead", 7201),
                       config=6, message_count=2)
    portal.add_messages(6201, [
        (5, DAY - timedelta(days=1), 9001, "вчера — вне окна"),
    ])
    portal.history_errors[6201] = {"error": "SESSION_NOT_FOUND"}
    portal.add_session(6202, chat=36202, created=DAY - timedelta(days=2),
                       operator=20590, user_id=9001, crm=("lead", 7202),
                       config=6, message_count=1)
    portal.add_messages(6202, [
        (6, DAY - timedelta(days=2), 9001, "позавчера — вне окна"),
    ])
    portal.add_activity(90011, session=6201, created=DAY + timedelta(hours=1),
                        responsible=20590, owner=("lead", 7201))
    portal.add_activity(90012, session=6202, created=DAY + timedelta(hours=2),
                        responsible=20590, owner=("lead", 7202))
    resp = fetch(period_req(), client=client)
    mt = resp["coverage"]["missing_text"]
    assert mt["by_reason"] == {"history_error": 1, "no_ol_messages_in_window": 1}
    assert any("6201" in w and "history.get с ошибкой" in w
               for w in resp["warnings"])
    assert any("6202" in w and "без сообщений ОЛ в окне" in w
               for w in resp["warnings"])
    assert resp["status"] == "PARTIAL"


def test_activity_audit_disabled_no_missing_text_section(portal, client):
    portal.add_activity(90006, session=None, created=DAY + timedelta(hours=7),
                        responsible=20590, owner=("lead", 7998))
    resp = fetch(period_req(options={"activity_audit": False}), client=client)
    assert "missing_text" not in resp["coverage"]
    assert "activity_index" not in resp["coverage"]
    assert resp["status"] == "VERIFIED"


def test_activity_audit_option_must_be_bool(portal, client):
    resp = fetch(period_req(options={"activity_audit": "yes"}), client=client)
    assert resp["status"] == "FAILED"
    assert resp["errors"][0]["code"] == "SCHEMA"
    assert portal.calls == []


# ============================================================ F4: потолок скана
def _perm_ids(n=10_400):
    # перестановка id (7919 взаимно просто с 10400): листинг недатирован —
    # недостижимый хвост РАССЕЯН по диапазону id, как на живом портале
    return [100000 + (i * 7919) % n for i in range(n)]


def test_ceiling_honest_boundary_and_activity_stubs(portal, client):
    """Потолок offset: без провокации 400, честная оценка хвоста по плотности id,
    добор стабов из activity-аудита, статус PARTIAL, «полнота НЕ заявляется»."""
    base = datetime(2026, 10, 1, tzinfo=OFF)
    ids = _perm_ids()
    unreachable_sid = ids[0]                     # i=0 — самая старая, за потолком
    for i in range(10_400):
        portal.sessions.append({
            "id": ids[i], "chatId": 200000 + i,
            "dateCreate": iso(base + timedelta(minutes=i)),
            "dateClose": None, "operatorId": 20590, "userId": 9002,
            "crmEntityType": "LEAD", "crmEntityId": 7000 + (i % 50),
            "configId": 6, "queueTransfers": 0, "messageCount": 0,
        })
    # активность окна указывает на сессию ЗА потолком листинга
    portal.add_activity(90099, session=unreachable_sid,
                        created=DAY + timedelta(hours=5),
                        responsible=20590, owner=("lead", 7001))
    resp = fetch(period_req(), client=client)
    assert resp["status"] == "PARTIAL"
    cov = resp["coverage"]["sessions_scan"]
    assert cov["ceiling_hit"] is True
    assert cov["stop_reason"] == "ceiling"
    assert cov["offset_limit"] == 10_000
    # ни одного запроса за пределами потолка (400 не провоцируем)
    beyond = [p for m, p in portal.calls
              if m == LIST and int(p.get("offset", 0)) > 10_000]
    assert beyond == []
    # честная граница: блок ids с оценкой хвоста по плотности
    ids_block = cov["ids"]
    assert ids_block["seen"] == cov["unique_sessions"]
    assert ids_block["missing_in_span_estimate"] >= 150    # ≈200 рассеянных
    assert any("полнота за потолком НЕ заявляется" in w for w in resp["warnings"])
    assert any("недатирован" in w for w in resp["warnings"])
    # стаб из activity-аудита: сессия за потолком получила историю по SESSION_ID
    assert any(f"{unreachable_sid}" in w and "activity-аудита" in w
               for w in resp["warnings"])
    assert any(f"сессия {unreachable_sid}" in w and "без сообщений ОЛ" in w
               for w in resp["warnings"])


def test_scan_direct_offset_beyond_limit_is_4xx(portal, client):
    """Прямой вызов за потолком (если бы предпроверки не было) → HTTP 400 →
    SOURCE_4XX: живой факт классифицируется как ошибка запроса."""
    with pytest.raises(ClientError) as ei:
        client.post(LIST, {"limit": 200, "offset": 10_050})
    assert ei.value.code == "SOURCE_4XX"


# ============================================================ batch LIST-форма
def test_batch_result_error_list_form_still_names_errors(portal, client):
    """PHP packed array: упали ВСЕ команды → result_error приходит LIST —
    поимённые ошибки не теряются (замечание приёмки по _cmd_map)."""
    for sid in (5001, 5002):
        portal.history_errors[sid] = {"error": "SESSION_NOT_FOUND"}
    portal.batch_list_form = True
    cmds = [(str(i), HIST, {"SESSION_ID": s, "LIMIT": 100})
            for i, s in enumerate((5001, 5002))]
    res, errs = client.batch(cmds)
    assert res == {} or all(v is None for v in res.values())
    assert set(errs) == {"0", "1"}
    assert all(e["error"] == "SESSION_NOT_FOUND" for e in errs.values())


def test_connector_mid_survives_into_payload(portal, client):
    """Ключ склейки с Авито v3 доезжает до payload. [ФАКТ живой прогон 09.11]:
    в history.get ключ называется camelCase «connectorMid» (184/317 сообщений
    окна 07.11) — принимаем и camelCase, и CONNECTOR_MID."""
    portal.add_messages(5001, [
        (108, DAY + timedelta(hours=9), 9001, "входящее от клиента",
         {"connectorMid": "av-msg-12345"}),
        (109, DAY + timedelta(hours=9, minutes=1), 9001, "второе входящее",
         {"CONNECTOR_MID": "av-msg-67890"}),
        (110, DAY + timedelta(hours=9, minutes=2), 9001, "третье входящее",
         {"connectorMid": ["av-msg-99999"]}),   # список — живая форма
    ])
    s = next(r for r in portal.sessions if r["id"] == 5001)
    s["messageCount"] = 7
    resp = fetch(period_req(), client=client)
    by_text = {f["payload"]["text"]: f for f in _msgs(resp)}
    assert by_text["входящее от клиента"]["payload"]["connector_mid"] == "av-msg-12345"
    assert by_text["второе входящее"]["payload"]["connector_mid"] == "av-msg-67890"
    assert by_text["третье входящее"]["payload"]["connector_mid"] == "av-msg-99999"


def test_transfer_out_of_window_dropped_silently(portal, client):
    """Transfer.list отдаёт переносы за ВСЮ жизнь сессии: внеокновые — ожидаемое,
    window_canary НЕ падает (живой прогон 09.11: 183/184 вне окна), счёт в coverage."""
    s = next(r for r in portal.sessions if r["id"] == 5002)
    s["queueTransfers"] = 1
    portal.transfers[5002] = [
        {"sessionId": 5002, "date": "2026-11-07T04:30:00+03:00",
         "fromOperatorId": 11898, "toOperatorId": 20590,
         "initiatorId": 11898, "mode": "auto", "reason": "", "type": "transfer"},
        {"sessionId": 5002, "date": "2026-10-01T09:00:00+03:00",   # вне окна
         "fromOperatorId": 1, "toOperatorId": 11898,
         "initiatorId": 1, "mode": "auto", "reason": "", "type": "transfer"},
    ]
    resp = fetch(period_req(), client=client)
    tr = [f for f in resp["facts"] if f["fact_type"] == "transfer"]
    assert len(tr) == 1 and tr[0]["timestamp"] == "2026-11-07T04:30:00+03:00"
    assert resp["detectors"]["window_canary"] == "PASS"
    assert resp["coverage"]["transfers"]["out_of_window_dropped"] == 1
    assert not any("window_canary" in w for w in resp["warnings"])
    assert resp["status"] == "VERIFIED"


def test_activity_associated_entity_zero_is_chat_unresolved(portal, client):
    """[ФАКТ замера 07.11] ASSOCIATED_ENTITY_ID=0 («чат не разрешён», Авито/
    карточка) — это chat_unresolved, а не «сессия 0 с ошибкой history»
    (живой прогон 09.11 давал 266 ложных history_error)."""
    for i in range(3):
        portal.add_activity(90100 + i, session=0,
                            created=DAY + timedelta(hours=1, minutes=i),
                            responsible=20590, owner=("lead", 7990 + i))
    resp = fetch(period_req(), client=client)
    mt = resp["coverage"]["missing_text"]
    assert mt["by_reason"] == {"chat_unresolved": 3}
    assert any("чат не разрешён" in w for w in resp["warnings"])
    # сессию 0 не запрашиваем вовсе
    assert not any(m == HIST and p.get("SESSION_ID") in ("0", 0)
                   for m, p in portal.calls)
