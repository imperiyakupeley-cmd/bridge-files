#!/usr/bin/env python3
"""CLI модуля messages: stdin JSON-запрос → stdout JSON-ответ (стык §10).

Запуск (вебхук владельца ОЛ передаётся переменной окружения, не хардкодом):
  echo '{"intent":"messages_period","request_id":"<uuid4>",...}' | \
    V3_OL_WEBHOOK='<вебхук владельца>' python3 ~/AiRop/v3lite/messages/run.py

Без V3_OL_WEBHOOK модуль отвечает FAILED (offline-режим): боевой режим НЕ
включён — интеграция в прод-конвейер отдельным решением главного админа.
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from msg.client import BitrixClient            # noqa: E402
from msg.config import load_config             # noqa: E402
from msg.fetcher import fetch                  # noqa: E402


def main() -> int:
    raw = sys.stdin.read()
    try:
        request = json.loads(raw)
    except ValueError as e:
        print(json.dumps({
            "request_id": "unknown", "intent": "unknown", "status": "FAILED",
            "as_of": None, "facts": [], "coverage": {}, "warnings": [],
            "errors": [{"code": "SCHEMA", "source": "stdin",
                        "detail": f"запрос не JSON: {e}"}],
            "detectors": {"filter_canary": "SKIP", "pagination_canary": "SKIP",
                          "window_canary": "SKIP", "author_crosscheck": "SKIP",
                          "duplicate_guard_dropped": 0},
        }, ensure_ascii=False))
        return 0
    cfg = load_config()
    client = BitrixClient(cfg) if cfg.ol_webhook else None
    response = fetch(request, config=cfg, client=client)
    print(json.dumps(response, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
