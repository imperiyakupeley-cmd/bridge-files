# Фикстуры сообщений ОЛ/Авито — политика неизменности

Формат как в `~/AiRop/v3lite/staging/fixtures/` ({"meta", "methods"}), данные
ПОЛНОСТЬЮ обезличены: вымышленные сотрудники (401/402/403), клиент-коннектор
(990), телефоны +7900000000x, тексты нейтральные, u2i-TEST-*. Ни токенов,
ни реальных id клиентов.

Все файлы immutable: SHA256SUMS, chmod 444, флаг uchg. Изменение = новая
фикстура с новой датой + перегенерация суммы:
```
cd ~/AiRop/v3lite/messages/fixtures
shasum -a 256 $(find . -type f ! -name SHA256SUMS | sort) > SHA256SUMS
chmod 444 * ; chflags uchg *
```

Состав (источник фактов: ~/AiRop/out/audit_avito_source_20261109.md):
- dataset_avito_b24_pair.json — спаренные сообщения Б24 и Avito v3 одного чата;
  ключ входящих CONNECTOR_MID==avito.id, подпись на Авито-стороне у исходящих;
- dataset_avito_gap_fallback.json — наши сообщения только в Авито (fallback
  прямого API) и прогрев до первого клиентского сообщения (диалога в Б24 нет);
- dataset_avito_sessions.json — v2.Session.list: скоуп оператора вебхука,
  открытая и закрытая сессии, userCode авито/не-авито;
- dataset_avito_card_events.json — клиентские системные строки
  («создал чат, но не написал») и отсутствие карточных событий в Б24.
