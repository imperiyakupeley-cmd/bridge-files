#!/usr/bin/env python3
"""Живая read-only приёмка фиксов 09.11 (F4/F5/D7/D8/D10) на портале.

Один полный прогон messages_period за 2026-11-07 под вебхуком владельца.
Вебхук извлекается в память процесса и НЕ попадает ни в вывод, ни в JSON.
Вызовы: только read-only whitelist, троттлинг 1,8 rps.
Итог: out/live_verify_20261109.json + краткий stdout.
"""
from __future__ import annotations

import json
import re
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

from msg.client import BitrixClient          # noqa: E402
from msg.config import MsgConfig, load_config  # noqa: E402
from msg.fetcher import fetch                # noqa: E402

OFF = timezone(timedelta(hours=3))
OUT = HERE / "out" / "live_verify_20261109.json"
DAY = "2026-11-07"


def _owner_hook() -> str:
    src = Path("~/CRM/build_report.py").expanduser().read_text(encoding="utf-8")
    m = re.search(r"(https?://[^\"'\s]+/rest/1/[a-z0-9]+)", src)
    if not m:
        raise SystemExit("вебхук владельца не найден")
    return m.group(1)


def main() -> None:
    cfg = load_config()
    cfg = MsgConfig(ol_webhook=_owner_hook(), webhook=cfg.webhook,
                    exclude_users=cfg.exclude_users,
                    rate_rps=1.8, timeout_s=25.0, offline=False)
    client = BitrixClient(cfg)
    req = {
        "intent": "messages_period",
        "request_id": "11111111-2222-3333-4444-555555555555",
        "from": f"{DAY}T00:00:00+03:00",
        "to": (datetime.fromisoformat(f"{DAY}T00:00:00+03:00")
               + timedelta(days=1)).isoformat(),
        "options": {},
    }
    t0 = time.monotonic()
    resp = fetch(req, client=client)
    wall = time.monotonic() - t0

    msgs = [f for f in resp["facts"] if f["fact_type"] == "message"]
    trs = [f for f in resp["facts"] if f["fact_type"] == "transfer"]
    cov = resp["coverage"]
    hist = cov.get("history", {})
    stat = cov.get("stat_aux", {})
    xc = stat.get("crosscheck", {})

    print(f"status={resp['status']} wall={wall:.0f}s")
    print(f"facts: message={len(msgs)} transfer={len(trs)}")
    print(f"errors: {len(resp['errors'])}  detectors: {resp['detectors']}")
    print(f"scan: candidates={cov.get('sessions_scan', {}).get('candidates')} "
          f"ceiling={cov.get('sessions_scan', {}).get('ceiling_hit')} "
          f"stop={cov.get('sessions_scan', {}).get('stop_reason')}")
    ids_b = cov.get("sessions_scan", {}).get("ids") or {}
    print(f"scan.ids: {ids_b}")
    print(f"history: sessions={hist.get('sessions')} msgs_total={hist.get('messages_total')} "
          f"underfetch={hist.get('underfetch_cap', {}).get('sessions')} "
          f"(missing={hist.get('underfetch_cap', {}).get('messages_missing_total')}) "
          f"count_mismatch={hist.get('count_mismatch', {}).get('sessions')} "
          f"truncated={hist.get('truncated_sessions')}")
    print(f"stat: sessions={stat.get('sessions')} errors={len(stat.get('errors', []))} "
          f"under={xc.get('under_sessions')} over={xc.get('over_sessions')}")
    print(f"transfers: rows={cov.get('transfers', {}).get('transfers')} "
          f"probed={cov.get('transfers', {}).get('sessions_probed')} "
          f"errors={len(cov.get('transfers', {}).get('errors', []))}")
    mt = cov.get("missing_text", {})
    print(f"missing_text: {mt.get('count')} by_reason={mt.get('by_reason')}")
    print(f"webhook_scope: {cov.get('webhook_scope')}")
    print(f"api_calls: {cov.get('api_calls', {}).get('total')}")
    print("warnings (первые 12):")
    for w in resp["warnings"][:12]:
        print(f"  - {w[:160]}")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(resp, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"сохранено: {OUT}")


if __name__ == "__main__":
    main()
