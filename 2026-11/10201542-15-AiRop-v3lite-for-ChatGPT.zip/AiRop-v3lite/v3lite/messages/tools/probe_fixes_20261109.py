#!/usr/bin/env python3
"""READ-ONLY пробы 09.11 (после приёмки admin2) для фиксов F5/D8/D10/F4.

Вопросы к порталу:
  F5  — реальная схема пагинации imopenlines.session.history.get:
        что возвращает полный вызов (первые/последние N?), как работает
        LAST_MESSAGE_ID (направление?), работает ли LIMIT;
  D8  — imopenlines.v2.Session.Transfer.list: per-session вызов (GET/POST,
        форма ответа), массив sessionId → HTTP 400 (тарификация 4xx);
  D10 — user.current: тип поля ID;
  F4  — порядок листинга Session.list (монотонность dateCreate/id desc),
        поведение на границе offset ~10200.

Вебхук владельца извлекается точечно из ~/CRM/build_report.py (как в пробах
08.11), НЕ печатается и не пишется. Только read-only методы whitelist.
Запуск: python3 tools/probe_fixes_20261109.py [--session 25396]
Результат: out/probe_fixes_20261109.json (без секретов).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

from msg.client import BitrixClient            # noqa: E402
from msg.config import MsgConfig, load_config  # noqa: E402
from msg.errors import MsgError                # noqa: E402
from msg.transport import HttpResult           # noqa: E402

_OWNER_HOOK_RE = re.compile(r"(https?://[^\"'\s]+/rest/1/[a-z0-9]+)")

HIST = "imopenlines.session.history.get"
SLIST = "imopenlines.v2.Session.list"
XFER = "imopenlines.v2.Session.Transfer.list"
STAT = "imopenlines.v2.Session.Stat.get"


def _owner_hook() -> str:
    src = open("/Users/aleksej/CRM/build_report.py", encoding="utf-8",
               errors="replace").read()
    m = _OWNER_HOOK_RE.search(src)
    if not m:
        raise SystemExit("вебхук владельца не найден")
    return m.group(1)


def hist_summary(env) -> dict:
    """env — полный конверт; вернуть сводку страницы истории."""
    payload = env
    if isinstance(env, dict) and "message" not in env and isinstance(env.get("result"), dict):
        payload = env["result"]
    msgs = payload.get("message") if isinstance(payload, dict) else None
    if not isinstance(msgs, dict):
        return {"envelope_keys": sorted(env.keys()) if isinstance(env, dict) else None,
                "messages": None}
    ids = sorted(int(k) for k in msgs if str(k).lstrip("-").isdigit())
    dates = [msgs[k].get("date") for k in msgs if isinstance(msgs[k], dict)]
    dates_sorted = sorted(d for d in dates if d)
    return {
        "count": len(msgs),
        "min_id": ids[0] if ids else None,
        "max_id": ids[-1] if ids else None,
        "first_date": dates_sorted[0] if dates_sorted else None,
        "last_date": dates_sorted[-1] if dates_sorted else None,
        "envelope_keys": sorted(env.keys()) if isinstance(env, dict) else None,
    }


def raw_get(client, method, params) -> dict:
    """GET в обход whitelist-обёртки call() не делаем: params проходят check."""
    return client.call(method, params)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--session", type=int, default=25396,
                    help="длинная сессия для проб пагинации (default 25396)")
    args = ap.parse_args()
    sid = args.session
    out: dict = {"note": "READ-ONLY пробы фиксов F5/D8/D10/F4; секреты исключены",
                 "session": sid}

    cfg = load_config()
    cfg.ol_webhook = _owner_hook()
    cfg.offline = False
    client = BitrixClient(cfg, throttle=True)

    # ── D10: user.current ─────────────────────────────────────────────────
    try:
        cur = client.call("user.current", hook="ol")
        u = cur.get("result") or {}
        out["user_current"] = {"ID": u.get("ID"), "ID_type": type(u.get("ID")).__name__,
                               "keys": sorted(u.keys())[:20]}
    except MsgError as e:
        out["user_current"] = {"error": e.to_json()}

    # ── F5: история длинной сессии ────────────────────────────────────────
    hist: dict = {}
    try:
        env = raw_get(client, HIST, {"SESSION_ID": sid})
        hist["full"] = hist_summary(env)
        payload = env.get("result") if "message" not in env else env
        msgs = payload.get("message") or {}
        ids = sorted(int(k) for k in msgs)
        hist["full"]["sample_ids"] = ids[:5] + (["..."] if len(ids) > 10 else []) + ids[-5:]
        # порядок ключей в выдаче как есть (первые 10)
        hist["full"]["raw_key_order_head"] = list(msgs.keys())[:10]
    except MsgError as e:
        hist["full"] = {"error": e.to_json()}
        ids = []
    out["history"] = hist

    if ids:
        mx, mn = max(ids), min(ids)
        # курсор от MAX (текущая реализация — не догружает)
        try:
            env = raw_get(client, HIST, {"SESSION_ID": sid, "LAST_MESSAGE_ID": mx})
            hist["cursor_max"] = hist_summary(env)
        except MsgError as e:
            hist["cursor_max"] = {"error": e.to_json()}
        # курсор от MIN (гипотеза: отдаёт СТАРШЕ чем id)
        try:
            env = raw_get(client, HIST, {"SESSION_ID": sid, "LAST_MESSAGE_ID": mn})
            s = hist_summary(env)
            if s.get("messages") is not None:
                payload = env.get("result") if "message" not in env else env
                new_ids = sorted(int(k) for k in (payload.get("message") or {}))
                s["new_ids_below_min"] = [i for i in new_ids if i < mn]
                s["overlap_with_full"] = len([i for i in new_ids if mn <= i <= mx])
            hist["cursor_min"] = s
        except MsgError as e:
            hist["cursor_min"] = {"error": e.to_json()}
        # LIMIT на полном вызове
        try:
            env = raw_get(client, HIST, {"SESSION_ID": sid, "LIMIT": 200})
            hist["limit200_full"] = hist_summary(env)
        except MsgError as e:
            hist["limit200_full"] = {"error": e.to_json()}
        # LIMIT + курсор от MIN
        try:
            env = raw_get(client, HIST, {"SESSION_ID": sid, "LAST_MESSAGE_ID": mn,
                                         "LIMIT": 200})
            hist["limit200_cursor_min"] = hist_summary(env)
        except MsgError as e:
            hist["limit200_cursor_min"] = {"error": e.to_json()}

    # Stat.get по сессии (messageCount, transfersCount — для D8/F5)
    try:
        env = client.post(STAT, {"sessionId": [sid]})
        rows = (env.get("result") or {}).get("sessions") or []
        out["stat"] = rows[:3]
    except MsgError as e:
        out["stat"] = [{"error": e.to_json()}]

    # ── D8: Transfer.list ─────────────────────────────────────────────────
    xfer: dict = {}
    # найти сессию с передачами: сканируем страницу 0 листинга, берём
    # queueTransfers>0 (или transfersCount из Stat.get пачки)
    cand: list[int] = []
    try:
        env = client.post(SLIST, {"limit": 200, "offset": 0})
        payload = env.get("result") or {}
        rows = payload.get("sessions") or []
        out["session_list_page0"] = {
            "rows": len(rows),
            "keys_sample": sorted(rows[0].keys()) if rows else [],
            "queue_transfers_rows": sum(1 for r in rows
                                        if (r.get("queueTransfers") or 0) > 0),
        }
        cand = [r["id"] for r in rows if (r.get("queueTransfers") or 0) > 0][:10]
    except MsgError as e:
        out["session_list_page0"] = {"error": e.to_json()}
    # Stat.get пачкой: transfersCount
    stat_ids: list[int] = []
    if cand:
        try:
            env = client.post(STAT, {"sessionId": cand})
            for r in (env.get("result") or {}).get("sessions") or []:
                if (r.get("transfersCount") or 0) > 0:
                    stat_ids.append(int(r["sessionId"]))
        except MsgError as e:
            xfer["stat_error"] = e.to_json()
    out["transfer_candidates"] = {"queue_gt0": cand, "with_transfers": stat_ids[:5]}
    probe_sid = stat_ids[0] if stat_ids else (cand[0] if cand else sid)
    # per-session GET
    try:
        env = raw_get(client, XFER, {"sessionId": probe_sid})
        payload = env.get("result")
        xfer["get_single"] = {
            "sid": probe_sid,
            "envelope_keys": sorted(env.keys()),
            "result_type": type(payload).__name__,
            "result_keys": sorted(payload.keys()) if isinstance(payload, dict) else None,
            "rows": (len(payload.get("transfers")) if isinstance(payload, dict)
                     and isinstance(payload.get("transfers"), list) else
                     (len(payload) if isinstance(payload, list) else None)),
            "sample": (payload.get("transfers")[:2] if isinstance(payload, dict)
                       and isinstance(payload.get("transfers"), list) else
                       (payload[:2] if isinstance(payload, list) else payload)),
        }
    except MsgError as e:
        xfer["get_single"] = {"sid": probe_sid, "error": e.to_json()}
    # per-session POST
    try:
        env = client.post(XFER, {"sessionId": probe_sid})
        payload = env.get("result")
        xfer["post_single"] = {
            "envelope_keys": sorted(env.keys()),
            "result_type": type(payload).__name__,
            "result_keys": sorted(payload.keys()) if isinstance(payload, dict) else None,
        }
    except MsgError as e:
        xfer["post_single"] = {"error": e.to_json()}
    # массив → ожидаем 4xx (для классификации ошибки)
    try:
        env = client.call(XFER, array_params={"sessionId": [probe_sid, probe_sid + 1]})
        payload = env.get("result")
        xfer["get_array"] = {"unexpected_ok": True,
                             "result_type": type(payload).__name__}
    except MsgError as e:
        xfer["get_array"] = e.to_json()
    out["transfer"] = xfer

    # ── F4: порядок листинга и граница offset ─────────────────────────────
    order: dict = {}
    sample_pages = [0, 1, 25, 50]
    pages = {}
    for off in sample_pages:
        try:
            env = client.post(SLIST, {"limit": 200, "offset": off})
            payload = env.get("result") or {}
            rows = payload.get("sessions") or []
            pages[off] = {
                "rows": len(rows),
                "first": {"id": rows[0].get("id"),
                          "dc": rows[0].get("dateCreate")} if rows else None,
                "last": {"id": rows[-1].get("id"),
                         "dc": rows[-1].get("dateCreate")} if rows else None,
                "hasNextPage": payload.get("hasNextPage"),
            }
        except MsgError as e:
            pages[off] = {"error": e.to_json()}
    order["pages"] = pages
    # граница offset: 10150, 10200, 10300
    boundary = {}
    for off, lim in ((10150, 50), (10200, 200), (10300, 50)):
        try:
            env = client.post(SLIST, {"limit": lim, "offset": off})
            payload = env.get("result") or {}
            rows = payload.get("sessions") or []
            boundary[f"off{off}_lim{lim}"] = {
                "rows": len(rows),
                "hasNextPage": payload.get("hasNextPage"),
                "first_dc": rows[0].get("dateCreate") if rows else None,
            }
        except MsgError as e:
            boundary[f"off{off}_lim{lim}"] = e.to_json()
    order["boundary"] = boundary
    out["listing_order"] = order

    os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
    path = os.path.join(HERE, "out", "probe_fixes_20261109.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1, default=str)
    # краткая сводка в stderr, без секретов
    print(json.dumps(out, ensure_ascii=False, indent=1, default=str), file=sys.stderr)
    print(f"сохранено: {path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
