#!/usr/bin/env python3
"""Измерение (READ-ONLY): полный offset-скан vs activity-индекс кандидатов.

Задача («предложи более быстрый индекс и измерь»): сравнить на контрольных днях
число REST-вызовов, время и состав кандидатов; проверить полноту activity-индекса
против скана (какой ценой достигается «без полного ежедневного обхода»).

Вебхук владельца ОЛ извлекается ТОЧЕЧНО из ~/CRM/build_report.py тем же
регэкспом, что в пробах 08.11 (/tmp/ol2_probe9+) — и НИКУДА не печатается и
не пишется. Прод-вебхук crm.* — из ~/AiRop/.env (BX_WEBHOOK). Только list/get.

Запуск: python3 tools/measure_live.py --day 2026-11-07 [--day 2026-11-08]
Результат: out/measure_<days>.json (без секретов).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.parse

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

from msg.activity_index import build_activity_index  # noqa: E402
from msg.client import BitrixClient  # noqa: E402
from msg.config import load_config  # noqa: E402
from msg.history import fetch_histories  # noqa: E402
from msg.sessions import scan_sessions  # noqa: E402
from msg.timeutil import day_bounds  # noqa: E402

_OWNER_HOOK_RE = re.compile(r"(https?://[^\"'\s]+/rest/1/[a-z0-9]+)")


def _owner_hook() -> str:
    src = open("/Users/aleksej/CRM/build_report.py", encoding="utf-8", errors="replace").read()
    m = _OWNER_HOOK_RE.search(src)
    if not m:
        raise SystemExit("вебхук владельца не найден в ~/CRM/build_report.py")
    return m.group(1)


def measure_day(client, cfg, day: str) -> dict:
    frm, to = day_bounds(day)
    out: dict = {"day": day}

    def _snap():
        return dict(client.stat.calls), client.stat.total

    t0 = time.monotonic()
    calls0 = _snap()
    scan = scan_sessions(client, cfg, frm=frm, to=to, cluster=None)
    out["scan"] = {**scan.coverage(), "wall_s": round(time.monotonic() - t0, 1),
                   "api_calls": client.stat.total - calls0[1]}
    scan_ids = {s.id for s in scan.candidates}

    t1 = time.monotonic()
    calls1 = _snap()
    act = build_activity_index(client, cfg, frm=frm, to=to, cluster=None,
                               with_canary=True)
    out["activity"] = {**act.coverage(),
                       "wall_s": round(time.monotonic() - t1, 1),
                       "api_calls": client.stat.total - calls1[1]}
    act_ids = set(act.session_ids)

    # аномалии привязки ASSOCIATED_ENTITY_ID (ловушка comms_collector §5):
    # сколько автологов указывают на 0/легаси-id вместо текущей сессии
    real = act_ids & scan_ids
    assoc_values = {}
    for e in act.entries:
        v = e.session_id if e.session_id is not None else "none"
        assoc_values[str(v)] = assoc_values.get(str(v), 0) + 1
    out["crosscheck"] = {
        "scan_candidates": len(scan_ids),
        "activity_sessions": len(act_ids),
        "common": len(real),
        "activity_only": sorted(act_ids - scan_ids)[:50],
        "scan_only_count": len(scan_ids - act_ids),
        "scan_only_sample": sorted(scan_ids - act_ids)[:50],
        "activity_without_session_binding": sum(1 for e in act.entries
                                                if e.session_id is None),
        "assoc_id_anomaly": {
            "rows_pointing_outside_scan": sum(n for v, n in assoc_values.items()
                                              if v != "none" and int(v) not in scan_ids),
            "rows_with_assoc_0": assoc_values.get("0", 0),
            "top_assoc_values": dict(sorted(assoc_values.items(),
                                            key=lambda kv: -kv[1])[:10]),
        },
        "canary": act.filter_canary,
    }

    # сколько стоил бы полный конвейер дня на каждом индексе (history-стадия
    # одинаковая — сравниваем только стадию построения индекса + одну выкачку)
    t2 = time.monotonic()
    calls2 = _snap()
    hist = fetch_histories(client, cfg, scan.candidates[:], max_text_len=200)
    n_msgs = sum(len(h.messages) for h in hist.values())
    out["history_stage"] = {
        "sessions": len(hist), "messages": n_msgs,
        "wall_s": round(time.monotonic() - t2, 1),
        "api_calls": client.stat.total - calls2[1],
        "calls_by_method": {k: v - calls2[0].get(k, 0)
                            for k, v in client.stat.calls.items()},
    }
    # сообщения дня (для сверки с эталоном 07.11: 317 сообщений / 40 чатов)
    from datetime import datetime, timezone, timedelta
    off = timezone(timedelta(hours=3))
    day_msgs = 0
    day_chats = set()
    for h in hist.values():
        for m in h.messages:
            if m.ts and m.ts.astimezone(off).date().isoformat() == day:
                day_msgs += 1
                day_chats.add(m.chat_id)
    out["day_totals"] = {"messages": day_msgs, "chats": len(day_chats)}
    out["scan_stop"] = scan.stop_reason
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--day", action="append", required=True,
                    help="контрольный день YYYY-MM-DD (можно несколько)")
    ap.add_argument("--out-dir", default=os.path.join(HERE, "out"))
    args = ap.parse_args()

    cfg = load_config()
    cfg.ol_webhook = _owner_hook()          # только в память процесса
    cfg.offline = False
    client = BitrixClient(cfg, throttle=True)

    results = []
    for day in args.day:
        print(f"измеряю {day} ...", file=sys.stderr)
        results.append(measure_day(client, cfg, day))

    payload = {
        "note": "READ-ONLY измерение индексов кандидатов; секреты исключены",
        "days": results,
        "rate_rps": cfg.rate_rps,
    }
    os.makedirs(args.out_dir, exist_ok=True)
    tag = "_".join(d.replace("-", "") for d in args.day)
    path = os.path.join(args.out_dir, f"measure_{tag}.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=1, default=str)
    print(f"сохранено: {path}", file=sys.stderr)
    for r in results:
        cc = r["crosscheck"]
        print(f"{r['day']}: scan={r['scan']['wall_s']}s/{r['scan']['pages']}стр/"
              f"{cc['scan_candidates']}канд | activity={r['activity']['wall_s']}s/"
              f"{r['activity']['pages']}стр/{cc['activity_sessions']}сесс | "
              f"общих={cc['common']} act_only={len(cc['activity_only'])} "
              f"scan_only={cc['scan_only_count']} canary={cc['canary']} | "
              f"день: {r['day_totals']['messages']} сообщ./"
              f"{r['day_totals']['chats']} чатов", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
