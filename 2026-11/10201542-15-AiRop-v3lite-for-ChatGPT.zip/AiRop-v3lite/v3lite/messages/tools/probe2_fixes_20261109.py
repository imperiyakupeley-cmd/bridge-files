#!/usr/bin/env python3
"""READ-ONLY проба 2 (09.11): уточнения после probe_fixes.

  F5: LIMIT в history.get — до какого предела отдаёт; полный размер сессии;
      доля системных (senderid=0) vs Stat.messagesCount;
  D8: тело HTTP 400 Transfer.list для разных форм вызова;
  F4: точная граница offset в Session.list.

Секреты не печатаются. Только read-only.
"""
from __future__ import annotations

import json
import os
import re
import sys
import urllib.parse

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

from msg.config import load_config  # noqa: E402
from msg.transport import Transport  # noqa: E402

_OWNER_HOOK_RE = re.compile(r"(https?://[^\"'\s]+/rest/1/[a-z0-9]+)")
HIST = "imopenlines.session.history.get"
SLIST = "imopenlines.v2.Session.list"
XFER = "imopenlines.v2.Session.Transfer.list"
STAT = "imopenlines.v2.Session.Stat.get"


def hook() -> str:
    src = open("/Users/aleksej/CRM/build_report.py", encoding="utf-8",
               errors="replace").read()
    return _OWNER_HOOK_RE.search(src).group(1)


def main() -> int:
    H = hook()
    t = Transport()
    out: dict = {}

    def call_raw(method, params=None, post_json=None):
        """Вернуть (status, body_json_или_текст) без ретраев."""
        if post_json is not None:
            url = f"{H.rstrip('/')}/{method}.json"
            r = t.post(url, post_json, 20.0)
        else:
            url = f"{H.rstrip('/')}/{method}.json"
            if params:
                url += "?" + urllib.parse.urlencode(params, doseq=True)
            r = t.get(url, 20.0)
        try:
            body = r.json()
        except ValueError:
            body = r.body[:300].decode("utf-8", "replace")
        return r.status, body

    def show(tag, status, body, keep=400):
        if isinstance(body, dict):
            s = json.dumps(body, ensure_ascii=False, default=str)
        else:
            s = str(body)
        out[tag] = {"status": status, "body": s[:keep]}

    # ── D8: формы вызова Transfer.list, сессия 29666 (transfersCount>0) ────
    sid = 29666
    show("xfer_get_no_params", *call_raw(XFER))
    show("xfer_get_scalar", *call_raw(XFER, {"sessionId": sid}))
    show("xfer_get_bracket", *call_raw(XFER, {"sessionId[]": sid}))
    show("xfer_get_repeat", *call_raw(XFER, {"sessionId": [sid, sid - 4]}))
    show("xfer_post_scalar", *call_raw(XFER, post_json={"sessionId": sid}))
    show("xfer_post_list1", *call_raw(XFER, post_json={"sessionId": [sid]}))
    show("xfer_post_list2", *call_raw(XFER, post_json={"sessionId": [sid, sid - 4]}))
    show("xfer_get_upper", *call_raw(XFER, {"SESSION_ID": sid}))

    # ── F5: LIMIT на истории 25396 ────────────────────────────────────────
    def hist_stats(body):
        if not isinstance(body, dict):
            return body
        msgs = (body.get("result") or {}).get("message") or body.get("message") or {}
        ids = [int(k) for k in msgs if str(k).lstrip("-").isdigit()]
        sys_n = sum(1 for v in msgs.values()
                    if isinstance(v, dict) and int(v.get("senderid") or -1) == 0)
        return {"count": len(msgs), "min_id": min(ids) if ids else None,
                "max_id": max(ids) if ids else None, "system_sender0": sys_n}

    for lim in (500, 1000, 5000):
        st, body = call_raw(HIST, {"SESSION_ID": 25396, "LIMIT": lim})
        out[f"hist_25396_limit{lim}"] = {"status": st, **hist_stats(body)}

    # самая длинная сессия из доступных: Stat.get по набору id (вкл. 25396,
    # 26550 и queue-transfer кандидатов), затем LIMIT-проба на максимум
    ids = [25396, 26550, 29666, 29662, 29574, 29570, 29562, 29554, 29540,
           29498, 29482, 29444, 14028, 16650, 25520]
    st, body = call_raw(STAT, post_json={"sessionId": ids})
    rows = (body.get("result") or {}).get("sessions") if isinstance(body, dict) else None
    biggest, biggest_n = None, 0
    if isinstance(rows, list):
        for r in rows:
            n = int(r.get("messagesCount") or 0)
            if n > biggest_n:
                biggest, biggest_n = int(r["sessionId"]), n
    out["stat_sample"] = {"biggest_session": biggest, "biggest_messagesCount": biggest_n,
                          "rows": [(r.get("sessionId"), r.get("messagesCount"))
                                   for r in rows] if isinstance(rows, list) else rows}
    if biggest:
        for lim in (1000, 5000):
            st, body = call_raw(HIST, {"SESSION_ID": biggest, "LIMIT": lim})
            out[f"hist_{biggest}_limit{lim}"] = {"status": st, **hist_stats(body)}

    # ── F4: граница offset Session.list ───────────────────────────────────
    for off, lim in ((10000, 1), (10001, 1), (10050, 100), (10100, 100),
                     (10200, 1), (5000, 6000)):
        st, body = call_raw(SLIST, post_json={"limit": lim, "offset": off})
        n = len(((body.get("result") or {}).get("sessions")) or []) \
            if isinstance(body, dict) else None
        out[f"slist_off{off}_lim{lim}"] = {"status": st, "rows": n}

    path = os.path.join(HERE, "out", "probe2_fixes_20261109.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1, default=str)
    print(json.dumps(out, ensure_ascii=False, indent=1, default=str), file=sys.stderr)
    print(f"сохранено: {path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
