# messages — модуль переписок Открытых линий (v3lite, изолированный)

On-demand получение переписок ОЛ за период и по клиентскому кластеру,
без копии всей CRM. Изолирован от DEV-ядра `v3lite/core` (файлы DEV не
редактировались).

Контракт согласован с admin2: `~/AiRop/spec_v3lite_admin2.md` (заморожен,
v1.0). Коды ошибок, статусы VERIFIED/PARTIAL/FAILED, канарейки и fail-closed
поведение повторяют контракт; расширения вынесены как предложение v1.1 (ниже).
Приёмка 09.11 (9 FAIL) отработана: детали — `qa/results/acceptance_admin2_
20261109_verdict.md`, живые доказательства фиксов — `out/probe_fixes_
20261109.json`, `out/probe2_fixes_20261109.json`, `out/live_verify_20261109.json`.

## Запуск

```bash
cd ~/AiRop/v3lite/messages
V3_OL_WEBHOOK='https://…/rest/1/…' python3 run.py < request.json > response.json
```

`request.json` — запрос на stdin, ответ — JSON на stdout. Без `V3_OL_WEBHOOK`
модуль отвечает FAILED/LIMIT без единого сетевого вызова (battle-режим НЕ
включён по умолчанию; боевой запуск — отдельное решение владельца).
`V3_WEBHOOK` (или `BX_WEBHOOK` из `~/AiRop/.env`) — прод-вебхук для
`crm.*`/`user.*`; `V3_OL_WEBHOOK` — вебхук владельца ОЛ для листинга сессий.

Измерение индексов (read-only): `python3 tools/measure_live.py --day 2026-11-07`
→ `out/measure_<дни>.json`; живая приёмка фиксов: `python3 tools/probe3_live_verify.py`
(вебхук владельца извлекается в память, не печатается). Секреты исключены.

## Запрос

```json
{"request_id": "…", "intent": "messages_period",
 "from": "2026-11-07T00:00:00+03:00", "to": "2026-11-08T00:00:00+03:00",
 "options": {"index": "scan", "include_system": false, "lines": [6],
             "sender_ids": null, "max_messages_per_chat": 0,
             "max_facts": 0, "max_text_len": 1000, "activity_audit": true}}
```

- `messages_period`: обязательны `from`/`to` (ISO-8601 с офсетом, окно [from,to),
  TZ Europe/Moscow); `cluster` запрещён.
- `messages_cluster`: обязателен `cluster.entities` = [{type,id}] (LEAD/CONTACT/
  DEAL по привязке сессии); `from`/`to` опциональны (без окна — вся история
  сессий кластера).
- `options.index`: `scan` (умолчание, полнота) | `activity` (быстро, всегда
  PARTIAL — полнота индекса не доказана) | `activity+scan` (activity как
  crosscheck поверх скана).
- `options.activity_audit` (bool, умолчание true): в scan-режиме с окном —
  activity-аудит автологов для поимённых missing_text и добора сессий за
  потолком скана. Отключается явно.
- Неизвестный ключ/значение → SCHEMA до любого обращения к порталу.

## Ответ

`{request_id, intent, status, as_of, facts[], coverage{}, warnings[], errors[], detectors{}}`

- fact_type `message`: `source_entity_id = "chat{chatId}#msg{messageId}"`,
  payload = {text (≤ max_text_len, потолок 4000), system, chat_id, session_id,
  line {id,name}, has_files, params_keys (≤10, только имена ключей),
  connector_mid — при наличии params.connectorMid (ключ склейки с Авито v3)}.
  Медиа не копируются: только признак has_files.
- fact_type `transfer`: `source_entity_id = "session{sid}#transfer{tid}"`,
  payload = {from_user, to_user, session_id, initiator_id, mode, reason}.
  Transfer.list отдаёт переносы за ВСЮ жизнь сессии: внеокновые отбрасываются
  тихо с подсчётом `coverage.transfers.out_of_window_dropped` (это не сбой
  фильтра окна).
- coverage: sessions_scan (включая честную границу потолка `ids{min,max,seen,
  span,missing_in_span_estimate}`) / activity_index / history (включая
  `underfetch_cap` — реальный недобор хвоста, и `count_mismatch` — расхождение
  счётчиков без потери) / authors / transfers / stat_aux (с crosscheck-детализацией
  under/over) / lines / webhook_scope / missing_text {count, by_reason, examples}.
- errors: коды контракта SCHEMA|SOURCE_429|SOURCE_4XX|SOURCE_5XX|SOURCE_NET|
  SOURCE_ERROR|ACCESS_DENIED|FILTER_CANARY|LIMIT|SECURITY. HTTP 4xx (кроме 429)
  — SOURCE_4XX: ошибка запроса, без ретраев; 5xx — SOURCE_5XX с ретраями.
- авторство (§8): роль WE/CLIENT/BOT/CONNECTOR по senderid == session.userId /
  EXTERNAL_AUTH_ID='imconnector' / EXCLUDE_USERS / AUTHOR_ID=1-коннектор;
  AUTHOR_ID=1 никогда не считается автором; crosscheck RESPONSIBLE ↔ фактические
  WE-отправители — только WARN (разные виды сообщений равенства не требуют).

## Проверенные факты API, на которых построено (пробы 08–09.11, read-only)

| Факт | Следствие в коде |
|---|---|
| `imopenlines.v2.Session.list`: фильтры operatorId/date/source МОЛЧА игнорируются | в whitelist вообще нет filter-ключей; полный offset-скан 200/стр + локальная фильтрация |
| offset ≤ 10 000, глубже HTTP 400; достижимо ≈10 200 строк; листинг НЕ отсортирован по датам (хвост недостижимого рассеян по диапазону id) | предзапросная проверка потолка (400 не провоцируем); ceiling → PARTIAL + оценка хвоста по плотности id; полнота за потолком НЕ заявляется |
| кандидаты = созданные < to И (открытые ИЛИ закрытые ≥ from); старые открытые разбросаны по всему листингу | ранний выход из скана запрещён — только полный проход |
| `history.get`: страница = НОВЕЙШИЕ limit сообщений (по умолчанию 50); LIMIT работает до 5000+; курсор LAST_MESSAGE_ID сервером ИГНОРИРУЕТСЯ | LIMIT-схема: базовый LIMIT=5000 одним вызовом; упор в лимит → эскалация ×2 (до двух раз); остался упор → cap_hit: поимённый underfetch + PARTIAL (фикс F5: старая курсорная схема не добирала ничего — 45/595 сессий) |
| history отдала меньше messageCount при незадетом LIMIT — метод отдал ВСЁ, что имеет | count_mismatch (поимённо): расхождение счётчиков (удалённые/семантика), НЕ потеря пагинации |
| `params.connectorMid` в history.get: ключ camelCase, значение скаляр ИЛИ список; 184/317 сообщений окна 07.11 | извлечение в payload.connector_mid — ключ склейки с адаптером Авито v3 |
| `Transfer.list`: sessionId ТОЛЬКО массивом — POST {"sessionId":[…]} или GET sessionId[]=…; скаляр и повторяющиеся ключи без [] → HTTP 400 | POST JSON-массив чанками по 20 (фикс D8: старая GET-форма повторяющихся ключей и роняла переносы — 6×SOURCE_5XX на приёмке); строки без id → transfer_id позиционный |
| batch 45 команд; PHP packed array: при плотных числовых ключах result/result_error приходят LIST (в т.ч. когда упали ВСЕ) | нормализация LIST↔dict в карту по ключам cmd; per-key ошибки не теряются |
| `Stat.get` работает ТОЛЬКО POST {"sessionId":[ids]}; системные (senderid=0) в счётчики не входят | crosscheck с РАЗЛИЧЕНИЕМ направления: under+cap_hit → «хвост не добран»; under без cap_hit → расхождение счётчиков; over → семантика (system), потери нет |
| `user.current` возвращает ID СТРОКОЙ («1») | нормализация int до сравнения с владельцем (фикс D10: ложный скоуп-warning на каждом прогоне); некорректный ID → warning, не крах |
| автологи: ASSOCIATED_ENTITY_ID = id сессии; 0 = «чат не разрешён» (Авито/карточка); TODO отличать по PROVIDER_TYPE_ID | activity-аудит: 0 → chat_unresolved (не «сессия 0»), поимённый missing_text с причиной: chat_unresolved / not_probed / history_error / no_ol_messages_in_window |
| `user.get` без ACTIVE: уволенные выпадают | имена не обязательны, unresolved → ids + WARN |
| полный листинг виден только вебхуку владельца (user 1) | user.current скоуп-проверка; не-владелец → PARTIAL |

## Живая приёмка фиксов 09.11 (07.11, read-only, 113 вызовов, ~2 мин)

`out/live_verify_20261109.json`: status PARTIAL (честно: потолок скана),
0 ошибок, канарейки pagination/window/author PASS.

- сообщения дня: 317/40 чатов — точно совпадает с эталоном замера 07.11
  (недобора больше нет: underfetch 0 сессий — было 45 с усечением до 50;
  587 сессий теперь с полной историей, history ≥ Stat);
- переносы: 184 строки по 115 сессиям за 6 вызовов (форма POST-массив),
  0 ошибок HTTP; в окне 1 факт (29662, 2026-11-07T18:18), 183 вне окна —
  ожидаемо отброшены с подсчётом;
- Stat-канарейка: under 2 сессии (27962: 10/11, 29550: 27/29 — LIMIT не задет,
  расхождение счётчиков), over 587 (системные сообщения; включая живой кейс
  25396: 152/143 при 11 системных — «потери НЕТ»);
- missing_text: 271 поимённо = 266 chat_unresolved (ровно те 266/288 автологов
  с ASSOCIATED_ENTITY_ID=0 из замера 07.11) + 5 no_ol_messages_in_window;
- скоуп: user_id 1 (ID строкой нормализован), ложных предупреждений нет;
- потолок скана: 10 200 строк, оценка хвоста ≈10 153 сессий по плотности id
  (span 20 353 при 10 200 виденных), полнота за потолком НЕ заявляется.

## Измерение: полный скан vs activity-индекс (07–08.11, read-only, 1.8 rps)

| День | Скан: время/вызовы/кандидаты | Activity: время/вызовы/сессии | Общих | Реальная привязка |
|---|---|---|---|---|
| 07.11 | 29,4 с / 51 вызов / 595 | 4,3 с / 8 вызовов / 22 | 17 | 266/288 автологов с ASSOCIATED_ENTITY_ID=0 |
| 08.11 | 29,1 с / 51 вызов / 596 | 4,1 с / 6 вызовов / 16 | 10 | 169/184 с 0 |

Вывод: activity-индекс в 7 раз быстрее и на порядок дешевле по вызовам, но
покрывает лишь ~2–4% сессий дня. Заменить скан он НЕ может: только
вспомогательно (авторство, missing_text, сессии вне окна скана). Полный день
целиком ≈ 2 минуты при 1,8 rps (113 вызовов живой приёмки).

## Документированные пробелы (главное)

1. Потолок offset ~10 200 строк: глубокая история недостижима этим API →
   ceiling → PARTIAL всегда; честная граница — оценка хвоста по плотности id
   + «полнота НЕ заявляется»; добор из activity-аудита (стабы по SESSION_ID)
   — вспомогательный, НЕ полнота.
2. Activity-индекс НЕ полон (266/288 и 169/184 автологов с привязкой 0,
   легаси-id): режим activity всегда PARTIAL; scan — умолчание.
3. Скоуп вебхука: полный листинг только у владельца (user 1); прод-вебхук
   видит подмножество → определяется и понижает статус до PARTIAL.
4. Авито и отправки из карточки лежат ВНЕ истории ОЛ (266/288 автологов дня
   без сессии): поимённый missing_text с причиной; тексты недоступны без
   второго источника — интерфейс для адаптера Авито: `docs/avito_adapter_interface.md`.
5. Stat.get-канарейка сравнивает «за всю сессию» только с числом до фильтра
   окна; недоступность Stat.get → WARN + PARTIAL, не FAILED.
6. 20+ клиентских user id не разрешаются user.get (удалённые/коннектор-юзеры):
   авторы остаются числами + WARN — честно, не блокирует.
7. Battle-режим НЕ включён: по умолчанию offline, сетевых вызовов нет.

## Тесты

`python3 -m pytest tests/ -q` → 127 тестов (92 приёмочных + 35 строгого join).
Матрица покрывает: чужой оператор,
передачи/атрибуция (живые ключи строк + POST-массив), старые открытые сессии,
>200 сообщений (LIMIT + эскалации), cap_hit → поимённый underfetch + FAIL,
count_mismatch ≠ потеря пагинации, 25396-сценарий (152/143, «потери НЕТ»),
LAST_MESSAGE_ID игнорируется, дефолт-страница 50 свежайших, Transfer
неверные формы → SOURCE_4XX, 4xx без ретраев, потолок без провокации 400 +
оценка хвоста + стабы, batch LIST-форма result_error, D10 строковый ID
владельца, missing_text все четыре причины, connectorMid (camelCase/список),
activity+scan чистый, границы окна, ACCESS_DENIED → FAILED, канарейка
фильтров → fallback, 429 → PARTIAL с фактами, кластер с окном и без,
ноль фактов → VERIFIED, дубли, max_facts, JSON без секретов, идемпотентность,
stat crosscheck (совпадение/under+cap/under-семантика/over/недоступен);
плюс exact-join (ниже).

## Строгий exact-join Авито↔Б24 (директива владельца 09.11, mw912x028ygf)

Прямой API Авито может перепутать клиентов → сшивка по тексту/времени
±N минут/телефону/имени КАТЕГОРИЧЕСКИ запрещена (включая «кандидатов»).
`msg/join.py::join_exact` — офлайн-движок строгих ключей:

- чат: (account_user_id, u2i) ↔ entity_id диалога + проверенный индекс
  userCode→аккаунт (fail-closed: не проверен — привязки нет);
- сообщение: CONNECTOR_MID == avito id, 1:1 в обе стороны;
- CRM: entity_data_2 с контролем взаимной однозначности (дубли лидов →
  crm AMBIGUOUS у обоих чатов);
- статусы факта: LINKED / UNLINKED / AMBIGUOUS; AMBIGUOUS не засчитывается
  никому и даёт поимённый warning (статус ≤ PARTIAL);
- сотрудник — только author_id Б24-копии; senderId Авито сотрудником Б24
  не является (employee_from_avito() всегда отказ; числовые совпадения —
  канарейка senderid_numeric_overlap, не атрибуция);
- опции-эвристики (window_minutes, phone, name, strip_signature, …)
  отклоняются SecurityError до любой работы — fuzzy невозможен структурно.

Тесты-ловушки (`tests/test_join_strict.py`, фикстура
`fixtures/dataset_join_strict_20261109.json`): два клиента с одинаковым
текстом в одну минуту — без перекрёстной склейки; подпись «Тестов Т.:» +
окно ±10 мин — исходящие НЕ сшиты; multi-account — чужой аккаунт UNLINKED;
дубли лидов; сообщения прямого API без CRM counterpart — UNLINKED,
сотруднику не считаются; senderId=402 ≠ сотрудник 402; затирание всех
текстов не меняет результат (контент не участвует). Прежнее fuzzy-ожидание
out_matches фикстуры dataset_avito_b24_pair.json отменено (файл immutable,
не правился; входящие in_matches остаются верными).

Координация: `docs/avito_adapter_interface.md` §3/§7 (адаптеру — убрать
fuzzy-ветку и AVITO_FUZZY_WINDOW_MIN), предложение в спеку admin2 —
`~/AiRop/out/spec_amendment_v12_exact_join_20261109.md`.

## Безопасность

Whitelist: 11 read-only методов; batch-команды проходят тот же whitelist;
глаголы-мутаторы запрещены регэкспом всегда; фильтры-«пустышки» Session.list
структурно исключены. Секреты не печатаются и не попадают в ответы (тест).
Вебхук владельца для проб извлекается в память процесса и не пишется в файлы.
