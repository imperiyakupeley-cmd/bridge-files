"""Фабрика фактов v3 core (контракт §4). Внутреннее поле timestamp_dt (datetime)
при сериализации превращается в ISO-строку Europe/Moscow и удаляется.
"""
from __future__ import annotations

from datetime import datetime

from .timeutil import fmt_iso

FACT_TYPES = {"message", "call", "task_todo", "transfer", "stage_change",
              "lead_new", "promise"}


def int_or_none(x) -> int | None:
    """Авторство/ID: Bitrix отдаёт числа строками. Спека §4 — author_id: int|None.
    Нормализуем в одном месте, чтобы роль (author in exclude_users) считалась
    по int-значению, а не по строке (ловушка int-vs-str, §9.5-6/D10)."""
    if x is None or x == "":
        return None
    try:
        return int(x)
    except (TypeError, ValueError):
        return None


def make_fact(*, fact_type: str, source: str, source_entity_id: str,
              timestamp: datetime | None, author_id, author_role: str,
              crm_entity: dict | None = None,
              payload: dict | None = None, evidence: dict | None = None) -> dict:
    if fact_type not in FACT_TYPES:
        raise ValueError(f"fact_type {fact_type!r} вне enum контракта")
    if author_role not in {"WE", "CLIENT", "BOT", "CONNECTOR"}:
        author_role = "CONNECTOR"
    return {
        "fact_type": fact_type,
        "source": source,
        "source_entity_id": source_entity_id,
        "timestamp_dt": timestamp,          # внутреннее; сериализация ниже
        "author_id": int_or_none(author_id),
        "author_role": author_role,
        "crm_entity": crm_entity,
        "payload": payload or {},
        "evidence": evidence or {},
    }


def serialize_facts(facts: list[dict]) -> list[dict]:
    out = []
    for f in facts:
        g = dict(f)
        dt = g.pop("timestamp_dt", None)
        g["timestamp"] = fmt_iso(dt) if dt is not None else None
        out.append(g)
    return out


def mask_phone(phone: str | None) -> str | None:
    """Обезличивание: последние 4 цифры. В факты телефоны идут ТОЛЬКО так."""
    if not phone:
        return None
    digits = "".join(ch for ch in phone if ch.isdigit())
    return "****" + digits[-4:] if len(digits) >= 4 else "****"
