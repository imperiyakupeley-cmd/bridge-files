"""Время v3 core: всё в Europe/Moscow (+03:00), ISO-8601 с офсетом.
Bitrix-фильтры по датам принимают 'dd.mm.yyyy HH:MM:SS' — конвертация сюда.
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone, date as _date

from zoneinfo import ZoneInfo

TZ = ZoneInfo("Europe/Moscow")
OFFSET = timezone(timedelta(hours=3))  # MSK без DST — стабилен круглый год

_ISO = re.compile(r"^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})([+-]\d{2}:\d{2})$")


class TimeError(ValueError):
    pass


def parse_iso(value: str, *, field: str = "time") -> datetime:
    """Строгий парсер 'YYYY-MM-DDTHH:MM:SS±HH:MM'. Без офсета — отказ (fail-closed)."""
    if not isinstance(value, str) or not _ISO.match(value):
        raise TimeError(f"{field}: ожидался ISO-8601 с офсетом, получено {value!r}")
    dt = datetime.fromisoformat(value)
    return dt.astimezone(TZ)


def fmt_iso(dt: datetime) -> str:
    """Канонический вывод: +03:00, без микросекунд."""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=OFFSET)
    dt = dt.astimezone(OFFSET)
    return dt.replace(microsecond=0).isoformat()


def now_msk() -> datetime:
    return datetime.now(TZ)


def day_bounds(day: str) -> tuple[datetime, datetime]:
    """'YYYY-MM-DD' → [T00:00+03:00, +24h)."""
    try:
        d = _date.fromisoformat(day)
    except ValueError as e:
        raise TimeError(f"day: {day!r} не YYYY-MM-DD") from e
    frm = datetime(d.year, d.month, d.day, tzinfo=OFFSET)
    return frm, frm + timedelta(hours=24)


def to_bx_filter_date(dt: datetime) -> str:
    """datetime → 'dd.mm.yyyy HH:MM:SS' для FILTER[>DATE_CREATE] и т.п."""
    return dt.astimezone(OFFSET).strftime("%d.%m.%Y %H:%M:%S")


def parse_bx_date(value: str) -> datetime | None:
    """'dd.mm.yyyy HH:MM:SS' (или ISO — отдельные методы отдают ISO) → datetime|None."""
    if not value or not isinstance(value, str):
        return None
    v = value.strip()
    for pat in ("%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M"):
        try:
            return datetime.strptime(v, pat).replace(tzinfo=OFFSET)
        except ValueError:
            continue
    try:  # ISO из прод-мира (звонки: '2026-11-08T18:09:25+03:00')
        return parse_iso(v, field="bx_date")
    except TimeError:
        return None
