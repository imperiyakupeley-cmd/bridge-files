"""Локальная валидация фильтров Bitrix REST (fail-closed ДО похода в сеть).

Формат ключа: FILTER[<OP><FIELD>], где OP ∈ {'', '=', '%', '>', '<', '>=', '<='},
FIELD — поле из разрешённого набора метода. Поля дат дополнительно проверяются
на формат dd.mm.yyyy HH:MM:SS. Неизвестное поле/оператор → FilterRejected.
"""
from __future__ import annotations

import re

from .errors import FilterRejected

OPS = ("", "=", "%", ">=", "<=", ">", "<")
_KEY_RE = re.compile(r"^FILTER\[([=!%<>]{0,2})([A-Za-z0-9_.]+)\]$")
_BX_DATE = re.compile(r"^\d{2}\.\d{2}\.\d{4}( \d{2}:\d{2}(:\d{2})?)?$")

# Разрешённые поля фильтров по методам (минимально достаточные для v3 core).
FILTER_FIELDS: dict[str, dict[str, set[str]]] = {
    "crm.lead.list": {
        "dates": {"DATE_CREATE", "DATE_MODIFY"},
        "fields": {"ID", "STATUS_ID", "ASSIGNED_BY_ID", "CREATED_BY_ID", "SOURCE_ID",
                   "PHONE", "EMAIL", "TITLE", "OPENED", "HAS_PHONE"},
    },
    "crm.deal.list": {
        "dates": {"DATE_CREATE", "DATE_MODIFY", "CLOSEDATE"},
        "fields": {"ID", "STAGE_ID", "ASSIGNED_BY_ID", "CONTACT_ID", "LEAD_ID", "TITLE"},
    },
    "crm.contact.list": {
        "dates": {"DATE_CREATE", "DATE_MODIFY"},
        "fields": {"ID", "NAME", "LAST_NAME", "ASSIGNED_BY_ID", "PHONE", "EMAIL"},
    },
    "crm.activity.list": {
        "dates": {"CREATED", "LAST_UPDATED", "DEADLINE", "START_TIME", "END_TIME"},
        "fields": {"ID", "TYPE_ID", "PROVIDER_TYPE_ID", "PROVIDER_ID", "RESPONSIBLE_ID",
                   "AUTHOR_ID", "OWNER_ID", "OWNER_TYPE_ID", "COMPLETED", "SUBJECT"},
    },
    "crm.stagehistory.list": {
        "dates": set(),
        "fields": {"STAGE_ID", "CREATED_TIME"},
    },
    "voximplant.statistic.get": {
        "dates": {"CALL_START_DATE"},
        "fields": {"ID", "PORTAL_USER_ID", "PHONE_NUMBER", "CRM_ENTITY_TYPE",
                   "CRM_ENTITY_ID", "CALL_FAILED_CODE"},
    },
    "user.get": {
        "dates": set(),
        "fields": {"ID", "NAME", "LAST_NAME", "ACTIVE", "USER_TYPE", "UF_DEPARTMENT"},
    },
}
_DATE_OPS = {">", "<", ">=", "<="}


def _is_date_like(field: str, method: str) -> bool:
    spec = FILTER_FIELDS.get(method, {})
    return field in spec.get("dates", set()) or field.endswith("_DATE") or \
        field in {"DATE_CREATE", "CREATED", "DEADLINE"}


def validate_filter(method: str, flt: dict) -> dict:
    """Проверить dict-фильтр (до превращения в FILTER[..] ключи). Возвращает копию."""
    spec = FILTER_FIELDS.get(method)
    if spec is None:
        # метод без фильтровальных полей (get/findbycomm) — фильтр запрещён
        if flt:
            raise FilterRejected(f"{method}: фильтры не поддерживаются валидатором")
        return {}
    allowed = spec["dates"] | spec["fields"]
    out = {}
    for key, value in (flt or {}).items():
        raw = key
        op, field = "", raw
        mm = re.match(r"^([=!%<>]{0,2})([A-Za-z0-9_.]+)$", raw)
        if not mm:
            raise FilterRejected(f"{method}: плохой ключ фильтра {raw!r}")
        op, field = mm.group(1), mm.group(2)
        if op not in OPS:
            raise FilterRejected(f"{method}: оператор {op!r} не разрешён (ключ {raw!r})")
        if field not in allowed:
            raise FilterRejected(f"{method}: поле {field!r} не в whitelist фильтра")
        if _is_date_like(field, method):
            if op and op not in _DATE_OPS and op != "=" and op != "":
                raise FilterRejected(f"{method}: оператор {op!r} неприменим к дате {field}")
            if isinstance(value, str) and not _BX_DATE.match(value):
                raise FilterRejected(
                    f"{method}: {field}={value!r} — нужен формат dd.mm.yyyy[ HH:MM[:SS]]")
            if isinstance(value, (list, tuple)):
                for v in value:
                    if isinstance(v, str) and not _BX_DATE.match(v):
                        raise FilterRejected(
                            f"{method}: {field}={v!r} — нужен dd.mm.yyyy[ HH:MM[:SS]]")
        out[key] = value
    return out
