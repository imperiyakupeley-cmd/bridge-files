"""Контракт запроса/ответа v3 core (спека admin2 §3–4).

Запрос: intent, request_id, employee_id, entity, from, to, tz, options.
- leads_day, calls_day: from/to обязательны; employee_id/entity запрещены.
- manager_day: from/to + employee_id обязательны; entity запрещён.
- resolve_employee: employee_id обязателен.
- resolve_client: entity (type,id) ИЛИ phone обязателы; from/to запрещены.
- client_dossier: entity (type,id) обязателен (идентификационный гейт GC-4:
  досье только по точному ID, имя ключом не является); employee_id запрещён;
  from/to опциональны — ограничивают таймлайн-факты окном [from, to).

Любой неизвестный ключ/значение → SchemaError → ответ FAILED c code=SCHEMA
ДО похода в REST (§3).
"""
from __future__ import annotations

import re
import uuid

from .errors import SchemaError
from .timeutil import parse_iso

TZ_NAME = "Europe/Moscow"

KNOWN_INTENTS = {
    "leads_day", "calls_day", "manager_day",
    "resolve_employee", "resolve_client", "client_dossier",
}

_COMMON_KEYS = {"intent", "request_id", "tz", "options"}
_OPTIONS_KEYS = {"include_voice", "max_messages_per_chat", "sources_override"}
_ENTITY_TYPES = {"lead", "deal", "contact"}
_PHONE_RE = re.compile(r"^\+?\d{7,15}$")

_UUID_RE = re.compile(r"^[0-9a-zA-Z._:-]{1,128}$")


def validate_request(req: dict) -> dict:
    if not isinstance(req, dict):
        raise SchemaError("запрос должен быть JSON-объектом")
    unknown = set(req) - _COMMON_KEYS - {"employee_id", "entity", "from", "to", "phone"}
    if unknown:
        raise SchemaError(f"неизвестные ключи запроса: {sorted(unknown)}")

    intent = req.get("intent")
    if intent not in KNOWN_INTENTS:
        raise SchemaError(f"неизвестный intent: {intent!r}")

    rid = req.get("request_id")
    if not rid or not isinstance(rid, str) or not _UUID_RE.match(rid):
        raise SchemaError("request_id обязателен (uuid4, до 128 символов)")

    tz = req.get("tz", TZ_NAME)
    if tz != TZ_NAME:
        raise SchemaError(f"tz только {TZ_NAME}, получено {tz!r}")

    options = req.get("options", {})
    if not isinstance(options, dict):
        raise SchemaError("options должен быть объектом")
    bad = set(options) - _OPTIONS_KEYS
    if bad:
        raise SchemaError(f"неизвестные опции: {sorted(bad)}")

    frm = to = None
    if "from" in req or "to" in req:
        if "from" not in req or "to" not in req:
            raise SchemaError("from и to идут парой")
        try:
            frm = parse_iso(req["from"], field="from")
            to = parse_iso(req["to"], field="to")
        except ValueError as e:  # TimeError — наружу отдаём только SCHEMA
            raise SchemaError(str(e)) from e
        if frm >= to:
            raise SchemaError("from должен быть раньше to (полуинтервал [from, to))")

    employee_id = req.get("employee_id")
    if employee_id is not None and not isinstance(employee_id, int):
        raise SchemaError("employee_id должен быть целым")

    entity = req.get("entity")
    if entity is not None:
        if not isinstance(entity, dict) or set(entity) != {"type", "id"} \
                or entity["type"] not in _ENTITY_TYPES or not isinstance(entity["id"], int):
            raise SchemaError("entity: {type: lead|deal|contact, id: int}")

    phone = req.get("phone")
    if phone is not None and (not isinstance(phone, str) or not _PHONE_RE.match(phone)):
        raise SchemaError("phone: строка 7–15 цифр, опционально +")

    # Правила обязательности по интентам (§3)
    if intent in ("leads_day", "calls_day"):
        if frm is None:
            raise SchemaError(f"{intent}: from/to обязательны")
        if employee_id is not None or entity is not None:
            raise SchemaError(f"{intent}: employee_id и entity запрещены (день общий)")
    elif intent == "manager_day":
        if frm is None:
            raise SchemaError("manager_day: from/to обязательны")
        if employee_id is None:
            raise SchemaError("manager_day: employee_id обязателен")
        if entity is not None:
            raise SchemaError("manager_day: entity запрещён")
    elif intent == "resolve_employee":
        if employee_id is None:
            raise SchemaError("resolve_employee: employee_id обязателен")
        if frm is not None or entity is not None:
            raise SchemaError("resolve_employee: окно и entity запрещены")
    elif intent == "resolve_client":
        if entity is None and phone is None:
            raise SchemaError("resolve_client: нужен entity или phone")
        if frm is not None:
            raise SchemaError("resolve_client: окно запрещено")
    elif intent == "client_dossier":
        if entity is None:
            raise SchemaError("client_dossier: entity обязателен")
        if employee_id is not None:
            raise SchemaError("client_dossier: employee_id запрещён")

    return {
        "intent": intent, "request_id": rid, "from": frm, "to": to,
        "employee_id": employee_id, "entity": entity, "phone": phone,
        "options": options,
    }


def new_request_id() -> str:
    return str(uuid.uuid4())


# ------------------------------------------------------------------- response

def make_response(validated: dict, *, facts: list, coverage: dict,
                  warnings: list[str], errors: list[dict], detectors: dict,
                  as_of) -> dict:
    """Сборка ответа со статусами (§4): VERIFIED | PARTIAL | FAILED.

    Правила честности: VERIFIED никогда не выдаётся при непустых errors/warnings
    или FAIL канарейке; ноль фактов при живых источниках = VERIFIED; ноль фактов
    при ошибке источника = FAILED.
    """
    schema_fail = any(e.get("code") == "SCHEMA" for e in errors)
    detector_fail = any(detectors.get(k) == "FAIL" for k in
                        ("filter_canary", "pagination_canary", "window_canary"))

    if schema_fail:
        status = "FAILED"
    elif not facts and errors:
        status = "FAILED"
    elif errors or warnings or detector_fail:
        status = "PARTIAL"
    else:
        status = "VERIFIED"

    return {
        "request_id": validated["request_id"],
        "intent": validated["intent"],
        "status": status,
        "as_of": as_of,
        "facts": facts,
        "coverage": coverage,
        "warnings": warnings,
        "errors": errors,
        "detectors": detectors,
    }


def failed_response(req: dict | None, error: dict, *, as_of: str) -> dict:
    """Схемный отказ: валидный JSON с request_id (если удалось прочитать)."""
    return {
        "request_id": (req or {}).get("request_id", ""),
        "intent": (req or {}).get("intent", ""),
        "status": "FAILED",
        "as_of": as_of,
        "facts": [],
        "coverage": {},
        "warnings": [],
        "errors": [error],
        "detectors": {},
    }
