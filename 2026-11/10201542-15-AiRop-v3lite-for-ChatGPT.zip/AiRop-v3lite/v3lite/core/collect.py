"""Точка входа v3 Lite core: stdin JSON-запрос → stdout JSON-ответ.

Контракты §3–4 спеки admin2. Только чтение: весь REST через BitrixClient
(whitelist, ретраи, лимиты, пагинация). Кэш-идемпотентность: v3_cache.db
(~/AiRop/v3lite/), повтор того же request_id/запроса возвращает сохранённый
ответ, если в нём не было транзиентных ошибок (SOURCE_429/5XX/NET).

Использование:
  echo '{"intent":"leads_day",...}' | python3 collect.py
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
import time

from .client import BitrixClient
from .config import load_config
from .contract import failed_response, validate_request
from .errors import CoreError, SchemaError
from .sources import activities, calls, clients, dossier, employees, leads
from .timeutil import fmt_iso, now_msk

_TRANSIENT = {"SOURCE_429", "SOURCE_5XX", "SOURCE_NET", "SOURCE_ERROR"}
_CACHE_DISABLED = os.environ.get("V3_CACHE") == "0"
# Версия ядра в ключе кэша: фикс логики сбора инвалидирует старые ответы.
# 0.2.1 (09.11): боевой batch-конверт (LIST/dict), fail-closed первых касаний
# (инцидент integ-ld-1 08.11: VERIFIED при потерянных касаниях), кэш старых
# leads_day-ответов без first-touch больше не используется.
# 0.3.0 (09.11, приёмка admin2): GC-1 задачи бота TASKS_TASK/CRM_WEBDAV_TASK
# → боту (не менеджеру); GC-8 owner-dangle проверка crm.*.get при эмите
# (warning + PARTIAL, не VERIFIED); F3 client_dossier реализован в core
# (идентификация/кластер/таймлайн/телефония/этапы); author_id всегда int|None.
CORE_VERSION = "0.3.0"


def canonical_hash(req: dict) -> str:
    blob = json.dumps(req, sort_keys=True, ensure_ascii=False) + f"|v{CORE_VERSION}"
    return hashlib.sha256(blob.encode()).hexdigest()


class ResponseCache:
    """Идемпотентность по request_id (§9.5 строка 3)."""

    def __init__(self, path: str):
        self.path = path
        self.enabled = not _CACHE_DISABLED
        if self.enabled:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with sqlite3.connect(path) as con:
                con.execute("CREATE TABLE IF NOT EXISTS responses ("
                            "request_id TEXT, req_hash TEXT, response TEXT, "
                            "created_at TEXT, PRIMARY KEY (request_id, req_hash))")

    def get(self, request_id: str, req_hash: str) -> dict | None:
        if not self.enabled:
            return None
        try:
            with sqlite3.connect(self.path) as con:
                row = con.execute(
                    "SELECT response FROM responses WHERE request_id=? AND req_hash=?",
                    (request_id, req_hash)).fetchone()
            return json.loads(row[0]) if row else None
        except (sqlite3.Error, json.JSONDecodeError):
            return None

    def put(self, request_id: str, req_hash: str, response: dict) -> None:
        codes = {e.get("code") for e in response.get("errors", [])}
        if codes & _TRANSIENT:
            return  # транзиентный PARTIAL не кэшируем — повтор пойдёт в REST
        try:
            with sqlite3.connect(self.path) as con:
                con.execute("INSERT OR REPLACE INTO responses VALUES (?,?,?,?)",
                            (request_id, req_hash, json.dumps(response,
                                                              ensure_ascii=False),
                             fmt_iso(now_msk())))
        except sqlite3.Error:
            pass


def dispatch(client, cfg, v: dict) -> dict:
    intent = v["intent"]
    eu = cfg.exclude_users
    if intent == "leads_day":
        return leads.collect(client, v, exclude_users=eu)
    if intent == "calls_day":
        return calls.collect(client, v, exclude_users=eu,
                             calls_db_path=cfg.calls_db)
    if intent == "manager_day":
        return activities.collect(client, v, exclude_users=eu)
    if intent == "resolve_employee":
        return employees.collect(client, v, exclude_users=eu)
    if intent == "resolve_client":
        return clients.collect(client, v, exclude_users=eu)
    if intent == "client_dossier":
        # F3: CRM-часть досье в core (идентификация GC-4, кластер GC-2/5,
        # таймлайн/телефония/этапы); тексты сообщений — модуль messages (§10)
        return dossier.collect(client, v, exclude_users=eu,
                               calls_db_path=cfg.calls_db)
    raise SchemaError(f"неизвестный intent: {intent}")


def run_request(raw: str | dict, *, cfg=None, transport=None,
                use_cache: bool = True) -> dict:
    """Полный цикл: парсинг → валидация → кэш → источники → ответ."""
    t0 = time.monotonic()
    try:
        req = json.loads(raw) if isinstance(raw, str) else raw
    except json.JSONDecodeError as e:
        return failed_response(None, {"code": "SCHEMA", "source": "",
                                      "detail": f"невалидный JSON: {e}"},
                               as_of=fmt_iso(now_msk()))
    try:
        v = validate_request(req)
    except SchemaError as e:
        return failed_response(req, e.to_json(), as_of=fmt_iso(now_msk()))

    cfg = cfg or load_config()
    cache = ResponseCache(cfg.cache_db) if use_cache else None
    req_hash = canonical_hash(req)
    if cache:
        cached = cache.get(v["request_id"], req_hash)
        if cached is not None:
            cached["meta"] = {"cache": "hit", "duration_ms": 0}
            return cached

    client = BitrixClient(cfg, transport=transport)
    try:
        resp = dispatch(client, cfg, v)
    except CoreError as e:
        resp = failed_response(req, e.to_json(), as_of=fmt_iso(now_msk()))
    except Exception as e:  # noqa: BLE001 — защита контракта: всегда валидный JSON
        resp = failed_response(req, {"code": "SOURCE_ERROR", "source": "core",
                                     "detail": f"{type(e).__name__}: {e}"},
                               as_of=fmt_iso(now_msk()))
    resp["meta"] = {"cache": "miss", "duration_ms": int((time.monotonic() - t0) * 1000),
                    "rest_calls": client.calls_made}
    if cache:
        cache.put(v["request_id"], req_hash, resp)
    return resp


def main() -> int:
    raw = sys.stdin.read()
    resp = run_request(raw)
    json.dump(resp, sys.stdout, ensure_ascii=False, indent=1)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
