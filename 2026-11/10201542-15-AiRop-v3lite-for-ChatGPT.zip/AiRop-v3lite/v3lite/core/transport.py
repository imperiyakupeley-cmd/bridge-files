"""Транспорт v3 core: HTTP-слой, отделён от логики — в тестах подменяется.

GET-only: любые запросы к Bitrix идут как GET (все методы whitelist — чтение).
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request

from .config import Config
from .errors import NetworkError

RETRYABLE_HTTP = {429, 500, 502, 503, 504}
RETRYABLE_BX_CODES = {"QUERY_LIMIT_EXCEEDED", "INTERNAL_SERVER_ERROR"}


class HttpResult:
    __slots__ = ("status", "headers", "body")

    def __init__(self, status: int, headers: dict, body: bytes):
        self.status = status
        self.headers = headers
        self.body = body

    def json(self):
        return json.loads(self.body.decode("utf-8"))


class Transport:
    """Синхронный GET-транспорт. Фейковый для тестов подменяет этот класс."""

    name = "urllib"

    def get(self, url: str, timeout: float) -> HttpResult:
        req = urllib.request.Request(url, method="GET", headers={"User-Agent": "airop-v3lite/0.1"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return HttpResult(r.status, dict(r.headers), r.read())
        except urllib.error.HTTPError as e:
            return HttpResult(e.code, dict(e.headers or {}), e.read())
        except Exception as e:  # сеть/DNS/таймаут
            raise NetworkError(f"{type(e).__name__}: {e}") from e


def build_url(webhook: str, method: str, params: dict | None) -> str:
    url = f"{webhook.rstrip('/')}/{method}.json"
    if params:
        clean = {k: v for k, v in params.items() if v is not None}
        if clean:
            url += "?" + urllib.parse.urlencode(clean, doseq=True)
    return url
