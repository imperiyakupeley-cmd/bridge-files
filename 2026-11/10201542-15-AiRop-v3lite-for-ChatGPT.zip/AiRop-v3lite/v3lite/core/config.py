"""Конфиг v3 Lite core. Изолирован от боевого ~/AiRop: ничего не импортирует
из прод-кода, не создаёт каталогов, не пишет в calls.db.

Вебхук читается из ~/AiRop/.env (ключ BX_WEBHOOK — прод-вебхук Анны, read-only),
вебхук владельца ОЛ — ТОЛЬКО из переменной окружения V3_OL_WEBHOOK
(спека admin2 §10: не хардкодить, не коммитить).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

# Прод-каталог читается только как файл .env (read-only), никакого импорта.
_PROD_ENV = os.path.expanduser("~/AiRop/.env")

DEFAULT_TZ = "Europe/Moscow"

# Лимиты/политика (спека §6, §7.6):
RATE_RPS = 1.8                 #Bitrix ≈ 2 req/s; держим чуть ниже
RATE_BURST = 3                 # короткий burst для batch-обёрток
TIMEOUT_S = 15.0               # как T_BITRIX прода
RETRIES_MAX = 3                # максимум ретраев после первой попытки
BACKOFF_BASE_S = 1.0           # экспоненциальный backoff: base * 2**n + jitter
BACKOFF_CAP_S = 30.0           # уважаем Retry-After, но не дольше капы
PAGE_SIZE_DEFAULT = 50         # сервер отдаёт по 50
PAGE_LIMIT_DEFAULT = 220       # 220*50 = 11 000 строк; offset-окно Bitrix ≈ 10 200
OFFSET_WINDOW_HARD = 10_200    # дальше сервер не отдаёт (спека §5 OL/§6) — честный truncated
BATCH_MAX_CMDS = 45            # < 50 команд на batch
CANARY_MAX_LAG_S = 6 * 3600    # calls.db свежесть для calls_day

CACHE_DB = os.path.expanduser("~/AiRop/v3lite/v3_cache.db")
CALLS_DB_RO = os.path.expanduser("~/AiRop/calls.db")   # ТОЛЬКО READ-ONLY (mode=ro)


def _read_env_file(path: str) -> dict:
    env = {}
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env[k.strip()] = v.strip()
    except FileNotFoundError:
        pass
    return env


@dataclass
class Config:
    """Все настройки core. Секрета в логах/ответах не разглашаем."""
    webhook: str = ""                 # прод-вебхук (crm.*, user.get, activity)
    ol_webhook: str = ""              # вебхук владельца для ОЛ (env only), в core НЕ используется
    exclude_users: set = field(default_factory=set)   # боты флота (Анна 17316, Михаил 15780)
    rate_rps: float = RATE_RPS
    timeout_s: float = TIMEOUT_S
    retries_max: int = RETRIES_MAX
    page_limit: int = PAGE_LIMIT_DEFAULT
    cache_db: str = CACHE_DB
    calls_db: str = CALLS_DB_RO
    offline: bool = False             # True → транспорт запрещает реальные запросы

    @property
    def portal_host(self) -> str:
        return self.webhook.split("/rest/")[0] if "/rest/" in self.webhook else ""


def load_config(env: dict | None = None, environ: dict | None = None) -> Config:
    """env: содержимое .env (для тестов); environ: os.environ-подобный словарь."""
    e = dict(_read_env_file(_PROD_ENV) if env is None else env)
    o = dict(os.environ if environ is None else environ)
    return Config(
        webhook=o.get("V3_WEBHOOK") or e.get("BX_WEBHOOK", ""),
        ol_webhook=o.get("V3_OL_WEBHOOK", ""),
        exclude_users={int(u.strip()) for u in
                       (o.get("V3_EXCLUDE_USERS") or e.get("EXCLUDE_USERS", "")).split(",")
                       if u.strip().isdigit()},
        # стендовая подмена копии calls.db (обезличенной); прод-путь тот же:
        # по умолчанию — READ-ONLY прод-файл, env отсутствует → без изменений
        calls_db=o.get("V3_CALLS_DB") or CALLS_DB_RO,
    )
