"""BitrixClient — read-only адаптер v3 core.

Гарантии (спека admin2 §4–7):
- whitelist методов/параметров (whitelist.py) + локальная валидация фильтров
  (filters.py) — оба ДО любого сетевого вызова;
- rate limit (токен-бакет ~2 rps с burst под batch);
- ретраи с экспоненциальным backoff на 429/5xx/сетевых ошибках/QUERY_LIMIT_EXCEEDED,
  максимум retries_max, уважение Retry-After;
- полная пагинация start/next/total с контролем усечения (page_limit, offset-окно
  ≈10 200) и дедупом строк по ID;
- batch только из whitelist-методов, ≤ BATCH_MAX_CMDS команд;
- coverage-счётчики на каждый метод (rows/pages/duplicates/truncated);
- canary-хуки: filter_canary живёт в canaries.py, но вызывается через клиент,
  чтобы ретраи/лимиты применялись единообразно.
"""
from __future__ import annotations

import random
import time
from dataclasses import dataclass, field

from . import whitelist
from .config import Config
from .errors import (AccessDenied, NetworkError, RateLimitError, SecurityError,
                     ServerError, SourceError)
from .filters import validate_filter
from .transport import RETRYABLE_BX_CODES, RETRYABLE_HTTP, Transport, build_url


@dataclass
class PageStats:
    rows: int = 0
    pages: int = 0
    total: int | None = None
    duplicates_dropped: int = 0
    truncated: bool = False
    stop_reason: str = "complete"   # complete | page_limit | offset_window | no_next

    def to_json(self) -> dict:
        return {k: getattr(self, k) for k in
                ("rows", "pages", "total", "duplicates_dropped", "truncated", "stop_reason")}


@dataclass
class _RateBucket:
    rps: float
    burst: int
    tokens: float = field(default=0.0)
    last: float = field(default_factory=time.monotonic)

    def __post_init__(self):
        self.tokens = float(self.burst)  # стартовый burst — без сна на первых вызовах

    def acquire(self, cost: int = 1, *, sleep=None) -> None:
        """Тарификация по единицам: cost>N добирается поэлементно, иначе при
        burst < cost бакет никогда не наполнился бы (инфинитный сон)."""
        sl = sleep or time.sleep
        for _ in range(int(cost)):
            while True:
                now = time.monotonic()
                self.tokens = min(self.burst,
                                  self.tokens + (now - self.last) * self.rps)
                self.last = now
                if self.tokens >= 1:
                    self.tokens -= 1
                    break
                sl((1 - self.tokens) / self.rps)


class BitrixClient:
    def __init__(self, cfg: Config, transport: Transport | None = None,
                 sleep=time.sleep, monotonic=time.monotonic):
        self.cfg = cfg
        self.transport = transport or Transport()
        self._bucket = _RateBucket(rps=cfg.rate_rps, burst=int(cfg.rate_rps * 2) + 1)
        self._sleep = sleep          # инъекция для тестов
        self._monotonic = monotonic
        self.coverage: dict[str, dict] = {}
        self.calls_made = 0

    # ------------------------------------------------------------------ core
    def _backoff(self, attempt: int, retry_after: float | None) -> float:
        if retry_after is not None:
            return min(max(retry_after, 0.5), 30.0)
        return min(1.0 * (2 ** attempt) + random.uniform(0, 0.3), 30.0)

    def call(self, method: str, params: dict | None = None) -> dict:
        """Одиночный GET-вызов с ретраями. Возвращает разобранный JSON (dict)."""
        params = whitelist.check_params(method, params or {})
        flt = {k: v for k, v in params.items() if k.startswith("FILTER[")}
        if flt:
            validate_filter(method,
                            {k[len("FILTER["):-1]: v for k, v in flt.items()})
        if self.cfg.offline:
            raise SecurityError("клиент в offline-режиме: сетевые вызовы запрещены")
        url = build_url(self.cfg.webhook, method, params)
        last_exc: Exception | None = None
        for attempt in range(self.cfg.retries_max + 1):  # 1 попытка + ретраи
            self._bucket.acquire(cost=1)
            self.calls_made += 1
            try:
                res = self.transport.get(url, self.cfg.timeout_s)
            except NetworkError as e:
                last_exc = e
                if attempt < self.cfg.retries_max:
                    self._sleep(self._backoff(attempt, None))
                    continue
                raise
            if res.status == 200:
                data = res.json()
                err = data.get("error")
                if err in RETRYABLE_BX_CODES:
                    last_exc = RateLimitError(f"{method}: {err}", source=method)
                    if attempt < self.cfg.retries_max:
                        self._sleep(self._backoff(
                            attempt, _retry_after(res.headers)))
                        continue
                    raise last_exc
                if err == "ACCESS_DENIED" or (err and "access" in str(err).lower()
                                              and res.status in (400, 403)):
                    raise AccessDenied(f"{method}: {err} "
                                       f"{data.get('error_description', '')}", source=method)
                if err:
                    raise SourceError(f"{method}: {err} "
                                      f"{data.get('error_description', '')}", source=method)
                return data
            if res.status in RETRYABLE_HTTP:
                last_exc = (RateLimitError if res.status == 429 else ServerError)(
                    f"{method}: HTTP {res.status}", source=method)
                if attempt < self.cfg.retries_max:
                    self._sleep(self._backoff(attempt, _retry_after(res.headers)))
                    continue
                raise last_exc
            if res.status in (400, 403, 404):
                try:
                    data = res.json()
                except Exception:
                    data = {}
                if data.get("error") == "ACCESS_DENIED" or res.status == 403:
                    raise AccessDenied(f"{method}: HTTP {res.status} "
                                       f"{data.get('error', '')}", source=method)
                raise SourceError(f"{method}: HTTP {res.status} "
                                  f"{data.get('error', '')}", source=method)
            raise ServerError(f"{method}: неожиданный HTTP {res.status}", source=method)
        raise last_exc or SourceError(f"{method}: исчерпаны попытки", source=method)

    # ------------------------------------------------------------- pagination
    def call_all(self, method: str, params: dict | None = None, *,
                 page_limit: int | None = None, id_field: str = "ID",
                 order_first: bool = True) -> tuple[list[dict], PageStats]:
        """Полный постраничный обход: start/next/total, дедуп, контроль усечения.

        order_first=True ставит order[ID]=ASC, если порядок не задан, — курсорная
        стабильность выборки внутри окна (спека: контроль стабильности окна).
        """
        base = whitelist.check_params(method, params or {})
        if order_first and "order[ID]" not in base and method != "user.get":
            base = {"order[ID]": "ASC", **base}
        page_limit = page_limit or self.cfg.page_limit
        rows: list[dict] = []
        seen: set = set()
        stats = PageStats()
        start = 0
        while True:
            page_params = {**base, "start": start}
            data = self.call(method, page_params)
            result = data.get("result")
            if not isinstance(result, list):
                # методы-геты (не листинги) сюда не должны попадать
                raise SourceError(f"{method}: ожидался list-результат", source=method)
            stats.pages += 1
            stats.total = data.get("total", stats.total)
            new_rows = 0
            for row in result:
                rid = row.get(id_field) if isinstance(row, dict) else row
                key = (method, rid)
                if key in seen:
                    stats.duplicates_dropped += 1
                    continue
                seen.add(key)
                rows.append(row)
                new_rows += 1
            nxt = data.get("next")
            if nxt is None:
                stats.stop_reason = "complete"
                break
            if new_rows == 0:
                # сервер гоняет по кругу (нестабильное окно) — выходим честно
                stats.stop_reason = "unstable_window"
                stats.truncated = True
                break
            nxt_int = int(nxt)
            if nxt_int + len(result) >= 10_200:
                stats.stop_reason = "offset_window"
                stats.truncated = True
                break
            if stats.pages >= page_limit:
                stats.stop_reason = "page_limit"
                stats.truncated = True
                break
            start = nxt_int
        stats.rows = len(rows)
        # канарейка пагинации: заявили total — отдали столько же?
        if stats.total is not None and not stats.truncated and stats.rows < stats.total:
            stats.truncated = True
            stats.stop_reason = "total_mismatch"
        self._note_coverage(method, stats)
        return rows, stats

    # ------------------------------------------------------------------ batch
    def batch(self, commands: list[tuple[str, dict]], *, label: str = "") -> list:
        """batch из whitelist-вызовов. Возвращает список ответов по порядку.

        Ошибки отдельных cmd НЕ валят весь batch: элемент = {"error": ...}.
        Каждая команда тарифицируется в rate limit.
        """
        if not commands:
            return []
        out: list = []
        for chunk_start in range(0, len(commands), 45):
            chunk = commands[chunk_start:chunk_start + 45]
            params: dict = {}
            for i, (m, p) in enumerate(chunk):
                whitelist.check_method(m)
                clean = whitelist.check_params(m, p or {})
                flt = {k: v for k, v in clean.items() if k.startswith("FILTER[")}
                if flt:
                    validate_filter(m, {k[len("FILTER["):-1]: v for k, v in flt.items()})
                # GET-style кодирование cmd: ключ=значение-строка
                qs = "&".join(f"{k}={v}" for k, v in clean.items())
                params[f"cmd[{i}]"] = f"{m}?{qs}" if qs else m
            self._bucket.acquire(cost=len(chunk))
            self.calls_made += 1
            data = self._batch_raw(params)
            by_idx, err_by_idx, anomalies = _parse_batch_envelope(data)
            for i in range(len(chunk)):
                if i in err_by_idx:
                    out.append({"error": _bx_error_code(err_by_idx[i]),
                                "error_description": _bx_error_desc(err_by_idx[i])})
                elif i in by_idx:
                    out.append(by_idx[i])
                else:
                    # сервер не вернул ни результат, ни ошибку для команды —
                    # аномалия; фиксируется в coverage[missing] и НЕ должна
                    # давать VERIFIED выше по стеку (fail-closed, инцидент 08.11)
                    out.append({"error": "MISSING_IN_BATCH"})
            missing_n = sum(1 for i in range(len(chunk))
                            if i not in by_idx and i not in err_by_idx)
            ok_n = len(chunk) - missing_n \
                - sum(1 for i in range(len(chunk)) if i in err_by_idx)
            cov_key = f"batch:{label or commands[0][0]}"
            cur = self.coverage.get(cov_key, {})
            cur["cmds"] = cur.get("cmds", 0) + len(chunk)
            cur["ok"] = cur.get("ok", 0) + ok_n
            cur["cmd_errors"] = cur.get("cmd_errors", 0) + (len(chunk) - ok_n - missing_n)
            cur["missing"] = cur.get("missing", 0) + missing_n
            if anomalies:
                cur["envelope_anomalies"] = \
                    (cur.get("envelope_anomalies", []) + anomalies)[:10]
            self.coverage[cov_key] = cur
        return out

    def _batch_raw(self, params: dict) -> dict:
        """Один batch-запрос с теми же ретраями, что call()."""
        url = build_url(self.cfg.webhook, "batch", params)
        last_exc = None
        for attempt in range(self.cfg.retries_max + 1):
            try:
                res = self.transport.get(url, self.cfg.timeout_s)
            except NetworkError as e:
                last_exc = e
                if attempt < self.cfg.retries_max:
                    self._sleep(self._backoff(attempt, None))
                    continue
                raise
            if res.status == 200:
                data = res.json()
                if data.get("error") in RETRYABLE_BX_CODES:
                    last_exc = RateLimitError(f"batch: {data['error']}")
                    if attempt < self.cfg.retries_max:
                        self._sleep(self._backoff(attempt, _retry_after(res.headers)))
                        continue
                    raise last_exc
                if data.get("error"):
                    raise SourceError(f"batch: {data['error']}", source="batch")
                return data
            if res.status in RETRYABLE_HTTP:
                last_exc = (RateLimitError if res.status == 429 else ServerError)(
                    f"batch: HTTP {res.status}", source="batch")
                if attempt < self.cfg.retries_max:
                    self._sleep(self._backoff(attempt, _retry_after(res.headers)))
                    continue
                raise last_exc
            raise SourceError(f"batch: HTTP {res.status}", source="batch")
        raise last_exc or SourceError("batch: исчерпаны попытки", source="batch")

    # -------------------------------------------------------------- coverage
    def _note_coverage(self, method: str, stats: PageStats) -> None:
        cur = self.coverage.get(method, {})
        cur.update(stats.to_json())
        self.coverage[method] = cur


def _retry_after(headers: dict) -> float | None:
    for k, v in (headers or {}).items():
        if k.lower() == "retry-after":
            try:
                return float(v)
            except (TypeError, ValueError):
                return None
    return None


def _int_key(k) -> int:
    try:
        return int(k)
    except (TypeError, ValueError):
        return 10 ** 9


def _parse_batch_envelope(data: dict) -> tuple[dict, dict, list]:
    """Разбор batch-конверта → ({idx: результат}, {idx: ошибка}, аномалии).

    Форма БОЕВОГО портала [ФАКТ: live-проба 09.11.2026, спека §5]:
      data.result = {
        "result":        LIST — когда все cmd-ключи плотные 0..n-1 (PHP packed);
                         dict {"0":.., "2":..} — когда часть команд упала в
                         result_error (разреженный PHP assoc);
                         [] — когда упали ВСЕ команды;
        "result_error":  [] — ошибок нет; dict {"1": {error..}} — разрежённо;
                         LIST — когда упали все команды;
        "result_total"/"result_next"/"result_time": для разбора не нужны.}
    Защитный путь: плоский конверт без внутренней обёртки (data.result = {cmd: ..}).
    Инцидент 08.11 (integ-ld-1): LIST-форма не разбиралась → MISSING_IN_BATCH
    на все команды → leads_day молча терял первые касания при статусе VERIFIED.
    """
    anomalies: list[str] = []
    payload = data.get("result")
    if isinstance(payload, dict) and any(
            k in payload for k in ("result", "result_error", "result_total")):
        res = payload.get("result")
        errors = payload.get("result_error")
    elif isinstance(payload, list) or (
            isinstance(payload, dict) and payload
            and all(isinstance(k, str) and k.isdigit() for k in payload)):
        # плоский/легаси конверт: data.result = {"0": ..} или [..] без обёртки
        res, errors = payload, data.get("result_error")
        anomalies.append("flat_envelope")
    else:
        res = errors = None
    if res is None:
        res = []
        anomalies.append("no_result_key")
    if errors is None:
        errors = []
    return (_index_cmd_map(res, "result", anomalies),
            _index_cmd_map(errors, "result_error", anomalies),
            anomalies)


def _index_cmd_map(x, what: str, anomalies: list) -> dict:
    """LIST ↔ dict с числовыми ключами → {int(cmd_idx): значение}."""
    if isinstance(x, list):
        return dict(enumerate(x))
    if isinstance(x, dict):
        out = {}
        for k, v in x.items():
            try:
                out[int(k)] = v
            except (TypeError, ValueError):
                anomalies.append(f"{what}: нечисловой cmd-ключ {k!r}")
        return out
    anomalies.append(f"{what}: неожиданный тип {type(x).__name__}")
    return {}


def _bx_error_code(err) -> str:
    if isinstance(err, dict):
        return str(err.get("error") or err.get("error_description") or "ERROR")
    return str(err)


def _bx_error_desc(err) -> str:
    if isinstance(err, dict):
        return str(err.get("error_description") or "")[:300]
    return ""
