"""Канарейки v3 core (спека admin2 §7). Все детекторы обязаны присутствовать
в ответе (детерминированные значения PASS/FAIL/WARN).

1. filter_canary  — парный запрос с заведомо пустым пересечением (дата > 2099):
   ответ ≠ 0 строк → сервер игнорирует фильтры → FAIL, факты источника
   отбрасываются, статус не выше PARTIAL.
2. pagination_canary — контроль «страницы×50 ≥ total», усечение, зацикливание.
3. window_canary — каждый факт ∈ [from, to); выход за границу — отброс факта.
4. duplicate_guard — дедуп фактов по (source, source_entity_id).
5. author_crosscheck — в источниках (activity vs диалог/voximpl).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from .timeutil import fmt_iso


@dataclass
class Detectors:
    filter_canary: dict = field(default_factory=dict)      # source -> PASS/FAIL
    pagination_canary: str = "PASS"
    window_canary: str = "PASS"
    author_crosscheck: str = "PASS"
    duplicate_guard_dropped: int = 0

    def to_json(self) -> dict:
        fc = self.filter_canary or {}
        agg = "PASS" if all(v == "PASS" for v in fc.values()) else "FAIL"
        return {
            "filter_canary": agg,
            "filter_canary_detail": {k: v for k, v in fc.items()},
            "pagination_canary": self.pagination_canary,
            "window_canary": self.window_canary,
            "author_crosscheck": self.author_crosscheck,
            "duplicate_guard_dropped": self.duplicate_guard_dropped,
        }


def window_check(facts: list[dict], frm: datetime, to: datetime,
                 *, warnings: list[str]) -> tuple[list[dict], str]:
    """Отбрасывает факты вне [from, to). Возвращает (факты, статус канарейки)."""
    kept, dropped = [], 0
    for f in facts:
        ts = f.get("timestamp_dt")
        if ts is None:
            kept.append(f)
            continue
        if frm <= ts < to:
            kept.append(f)
        else:
            dropped += 1
            warnings.append(
                f"window_canary: факт {f.get('fact_type')}:{f.get('source_entity_id')} "
                f"вне окна [{fmt_iso(frm)}, {fmt_iso(to)}), отброшен")
    status = "PASS" if dropped == 0 else "FAIL"
    return kept, status


def dedup_facts(facts: list[dict], *, counters: dict) -> list[dict]:
    """Дедуп по (source, source_entity_id). Счётчики считаются ПОСЛЕ дедупа (§7.5)."""
    seen: set = set()
    out = []
    dropped = 0
    for f in facts:
        key = (f.get("source"), f.get("source_entity_id"))
        if key in seen:
            dropped += 1
            continue
        seen.add(key)
        out.append(f)
    counters["duplicate_guard_dropped"] = dropped
    return out


def pagination_from_stats(all_stats: dict[str, dict], *, warnings: list[str]) -> str:
    """Агрегация stop_reason всех выборок: любое усечение → FAIL + пояснение."""
    bad = {}
    for m, s in all_stats.items():
        if s.get("non_paged"):
            continue
        if s.get("truncated") or s.get("stop_reason") != "complete":
            bad[m] = s
    if bad:
        for m, s in bad.items():
            warnings.append(f"pagination_canary: {m} усечён ({s.get('stop_reason')}, "
                            f"rows={s.get('rows')}, total={s.get('total')})")
        return "FAIL"
    return "PASS"


def filter_canary(client, method: str, probe_filter: dict) -> str:
    """Канарейка фильтра: probe_filter должен дать 0 строк.

    Возвращает PASS | FAIL | ERROR:
    - PASS — 0 строк, фильтры работают;
    - FAIL — сервер вернул строки на заведомо пустом пересечении (фильтры
      игнорируются) → факты источника отбрасываются, fail-closed;
    - ERROR — сам источник не ответил (429/5xx/сеть): это транзиентное
      состояние, НЕ приговор фильтрам (не кэшировать ответ).
    """
    from .errors import CoreError
    try:
        params = {f"FILTER[{k}]": v for k, v in probe_filter.items()}
        data = client.call(method, {**params, "start": 0})
    except CoreError:
        return "ERROR"
    rows = data.get("result") or []
    total = data.get("total", len(rows))
    return "PASS" if total == 0 and not rows else "FAIL"
