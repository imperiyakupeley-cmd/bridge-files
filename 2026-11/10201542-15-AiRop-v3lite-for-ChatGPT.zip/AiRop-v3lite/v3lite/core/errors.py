"""Коды ошибок и исключения v3 core.

Контракт кодов (спека admin2 §4): SCHEMA | SOURCE_429 | SOURCE_5XX |
SOURCE_NET | SOURCE_ERROR | ACCESS_DENIED | NOT_FOUND | NOT_IMPLEMENTED |
FILTER_CANARY | LIMIT.
"""
from __future__ import annotations


class CoreError(Exception):
    code = "SOURCE_ERROR"

    def __init__(self, detail: str = "", *, source: str = ""):
        super().__init__(detail or self.code)
        self.detail = detail or self.code
        self.source = source

    def to_json(self) -> dict:
        return {"code": self.code, "source": self.source, "detail": self.detail}


class SchemaError(CoreError):
    """Нарушение контракта запроса/фильтра. Ответ FAILED до похода в REST."""
    code = "SCHEMA"


class SecurityError(CoreError):
    """Метод/параметр вне whitelist — запрет до любого сетевого вызова."""
    code = "SCHEMA"


class FilterRejected(CoreError):
    """Локальная валидация фильтра не прошла."""
    code = "SCHEMA"


class SourceError(CoreError):
    """Источник упал после всех ретраев."""
    code = "SOURCE_ERROR"


class RateLimitError(SourceError):
    code = "SOURCE_429"


class ServerError(SourceError):
    code = "SOURCE_5XX"


class NetworkError(SourceError):
    code = "SOURCE_NET"


class AccessDenied(SourceError):
    code = "ACCESS_DENIED"


class NotFound(CoreError):
    code = "NOT_FOUND"


class NotInCore(CoreError):
    """Источник/интент за пределами core (например Open Lines — модуль dev_agent)."""
    code = "NOT_IMPLEMENTED"
