"""Open Lines / сообщения — НЕ задача core (спека admin2 §10, задача ИИ-РОП):
модуль пишет dev_agent. Стык: core отдаёт activity-индекс TYPE_ID=6 с chat_ref
"{owner_type}:{owner_id}"; dev_agent разрешает чат через
imopenlines.crm.chat.getlastid (НИКОГДА через ASSOCIATED_ENTITY_ID) и тянет текст
im.dialog.messages.get ПОСТРАНИЧНО. Whitelist-заготовки для этих методов уже
в core/whitelist.py (getlastid/get), сам модуль сообщений — вне core.

Эта заглушка даёт честный NOT_IMPLEMENTED, чтобы manager_day не выглядел VERIFIED.
"""
from __future__ import annotations


def stub_error() -> dict:
    return {
        "code": "NOT_IMPLEMENTED",
        "source": "openlines.messages",
        "detail": "тексты сообщений Open Lines — модуль dev_agent (спека §10); "
                  "core отдаёт только activity-индекс (chat_ref)",
    }
