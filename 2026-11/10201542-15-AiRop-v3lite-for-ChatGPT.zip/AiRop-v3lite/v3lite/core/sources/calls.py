"""calls_day: все звонки всех менеджеров в [from, to).

Первичный источник — voximplant.statistic через calls.db READ-ONLY
(спека §5: готовый сборщик, выкачку не дублируем). Кросс-чек — crm.activity.list
TYPE_ID=2 за окно: совпадение по CRM_ACTIVITY_ID. Инцидент 05.08 («один звонок —
лучший и худший»): пара voximpl+activity = ОДИН факт, voximpl первичен,
activity идёт в evidence; активность без voximpl-записи — отдельный факт
с warning (разрыв покрытия), не молча.

Свежесть: если calls.db отстаёт и окно выходит за последнюю запись —
честный PARTIAL с coverage.last_row.
"""
from __future__ import annotations

import sqlite3
from datetime import timedelta

from .. import facts as F
from ..canaries import filter_canary
from ..config import CANARY_MAX_LAG_S
from ..facts import mask_phone
from ..timeutil import fmt_iso, parse_bx_date, parse_iso, to_bx_filter_date
from .common import finish, note_pagination

_ENTITY = {"LEAD": "lead", "CONTACT": "contact", "DEAL": "deal"}
_SELECT = ["ID", "OWNER_ID", "OWNER_TYPE_ID", "TYPE_ID", "PROVIDER_TYPE_ID",
           "RESPONSIBLE_ID", "AUTHOR_ID", "CREATED", "SUBJECT", "COMPLETED"]


def collect(client, v: dict, *, exclude_users: set, calls_db_path: str) -> dict:
    frm, to = v["from"], v["to"]
    warnings: list[str] = []
    errors: list[dict] = []
    coverage: dict = {}
    det: dict = {"filter_canary": {}}
    page_stats: dict[str, dict] = {}
    all_facts: list[dict] = []

    # ---- 1) voximpl через calls.db (READ-ONLY: mode=ro, прод-файл не трогаем)
    try:
        rows, last_row, err = _read_calls_db(calls_db_path, frm, to)
    except sqlite3.Error as e:
        rows, last_row = [], None
        errors.append({"code": "SOURCE_ERROR", "source": "voximplant(calls.db)",
                       "detail": f"calls.db не читается: {e}"})
    else:
        if err:
            errors.append(err)

    by_activity_id: dict[str, dict] = {}
    fact_by_activity: dict[str, dict] = {}
    for r in rows:
        if r["activity_id"]:
            by_activity_id[str(r["activity_id"])] = r
        entity = None
        if r["entity_type"] in _ENTITY and r["entity_id"]:
            entity = {"type": _ENTITY[r["entity_type"]],
                      "id": int(r["entity_id"]) if str(r["entity_id"]).isdigit()
                      else r["entity_id"]}
        fact = F.make_fact(
            fact_type="call",
            source="voximplant.statistic",
            source_entity_id=f"voximpl:{r['bx_stat_id']}",
            timestamp=parse_iso(r["start_date"]),
            author_id=r["manager_id"],
            author_role="BOT" if r["manager_id"] in exclude_users else "WE",
            crm_entity=entity,
            payload={"call_type": r["call_type"], "duration": r["duration"],
                     "phone": mask_phone(r["phone"]), "status": r["status"],
                     "fail_code": r["fail_code"]},
            evidence={"db": "calls.db (read-only)",
                      "query": f"start_date ∈ [{fmt_iso(frm)}, {fmt_iso(to)})"},
        )
        all_facts.append(fact)
        if r["activity_id"]:
            fact_by_activity[str(r["activity_id"])] = fact
    coverage["voximplant(calls.db)"] = {
        "rows": len(rows), "last_row": last_row, "readonly": True,
        "note": "первичный источник звонков (спека §5); запись в calls.db запрещена",
    }
    if rows and last_row:
        try:
            last_dt = parse_iso(last_row)
            if to > last_dt and (to - last_dt) > timedelta(seconds=CANARY_MAX_LAG_S):
                warnings.append(
                    f"calls.db отстаёт: последняя запись {last_row}, окно до "
                    f"{fmt_iso(to)} — покрытие окна неполно")
        except Exception:
            pass

    # ---- 2) кросс-чек crm.activity.list TYPE_ID=2 (инцидент 05.08: дедуп пары)
    fc = filter_canary(client, "crm.activity.list", {">CREATED": "01.01.2099 00:00:00"})
    det["filter_canary"]["crm.activity.list"] = fc
    if fc == "ERROR":
        errors.append({"code": "SOURCE_ERROR", "source": "crm.activity.list",
                       "detail": "канарейка фильтра: источник не ответил "
                                 "(кросс-чек недоступен)"})
    elif fc == "FAIL":
        warnings.append("фильтр crm.activity.list игнорируется сервером — "
                        "кросс-чек звонков отброшен (fail-closed)")
        errors.append({"code": "FILTER_CANARY", "source": "crm.activity.list",
                       "detail": "канарейка фильтра дала строки на пустом пересечении"})
    else:
        flt = {"TYPE_ID": "2", ">=CREATED": to_bx_filter_date(frm),
               "<CREATED": to_bx_filter_date(to)}
        params = {**{f"FILTER[{k}]": val for k, val in flt.items()},
                  "select[]": _SELECT}
        acts, stats = client.call_all("crm.activity.list", params)
        page_stats["crm.activity.list:TYPE2"] = stats.to_json()
        matched = unmatched = 0
        for a in acts:
            aid = str(a.get("ID"))
            if aid in by_activity_id:
                matched += 1      # пара voximpl+activity = один факт (инцидент 05.08)
                vf = fact_by_activity.get(aid)
                if vf is not None:
                    vf["evidence"]["crosscheck_activity_id"] = aid
                    # авторский кросс-чек: manager_id(voximpl) vs RESPONSIBLE_ID(activity)
                    resp = F.int_or_none(a.get("RESPONSIBLE_ID"))
                    if vf["author_id"] and resp is not None and resp != vf["author_id"]:
                        det["author_crosscheck"] = "WARN"
                        warnings.append(
                            f"activity {aid}: RESPONSIBLE_ID={resp} ≠ manager_id="
                            f"{vf['author_id']} — приоритет voximpl, см. evidence")
                continue
            unmatched += 1
            ts = parse_bx_date(a.get("CREATED", ""))
            if ts is None:
                warnings.append(f"activity {aid}: нечитаемое CREATED, отброшено")
                continue
            from .activities import fact_from_activity
            f = fact_from_activity(a, exclude_users=exclude_users,
                                   evidence={"query": "TYPE_ID=2&CREATED∈window",
                                             "note": "нет пары в calls.db — "
                                                     "возможен лаг сборщика"})
            if f is not None:
                all_facts.append(f)
                warnings.append(f"activity {aid}: звонок-активность без записи "
                                f"voximpl в calls.db (лаг/внешний звонок)")
        coverage["activity_crosscheck"] = {
            "rows": len(acts), "matched_voximpl": matched,
            "unmatched_activities": unmatched,
            "note": "matched = один факт (voximpl первичен); unmatched — факт "
                    "с warning (инцидент 05.08: дубли запрещены)",
        }
    note_pagination(det, page_stats, warnings)

    # GC-8 owner dangle: владельцы всех фактов (voximpl entity + activity
    # cross-check) проверяются crm.*.get батчем; призрак (не найден) →
    # warning + PARTIAL, факт не отбрасывается молча
    from .owners import verify_fact_owners
    oc = verify_fact_owners(client, all_facts, warnings=warnings,
                            coverage=coverage)
    if oc.get("dangling"):
        det.setdefault("owner_dangle", oc["dangling"])

    det.setdefault("author_crosscheck", "PASS")
    return finish(v, facts=all_facts, coverage=coverage, warnings=warnings,
                  errors=errors, det=det, frm=frm, to=to, client=client)


def _read_calls_db(path: str, frm, to):
    """Чтение calls.db строго READ-ONLY (uri mode=ro)."""
    import os
    err = None
    if not os.path.exists(path):
        return [], None, {"code": "SOURCE_ERROR", "source": "voximplant(calls.db)",
                          "detail": f"нет файла {path}"}
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10)
    con.row_factory = sqlite3.Row
    try:
        last = con.execute(
            "SELECT MAX(start_date) FROM calls WHERE start_date IS NOT NULL"
        ).fetchone()[0]
        rows_raw = con.execute(
            "SELECT bx_stat_id, bx_call_id, activity_id, manager_id, entity_type,"
            " entity_id, client_name, phone, call_type, start_date, duration,"
            " status, fail_code FROM calls "
            "WHERE start_date >= ? AND start_date < ? ORDER BY start_date",
            (fmt_iso(frm), fmt_iso(to))).fetchall()
        rows = [dict(r) for r in rows_raw]
        # строковое сравнение ISO с одним офсетом надёжно, но перепроверяем парсингом
        rows = [r for r in rows
                if r["start_date"] and frm <= parse_iso(r["start_date"]) < to]
        return rows, last, err
    finally:
        con.close()
