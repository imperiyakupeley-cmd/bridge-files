"""client_dossier (CRM-часть, F3): досье клиента по ТОЧНОМУ type+ID.

Идентификационный гейт (GC-4, инцидент 03.11 «досье не того клиента»):
- досье строится ТОЛЬКО по entity {type,id} (контракт §3); имя не является
  ключом досье (по имени — только список кандидатов, это resolve_client);
- несуществующий ID → FAILED NOT_FOUND: никакого автоподбора «похожих»,
  досье по призраку не строится (GC-8);
- ответ начинается с эха ID: result.identification.echo = "contact:16790";
- неоднозначность кластера (несколько контактов на одном телефоне) НЕ
  разрешается автоматически: досье — строго по запрошенному ID, остальные
  перечислены как связанные (clarification), истории не сливаются (GC-5).

Кластер (GC-2/GC-5, инцидент 02.11 «11 лидов без звонков»):
- все телефоны карточки → crm.duplicate.findbycomm → дубли lead/contact/deal;
- суждение «дубль» — только по ≥2 независимым ключам (совпавший телефон +
  совпавший IM-профиль коннектора imol|avito|2|u2i-*); один ключ — «возможный
  дубль, требует ручной проверки»; слияние записей API запрещено (read-only).

Таймлайн: crm.activity.list по КАЖДОМУ члену кластера (OWNER_TYPE_ID/OWNER_ID,
полный постраничный обход) → факты через fact_from_activity (GC-1: задачи бота
TASKS_TASK — боту, не менеджеру). Телефония кластера — voximpl через calls.db
(READ-ONLY) по ВСЕМ номерам кластера (эталон GC-2: 5+7+9=21 звонок на
лиде 9080 + контактах 8868/16790 при 0 на сделке 17016), кросс-чек пар по
activity_id (voximpl первичен, инцидент 05.08). Звонок, найденный по номеру,
активность которого не попала в owner-обход (висит на призраке/чужой карточке),
дочитывается crm.activity.get — так ловится «звонок на призраке» (GC-8:
owner dangle → warning + PARTIAL, owners.py).

Сделки: crm.deal.list FILTER[CONTACT_ID] по контактам кластера (+ сама
сделка, если запрошена); этапы топ-сделок — crm.stagehistory.list (автор
этапа REST недоступен — автор не утверждается, GC-9-этика).

Детектор GC-2/GC-7 («сделка без звонков при живых звонках в кластере»):
warning «привязка звонков сломана» — это факт о CRM, НЕ обвинение менеджера.

Тексты сообщений: core отдаёт ТОЛЬКО индекс (kind=message_index, text=None,
SUBJECT не парсится в текст — «без догадок», GC-10); тексты — интент
messages_cluster модуля dev_agent, стык закрывается в staging merge
(заглушка NOT_IMPLEMENTED снимается, если тексты реально получены).
"""
from __future__ import annotations

import sqlite3

from .. import facts as F
from ..canaries import filter_canary
from ..errors import NotFound, SourceError
from ..facts import mask_phone
from ..timeutil import fmt_iso, now_msk, parse_bx_date, parse_iso
from .activities import fact_from_activity
from .common import finish, note_pagination, qs
from .clients import _brief, _phones_of, normalize_phone
from .openlines import stub_error
from .owners import verify_fact_owners

_GET = {"lead": "crm.lead.get", "contact": "crm.contact.get",
        "deal": "crm.deal.get"}
_OWNER_CODE = {"lead": 1, "contact": 2, "deal": 3}

_ACT_SELECT = ["ID", "OWNER_ID", "OWNER_TYPE_ID", "TYPE_ID", "PROVIDER_TYPE_ID",
               "PROVIDER_ID", "RESPONSIBLE_ID", "AUTHOR_ID", "CREATED",
               "LAST_UPDATED", "SUBJECT", "COMPLETED", "DEADLINE", "DESCRIPTION"]
_DEAL_SELECT = ["ID", "TITLE", "STAGE_ID", "ASSIGNED_BY_ID", "CONTACT_ID",
                "LEAD_ID", "OPPORTUNITY", "DATE_CREATE", "CLOSEDATE",
                "DATE_MODIFY"]

# Ограничения on-demand сбора (квоты REST, «типично 8–15» + кластер):
MAX_PHONES = 5            # номеров кластера для findbycomm
MAX_CONTACTS = 6          # контактов кластера (карточки/обход)
MAX_LEADS = 6
MAX_DEALS = 8             # сделок кластера в выдаче
MAX_ENTITY_SCAN = 12      # членов кластера для owner-обхода активностей
STAGEHISTORY_DEALS = 3    # сделок с этапами (crm.stagehistory.list)
MAX_CALLS_ROWS = 2000     # строк calls.db по номерам кластера


def _ims_of(row: dict) -> list[str]:
    out = []
    im = row.get("IM")
    if isinstance(im, list):
        for p in im:
            v = p.get("VALUE") if isinstance(p, dict) else None
            if v:
                out.append(str(v))
    return out


def _get_card(client, etype: str, eid: int) -> dict:
    """Карточка crm.{type}.get. Не найдена → NotFound (досье не строится).

    Живой портал на несуществующий ID отвечает HTTP 400 «Not found» →
    клиент превращает это в SourceError; распознаём и честно отказываем."""
    try:
        data = client.call(_GET[etype], {"ID": eid})
    except SourceError as e:
        low = str(getattr(e, "detail", "")).lower()
        if "not found" in low or "not_found" in low or "не найден" in low:
            raise NotFound(f"{_GET[etype]}: сущность {etype}:{eid} не найдена — "
                           "досье по призраку не строится (GC-8)",
                           source=_GET[etype]) from e
        raise
    row = data.get("result") if isinstance(data, dict) else None
    if not isinstance(row, dict) or row.get("ID") is None:
        raise NotFound(f"{_GET[etype]}: сущность {etype}:{eid} не найдена — "
                       "досье по призраку не строится (GC-8)", source=_GET[etype])
    return row


def _batch_cards(client, refs: list[tuple[str, int]], *, coverage: dict
                 ) -> dict[tuple[str, int], dict]:
    """Карточки членов кластера батчем: (type,id) → row | {} (не найдена)."""
    out: dict[tuple[str, int], dict] = {}
    if not refs:
        return out
    cmds = [(_GET[t], {"ID": str(i)}) for t, i in refs]
    try:
        answers = client.batch(cmds, label="dossier_cards")
    except Exception as e:
        coverage["batch:dossier_cards"] = {"error": str(e)[:200]}
        return out
    ok = 0
    for ref, ans in zip(refs, answers):
        if isinstance(ans, dict) and not ans.get("error") and ans.get("ID") is not None:
            out[ref] = ans
            ok += 1
        else:
            out[ref] = {}
    coverage["batch:dossier_cards"] = {"cmds": len(refs), "ok": ok,
                                       "not_found": len(refs) - ok}
    return out


def _calls_by_phones(path: str, phones: set[str], *, max_rows: int = MAX_CALLS_ROWS
                     ) -> tuple[list[dict], str | None]:
    """voximpl-звонки кластера из calls.db (READ-ONLY mode=ro) по нормализо-
    ванным номерам. Сравнение номеров — только нормализованные цифры."""
    import os
    if not os.path.exists(path):
        return [], None
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10)
    con.row_factory = sqlite3.Row
    try:
        rows_raw = con.execute(
            "SELECT bx_stat_id, activity_id, manager_id, entity_type, entity_id,"
            " client_name, phone, call_type, start_date, duration, status,"
            " fail_code FROM calls WHERE phone IS NOT NULL AND phone != ''"
        ).fetchall()
    finally:
        con.close()
    out = []
    truncated_at = None
    for r in rows_raw:
        if normalize_phone(r["phone"] or "") in phones:
            if len(out) >= max_rows:
                truncated_at = max_rows
                break
            out.append(dict(r))
    return out, truncated_at


def collect(client, v: dict, *, exclude_users: set, calls_db_path: str) -> dict:
    entity = v["entity"]
    frm, to = v["from"], v["to"]
    warnings: list[str] = []
    errors: list[dict] = [stub_error()]   # тексты ОЛ — модуль messages (§10);
    # заглушка снимается интеграцией, если messages_cluster отработал
    coverage: dict = {}
    det: dict = {"filter_canary": {}}
    page_stats: dict[str, dict] = {}
    all_facts: list[dict] = []

    # ------------------------------------------------ 1) идентификация (GC-4)
    try:
        card = _get_card(client, entity["type"], entity["id"])
    except NotFound as e:
        return finish(v, facts=[], coverage={}, warnings=[], errors=[e.to_json()],
                      det={"filter_canary": "N/A", "pagination_canary": "N/A",
                           "window_canary": "N/A", "author_crosscheck": "N/A",
                           "identification_gate": "FAIL"},
                      frm=None, to=None, client=client)
    phones_raw = _phones_of(card)
    norm_phones: list[str] = []
    for p in phones_raw:
        n = normalize_phone(p)
        if n and n not in norm_phones:
            norm_phones.append(n)
    if len(norm_phones) > MAX_PHONES:
        warnings.append(f"у карточки {len(norm_phones)} номеров — проверены "
                        f"первые {MAX_PHONES} (кластер может быть шире)")
        norm_phones = norm_phones[:MAX_PHONES]
    phones_set = set(norm_phones)
    ims = _ims_of(card)
    ident = {
        "echo": f"{entity['type']}:{entity['id']}",
        "entity": _brief(entity["type"], card),
        "phones_masked": [mask_phone(p) for p in phones_raw],
        "im_profiles": len(ims),
        "gate": "exact_type_id (GC-4): имя не является ключом досье; "
                "несуществующий ID → NOT_FOUND без автоподбора",
    }
    coverage[f"{_GET[entity['type']]}"] = {"rows": 1}

    # ------------------------------------------------ 2) кластер по телефонам
    cluster: dict[str, set[int]] = {"lead": set(), "contact": set(), "deal": set()}
    cluster[entity["type"]].add(entity["id"])
    for ph in norm_phones:
        try:
            data = client.call("crm.duplicate.findbycomm",
                               {"TYPE": "PHONE", "VALUES[]": ph})
        except SourceError as e:
            warnings.append(f"crm.duplicate.findbycomm ({mask_phone(ph)}) не "
                            f"ответил: кластер возможно неполн ({str(e)[:120]})")
            continue
        dup = data.get("result") or {}
        dup_norm = {k.lower(): (x if isinstance(x, list) else [])
                    for k, x in dup.items()}
        for t in ("lead", "contact", "deal"):
            for x in dup_norm.get(t, []):
                xi = F.int_or_none(x)
                if xi is not None:
                    cluster[t].add(xi)
        coverage[f"crm.duplicate.findbycomm:{mask_phone(ph)}"] = {
            "rows": sum(len(x) for x in dup_norm.values()),
            "query": f"TYPE=PHONE&VALUES[]={ph[:2]}***{ph[-2:]}",
        }
    # связь по конвертации (GC-2: лид CONVERTED → контакт) — отдельный ключ,
    # не телефон: lead.CONTACT_ID / deal.CONTACT_ID
    conv_links: list[str] = []
    for t, field in (("lead", "CONTACT_ID"), ("deal", "CONTACT_ID")):
        cid = F.int_or_none(card.get(field))
        if cid:
            cluster["contact"].add(cid)
            conv_links.append(f"{t}:{entity['id']}→contact:{cid} (CONVERTED)")

    # ------------------------------------------------ 3) карточки кластера
    contact_refs = [("contact", i) for i in sorted(cluster["contact"])][:MAX_CONTACTS]
    lead_refs = [("lead", i) for i in sorted(cluster["lead"])][:MAX_LEADS]
    deal_refs = [("deal", i) for i in sorted(cluster["deal"])][:MAX_DEALS]
    if len(cluster["contact"]) > MAX_CONTACTS:
        warnings.append(f"кластер: {len(cluster['contact'])} контактов по номерам — "
                        f"взято {MAX_CONTACTS} (остальные в coverage, обход неполон)")
    if len(cluster["lead"]) > MAX_LEADS:
        warnings.append(f"кластер: {len(cluster['lead'])} лидов — взято {MAX_LEADS}")
    cards = _batch_cards(client, contact_refs + lead_refs + deal_refs,
                         coverage=coverage)
    cards[(entity["type"], entity["id"])] = card
    known_ok = {ref for ref, row in cards.items() if row}

    # суждения о дублях (GC-5): ≥2 ключей = «вероятный дубль», 1 = «возможный»
    cluster_members: list[dict] = []
    req_ref = (entity["type"], entity["id"])
    for ref in contact_refs:
        row = cards.get(ref, {})
        c_phones = {normalize_phone(p) for p in _phones_of(row)}
        c_ims = set(_ims_of(row))
        keys = []
        if c_phones & phones_set:
            keys.append("phone")
        if ims and c_ims & set(ims):
            keys.append("im_profile")
        if ref == req_ref:
            judgement = "исходная запись досье"
        elif len(keys) >= 2:
            judgement = "вероятный дубль (2+ ключа)"
        elif len(keys) == 1:
            judgement = "возможный дубль (1 ключ) — требует ручной проверки, истории не сливаются"
        else:
            judgement = "связь по кластеру (ключ не определён)"
        cluster_members.append({"type": "contact", "id": ref[1],
                                "exists": bool(row),
                                "match_keys": keys, "judgement": judgement,
                                "phones_masked": [mask_phone(p) for p in _phones_of(row)]})
    for ref in lead_refs:
        row = cards.get(ref, {})
        status = str(row.get("STATUS_ID") or "")
        rel = ("converted→" + f"contact:{F.int_or_none(row.get('CONTACT_ID'))}"
               if status.startswith("CONVERTED") and row.get("CONTACT_ID")
               else "лид кластера")
        cluster_members.append({"type": "lead", "id": ref[1], "exists": bool(row),
                                "status_id": status or None, "relation": rel})
    dup_contacts = [m for m in cluster_members
                    if m["type"] == "contact"
                    and str(m.get("judgement", "")).startswith(("вероятный", "возможный"))]
    n_contacts_in_cluster = sum(1 for m in cluster_members if m["type"] == "contact")
    if len(dup_contacts) >= 1:
        warnings.append(
            "неоднозначность идентификации (GC-4/GC-5): контактов в кластере "
            f"{n_contacts_in_cluster} — досье строго по " + ident["echo"]
            + ", остальные перечислены как связанные (дубли: " + "; ".join(
                f"contact:{m['id']}={m['judgement']}" for m in dup_contacts[:5])
            + "); автопоглощение дублей запрещено (read-only)")

    # ------------------------------------------------ 4) сделки кластера
    deals: dict[int, dict] = {}
    deal_scan_contacts = [i for t, i in contact_refs]
    if entity["type"] == "deal":
        deals[entity["id"]] = card
    for cid in deal_scan_contacts:
        rows, stats = client.call_all(
            "crm.deal.list", {"FILTER[CONTACT_ID]": str(cid),
                              "select[]": _DEAL_SELECT})
        page_stats[f"crm.deal.list:contact{cid}"] = stats.to_json()
        for d in rows:
            di = F.int_or_none(d.get("ID"))
            if di is not None:
                deals[di] = d
    for di in list(cluster["deal"])[:MAX_DEALS]:
        if di not in deals:
            row = cards.get(("deal", di))
            if row:
                deals[di] = row
    if len(deals) > MAX_DEALS:
        warnings.append(f"сделок в кластере {len(deals)} — в досье первые "
                        f"{MAX_DEALS} по порядку обхода")
        deals = dict(list(deals.items())[:MAX_DEALS])
    deal_briefs = [{"id": di,
                    "title": d.get("TITLE"),
                    "stage_id": d.get("STAGE_ID"),
                    "opportunity": d.get("OPPORTUNITY"),
                    "assigned_by_id": d.get("ASSIGNED_BY_ID"),
                    "contact_id": d.get("CONTACT_ID"),
                    "date_create": d.get("DATE_CREATE")}
                   for di, d in sorted(deals.items())]
    for m in cluster_members:
        if m["type"] == "contact" and m["exists"]:
            m["deals"] = sum(1 for d in deals.values()
                             if str(d.get("CONTACT_ID")) == str(m["id"]))

    # ------------------------------------------------ 5) таймлайн активностей
    fc = filter_canary(client, "crm.activity.list", {">CREATED": "01.01.2099 00:00:00"})
    det["filter_canary"]["crm.activity.list"] = fc
    activities_ok = True
    if fc == "ERROR":
        errors.append({"code": "SOURCE_ERROR", "source": "crm.activity.list",
                       "detail": "канарейка фильтра: источник не ответил"})
        activities_ok = False
    elif fc == "FAIL":
        errors.append({"code": "FILTER_CANARY", "source": "crm.activity.list",
                       "detail": "сервер вернул строки на заведомо пустой фильтр"})
        warnings.append("фильтр crm.activity.list игнорируется сервером — "
                        "таймлайн кластера не собран (fail-closed)")
        activities_ok = False

    scan: list[tuple[str, int]] = [(entity["type"], entity["id"])]
    for ref in contact_refs + lead_refs:
        if ref not in scan:
            scan.append(ref)
    for di in sorted(deals):
        if ("deal", di) not in scan:
            scan.append(("deal", di))
    if len(scan) > MAX_ENTITY_SCAN:
        warnings.append(f"кластер {len(scan)} сущностей — owner-обход первых "
                        f"{MAX_ENTITY_SCAN}, активности остальных не собраны "
                        "(см. coverage.cluster)")
        scan = scan[:MAX_ENTITY_SCAN]
    act_by_id: dict[str, dict] = {}
    if activities_ok:
        for t, i in scan:
            rows, stats = client.call_all(
                "crm.activity.list",
                {"FILTER[OWNER_TYPE_ID]": str(_OWNER_CODE[t]),
                 "FILTER[OWNER_ID]": str(i), "select[]": _ACT_SELECT})
            page_stats[f"crm.activity.list:{t}{i}"] = stats.to_json()
            for r in rows:
                act_by_id[str(r["ID"])] = r
        for r in act_by_id.values():
            fact = fact_from_activity(
                r, exclude_users=exclude_users,
                evidence={"query": f"OWNER_TYPE_ID={r.get('OWNER_TYPE_ID')}"
                                   f"&OWNER_ID={r.get('OWNER_ID')}",
                          "note": "обход по OWNER кластера (GC-3: путь по "
                                  "OWNER, BINDINGS запрещён)"})
            if fact is not None:
                all_facts.append(fact)
    note_pagination(det, page_stats, warnings)

    # ------------------------------------------- 6) телефония кластера (GC-2)
    calls_rows, calls_trunc = _calls_by_phones(calls_db_path, phones_set)
    if calls_trunc:
        warnings.append(f"calls.db по номерам кластера: достигнут потолок "
                        f"{MAX_CALLS_ROWS} строк — телфония кластера неполна")
    vox_by_activity: dict[str, dict] = {}
    for r in calls_rows:
        if r["activity_id"]:
            vox_by_activity[str(r["activity_id"])] = r
    # звонки calls.db, чья активность не найдена owner-обходом (висит на
    # призраке/чужой карточке) — дочитываем crm.activity.get (только TYPE_ID=2;
    # одиночное чтение CONFIGURABLE TYPE_ID=6 сервером запрещено, GC-3)
    missing_ids = [aid for aid in vox_by_activity if aid not in act_by_id]
    fetched_ghost = 0
    if missing_ids:
        cmds = [("crm.activity.get", {"ID": aid}) for aid in missing_ids[:45]]
        try:
            answers = client.batch(cmds, label="dossier_ghost_activities")
        except Exception as e:
            warnings.append("crm.activity.get (звонки вне owner-обхода) не "
                            f"ответил: {str(e)[:120]}")
            answers = []
        for aid, ans in zip(missing_ids[:45], answers):
            row = ans if isinstance(ans, dict) and not ans.get("error") else None
            if row and row.get("ID") is not None and str(row.get("TYPE_ID")) == "2":
                act_by_id[aid] = row
                fetched_ghost += 1
                fact = fact_from_activity(
                    row, exclude_users=exclude_users,
                    evidence={"note": "активность найдена по номеру телефона "
                              "через calls.db (владелец вне owner-обхода "
                              "кластера — призрак/чужая карточка, GC-8)"})
                if fact is not None:
                    all_facts.append(fact)
        if len(missing_ids) > 45:
            warnings.append(f"звонков вне owner-обхода {len(missing_ids)} — "
                            "дочитано 45, остальные только в voximpl-фактах")
        coverage["dossier.ghost_activities"] = {
            "found_in_calls_db": len(missing_ids), "fetched": fetched_ghost,
            "note": "crm.activity.get по activity_id из calls.db; ловушка "
                    "«звонок на призраке» (GC-8)"}

    # voximpl-факты (первичный источник звонков) + дедуп пары voximpl/activity
    fact_by_activity_id: dict[str, dict] = {}
    for f in all_facts:
        if f["source"] == "crm.activity.list" and \
                f["source_entity_id"].startswith("activity:"):
            fact_by_activity_id[f["source_entity_id"].split(":", 1)[1]] = f
    vox_facts: list[dict] = []
    for r in calls_rows:
        ent = None
        if r["entity_type"] in ("LEAD", "CONTACT", "DEAL") and r["entity_id"]:
            ent = {"type": r["entity_type"].lower(),
                   "id": F.int_or_none(r["entity_id"]) or r["entity_id"]}
        vox = F.make_fact(
            fact_type="call", source="voximplant.statistic",
            source_entity_id=f"voximpl:{r['bx_stat_id']}",
            timestamp=parse_iso(r["start_date"]),
            author_id=r["manager_id"],
            author_role="BOT" if F.int_or_none(r["manager_id"]) in exclude_users else "WE",
            crm_entity=ent,
            payload={"call_type": r["call_type"], "duration": r["duration"],
                     "phone": mask_phone(r["phone"]), "status": r["status"],
                     "fail_code": r["fail_code"]},
            evidence={"db": "calls.db (read-only)",
                      "query": "phone ∈ cluster_phones (нормализованные)",
                      "activity_id": (str(r["activity_id"])
                                      if r["activity_id"] else None)})
        vox_facts.append(vox)
    # пара voximpl+activity = ОДИН факт (инцидент 05.08): voximpl первичен,
    # activity-факт снимается, ссылка идёт в evidence
    paired_activity = set()
    for vox in vox_facts:
        aid = vox["evidence"].get("activity_id")
        if aid and aid in fact_by_activity_id:
            af = fact_by_activity_id[aid]
            paired_activity.add(aid)
            vox["evidence"]["crosscheck_activity_id"] = aid
            resp = F.int_or_none(af["evidence"].get("RESPONSIBLE_ID"))
            if vox["author_id"] is not None and resp is not None \
                    and resp != vox["author_id"]:
                det["author_crosscheck"] = "WARN"
                warnings.append(
                    f"activity {aid}: RESPONSIBLE_ID={resp} ≠ manager_id="
                    f"{vox['author_id']} — приоритет voximpl (см. evidence)")
    all_facts = [f for f in all_facts
                 if not (f["source"] == "crm.activity.list"
                         and f["source_entity_id"].split(":", 1)[-1] in paired_activity)]
    all_facts.extend(vox_facts)
    det.setdefault("author_crosscheck", "PASS")
    coverage["dossier.calls_db"] = {
        "rows": len(calls_rows), "phones_queried": len(norm_phones),
        "phones_masked": [mask_phone(p) for p in norm_phones],
        "readonly": True,
        "note": "voximpl — первичный источник звонков кластера (спека §5)"}

    # ------------------------------------------------ 7) owner dangle (GC-8)
    # (до счётчиков звонков: dangling-статусы нужны детектору GC-2 ниже)
    oc = verify_fact_owners(client, all_facts, warnings=warnings,
                            coverage=coverage, known_ok=known_ok)
    if oc.get("dangling"):
        det["owner_dangle"] = oc["dangling"]

    # --------------------------------- 8) GC-2/GC-7: сделка без звонков в кластере
    cluster_pairs = set(scan) | {("deal", di) for di in deals}
    call_facts = [f for f in all_facts if f["fact_type"] == "call"]
    calls_by_entity: dict[str, int] = {}
    cluster_calls = 0
    dangling_calls = 0
    for f in call_facts:
        ent = f.get("crm_entity") or {}
        key = f"{ent.get('type')}:{ent.get('id')}"
        calls_by_entity[key] = calls_by_entity.get(key, 0) + 1
        if f["payload"].get("owner_status") == "dangling":
            dangling_calls += 1
        elif (ent.get("type"), F.int_or_none(ent.get("id"))) in cluster_pairs:
            cluster_calls += 1
    deals_without_calls = []
    for d in deal_briefs:
        n = calls_by_entity.get(f"deal:{d['id']}", 0)
        if n == 0:
            deals_without_calls.append({"deal_id": d["id"], "title": d["title"]})
    if deals_without_calls and (cluster_calls or dangling_calls):
        for d in deals_without_calls[:5]:
            warnings.append(
                f"сделка {d['deal_id']} «{d['title']}\": 0 звонков на сделке, "
                f"в кластере {cluster_calls} звонков"
                + (f" + {dangling_calls} на призраках" if dangling_calls else "")
                + " — привязка звонков сломана (GC-2/GC-7): факт о CRM, "
                  "НЕ обвинение менеджера; смотрите таймлайн лида/дублей")

    # ------------------------------------------------ 9) этапы топ-сделок
    # [ФАКТ, live 09.11]: боевой REST ждёт camelCase (entityTypeId/entityId)
    # и заворачивает ответ в result.items; CREATED_TIME — ISO с офсетом.
    # Старый UPPER-формат (моки/другие порталы) — fallback.
    stage_n = 0
    for d in deal_briefs[:STAGEHISTORY_DEALS]:
        data = None
        for form in ({"entityTypeId": 1, "entityId": str(d["id"])},
                     {"ENTITY_TYPE": 1, "ENTITY_ID": str(d["id"])}):
            try:
                data = client.call("crm.stagehistory.list", form)
                res = data.get("result")
                rows = (res.get("items") if isinstance(res, dict) else res) or []
                if isinstance(rows, list) and rows:
                    break
                if isinstance(rows, list) and not rows and form is not None:
                    # пустой ответ — тоже ответ; не переспрашиваем второй формой
                    break
            except SourceError:
                data = None
                continue
        if data is None:
            warnings.append(f"crm.stagehistory.list (сделка {d['id']}) не "
                            "ответил: этапы сделки не собраны")
            continue
        for k, r in enumerate(rows):
            raw_ts = r.get("CREATED_TIME", "")
            try:
                ts = parse_iso(raw_ts)
            except Exception:                      # noqa: BLE001 — не-ISO строка
                ts = None
            if ts is None:
                ts = parse_bx_date(raw_ts)
            if ts is None:
                continue
            stage_n += 1
            author = F.int_or_none(r.get("USER_ID"))
            all_facts.append(F.make_fact(
                fact_type="stage_change", source="crm.stagehistory.list",
                source_entity_id=f"stagehistory:deal:{d['id']}:{r.get('ID') or k}",
                timestamp=ts, author_id=author,
                author_role="WE" if author is not None else "CONNECTOR",
                crm_entity={"type": "deal", "id": d["id"]},
                payload={"stage_id": r.get("STATUS_ID") or r.get("STAGE_ID"),
                         "deal_id": d["id"]},
                evidence={"query": f"entityTypeId=1&entityId={d['id']}",
                          "note": "история только этапов (одна страница); "
                                  "автор этапа из REST недоступен — причин "
                                  "смены этапа и сроков не утверждаем (GC-9)"}))
    if stage_n:
        coverage["crm.stagehistory.list"] = {
            "facts": stage_n,
            "note": "одна страница на сделку; при >page_limit история этапов "
                    "усекается снизу (см. items в evidence)"}

    # ------------------------------------------------ 10) тексты — стаб (GC-10)
    msg_index_n = 0
    for f in all_facts:
        if f["payload"].get("kind") == "message_index":
            msg_index_n += 1
            f["payload"]["text"] = None
            f["payload"]["text_source"] = ("messages_cluster (модуль dev_agent); "
                                           "SUBJECT не парсится в текст")

    # ------------------------------------------------ 11) сборка ответа
    kinds: dict = {}
    for f in all_facts:
        kinds[f["fact_type"]] = kinds.get(f["fact_type"], 0) + 1
    coverage["classification"] = {**kinds, "facts": len(all_facts)}
    coverage["cluster"] = {
        "members": [{"type": t, "id": i} for t, i in scan],
        "contacts_total": len(cluster["contact"]),
        "leads_total": len(cluster["lead"]),
        "deals_in_dossier": len(deals),
        "converted_links": conv_links,
        "note": "обход активностей по OWNER каждого члена кластера (GC-2/GC-3)",
    }
    ts_list = [f["timestamp_dt"] for f in all_facts if f.get("timestamp_dt")]
    result = {
        "identification": ident,
        "cluster": {
            "contacts": [m for m in cluster_members if m["type"] == "contact"],
            "leads": [m for m in cluster_members if m["type"] == "lead"],
            "deals": [{"id": d["id"], "title": d["title"]} for d in deal_briefs],
            "converted_links": conv_links,
        },
        "deals": deal_briefs,
        "timeline_summary": {
            "facts": len(all_facts),
            "by_type": kinds,
            "first": fmt_iso(min(ts_list)) if ts_list else None,
            "last": fmt_iso(max(ts_list)) if ts_list else None,
        },
        "calls_summary": {
            "cluster_calls": cluster_calls,
            "dangling_calls": dangling_calls,
            "by_entity": calls_by_entity,
            "deals_without_calls": deals_without_calls,
            "note": "«звонил/не звонил» — только по кластеру (GC-2/GC-7); "
                    "0 на сделке при звонках в кластере = сломана привязка, "
                    "не «менеджер не звонил»",
        },
        "texts": {
            "message_index_facts": msg_index_n,
            "status": "stub_core",
            "note": "тексты сообщений — интент messages_cluster модуля "
                    "messages (dev_agent); core тексты не тянет и SUBJECT не "
                    "парсит (GC-10 «без догадок»)",
        },
        "window_note": (None if frm is None else
                        f"таймлайн-факты ограничены окном [{fmt_iso(frm)}, "
                        f"{fmt_iso(to)}) — см. window_canary; счётчики "
                        "calls_summary посчитаны по кластеру до фильтра окна"),
    }
    resp = finish(v, facts=all_facts, coverage=coverage, warnings=warnings,
                  errors=errors, det=det, frm=frm, to=to, client=client)
    resp["result"] = result
    return resp
