"""Проверка существования OWNER у фактов — GC-8 «owner dangle».

Живой эталон (09.11): activity 1001974 «Исходящий звонок Михаилу (13 мин)»
висит на OWNER_TYPE_ID=2 (CONTACT), OWNER_ID=17016 — контакт 17016 НЕ найден
(crm.contact.get → HTTP 400 «Not found»; создатели имели в виду СДЕЛКУ 17016:
ID-пространства типов пересекаются). Звонок невидим ни в одной карточке.

Правило v3 (GC-8): факт со ссылкой на несуществующую сущность НЕ отбрасывается
молча и НЕ выдаёт VERIFIED — проверка crm.{lead,contact,deal}.get батчем при
эмите факта; владелец не найден →
  * факт сохраняется с payload.owner_status='dangling' (visible, не потерян);
  * warning «owner dangle» (поимённо, с ограничением объёма);
  * статус ответа PARTIAL (warning ≠ VERIFIED — спека §4).

Ограничение: проверяются только ссылки типа lead/contact/deal с числовым ID.
"""
from __future__ import annotations

from .. import facts as F

_GET = {"lead": "crm.lead.get", "contact": "crm.contact.get",
        "deal": "crm.deal.get"}


def _ref(ent: dict | None) -> tuple[str, int] | None:
    if not isinstance(ent, dict):
        return None
    t, i = ent.get("type"), ent.get("id")
    if t not in _GET:
        return None
    i = F.int_or_none(i)
    return (t, i) if i is not None else None


def verify_fact_owners(client, facts: list[dict], *, warnings: list[str],
                       coverage: dict, known_ok: set | None = None,
                       warn_limit: int = 10) -> dict:
    """Батч-проверка OWNER (crm.*.get) всех уникальных crm_entity фактов.

    known_ok — уже проверенные существующие (type,id) из этого же запроса
    (например, карточки кластера в client_dossier): их не переспрашиваем.
    Возвращает счётчик {"checked", "dangling"} и пишет coverage["owner_check"].
    Сама проверка недоступна (источник упал) → warning: существование не
    подтверждено, VERIFIED невозможно (fail-closed), но факты не теряем.
    """
    known_ok = known_ok or set()
    uniq: dict[tuple[str, int], str] = {}
    bad_refs = 0
    for f in facts:
        ref = _ref(f.get("crm_entity"))
        if ref is None:
            if f.get("crm_entity"):
                bad_refs += 1
            continue
        if ref not in known_ok:
            uniq[ref] = _GET[ref[0]]
    cov = {"bad_refs_non_numeric": bad_refs}

    if not uniq:
        cov.update({"checked": 0, "dangling": 0,
                    "note": "ссылок для проверки нет (или все проверены ранее)"})
        coverage["owner_check"] = cov
        return {"checked": 0, "dangling": 0}

    refs = sorted(uniq)
    cmds = [(uniq[ref], {"ID": str(ref[1])}) for ref in refs]
    try:
        answers = client.batch(cmds, label="owner_check")
    except Exception as e:  # источник проверки упал — не молчим, не VERIFIED
        warnings.append("owner dangle check недоступен: существование владельцев "
                        f"не подтверждено ({str(e)[:120]}) — VERIFIED невозможно")
        cov.update({"checked": 0, "dangling": None, "error": str(e)[:200]})
        coverage["owner_check"] = cov
        return {"checked": 0, "dangling": None}

    dangling: set[tuple[str, int]] = set()
    for ref, ans in zip(refs, answers):
        # успех crm.*.get в batch = dict-строка с ID; per-cmd ошибка/пустое
        # значение («Not found», HTTP 400 в result_error) = призрак
        if not (isinstance(ans, dict) and not ans.get("error")
                and ans.get("ID") is not None):
            dangling.add(ref)

    for f in facts:
        ref = _ref(f.get("crm_entity"))
        if ref in dangling:
            f["payload"]["owner_status"] = "dangling"
            f["payload"]["owner_ref"] = f"{ref[0]}:{ref[1]}"
            f["evidence"]["owner_dangle"] = (
                f"{_GET[ref[0]]}: владелец {ref[0]}:{ref[1]} не найден — "
                "сущность не существует (ID-пространства типов пересекаются, "
                "GC-8); звонок/дело невидимы в карточке владельца")

    if dangling:
        refs_str = ", ".join(f"{t}:{i}" for t, i in sorted(dangling)[:warn_limit])
        n_more = len(dangling) - min(len(dangling), warn_limit)
        warnings.append(
            f"owner dangle: {len(dangling)} ссылок на несуществующие сущности "
            f"({refs_str}" + (f" +{n_more} ещё" if n_more > 0 else "") +
            ") — факты сохранены с payload.owner_status=dangling; звонок/дело "
            "висит на призраке (владелец не найден, GC-8), приписывать его "
            "карточке/менеджеру нельзя; статус понижен до PARTIAL")
    cov.update({"checked": len(refs), "dangling": len(dangling),
                "dangling_refs": [f"{t}:{i}" for t, i in sorted(dangling)],
                "note": "crm.{lead,contact,deal}.get батчем при эмите факта "
                        "(GC-8); dangling → warning + PARTIAL, не VERIFIED"})
    coverage["owner_check"] = cov
    return {"checked": len(refs), "dangling": len(dangling)}
