"""Реестр источников v3. Core даёт CRM-часть; Open Lines (тексты сообщений)
регистриует dev_agent своим модулем (спека §10) — core его НЕ реализует.
"""
from __future__ import annotations

_REGISTRY: dict[str, object] = {}


def register_source(name: str, source) -> None:
    _REGISTRY[name] = source


def get_source(name: str):
    return _REGISTRY.get(name)


def core_sources() -> list[str]:
    return ["crm.lead.list", "crm.activity.list", "voximplant(calls.db)",
            "user.get", "crm.duplicate.findbycomm"]
