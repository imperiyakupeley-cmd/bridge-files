"""leads_day: все лиды, СОЗДАННЫЕ в [from, to) + факты первых касаний.

Источник: crm.lead.list (фильтр по DATE_CREATE — единственная надёжная дата,
спека §5: DATE_MODIFY под запретом как признак касания, инцидент 15.08).
Первое касание: crm.activity.list по каждому лиду через batch (order CREATED ASC,
первая строка). Факты касаний эмитятся только если попали в окно (window_canary),
иначе — счётчик в coverage (не теряем молча). Ошибка или потеря отдельной команды
batch (включая MISSING_IN_BATCH) — это errors[] → статус НЕ VERIFIED
(fail-closed, инцидент 08.11 integ-ld-1: касания терялись молча при VERIFIED).
"""
from __future__ import annotations

from .. import facts as F
from ..canaries import filter_canary
from ..timeutil import parse_bx_date, to_bx_filter_date
from .activities import fact_from_activity
from .common import finish, note_pagination, qs

_SELECT = ["ID", "TITLE", "DATE_CREATE", "ASSIGNED_BY_ID", "CREATED_BY_ID",
           "STATUS_ID", "SOURCE_ID", "DATE_MODIFY", "COMMENTS"]


def collect(client, v: dict, *, exclude_users: set) -> dict:
    frm, to = v["from"], v["to"]
    warnings: list[str] = []
    errors: list[dict] = []
    coverage: dict = {}
    det: dict = {"filter_canary": {}}
    all_facts: list[dict] = []
    page_stats: dict[str, dict] = {}

    # 1) канарейка фильтра (fail-closed: FAIL → лиды не собираем вовсе)
    fc = filter_canary(client, "crm.lead.list", {">DATE_CREATE": "01.01.2099 00:00:00"})
    det["filter_canary"]["crm.lead.list"] = fc
    if fc == "ERROR":
        # источник не ответил — транзиентно, ответ НЕ должен кэшироваться
        return finish(v, facts=[], coverage=coverage, warnings=[],
                      errors=[{"code": "SOURCE_ERROR", "source": "crm.lead.list",
                               "detail": "канарейка фильтра: источник не ответил"}],
                      det=det, frm=None, to=None, client=client)
    if fc == "FAIL":
        warnings.append("фильтр crm.lead.list игнорируется сервером — факты "
                        "lead_new отброшены (fail-closed)")
        coverage["crm.lead.list"] = {"canary": "FAIL", "rows": 0}
        return finish(v, facts=[], coverage=coverage, warnings=warnings,
                      errors=[{"code": "FILTER_CANARY", "source": "crm.lead.list",
                               "detail": "сервер вернул строки на заведомо пустой фильтр"}],
                      det=det, frm=None, to=None, client=client)

    # 2) лиды по DATE_CREATE ∈ [from, to)
    flt = {">=DATE_CREATE": to_bx_filter_date(frm), "<DATE_CREATE": to_bx_filter_date(to)}
    params = {**{f"FILTER[{k}]": val for k, val in flt.items()},
              "select[]": _SELECT}
    rows, stats = client.call_all("crm.lead.list", params)
    page_stats["crm.lead.list"] = stats.to_json()
    note_pagination(det, page_stats, warnings)

    for r in rows:
        ts = parse_bx_date(r.get("DATE_CREATE", ""))
        if ts is None:
            warnings.append(f"lead {r.get('ID')}: нечитаемая DATE_CREATE, факт отброшен")
            continue
        author = r.get("CREATED_BY_ID")
        all_facts.append(F.make_fact(
            fact_type="lead_new",
            source="crm.lead.list",
            source_entity_id=f"lead:{r['ID']}",
            timestamp=ts,
            author_id=author,
            author_role="BOT" if author in exclude_users else "WE",
            crm_entity={"type": "lead", "id": r["ID"]},
            payload={"title": r.get("TITLE"),
                     "status_id": r.get("STATUS_ID"),
                     "source_id": r.get("SOURCE_ID"),
                     "assigned_by_id": r.get("ASSIGNED_BY_ID"),
                     "created_by_id": r.get("CREATED_BY_ID")},
            evidence={"query": qs(flt), "select": ",".join(_SELECT)},
        ))
    coverage["crm.lead.list"] = {
        **stats.to_json(),
        "note": "день лида = DATE_CREATE (DATE_MODIFY запрещён спекой: "
                "инцидент 15.08 массовой правки)",
    }

    # 3) первые касания по каждому лиду (batch, order CREATED ASC, первая строка)
    if rows:
        cmds = [("crm.activity.list",
                 {"FILTER[OWNER_TYPE_ID]": "1", "FILTER[OWNER_ID]": str(r["ID"]),
                  "order[CREATED]": "ASC", "start": 0})
                for r in rows]
        try:
            answers = client.batch(cmds, label="lead_first_touch")
        except Exception as e:  # источник касаний упал — лиды остаются, PARTIAL
            errors.append({"code": "SOURCE_ERROR", "source": "batch:crm.activity.list",
                           "detail": f"первые касания не получены: {e}"})
            answers = None
        if answers is not None:
            # честный coverage batch-конверта из клиента → в ответ (§7.5)
            bcov = client.coverage.get("batch:lead_first_touch")
            if bcov:
                coverage["batch:lead_first_touch"] = dict(bcov)
            with_touch = out_win = cmd_err = cmd_missing = 0
            err_samples: list[str] = []
            if len(answers) != len(rows):
                # сам batch() должен возвращать по ответу на команду; иначе —
                # контракт нарушен, касаниям доверять нельзя (fail-closed)
                errors.append({"code": "SOURCE_ERROR",
                               "source": "batch:crm.activity.list",
                               "detail": f"batch вернул {len(answers)} ответов "
                                         f"на {len(rows)} команд"})
                answers = []
            for lead, ans in zip(rows, answers):
                if isinstance(ans, dict) and ans.get("error"):
                    code = str(ans.get("error"))
                    if code == "MISSING_IN_BATCH":
                        cmd_missing += 1
                    else:
                        cmd_err += 1
                    if len(err_samples) < 3:
                        err_samples.append(f"lead {lead.get('ID')}: {code}")
                    continue
                first = _first_row(ans)
                if first is None:
                    continue
                with_touch += 1
                fact = fact_from_activity(first, exclude_users=exclude_users,
                                          evidence={
                                              "query": f"OWNER_TYPE_ID=1&OWNER_ID={lead['ID']}"
                                                       "&order=CREATED ASC",
                                              "page": 1})
                ts = fact.get("timestamp_dt")
                if ts is not None and frm <= ts < to:
                    all_facts.append(fact)
                else:
                    out_win += 1
            # fail-closed (инцидент 08.11): недополучение обязательного
            # источника касаний ≠ VERIFIED — фиксируем ошибку в ответ
            if cmd_err or cmd_missing:
                errors.append({
                    "code": "SOURCE_ERROR",
                    "source": "batch:crm.activity.list",
                    "detail": f"первые касания недополучены: {cmd_err} команд "
                              f"с ошибкой, {cmd_missing} без ответа "
                              f"(MISSING_IN_BATCH) из {len(rows)}; примеры: "
                              + "; ".join(err_samples)})
            coverage["first_touch"] = {
                "leads": len(rows), "with_any_activity": with_touch,
                "first_touch_in_window": with_touch - out_win,
                "first_touch_outside_window": out_win,
                "without_any_activity": len(rows) - with_touch,
                "cmd_error": cmd_err, "cmd_missing": cmd_missing,
                "note": "касание вне окна [from,to) не эмитится (window_canary), "
                        "видно в счётчиках; cmd_error/cmd_missing > 0 → статус "
                        "не VERIFIED (fail-closed)",
            }

    return finish(v, facts=all_facts, coverage=coverage, warnings=warnings,
                  errors=errors, det=det, frm=frm, to=to, client=client)


def _first_row(ans) -> dict | None:
    if isinstance(ans, dict) and ans.get("error"):
        return None
    rows = ans if isinstance(ans, list) else (ans or {}).get("result", [])
    return rows[0] if rows else None
