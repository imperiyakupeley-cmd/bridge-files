"""get_activities(manager-day): индекс дел дня сотрудника из crm.activity.list.

Правила (спека §5, §8, задача ИИ-РОП, золотые кейсы GC-1/3/8):
- TYPE_ID=6 — сообщения (автологи ОЛ/коннекторы) И ручные TODO И задачи бота:
  различение ТОЛЬКО по PROVIDER (GC-1 стр. 214 золотых кейсов), не по
  TYPE_ID/SUBJECT:
    * ручное TODO — PROVIDER_TYPE_ID='TODO' (подтверждено audit_compute 03.11);
    * задача бота — PROVIDER_TYPE_ID/PROVIDER_ID = TASKS_TASK/CRM_WEBDAV_TASK
      («Отложенный клиент», бот dogrev): автор = AUTHOR_ID-бот, role=BOT,
      kind='bot_task' — к делам менеджера НЕ относится (инцидент 02.11:
      TASKS_TASK завышал показатели менеджера);
- TYPE_ID=2 — звонки (кросс-чек голосового источника, SUBJECT парсить осторожно);
- AUTHOR_ID=1 — коннектор, НЕ автор: фактический отправитель исходящего =
  RESPONSIBLE_ID. Автор и ответственный никогда не смешиваются;
- SUBJECT «Исходящее/Входящее» — вспомогательный признак, не идентификатор;
- OWNER_TYPE_ID 1/2/3 = lead/contact/deal [ФАКТ спеки §5]; существование
  владельца проверяется при эмите (owners.py, GC-8 owner dangle: призрак
  → warning + PARTIAL, факт не отбрасывается молча);
- manager_day БЕЗ предположения владения сделкой: собираем и по RESPONSIBLE_ID,
  и по AUTHOR_ID (кроме коннектора 1), дедуп по ID активности.
"""
from __future__ import annotations

from .. import facts as F
from ..canaries import filter_canary
from ..timeutil import parse_bx_date, to_bx_filter_date
from .common import finish, note_pagination, qs
from .owners import verify_fact_owners

OWNER_TYPES = {1: "lead", 2: "contact", 3: "deal"}   # [ФАКТ] спека §5

_SELECT = ["ID", "OWNER_ID", "OWNER_TYPE_ID", "TYPE_ID", "PROVIDER_TYPE_ID",
           "PROVIDER_ID", "RESPONSIBLE_ID", "AUTHOR_ID", "CREATED",
           "LAST_UPDATED", "SUBJECT", "COMPLETED", "DEADLINE", "DESCRIPTION"]

# PROVIDER_TYPE_ID, характерные для автологов сообщений (не-TODO внутри TYPE 6)
_MSG_PROVIDERS = ("CONFIGURABLE", "OL", "IMOPENLINES", "CONNECTOR")

# Задачи бота внутри TYPE_ID=6: различение ТОЛЬКО по PROVIDER (GC-1, стр. 214):
# PROVIDER_ID=CRM_WEBDAV_TASK/TASKS_TASK (PROVIDER_TYPE_ID бывает TASKS_TASK
# и пустой) — автор-бот AUTHOR_ID, никогда RESPONSIBLE-менеджер.
_BOT_TASK_PREFIXES = ("TASKS_TASK", "CRM_WEBDAV_TASK")


def _is_bot_task(pti: str, provider_id: str) -> bool:
    a = (pti or "").upper()
    b = (provider_id or "").upper()
    return any(a.startswith(p) or b.startswith(p) for p in _BOT_TASK_PREFIXES)


def get_activities(client, employee_id: int, frm, to, *, exclude_users: set,
                   warnings: list[str], errors: list[dict], coverage: dict,
                   det: dict, page_stats: dict) -> list[dict]:
    """Ядро manager_day: активности дня сотрудника. Возвращает факты."""
    # канарейка фильтра (единый метод — один прогон)
    fc = filter_canary(client, "crm.activity.list", {">CREATED": "01.01.2099 00:00:00"})
    det.setdefault("filter_canary", {})["crm.activity.list"] = fc
    if fc == "ERROR":
        errors.append({"code": "SOURCE_ERROR", "source": "crm.activity.list",
                       "detail": "канарейка фильтра: источник не ответил"})
        return []
    if fc == "FAIL":
        warnings.append("фильтр crm.activity.list игнорируется сервером — "
                        "активности дня отброшены (fail-closed)")
        errors.append({"code": "FILTER_CANARY", "source": "crm.activity.list",
                       "detail": "сервер вернул строки на заведомо пустой фильтр"})
        return []

    frm_bx, to_bx = to_bx_filter_date(frm), to_bx_filter_date(to)
    queries = {
        "by_responsible": {"RESPONSIBLE_ID": str(employee_id)},
        "by_author": {"AUTHOR_ID": str(employee_id)},
    }
    by_id: dict = {}
    for name, extra in queries.items():
        flt = {**extra, ">=CREATED": frm_bx, "<CREATED": to_bx}
        params = {**{f"FILTER[{k}]": val for k, val in flt.items()},
                  "select[]": _SELECT}
        rows, stats = client.call_all("crm.activity.list", params)
        page_stats[f"crm.activity.list:{name}"] = stats.to_json()
        for r in rows:
            if name == "by_author" and int(r.get("AUTHOR_ID") or 0) == 1:
                continue  # AUTHOR_ID=1 — коннектор: автора-«1» никогда не собираем
            by_id[r["ID"]] = r
        coverage[f"crm.activity.list:{name}"] = stats.to_json()

    fact_list = []
    for r in by_id.values():
        fact = fact_from_activity(r, exclude_users=exclude_users,
                                  employee_id=employee_id,
                                  evidence={"query": qs(
                                      {"RESPONSIBLE_ID|AUTHOR_ID": employee_id,
                                       ">=CREATED": frm_bx, "<CREATED": to_bx})})
        if fact is not None:
            fact_list.append(fact)
    # GC-8 owner dangle: существование владельцев проверяем при эмите факта;
    # призрак (не найден) → warning + PARTIAL, факт НЕ отбрасывается молча
    verify_fact_owners(client, fact_list, warnings=warnings, coverage=coverage)
    return fact_list


def fact_from_activity(r: dict, *, exclude_users: set, employee_id: int | None = None,
                       evidence: dict | None = None) -> dict | None:
    """Активность CRM → факт контракта. Авторство — по правилам §8 (не путать
    AUTHOR_ID с RESPONSIBLE_ID). Возвращает факт или None (нечитаемая строка)."""
    ts = parse_bx_date(r.get("CREATED", ""))
    if ts is None:
        return None
    type_id = int(r.get("TYPE_ID") or 0)
    pti = str(r.get("PROVIDER_TYPE_ID") or "")
    provider_id = str(r.get("PROVIDER_ID") or "")
    subject = str(r.get("SUBJECT") or "")
    author_raw = r.get("AUTHOR_ID")
    responsible = r.get("RESPONSIBLE_ID")
    owner = {"type": OWNER_TYPES.get(int(r.get("OWNER_TYPE_ID") or 0)),
             "id": r.get("OWNER_ID")}
    owner = {k: v for k, v in owner.items() if v is not None} or None
    # авторство/роли — строго по int (ловушка str-ID, §9.5-6)
    author_int = F.int_or_none(author_raw)
    resp_int = F.int_or_none(responsible)

    if type_id == 6 and pti.upper().startswith("TODO"):
        # ручное TODO: TYPE_ID=6 + PROVIDER_TYPE_ID=TODO (audit_compute 03.11)
        author = author_int if author_int not in (None, 1) else resp_int
        return F.make_fact(
            fact_type="task_todo", source="crm.activity.list",
            source_entity_id=f"activity:{r['ID']}", timestamp=ts,
            author_id=author,
            author_role="BOT" if author in exclude_users else "WE",
            crm_entity=owner,
            payload={"subject": subject, "kind": "todo",
                     "deadline": r.get("DEADLINE"), "completed": r.get("COMPLETED"),
                     "description_len": len(str(r.get("DESCRIPTION") or ""))},
            evidence={**(evidence or {}),
                      "TYPE_ID": 6, "PROVIDER_TYPE_ID": pti,
                      "AUTHOR_ID_raw": author_raw, "RESPONSIBLE_ID": responsible},
        )
    if _is_bot_task(pti, provider_id):
        # задача бота (GC-1): TASKS_TASK/CRM_WEBDAV_TASK — автор = AUTHOR_ID-бот
        # (dogrev 15780 и т.п.), role=BOT, к делам менеджера не относится.
        author = author_int if author_int != 1 else resp_int
        return F.make_fact(
            fact_type="task_todo", source="crm.activity.list",
            source_entity_id=f"activity:{r['ID']}", timestamp=ts,
            author_id=author,
            author_role="BOT" if (author is None or author in exclude_users)
            else "WE",
            crm_entity=owner,
            payload={"subject": subject, "kind": "bot_task",
                     "provider_type_id": pti or None,
                     "provider_id": provider_id or None,
                     "deadline": r.get("DEADLINE"), "completed": r.get("COMPLETED")},
            evidence={**(evidence or {}),
                      "TYPE_ID": type_id, "PROVIDER_TYPE_ID": pti,
                      "PROVIDER_ID": provider_id,
                      "AUTHOR_ID_raw": author_raw, "RESPONSIBLE_ID": responsible,
                      "note": "задача бота (GC-1): PROVIDER=TASKS_TASK/"
                              "CRM_WEBDAV_TASK; автор-бот AUTHOR_ID, не "
                              "RESPONSIBLE-менеджер"},
        )
    if type_id == 2:
        # звонок-активность: фактический участник = RESPONSIBLE_ID (не AUTHOR_ID=1)
        return F.make_fact(
            fact_type="call", source="crm.activity.list",
            source_entity_id=f"activity:{r['ID']}", timestamp=ts,
            author_id=resp_int,
            author_role="BOT" if resp_int in exclude_users else "WE",
            crm_entity=owner,
            payload={"subject": subject, "kind": "activity_call",
                     "completed": r.get("COMPLETED")},
            evidence={**(evidence or {}),
                      "TYPE_ID": 2, "AUTHOR_ID_raw": author_raw,
                      "RESPONSIBLE_ID": responsible,
                      "note": "кросс-чек с voximpl в calls_day; AUTHOR_ID=1 "
                              "здесь коннектор, не автор"},
        )
    if type_id == 6:
        # автолог сообщения: индекс дня. Текст сообщения — модуль Open Lines
        # (dev_agent): в payload только chat_ref, текст не тянем.
        # Направление — по SUBJECT («Исходящее/Входящее» — вспомогательный
        # признак §5, не идентификатор): точную роль подтвердит диалог.
        subj_l = subject.lower()
        if subj_l.startswith("вход"):
            msg_author, msg_role = None, "CLIENT"
        else:  # «Исходящее» или без SUBJECT: отправитель = RESPONSIBLE_ID
            msg_author = resp_int
            msg_role = "BOT" if resp_int in exclude_users else "WE"
        return F.make_fact(
            fact_type="message", source="crm.activity.list",
            source_entity_id=f"activity:{r['ID']}", timestamp=ts,
            author_id=msg_author,
            author_role=msg_role,
            crm_entity=owner,
            payload={"subject": subject, "kind": "message_index",
                     "provider_type_id": pti or None,
                     "chat_ref": (f"{owner['type']}:{owner['id']}"
                                  if owner else None)},
            evidence={**(evidence or {}),
                      "TYPE_ID": 6, "AUTHOR_ID_raw": author_raw,
                      "RESPONSIBLE_ID": responsible,
                      "note": "индекс сообщения; текст/роль автора уточняет "
                              "модуль Open Lines (dev_agent) по chat_ref"},
        )
    # прочие дела: встреча(1)/задача(3)/письмо(4)/другое(5)
    kind = {1: "meeting", 3: "task", 4: "email", 5: "other"}.get(type_id, "other")
    author = author_int if author_int not in (None, 1) else resp_int
    fact_type = "message" if type_id == 4 else "task_todo"
    return F.make_fact(
        fact_type=fact_type, source="crm.activity.list",
        source_entity_id=f"activity:{r['ID']}", timestamp=ts,
        author_id=author,
        author_role="BOT" if author in exclude_users else "WE",
        crm_entity=owner,
        payload={"subject": subject, "kind": kind,
                 "completed": r.get("COMPLETED")},
        evidence={**(evidence or {}), "TYPE_ID": type_id,
                  "AUTHOR_ID_raw": author_raw, "RESPONSIBLE_ID": responsible},
    )


def collect(client, v: dict, *, exclude_users: set) -> dict:
    """manager_day (CRM-часть core): активности дня сотрудника.
    Open Lines (тексты сообщений) — заглушка NOT_IMPLEMENTED, см. openlines.py."""
    from .openlines import stub_error
    warnings: list[str] = []
    errors: list[dict] = [stub_error()]
    coverage: dict = {}
    det: dict = {"filter_canary": {}}
    page_stats: dict[str, dict] = {}

    acts = get_activities(client, v["employee_id"], v["from"], v["to"],
                          exclude_users=exclude_users, warnings=warnings,
                          errors=errors, coverage=coverage, det=det,
                          page_stats=page_stats)
    note_pagination(det, page_stats, warnings)
    kinds: dict = {}
    for a in acts:
        kinds[a["fact_type"]] = kinds.get(a["fact_type"], 0) + 1
    coverage["classification"] = {**kinds, "activities": len(acts)}
    coverage["boundary"] = ("тексты сообщений Open Lines — модуль dev_agent "
                            "(спека §10): core отдаёт индекс (chat_ref), не текст")
    return finish(v, facts=acts, coverage=coverage, warnings=warnings,
                  errors=errors, det=det, frm=v["from"], to=v["to"], client=client)
