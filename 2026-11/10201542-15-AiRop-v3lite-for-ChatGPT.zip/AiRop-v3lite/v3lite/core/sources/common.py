"""Общие хелперы источников: сборка ответа, дедуп, канарейки."""
from __future__ import annotations

from ..canaries import dedup_facts, pagination_from_stats, window_check
from ..contract import make_response
from ..facts import serialize_facts
from ..timeutil import fmt_iso, now_msk


def finish(v: dict, *, facts: list, coverage: dict, warnings: list[str],
           errors: list[dict], det: dict, frm, to, client) -> dict:
    """Финализация: агрегация канарейки фильтра → окно → дедуп → статус."""
    fc = det.get("filter_canary")
    if isinstance(fc, dict):
        vals = list(fc.values())
        det["filter_canary_detail"] = dict(fc)
        det["filter_canary"] = ("FAIL" if "FAIL" in vals else
                                "ERROR" if "ERROR" in vals else
                                "PASS" if vals else "N/A")
    if frm is not None and to is not None:
        facts, wc = window_check(facts, frm, to, warnings=warnings)
        det["window_canary"] = wc
    dd: dict = {}
    facts = dedup_facts(facts, counters=dd)
    det["duplicate_guard_dropped"] = dd.get("duplicate_guard_dropped", 0)
    coverage["_rest_calls"] = client.calls_made
    return make_response(v, facts=serialize_facts(facts), coverage=coverage,
                         warnings=warnings, errors=errors, detectors=det,
                         as_of=fmt_iso(now_msk()))


def note_pagination(det: dict, page_stats: dict, warnings: list[str]) -> None:
    det["pagination_canary"] = pagination_from_stats(page_stats, warnings=warnings)


def qs(flt: dict) -> str:
    return "&".join(f"{k}={v}" for k, v in flt.items())
