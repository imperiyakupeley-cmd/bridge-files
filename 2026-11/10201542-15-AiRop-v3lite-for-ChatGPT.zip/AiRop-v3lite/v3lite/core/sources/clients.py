"""resolve_client: разрешение клиента + дедуп по телефону.

Пути:
- по entity {type,id}: crm.{lead|deal|contact}.get;
- по телефону: crm.duplicate.findbycomm TYPE=PHONE VALUES[]=<нормализованный>
  (группы дублей lead/contact/deal), затем батч crm.*.get по найденным id
  (топ-5 на тип — защита от размножения).

Инцидент «bitrix-duplicate-contact-trap» (§9.4): дубликаты контактов перечисляются
в warnings (это признак грязных данных), чужие сущности не подтягиваются,
дубликат-контакт НЕ создаётся (мы read-only). Телефоны в ответе маскируются.
"""
from __future__ import annotations

import re

from ..contract import make_response
from ..facts import mask_phone
from ..timeutil import fmt_iso, now_msk

_NA_DETECTORS = {"filter_canary": "N/A", "pagination_canary": "PASS",
                 "window_canary": "N/A", "author_crosscheck": "N/A"}
_GET = {"lead": ("crm.lead.get", ["ID", "TITLE", "NAME", "LAST_NAME", "STATUS_ID",
                                  "ASSIGNED_BY_ID", "CREATED_BY_ID", "DATE_CREATE",
                                  "PHONE"]),
        "deal": ("crm.deal.get", ["ID", "TITLE", "STAGE_ID", "ASSIGNED_BY_ID",
                                  "CONTACT_ID", "OPPORTUNITY", "DATE_CREATE"]),
        "contact": ("crm.contact.get", ["ID", "NAME", "LAST_NAME", "ASSIGNED_BY_ID",
                                        "DATE_CREATE", "PHONE", "EMAIL"])}


def normalize_phone(phone: str) -> str:
    digits = re.sub(r"\D", "", phone or "")
    if len(digits) == 11 and digits.startswith("8"):
        digits = "7" + digits[1:]
    return digits


def _phones_of(row: dict) -> list[str]:
    out = []
    ph = row.get("PHONE")
    if isinstance(ph, list):
        for p in ph:
            v = p.get("VALUE") if isinstance(p, dict) else None
            if v:
                out.append(v)
    elif isinstance(ph, str) and ph:
        out.append(ph)
    return out


def _brief(etype: str, row: dict) -> dict:
    full_name = " ".join(x for x in (row.get("NAME"), row.get("LAST_NAME")) if x)
    return {
        "id": row.get("ID"),
        "type": etype,
        "title": row.get("TITLE") or (full_name or None),
        "assigned_by_id": row.get("ASSIGNED_BY_ID"),
        "phones": [mask_phone(p) for p in _phones_of(row)],
        "date_create": row.get("DATE_CREATE"),
    }


def resolve_client(client, *, entity: dict | None, phone: str | None) -> dict:
    """Основная логика. Возвращает (result, warnings, coverage)."""
    warnings: list[str] = []
    coverage: dict = {}
    result: dict = {"query_phone": None, "query_phone_normalized": None,
                    "entity": None, "duplicates": {}, "cards": []}

    # --- 1) по entity, если задан
    if entity:
        method, _sel = _GET[entity["type"]]
        from ..errors import SourceError
        try:
            data = client.call(method, {"ID": entity["id"]})
        except SourceError as e:
            if "NOT_FOUND" in e.detail:
                raise KeyError(f"{method}: сущность "
                               f"{entity['type']}:{entity['id']} не найдена") from e
            raise
        row = data.get("result")
        if not isinstance(row, dict):
            raise KeyError(f"{method}: сущность {entity['type']}:{entity['id']} "
                           f"не найдена")
        result["entity"] = _brief(entity["type"], row)
        coverage[method] = {"rows": 1}
        phone = phone or next((_ for _ in _phones_of(row)), None)

    # --- 2) дедуп по телефону (crm.duplicate.findbycomm VALUES[])
    if phone:
        norm = normalize_phone(phone)
        result["query_phone"] = mask_phone(phone)
        result["query_phone_normalized"] = norm
        data = client.call("crm.duplicate.findbycomm",
                           {"TYPE": "PHONE", "VALUES[]": norm})
        dup = data.get("result") or {}
        # формат ответа: {"LEAD":[...], "CONTACT":[...], "DEAL":[...]}
        dup_norm = {k.lower(): (v if isinstance(v, list) else [])
                    for k, v in dup.items()}
        result["duplicates"] = dup_norm
        coverage["crm.duplicate.findbycomm"] = {
            "rows": sum(len(v) for v in dup_norm.values()),
            "query": f"TYPE=PHONE&VALUES[]={norm}",
        }
        contacts = dup_norm.get("contact", [])
        if entity and entity["type"] == "contact" and entity["id"] not in contacts:
            contacts = [entity["id"]] + contacts[:4]
        if len(contacts) > 1:
            warnings.append(
                f"дубликаты контактов по телефону {mask_phone(phone)}: {contacts[:10]}"
                " — чат должен разрешаться по ВСЕМ дублям (инцидент 9.4)")
        # карточки топ-5 контактов
        if contacts:
            cmds = [("crm.contact.get", {"ID": str(cid)}) for cid in contacts[:5]]
            answers = client.batch(cmds, label="contact_cards")
            for ans in answers:
                row = ans if isinstance(ans, dict) and not ans.get("error") else None
                if row:
                    result["cards"].append(_brief("contact", row))
        leads = dup_norm.get("lead", [])[:5]
        if leads:
            cmds = [("crm.lead.get", {"ID": str(lid)}) for lid in leads]
            for ans in client.batch(cmds, label="lead_cards"):
                row = ans if isinstance(ans, dict) and not ans.get("error") else None
                if row:
                    result["cards"].append(_brief("lead", row))
    return result, warnings, coverage


def collect(client, v: dict, *, exclude_users: set) -> dict:
    coverage: dict = {}
    try:
        result, warnings, coverage = resolve_client(
            client, entity=v.get("entity"), phone=v.get("phone"))
    except KeyError as e:
        err = {"code": "NOT_FOUND", "source": "crm.*.get", "detail": str(e).strip('"')}
        return make_response(v, facts=[], coverage=coverage, warnings=[],
                             errors=[err], detectors=dict(_NA_DETECTORS),
                             as_of=fmt_iso(now_msk()))
    except Exception as e:  # источник упал
        code = getattr(e, "code", "SOURCE_ERROR")
        err = {"code": code, "source": getattr(e, "source", "crm.*"),
               "detail": str(e)}
        return make_response(v, facts=[], coverage=coverage, warnings=[],
                             errors=[err], detectors=dict(_NA_DETECTORS),
                             as_of=fmt_iso(now_msk()))
    resp = make_response(v, facts=[], coverage=coverage, warnings=warnings,
                         errors=[], detectors=dict(_NA_DETECTORS),
                         as_of=fmt_iso(now_msk()))
    resp["result"] = result
    return resp
