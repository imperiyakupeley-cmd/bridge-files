"""resolve_employee: карточка сотрудника из user.get (read-only).

Боты флота (EXCLUDE_USERS из .env, напр. Анна 17316 / Михаил 15780) помечаются
is_bot=true — атрибуция «бот не судья» (§8). Кэш на процесс.
"""
from __future__ import annotations

from ..contract import make_response
from ..errors import NotFound
from ..timeutil import fmt_iso, now_msk

_CACHE: dict[int, dict] = {}

_NA_DETECTORS = {"filter_canary": "N/A", "pagination_canary": "PASS",
                 "window_canary": "N/A", "author_crosscheck": "N/A"}


def employee_card(client, employee_id: int, *, exclude_users: set) -> dict:
    """Чистая функция разрешения (используется и как API, и как intent)."""
    if employee_id not in _CACHE:
        data = client.call("user.get", {"ID": employee_id})
        rows = data.get("result") or []
        if not rows:
            raise NotFound(f"user.get: сотрудник {employee_id} не найден",
                           source="user.get")
        u = rows[0]
        _CACHE[employee_id] = {
            "id": int(u.get("ID")),
            "name": " ".join(x for x in (u.get("NAME"), u.get("LAST_NAME")) if x)
                    or f"user_{employee_id}",
            "active": u.get("ACTIVE") == "Y",
            "email": u.get("EMAIL"),
            "department_ids": u.get("UF_DEPARTMENT") or [],
            "user_type": u.get("USER_TYPE"),
            "is_bot": int(employee_id) in exclude_users,
        }
    return _CACHE[employee_id]


def collect(client, v: dict, *, exclude_users: set) -> dict:
    try:
        card = employee_card(client, v["employee_id"], exclude_users=exclude_users)
    except NotFound as e:
        resp = make_response(v, facts=[], coverage={"user.get": {"rows": 0}},
                             warnings=[], errors=[e.to_json()],
                             detectors=dict(_NA_DETECTORS),
                             as_of=fmt_iso(now_msk()))
        return resp
    resp = make_response(
        v, facts=[], coverage={"user.get": {"rows": 1, "readonly": True}},
        warnings=[], errors=[], detectors=dict(_NA_DETECTORS),
        as_of=fmt_iso(now_msk()))
    resp["result"] = card
    return resp
