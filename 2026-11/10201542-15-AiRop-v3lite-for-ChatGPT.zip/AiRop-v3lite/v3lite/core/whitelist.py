"""Whitelist методов и параметров Bitrix REST для v3 core.

Правило: ТОЛЬКО чтение. Метод вне whitelist → SecurityError ДО любого сетевого
вызова; глаголы-мутаторы (add/update/delete/set/import/...) запрещены всегда,
даже если кто-то добавит метод в список. Обёртка batch — только с cmd-методами
из whitelist.

PARAMS-спека на метод:
  literals  — точные разрешённые ключи (start, order, ...)
  prefixes  — разрешённые префиксы ключей ('FILTER[' — содержимое фильтра
              проверяет filters.py отдельно)
"""
from __future__ import annotations

import re

from .errors import SecurityError

# Методы, меняющие данные, — абсолютный запрет независимо от whitelist.
_MUTATING = re.compile(
    r"\.(add|update|delete|set|import|register|send|force|merge|fields\.add|"
    r"user\.consent|confirm|cancel|complete|forward|pin|read|mark|answer|call)\b",
    re.I,
)

# Общие параметры листинга/чтения.
_COMMON_LITERALS = {"start", "order"}
_COMMON_PREFIXES = ("FILTER[", "select[", "filter[", "order[")


def _spec(literals: set[str] | None = None, prefixes: tuple[str, ...] = (),
          extra_literals: set[str] | None = None) -> dict:
    return {
        "literals": (literals or set()) | _COMMON_LITERALS | (extra_literals or set()),
        "prefixes": tuple(set(prefixes) | set(_COMMON_PREFIXES)),
    }


METHOD_WHITELIST: dict[str, dict] = {
    # --- CRM: сущности ---
    "crm.lead.list": _spec({"ID", "order"}, ("FILTER[", "select[")),
    "crm.lead.get": _spec({"ID"}),
    "crm.lead.fields": _spec(set(), ()),
    "crm.deal.list": _spec({"ID"}, ("FILTER[", "select[")),
    "crm.deal.get": _spec({"ID"}),
    "crm.contact.list": _spec({"ID"}, ("FILTER[", "select[")),
    "crm.contact.get": _spec({"ID"}),
    "crm.contact.fields": _spec(set(), ()),
    # [ФАКТ, live 09.11]: боевой REST ждёт camelCase entityTypeId/entityId
    # и отвечает result.items; старый UPPER-формат оставлен как fallback
    "crm.stagehistory.list": _spec({"ENTITY_TYPE", "ENTITY_ID",
                                    "entityTypeId", "entityId"},
                                   ("FILTER[", "select[")),
    # --- CRM: активности (индекс сообщений/звонков/TODO дня) ---
    "crm.activity.list": _spec({"ID"}, ("FILTER[", "select[")),
    "crm.activity.get": _spec({"ID"}),
    # --- Дубликаты по коммуникации ---
    "crm.duplicate.findbycomm": _spec({"TYPE", "ENTITY_TYPE"}, ("VALUES[")),
    # --- Пользователи ---
    "user.get": _spec({"ID", "ACTIVE"}, ("FILTER[",)),
    # --- Телфония: только чтение статистики (кросс-чек calls_day) ---
    "voximplant.statistic.get": _spec({"ID"}, ("FILTER[",)),
    # --- Open Lines: только разрешение чата; САМ МОДУЛЬ СООБЩЕНИЙ — dev_agent ---
    "imopenlines.crm.chat.getlastid": _spec({"CRM_ENTITY_TYPE", "CRM_ENTITY_ID"}),
    "imopenlines.crm.chat.get": _spec({"CRM_ENTITY_TYPE", "CRM_ENTITY_ID"}),
}

BATCH_ALLOWED = True  # batch сам валидирует каждый cmd по whitelist


def check_method(method: str) -> None:
    """Метод разрешён? Кидае SecurityError до какого-либо запроса."""
    if not isinstance(method, str) or not re.fullmatch(r"[a-z0-9_.]+", method):
        raise SecurityError(f"некорректное имя метода: {method!r}")
    if _MUTATING.search(method):
        raise SecurityError(f"метод запрещён (мутатор): {method}")
    if method not in METHOD_WHITELIST:
        raise SecurityError(f"метод вне whitelist: {method}")


def check_params(method: str, params: dict) -> dict:
    """Валидация ключей параметров. Возвращает чистую копию params."""
    check_method(method)
    spec = METHOD_WHITELIST[method]
    out: dict = {}
    for k, v in (params or {}).items():
        if k in spec["literals"]:
            out[k] = v
            continue
        if any(k.startswith(p) for p in spec["prefixes"]):
            out[k] = v
            continue
        raise SecurityError(f"параметр {k!r} не разрешён для {method}", source=method)
    return out
