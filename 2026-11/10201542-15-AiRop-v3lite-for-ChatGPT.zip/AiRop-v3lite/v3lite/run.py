#!/usr/bin/env python3
"""CLI-обёртка: stdin JSON-запрос → stdout JSON-ответ (контракт §3–4).

Запуск из любого каталога:
  echo '{"intent":...}' | python3 ~/AiRop/v3lite/run.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.collect import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
