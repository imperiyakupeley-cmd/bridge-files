#!/usr/bin/env python3
"""Живой smoke-прогон v3 core на реальном портале. ТОЛЬКО read-only GET:
user.get, crm.activity.list, crm.lead.list, crm.duplicate.findbycomm,
crm.deal.get (проверка маппинга OWNER_TYPE_ID). Никаких записей.

Вывод — метрики (latency/rows/canaries), без персональных данных (факты
не печатаются). Запуск вручную: python3 smoke_live.py
"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.canaries import filter_canary
from core.client import BitrixClient
from core.config import load_config
from core.timeutil import now_msk, to_bx_filter_date

M = {"probe": [], "error": []}


def timed(name, fn):
    t0 = time.monotonic()
    try:
        out = fn()
        M["probe"].append({"name": name, "ms": int((time.monotonic() - t0) * 1000),
                           **out})
    except Exception as e:
        M["error"].append({"name": name, "code": getattr(e, "code", "EXC"),
                           "detail": str(e)[:200]})


def main():
    cfg = load_config()
    assert cfg.webhook, "нет BX_WEBHOOK в ~/AiRop/.env"
    cli = BitrixClient(cfg)
    now = now_msk()

    timed("user.get(бот Анна)", lambda: {
        "rows": len(cli.call("user.get", {"ID": 17316}).get("result") or [])})

    timed("filter_canary crm.activity.list", lambda: {
        "result": filter_canary(cli, "crm.activity.list",
                                {">CREATED": "01.01.2099 00:00:00"})})

    # страница активностей за последний час (TYPE_ID=6 — индекс сообщений)
    frm = to_bx_filter_date(now.replace(minute=0, second=0))
    to = to_bx_filter_date(now)

    def one_page():
        d = cli.call("crm.activity.list",
                     {"FILTER[TYPE_ID]": "6", "FILTER[>=CREATED]": frm,
                      "FILTER[<CREATED]": to, "start": 0})
        r = d.get("result") or []
        return {"rows": len(r), "total": d.get("total"),
                "providers": sorted({str(x.get("PROVIDER_TYPE_ID"))
                                     for x in r})[:5],
                "author1_share": round(sum(1 for x in r
                                           if str(x.get("AUTHOR_ID")) == "1")
                                       / len(r), 2) if r else None}
    timed("activity TYPE_ID=6 за час (1 стр.)", one_page)

    timed("filter_canary crm.lead.list", lambda: {
        "result": filter_canary(cli, "crm.lead.list",
                                {">DATE_CREATE": "01.01.2099 00:00:00"})})

    def leads_page():
        d = cli.call("crm.lead.list", {
            "FILTER[>=DATE_CREATE]": to_bx_filter_date(now.replace(
                hour=0, minute=0, second=0)),
            "FILTER[<DATE_CREATE]": to, "start": 0})
        return {"rows": len(d.get("result") or []), "total": d.get("total")}
    timed("crm.lead.list сегодня (1 стр.)", leads_page)

    timed("findbycomm пустой номер", lambda: {
        "dup_types": sorted((cli.call("crm.duplicate.findbycomm",
                                      {"TYPE": "PHONE",
                                       "VALUES[]": "70000000000"})
                             .get("result") or {}).keys())})

    # проверка маппинга OWNER_TYPE_ID [спека §5: 1/2/3 = lead/contact/deal]
    def owner_map():
        d = cli.call("crm.activity.list",
                     {"FILTER[TYPE_ID]": "6", "FILTER[>=CREATED]": frm,
                      "FILTER[<CREATED]": to, "start": 0})
        for x in (d.get("result") or []):
            ot, oid = x.get("OWNER_TYPE_ID"), x.get("OWNER_ID")
            if ot == 3 and oid:
                cli.call("crm.deal.get", {"ID": oid})
                return {"checked": "OWNER_TYPE_ID=3 → crm.deal.get OK", "id": oid}
            if ot == 2 and oid:
                cli.call("crm.contact.get", {"ID": oid})
                return {"checked": "OWNER_TYPE_ID=2 → crm.contact.get OK",
                        "id": oid}
        return {"checked": "нет OWNER в выборке"}
    timed("OWNER_TYPE_ID маппинг", owner_map)

    M["rest_calls"] = cli.calls_made
    M["coverage"] = cli.coverage
    print(json.dumps(M, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
