"""Карточные события Авито: честная полнота и gaps/coverage (аудит §3, §9.6-D).

Факты [ФАКТ, аудит 09.11]:
- «посмотрел номер телефона», звонок из карточки: в истории v3 НЕТ, в Б24 НЕ
  попадают; видны ТОЛЬКО как last_message в листинге v2 → события интереса
  теряются исторически; фикстура НЕ фабрикует их из ничего.
- «создал чат, но пока не написал»: приходит в v3 КАК клиентский text с
  префиксом «[Системное сообщение]» — учитывается отдельным событием интереса.

coverage.card_events честно разделяет: v3_history (префиксные строки),
v2_last_message (сэмплинг, историческая полнота НЕ гарантируется),
not_available (типы событий, которых нет ни в одном источнике адаптера).
"""
from __future__ import annotations

from .config import SYSTEM_PREFIX
from .normalize import classify_card_marker, is_system_text
from .timeutil import from_epoch, fmt_iso

SOURCE_V3 = "avito.messenger.v3"
SOURCE_V2 = "avito.messenger.v2"

KNOWN_EVENTS = ("viewed_phone", "chat_created_no_message", "card_call")


def event_fact_from_v3(row: dict, chat_u2i: str, *, max_text_len: int = 1000) -> dict | None:
    """Строка v3 с системным признаком → факт события интереса.

    Системные строки приходят двумя формами [ФАКТ, замер 09.11.2026]:
    - type=system, author_id=0, content.text (+ flow_id);
    - type=text с префиксом «[Системное сообщение]» (фикстура D).
    Возвращает None, если это обычное клиентское/наше сообщение."""
    item = row.get("content") or {}
    text = item.get("text") if isinstance(item, dict) else item
    is_typed_system = str(row.get("type")) == "system" or str(row.get("author_id")) in ("0",)
    if not (isinstance(text, str) and text.strip()):
        return None
    if not (is_typed_system or is_system_text(text)):
        return None
    marker = classify_card_marker(text)
    if marker is None:
        if is_typed_system:
            marker = "system_other"
        else:
            return None
    clean = text[len(SYSTEM_PREFIX):].strip() if text.startswith(SYSTEM_PREFIX) else text
    payload = {
        "text": clean[:max_text_len],
        "system": True,
        "chat_u2i": chat_u2i,
        "interest_event": marker,
        "via": "v3_history_typed_system" if is_typed_system else "v3_history_prefix",
        "content_supported": True,
        "author_resolved": False,
        "direction": row.get("direction"),
    }
    return {
        "fact_type": "message",
        "source": SOURCE_V3,
        "source_entity_id": f"avito:{chat_u2i}#msg:{row.get('id')}",
        "timestamp_dt": from_epoch(row.get("created")),
        "author_id": row.get("author_id"),
        "author_role": "CONNECTOR",
        "crm_entity": None,
        "payload": payload,
        "evidence": {"avito_message_id": str(row.get("id")),
                     "avito_created_epoch": row.get("created")},
    }


def event_fact_from_v2_chat(chat_row: dict, *, max_text_len: int = 1000) -> dict | None:
    """last_message листинга v2 с type=system → факт события интереса.

    ПОЛНОТА ЧЕСТНО ОГРАНИЧЕНА: v2 виден только ПОСЛЕДНИЙ маркер чата — события
    в середине истории недоступны (coverage gap, не VERIFIED)."""
    lm = chat_row.get("last_message") or {}
    text = lm.get("text")
    mtype = str(lm.get("type") or "")
    if mtype != "system" and not (isinstance(text, str) and is_system_text(text)):
        return None
    marker = classify_card_marker(text)
    clean = text[len(SYSTEM_PREFIX):].strip() if isinstance(text, str) and text.startswith(SYSTEM_PREFIX) else text
    payload = {
        "text": (clean or "")[:max_text_len],
        "system": True,
        "chat_u2i": chat_row.get("id"),
        "interest_event": marker or "system_other",
        "via": "v2_last_message_sampling",
        "completeness": "виден только ПОСЛЕДНИЙ маркер чата — историческая полнота НЕ гарантируется",
        "content_supported": True,
        "author_resolved": False,
        "direction": None,
    }
    ts = lm.get("created") or chat_row.get("updated_ts")
    return {
        "fact_type": "message",
        "source": SOURCE_V2,
        "source_entity_id": f"avito:{chat_row.get('id')}#last",
        "timestamp_dt": from_epoch(ts),
        "author_id": None,
        "author_role": "CONNECTOR",
        "crm_entity": None,
        "payload": payload,
        "evidence": {"v2_chat_id": str(chat_row.get("id")), "updated_ts": chat_row.get("updated_ts")},
    }


def coverage_report(events: list[dict], *, v2_scanned_chats: int = 0,
                    v3_scanned_messages: int = 0) -> dict:
    """Честные gaps/coverage по карточным событиям (§9.6-D PASS-критерий:
    0 выдуманных событий; каждое исключение видно)."""
    by_kind: dict[str, int] = {}
    by_source: dict[str, int] = {}
    for e in events:
        k = e["payload"].get("interest_event")
        s = e["source"]
        by_kind[k] = by_kind.get(k, 0) + 1
        by_source[s] = by_source.get(s, 0) + 1
    return {
        "card_events": {
            "detected_total": len(events),
            "by_kind": by_kind,
            "by_source": by_source,
            "v3_history_scanned_messages": v3_scanned_messages,
            "v2_chats_scanned": v2_scanned_chats,
            "gaps": {
                "v3_history_has_card_events": False,
                "v3_history_exception": "только префиксные «[Системное сообщение]»",
                "v2_last_message": "виден только ПОСЛЕДНИЙ маркер чата — историческая полнота НЕ гарантируется",
                "not_available_anywhere": [
                    "viewed_phone (история)", "card_call (история)",
                    "детали карточных событий (объявление, время просмотра)"],
            },
            "note": "события не фабрикуются: только фактически увиденные маркеры",
        }
    }
