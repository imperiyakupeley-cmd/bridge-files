"""Время адаптера: Europe/Moscow (+03:00), ISO-8601 с офсетом (спека §2).

Окно — полуинтервал [from, to). Avito v3 отдаёт epoch-секунды (`created`)
[ФАКТ, аудит 09.11] — переводим в МСК; часовой пояс фиксированный (переходов
нет), год стабилен.
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone

TZ_NAME = "Europe/Moscow"
OFFSET = timezone(timedelta(hours=3))

_ISO = re.compile(r"^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})([+-]\d{2}:\d{2})$")


class TimeError(ValueError):
    pass


def parse_iso(value: str, *, field: str = "time") -> datetime:
    """Строгий парсер 'YYYY-MM-DDTHH:MM:SS±HH:MM'. Без офсета — отказ."""
    if not isinstance(value, str) or not _ISO.match(value):
        raise TimeError(f"{field}: ожидался ISO-8601 с офсетом, получено {value!r}")
    return datetime.fromisoformat(value).astimezone(OFFSET)


def parse_iso_loose(value) -> datetime | None:
    """Для данных ИСТОЧНИКА (Б24 отдаёт ISO с офсетом): None при мусоре.

    Битую дату не подставляем и не гадаем — None и coverage-warning
    (fail-closed, §4 п.5)."""
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        dt = datetime.fromisoformat(value.strip())
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=OFFSET)  # портал отдаёт МСК
    return dt.astimezone(OFFSET)


def from_epoch(ts, *, field: str = "created") -> datetime | None:
    """epoch-секунды Avito → datetime в МСК; мусор → None (fail-closed, не гадаем)."""
    if ts is None or isinstance(ts, bool) or not isinstance(ts, (int, float)):
        return None
    try:
        return datetime.fromtimestamp(float(ts), OFFSET)
    except (OverflowError, OSError, ValueError):
        return None


def fmt_iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=OFFSET)
    return dt.astimezone(OFFSET).replace(microsecond=0).isoformat()


def now_msk() -> datetime:
    return datetime.now(OFFSET)
