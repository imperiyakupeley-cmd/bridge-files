"""Read-only клиент Avito messenger API: v2 листинг чатов + v3 сообщения.

Гарантии (спека §5/§7):
- только два GET-метода (whitelist в transport; методов записи НЕ существует);
- троттлинг rate_rps (лимиты Avito не замерены [ПРЕДПОЛ.] → консервативно);
- §7.6: максимум 3 ретрая с backoff на 429/5xx/сеть, затем Error-подкласс →
  источник в errors, сборка продолжается;
- 401 → инвалидация токена и ОДИН повтор (истечение client_credentials-токена);
- пагинация с канарейкой offset: если сервер молча игнорирует offset (та же
  первая страница) → offset_canary=FAIL, усечение честно в coverage (§7.2).
"""
from __future__ import annotations

import random
import time
import urllib.parse

from .auth import Credentials, TokenManager
from .config import AvitoConfig
from .errors import (AccessDenied, NetworkError, NotFoundError, RateLimitError,
                     SecurityError, ServerError, SourceError)
from .transport import Transport, build_get_url
from .whitelist import Whitelist

RETRYABLE_HTTP = {429, 500, 502, 503, 504}


class Page:
    """Страница листинга/сообщений + сырые заголовки для замеров."""

    __slots__ = ("items", "raw")

    def __init__(self, items: list, raw: dict):
        self.items = items
        self.raw = raw


class AvitoClient:
    def __init__(self, cfg: AvitoConfig, transport: Transport | None = None,
                 creds: Credentials | None = None, *, throttle: bool = True):
        if cfg.live is False:
            # offline-конфиг: ни одного сетевого вызова (боевой режим выключен)
            raise SecurityError("конфиг offline: сеть запрещена (AVITO_ADAPTER_LIVE=1 не задан)")
        self.cfg = cfg
        self.creds = creds or Credentials(cfg.creds_path)
        cfg.api_base = self.creds.api_base
        cfg.token_url = self.creds.token_url
        if cfg.account_user_id is None:
            cfg.account_user_id = int(self.creds.user_id)
        self.whitelist = Whitelist(cfg.api_base, cfg.token_url)
        self.transport = transport or Transport(self.whitelist)
        if self.transport.whitelist is None:
            self.transport.whitelist = self.whitelist
        self.tokens = TokenManager(self.creds, self.transport, timeout_s=cfg.timeout_s)
        self.throttle = throttle
        self._last_ts = 0.0
        self.calls: dict[str, int] = {}
        self.total_calls = 0
        self.wall_s = 0.0
        self.rate_limit_seen: dict[str, int] = {}  # заголовки X-RateLimit-* (если есть)

    # ------------------------------------------------------------------ core
    def _wait_slot(self) -> None:
        if not self.throttle:
            return
        now = time.monotonic()
        wait = (1.0 / self.cfg.rate_rps) - (now - self._last_ts)
        if wait > 0:
            time.sleep(wait)
        self._last_ts = time.monotonic()

    def _bump(self, name: str, dt: float) -> None:
        self.calls[name] = self.calls.get(name, 0) + 1
        self.total_calls += 1
        self.wall_s += dt

    def _note_rate_headers(self, headers: dict) -> None:
        for k, v in headers.items():
            lk = str(k).lower()
            if lk.startswith("x-ratelimit") or lk == "retry-after":
                try:
                    self.rate_limit_seen[lk] = int(float(v))
                except (TypeError, ValueError):
                    pass

    def _get_json(self, name: str, path: str, params: dict | None) -> dict:
        url = build_get_url(self.cfg.api_base, path, params)
        last_err: Exception | None = None
        retried_auth = False
        for attempt in range(self.cfg.retries_max + 1):
            self._wait_slot()
            t0 = time.monotonic()
            try:
                r = self.transport.get(url, self.cfg.timeout_s,
                                       headers={"Authorization": f"Bearer {self.tokens.token()}"})
            except NetworkError as e:
                last_err = e
                self._backoff(attempt)
                continue
            self._bump(name, time.monotonic() - t0)
            self._note_rate_headers(r.headers)
            if r.status == 401 and not retried_auth:
                # токен истёк/отозван: обновить и один раз повторить
                self.tokens.invalidate()
                retried_auth = True
                continue
            if r.status in RETRYABLE_HTTP:
                last_err = (RateLimitError if r.status == 429 else ServerError)(
                    f"HTTP {r.status} (попытка {attempt + 1})", source=name)
                self._backoff(attempt, self._retry_after(r))
                continue
            if r.status == 404:
                raise NotFoundError(f"HTTP 404: {name}", source=name)
            if r.status in (401, 403):
                raise AccessDenied(f"HTTP {r.status}", source=name)
            if r.status != 200:
                raise ServerError(f"HTTP {r.status}", source=name)
            try:
                body = r.json()
            except ValueError as e:
                last_err = SourceError("невалидный JSON в ответе", source=name)
                self._backoff(attempt)
                continue
            return body
        raise last_err or SourceError("источник недоступен", source=name)

    # ---------------------------------------------------------------- calls
    def get_chats_page(self, offset: int = 0, limit: int | None = None) -> Page:
        """Листинг чатов v2: сортировка по updated_ts (новые сверху) [ФАКТ].

        Отсюда же маркеры карточных событий (last_message, type=system) —
        единственное место, где они видны (аудит §3, фикстура D).
        """
        limit = limit or self.cfg.chats_page_clamped
        body = self._get_json("v2.chats", f"/messenger/v2/accounts/{self.cfg.account_user_id}/chats",
                              {"limit": limit, "offset": offset})
        items = body.get("chats") or []
        return Page(items, body)

    def get_messages_page(self, chat_id: str, offset: int = 0,
                          limit: int | None = None) -> Page:
        """История сообщений чата v3 (новые сверху), limit ≤ 100 [ФАКТ]."""
        limit = limit or self.cfg.messages_page_clamped
        body = self._get_json(
            "v3.messages",
            f"/messenger/v3/accounts/{self.cfg.account_user_id}/chats/{chat_id}/messages/",
            {"limit": limit, "offset": offset})
        items = body.get("messages") or []
        return Page(items, body)

    # -------------------------------------------------------------- backoff
    def _retry_after(self, r) -> float | None:
        try:
            v = r.headers.get("Retry-After") or r.headers.get("retry-after")
            return float(v) if v else None
        except (TypeError, ValueError):
            return None

    def _backoff(self, attempt: int, retry_after: float | None = None) -> None:
        if attempt >= self.cfg.retries_max:
            return
        delay = min(self.cfg.backoff_base_s * (2 ** attempt) + random.uniform(0, 0.3),
                    self.cfg.backoff_cap_s)
        if retry_after:
            delay = min(max(delay, retry_after), self.cfg.backoff_cap_s)
        time.sleep(delay)

    def stat(self) -> dict:
        return {"calls": dict(sorted(self.calls.items())), "total": self.total_calls,
                "sum_s": round(self.wall_s, 2), "rate_limit_headers": self.rate_limit_seen}
