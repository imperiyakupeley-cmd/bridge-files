"""client_credentials-аутентификация Avito API из защищённого хранилища.

Ключи читаются из файла (env AVITO_CREDENTIALS_JSON, по умолчанию
~/Avito/avito-api-credentials.json — [ФАКТ, аудит 09.11 §4]). Токен живёт в
памяти с истечением по expires_in; при 401 инвалидируется и берётся заново
(один retry на вызове клиента). Токен и client_secret НИКОГДА не попадают в
логи/ошибки/repr (detail маскируется на стороне transport; здесь — guard).
"""
from __future__ import annotations

import json
import os
import time

from .errors import AccessDenied, NetworkError, RateLimitError, ServerError, SourceError


class Credentials:
    """Содержимое защищённого хранилища. repr маскирован."""

    __slots__ = ("client_id", "client_secret", "user_id", "api_base", "token_url", "path")

    def __init__(self, path: str):
        self.path = path
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
        except FileNotFoundError as e:
            raise SourceError(f"хранилище ключей не найдено: {path}", source="auth") from e
        except ValueError as e:
            raise SourceError("хранилище ключей: невалидный JSON", source="auth") from e
        self.client_id = data.get("client_id")
        self.client_secret = data.get("client_secret")
        self.user_id = data.get("user_id")
        self.api_base = str(data.get("api_base") or "https://api.avito.ru").rstrip("/")
        self.token_url = str(data.get("token_url") or "https://api.avito.ru/token")
        if not self.client_id or not self.client_secret or not self.user_id:
            raise SourceError("хранилище ключей: нет client_id/client_secret/user_id",
                              source="auth")

    def __repr__(self) -> str:  # секрет не печатаем
        return (f"Credentials(path={self.path!r}, client_id=***, "
                f"user_id={self.user_id}, api_base={self.api_base!r})")


class TokenManager:
    """Токен в памяти: кэш по expires_in (с запасом 60 c), обновление при 401."""

    SAFETY_S = 60

    def __init__(self, creds: Credentials, transport, *, timeout_s: float = 20.0):
        self.creds = creds
        self.transport = transport
        self.timeout_s = timeout_s
        self._token: str | None = None
        self._expires_at = 0.0
        self.fetches = 0

    def token(self) -> str:
        if self._token and time.monotonic() < self._expires_at:
            return self._token
        return self._fetch()

    def invalidate(self) -> None:
        self._token = None
        self._expires_at = 0.0

    def _fetch(self) -> str:
        t0 = time.monotonic()
        r = self.transport.post(self.creds.token_url, {
            "grant_type": "client_credentials",
            "client_id": self.creds.client_id,
            "client_secret": self.creds.client_secret,
        }, self.timeout_s)
        if r.status in (429, 500, 502, 503, 504):
            raise (RateLimitError if r.status == 429 else ServerError)(
                f"token: HTTP {r.status} ({time.monotonic() - t0:.1f} c)", source="auth")
        if r.status in (400, 401, 403):
            raise AccessDenied("token: отклонён (ключи/доступ)", source="auth")
        if r.status != 200:
            raise ServerError(f"token: HTTP {r.status}", source="auth")
        try:
            body = r.json()
        except ValueError as e:
            raise NetworkError("token: невалидный JSON", source="auth") from e
        tok = body.get("access_token")
        if not tok:
            raise SourceError("token: ответ без access_token", source="auth")
        try:
            expires_in = float(body.get("expires_in") or 3600)
        except (TypeError, ValueError):
            expires_in = 3600
        self._token = str(tok)
        self._expires_at = time.monotonic() + max(1.0, expires_in - self.SAFETY_S)
        self.fetches += 1
        return self._token
