"""Строгое слияние Б24 ↔ Avito v3 — exact-IDs-only (директивы владельца 09.11:
мосты mw912x028ygf и mw912vdyd7fq).

ЗАПРЕЩЕНО категорически и без исключений: привязка клиента/чата/сообщения по
похожести текста, подписи, телефону, имени или окну времени (±N минут) —
в том числе «только как кандидаты». Движок при соединении НЕ читает текст,
имена, телефоны и НЕ сравнивает времена: ключи — только стабильные
технические ID. Время используется лишь для сортировки фактов и честной
coverage-метки прогрева, не для склейки (доказывается тестом: затирание всех
текстов и сдвиг всех времён не меняют результат слияния).

Разрешённые пути привязки Avito→CRM:
  чат:  u2i ↔ chatId Б24 — ТОЛЬКО подтверждённое соответствие стабильных ID:
        inline-mapping запроса, entity_id диалога
        `avito|{line}|{u2i}|{connector_user_id}`, персистентный индекс
        (наполняется ТОЛЬКО этими источниками). Коллизия (один u2i заявлен
        2+ чатами или один чат 2+ u2i) → привязки НЕТ (AMBIGUOUS), WARN.
  сообщение: params.CONNECTOR_MID (Б24) == id сообщения Авито, 1:1 В ОБЕ
        стороны, внутри подтверждённой пары чатов. Дубль ключа с любой
        стороны или ключ, заявленный ЧУЖИМ чатом → AMBIGUOUS без склейки.
        Совпадение одного CONNECTOR_MID доказывает связь только этого
        сообщения и НЕ доказывает привязку кластера карточек CRM —
        дубли клиентов и кластеризация решаются downstream
        (модуль messages, crm_status AMBIGUOUS при дублях сущностей).

Статусы в payload каждого факта:
  chat_binding: LINKED | UNLINKED | AMBIGUOUS — подтверждённая связка
                u2i↔chatId для чата факта.
  join_status:  LINKED | UNLINKED | AMBIGUOUS — сшивка сообщения с копией
                другой системы (exact-ключ или её отсутствие; причина —
                payload.join_reason).
  UNLINKED/AMBIGUOUS факты НЕ выбрасываются: остаются отдельными фактами
  (данные не теряются), но клиенту/менеджеру сверх родной стороны не
  засчитываются; WARN поимённый (только id, без текстов). Любой
  UNLINKED/AMBIGUOUS → статус ответа не выше PARTIAL (§4 честность).

Атрибуция сотрудника — ТОЛЬКО author_id копии Б24 (роль слитого факта —
от Б24; расхождение с ролью Авито-стороны → WARN author_crosscheck,
приоритет Б24 §5). author_id Авито НЕ равен Bitrix user_id и менеджеру
не приписывается: числовое совпадение author_id Авито с id сотрудника
чата — канарейка WARN, не соответствие. Б24-копии без авито-пары несут
родную атрибуцию (собственные id Б24) — это не склейка.

duplicate_guard: дедуп по (source, source_entity_id) — §7.5.
"""
from __future__ import annotations

from collections import defaultdict

from .facts import avito_fact, avito_role, connector_mid, b24_role, is_system_row, make_fact
from .timeutil import parse_iso_loose

SOURCE_MERGED = "merged.b24+avito.v3"
SOURCE_B24 = "b24.ol"

# ── запрет эвристик на уровне API (директива 09.11, как в модуле messages) ──
# Эти ключи нельзя даже ПЕРЕДАТЬ в слияние — любой из них → SchemaError.
FORBIDDEN_JOIN_OPTIONS = frozenset({
    "window_minutes", "fuzzy_window_min", "time_window_s", "time_window_minutes",
    "text_similarity", "min_similarity", "match_by_text", "match_by_phone",
    "match_by_name", "phone", "phones", "name", "names", "strip_signature",
    "signature_regex", "normalize_text", "fuzzy", "use_fuzzy",
    "similarity_threshold",
})

LINKED, UNLINKED, AMBIGUOUS = "LINKED", "UNLINKED", "AMBIGUOUS"


class MergeReport:
    def __init__(self):
        self.facts: list[dict] = []
        self.warnings: list[str] = []
        self.coverage: dict = {}

    def merge(self, other: "MergeReport") -> "MergeReport":
        self.facts.extend(other.facts)
        self.warnings.extend(other.warnings)
        for k, v in other.coverage.items():
            if isinstance(v, dict) and isinstance(self.coverage.get(k), dict):
                self.coverage[k].update(v)
            else:
                self.coverage[k] = v
        return self


def _ts_of_b24(row: dict):
    return parse_iso_loose(row.get("date"))


def _clip(text, max_len: int):
    return None if text is None else str(text)[:max_len]


def _set_link(fact: dict, *, chat_binding: str, join_status: str, reason: str) -> dict:
    fact["payload"]["chat_binding"] = chat_binding
    fact["payload"]["join_status"] = join_status
    fact["payload"]["join_reason"] = reason
    return fact


def _b24_fact(row: dict, chat_id, users_by_id: dict, u2i: str | None,
              *, max_text_len: int, role_mode: str, warnings: list) -> dict:
    role, resolved = b24_role(users_by_id, row.get("author_id"))
    system = is_system_row(row, role)
    if not resolved and role != "CONNECTOR":
        warnings.append(f"chat{chat_id}#msg{row.get('id')}: автор {row.get('author_id')!r} "
                        f"не разрешён по users-блоку — роль WE, не молча (§7.3)")
    params = row.get("params") or {}
    mid = connector_mid(row)
    payload = {
        "text": _clip(row.get("text"), max_text_len),
        "system": system,
        "chat_id": chat_id,
        "u2i": u2i,
        "connector_mid": mid,
        "params_keys": sorted(params.keys())[:10],
        "author_resolved": resolved,
    }
    return make_fact(
        fact_type="message", source=SOURCE_B24,
        source_entity_id=f"chat{chat_id}#msg{row.get('id')}",
        timestamp=_ts_of_b24(row), author_id=row.get("author_id"),
        author_role=role, payload=payload,
        evidence={"connector_mid": mid}, role_mode=role_mode)


def _merged_fact(b24_row: dict, av_row: dict, chat_id, u2i: str, *, kind: str,
                 users_by_id: dict, max_text_len: int,
                 role_mode: str, warnings: list) -> dict:
    """Слитый факт: роль и атрибуция — ТОЛЬКО от копии Б24 (author_id Б24)."""
    base = _b24_fact(b24_row, chat_id, users_by_id, u2i, max_text_len=max_text_len,
                     role_mode=role_mode, warnings=warnings)
    base["source"] = SOURCE_MERGED
    base["source_entity_id"] = (
        f"chat{chat_id}#msg{b24_row.get('id')}+avito:{u2i}#msg:{av_row.get('id')}")
    av_role, _resolved, _ctype = avito_role(av_row, None)
    base["evidence"] = {
        **base.get("evidence", {}),
        "b24": {"source_entity_id": f"chat{chat_id}#msg{b24_row.get('id')}",
                "connector_mid": connector_mid(b24_row),
                "author_role_b24": base["author_role"]},
        "avito": {"source_entity_id": f"avito:{u2i}#msg:{av_row.get('id')}",
                  "message_id": str(av_row.get("id")),
                  "author_id": av_row.get("author_id"),
                  "direction": av_row.get("direction"),
                  "created_epoch": av_row.get("created"),
                  "author_role_avito": av_role},
        # kind — только "exact_connector_mid": других видов склейки не существует.
        "join": {"kind": kind},
    }
    if av_role != base["author_role"]:
        warnings.append(
            f"chat{chat_id}#msg{b24_row.get('id')}: расхождение ролей Б24="
            f"{base['author_role']} vs Авито={av_role} — приоритет Б24 (§5), WARN")
    return base


def merge_chat(b24: dict, avito_rows: list[dict] | None, u2i: str | None,
               chat_id=None, *, account_user_id=None, chat_binding: str = LINKED,
               foreign_mids: set[str] | None = None, foreign_av_ids: set[str] | None = None,
               max_text_len: int = 1000, role_mode: str = "extended") -> MergeReport:
    """Слияние одного чата. chat_binding — статус связки u2i↔chatId:
    LINKED (подтверждена индексом/mapping/entity_id), UNLINKED (нет связки),
    AMBIGUOUS (коллизия). При UNLINKED/AMBIGUOUS сшивки сообщений НЕ
    выполняются вовсе — fail-closed, привязка не выдумывается.

    foreign_mids / foreign_av_ids — ключи, заявленные ДРУГИМИ чатами
    (cross-chat защита): совпадение с ними → AMBIGUOUS, не склейка.
    """
    rep = MergeReport()
    warnings = rep.warnings
    foreign_mids = foreign_mids or set()
    foreign_av_ids = foreign_av_ids or set()
    users_by_id = {int(u.get("id")): u for u in (b24.get("users") or [])
                   if u.get("id") is not None}
    b24_rows = list(b24.get("messages") or [])
    avito_rows = list(avito_rows or [])
    av_by_id = {str(r.get("id")): r for r in avito_rows}

    joined_b24_ids: set[str] = set()
    joined_avito_ids: set[str] = set()
    ambiguous_b24_ids: set[str] = set()
    ambiguous_av_ids: set[str] = set()

    # ---- ТОЧНАЯ склейка: CONNECTOR_MID == avito.id, 1:1 в обе стороны.
    # Выполняется ТОЛЬКО при подтверждённой связке чата (chat_binding == LINKED).
    exact_pairs: list[tuple[dict, dict]] = []
    foreign_warned: set[str] = set()
    if chat_binding == LINKED:
        exact_by_av: dict[str, list[dict]] = defaultdict(list)
        for r in b24_rows:
            mid = connector_mid(r)
            if not mid:
                continue
            if mid in foreign_mids:
                # ключ заявлен другим чатом (или спорный между чатами) — верить
                # нельзя: AMBIGUOUS, склейки нет, поимённый WARN
                ambiguous_b24_ids.add(str(r.get("id")))
                if str(mid) in av_by_id:
                    ambiguous_av_ids.add(str(mid))
                if mid not in foreign_warned:
                    foreign_warned.add(mid)
                    warnings.append(
                        f"chat{chat_id}: CONNECTOR_MID {mid} заявлен также другим "
                        f"чатом — связка AMBIGUOUS, склейки нет (защита от "
                        f"перепутывания клиентов)")
                continue
            if str(mid) in av_by_id:
                exact_by_av[str(mid)].append(r)
        for aid, rows in exact_by_av.items():
            if len(rows) > 1 or aid in foreign_av_ids or aid in foreign_mids:
                ambiguous_b24_ids.update(str(r.get("id")) for r in rows)
                ambiguous_av_ids.add(aid)
                warnings.append(
                    f"chat{chat_id}: коллизия точного ключа {aid} — строки Б24 "
                    f"{[r.get('id') for r in rows]}; склейки нет (защита от ложных merges)")
                continue
            exact_pairs.append((rows[0], av_by_id[aid]))
    for r, ar in exact_pairs:
        joined_b24_ids.add(str(r.get("id")))
        joined_avito_ids.add(str(ar.get("id")))

    # ---- слитые факты (единственный вид сшивки: exact_connector_mid):
    # роль и атрибуция сотрудника — ТОЛЬКО от копии Б24
    for r, ar in exact_pairs:
        f = _merged_fact(r, ar, chat_id, u2i, kind="exact_connector_mid",
                         users_by_id=users_by_id,
                         max_text_len=max_text_len, role_mode=role_mode,
                         warnings=warnings)
        _set_link(f, chat_binding=chat_binding, join_status=LINKED,
                  reason="exact_connector_mid")
        rep.facts.append(f)

    # ---- Б24-строки без точной пары: факты как есть, родная атрибуция Б24
    rest_b24 = [r for r in b24_rows if str(r.get("id")) not in joined_b24_ids]
    cats = {"in": [], "out": [], "system": []}
    b24_in_joined_client = 0
    for r, _ar in exact_pairs:
        role, _res = b24_role(users_by_id, r.get("author_id"))
        if role == "CLIENT":
            b24_in_joined_client += 1
    for r in rest_b24:
        role, _res = b24_role(users_by_id, r.get("author_id"))
        if is_system_row(r, role):
            cats["system"].append(r)
        elif role == "CLIENT":
            cats["in"].append(r)
        else:
            cats["out"].append(r)
    b24_out_unpaired = 0
    for r in rest_b24:
        role, _res = b24_role(users_by_id, r.get("author_id"))
        f = _b24_fact(r, chat_id, users_by_id, u2i, max_text_len=max_text_len,
                      role_mode=role_mode, warnings=warnings)
        rid = str(r.get("id"))
        if rid in ambiguous_b24_ids or chat_binding == AMBIGUOUS:
            _set_link(f, chat_binding=chat_binding, join_status=AMBIGUOUS,
                      reason="connector_mid_collision" if rid in ambiguous_b24_ids
                      else "chat_binding_collision")
        else:
            if not f["payload"]["system"] and role in ("WE", "BOT", "UNKNOWN"):
                b24_out_unpaired += 1
            _set_link(f, chat_binding=chat_binding, join_status=UNLINKED,
                      reason=("no_chat_binding" if chat_binding == UNLINKED
                              else ("no_connector_mid" if not f["payload"]["connector_mid"]
                                    else "no_exact_key")))
        rep.facts.append(f)

    # ---- остаток Авито: fallback / прогрев / непарные входящие.
    # Сшивки нет — статус по связке чата; атрибуции сотруднику НЕТ никогда.
    min_b24_ts = min((t for t in (_ts_of_b24(r) for r in b24_rows) if t is not None),
                     default=None)
    av_facts: list[dict] = []
    for ar in avito_rows:
        aid = str(ar.get("id"))
        if aid in joined_avito_ids:
            continue
        f = avito_fact(ar, u2i or str(chat_id), account_user_id,
                       max_text_len=max_text_len, role_mode=role_mode,
                       warnings=warnings)
        if aid in ambiguous_av_ids or chat_binding == AMBIGUOUS:
            _set_link(f, chat_binding=chat_binding, join_status=AMBIGUOUS,
                      reason="connector_mid_collision" if aid in ambiguous_av_ids
                      else "chat_binding_collision")
        elif chat_binding == UNLINKED:
            _set_link(f, chat_binding=UNLINKED, join_status=UNLINKED,
                      reason="no_chat_binding")
        else:
            _set_link(f, chat_binding=LINKED, join_status=UNLINKED,
                      reason="no_exact_key")
        pre_dialog = (min_b24_ts is None) or (
            f["timestamp_dt"] is not None and f["timestamp_dt"] < min_b24_ts)
        if f["payload"].get("interest_event") == "chat_created_no_message":
            # «создал чат, но не написал»: в момент события первого сообщения
            # ещё нет → диалога ОЛ не существовало по смыслу маркера (аудит §3)
            pre_dialog = True
        f["payload"]["pre_dialog"] = bool(pre_dialog)
        if pre_dialog:
            warnings.append(
                f"avito {u2i}#msg{ar.get('id')}: отправлено ДО первого сообщения Б24 — "
                f"прогрев/догрев, диалога ОЛ ещё не было (ПРОПУСК №2)")
        if f["payload"].get("direction") == "in" and not f["payload"].get("system") \
                and str(ar.get("author_id")) not in ("0",):
            warnings.append(f"avito {u2i}#msg{ar.get('id')}: входящее без пары в Б24 "
                            f"(CONNECTOR_MID не найден) — потеря в Б24?")
        # канарейка: author_id Авито числово совпал с id сотрудника чата —
        # это НЕ соответствие, приписывать менеджеру запрещено (директива 09.11)
        a_author = ar.get("author_id")
        a_int = None
        if a_author is not None and str(a_author).lstrip("-").isdigit():
            a_int = int(str(a_author))
        if a_int is not None and a_int in users_by_id:
            u = users_by_id[a_int]
            if not u.get("connector") and not u.get("bot"):
                warnings.append(
                    f"avito {u2i}#msg{ar.get('id')}: author_id {a_author} числово "
                    f"совпал с id сотрудника Б24 — СОВПАДЕНИЕ НЕ ЯВЛЯЕТСЯ "
                    f"соответствием, менеджеру не приписано (директива 09.11)")
        av_facts.append(f)

    # ---- duplicate_guard: дедуп по (source, source_entity_id) — §7.5
    seen: set[tuple[str, str]] = set()
    dropped = 0
    ordered = rep.facts + av_facts
    rep.facts = []
    for f in ordered:
        key = (f["source"], f["source_entity_id"])
        if key in seen:
            dropped += 1
            continue
        seen.add(key)
        rep.facts.append(f)

    n_ambiguous = sum(1 for f in rep.facts
                      if f["payload"].get("join_status") == AMBIGUOUS)
    joined_exact = len(exact_pairs)
    av_out_total = sum(1 for r in avito_rows if r.get("direction") == "out")
    av_only_out = sum(1 for f in rep.facts
                      if f["source"].startswith("avito.")
                      and f["payload"].get("direction") == "out")
    av_only_out_warming = sum(1 for f in rep.facts
                              if f["source"].startswith("avito.")
                              and f["payload"].get("direction") == "out"
                              and f["payload"].get("pre_dialog"))
    n_unlinked = sum(1 for f in rep.facts
                     if f["payload"].get("join_status") == UNLINKED)
    rep.coverage = {
        "chat_id": chat_id, "u2i": u2i, "chat_binding": chat_binding,
        "b24_rows": len(b24_rows),
        "b24_in": len(cats["in"]) + b24_in_joined_client,
        "b24_out": len(cats["out"]), "b24_system": len(cats["system"]),
        "b24_out_without_avito_pair": b24_out_unpaired,
        "avito_rows": len(avito_rows), "avito_out_total": av_out_total,
        "joined_exact": joined_exact,
        "avito_only_out": av_only_out,
        "avito_only_out_fallback": av_only_out - av_only_out_warming,
        "avito_only_out_warming": av_only_out_warming,
        "unlinked": n_unlinked, "ambiguous": n_ambiguous,
        "collisions": n_ambiguous,
        "duplicate_guard_dropped": dropped,
    }
    return rep


def merge_chats(b24_chats: dict, avito_chats: dict, pairs: list | None = None, *,
                account_user_id=None, max_text_len: int = 1000,
                role_mode: str = "extended") -> MergeReport:
    """b24_chats: {chat_id: {users, messages}}; avito_chats: {u2i: [rows]};
    pairs: [(chat_id, u2i)] — ТОЛЬКО подтверждённые заявления привязки
    (индекс/mapping/entity_id). Коллизии привязок (u2i у 2+ чатов, чат у 2+
    u2i) → AMBIGUOUS без связки; чат без пары → UNLINKED с WARN (привязка
    не выдумывается).

    Cross-chat защита: CONNECTOR_MID или id сообщения Авито, заявленные в
    другом чате, не участвуют в склейке этого чата — только AMBIGUOUS.
    """
    pairs = [(str(c), str(u)) for c, u in (pairs or [])]
    rep = MergeReport()

    # ── коллизии привязок чат-уровня (fail-closed)
    u2i_chats: dict[str, set] = defaultdict(set)
    chat_u2is: dict[str, set] = defaultdict(set)
    for chat_id, u2i in pairs:
        u2i_chats[u2i].add(chat_id)
        chat_u2is[chat_id].add(u2i)
    colliding_u2i = {u for u, cs in u2i_chats.items() if len(cs) > 1}
    colliding_chats = {c for c, us in chat_u2is.items() if len(us) > 1}
    for u in sorted(colliding_u2i):
        rep.warnings.append(
            f"u2i {u} заявлен несколькими чатами {sorted(u2i_chats[u])} — "
            f"связка AMBIGUOUS, склейки нет (дубли клиентов не угадываем)")
    for c in sorted(colliding_chats):
        rep.warnings.append(
            f"chat{c} заявлен несколькими u2i {sorted(chat_u2is[c])} — "
            f"связка AMBIGUOUS, склейки нет")

    binding: dict[str, str] = {}
    resolved_u2i: dict[str, str] = {}
    for chat_id in (b24_chats or {}):
        c = str(chat_id)
        claims = chat_u2is.get(c, set())
        if not claims:
            binding[c] = UNLINKED
        elif len(claims) > 1 or claims & colliding_u2i:
            binding[c] = AMBIGUOUS
        else:
            binding[c] = LINKED
            resolved_u2i[c] = next(iter(claims))

    # ── cross-chat индексы ключей
    mid_owners: dict[str, set] = defaultdict(set)
    for chat_id, b24 in (b24_chats or {}).items():
        for r in (b24.get("messages") or []):
            m = connector_mid(r)
            if m:
                mid_owners[m].add(str(chat_id))
    av_id_owners: dict[str, set] = defaultdict(set)
    for u2i, rows in (avito_chats or {}).items():
        for r in rows or []:
            av_id_owners[str(r.get("id"))].add(str(u2i))
    av_id_dups = {i: os for i, os in av_id_owners.items() if len(os) > 1}
    for i, os_ in sorted(av_id_dups.items()):
        rep.warnings.append(
            f"avito message id {i} встречен в нескольких чатах {sorted(os_)} — "
            f"связка AMBIGUOUS, склейки нет")

    used_u2i: set[str] = set()
    n_coll = 0
    for chat_id, b24 in (b24_chats or {}).items():
        c = str(chat_id)
        u2i = resolved_u2i.get(c)
        rows = (avito_chats or {}).get(u2i, []) if u2i else []
        if u2i is None:
            rep.warnings.append(
                f"chat{c}: нет подтверждённого сопоставления u2i↔chatId — "
                f"Авито-сторона не привязана (UNLINKED, заполните индекс/mapping "
                f"по entity_id; эвристики запрещены)")
        foreign_mids = {m for m, cs in mid_owners.items()
                        if c not in cs or len(cs) > 1}  # спорный ключ — ядовит для всех
        # id сообщения Авито, существующий вне этой пары чатов (или в нескольких):
        # для склейки в этом чате не доказательство — только AMBIGUOUS
        foreign_av_ids = {i for i, os_ in av_id_owners.items()
                          if os_ != {u2i}} if u2i else set(av_id_owners)
        sub = merge_chat(b24, rows, u2i, chat_id, account_user_id=account_user_id,
                         chat_binding=binding[c], foreign_mids=foreign_mids,
                         foreign_av_ids=foreign_av_ids,
                         max_text_len=max_text_len, role_mode=role_mode)
        rep.facts.extend(sub.facts)
        rep.warnings.extend(sub.warnings)
        rep.coverage[c] = sub.coverage
        n_coll += sub.coverage.get("ambiguous", 0)
        if u2i:
            used_u2i.add(u2i)
    for u2i, rows in (avito_chats or {}).items():
        if u2i in used_u2i:
            continue
        cb = AMBIGUOUS if (u2i in colliding_u2i or u2i in av_id_dups) else UNLINKED
        sub = merge_chat({}, rows, u2i, None, account_user_id=account_user_id,
                         chat_binding=cb, foreign_mids=set(),
                         foreign_av_ids=set(),
                         max_text_len=max_text_len, role_mode=role_mode)
        rep.facts.extend(sub.facts)
        rep.warnings.extend(sub.warnings)
        rep.coverage[f"unmapped:{u2i}"] = sub.coverage
        if cb == UNLINKED:
            rep.warnings.append(
                f"u2i {u2i}: нет chatId в подтверждённом индексе — факты UNLINKED, "
                f"без привязки к CRM (эвристики запрещены)")
        n_coll += sub.coverage.get("ambiguous", 0)
    rep.coverage["_totals"] = {"chats": len((b24_chats or {})) + len(
        [u for u in (avito_chats or {}) if u not in used_u2i]),
        "collisions_total": n_coll}
    return rep
