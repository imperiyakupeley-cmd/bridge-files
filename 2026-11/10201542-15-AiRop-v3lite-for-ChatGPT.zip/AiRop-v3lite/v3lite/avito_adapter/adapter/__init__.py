"""Read-only адаптер Avito messenger API — ИИ-РОП v3 Lite (изолированный модуль).

Границы (спека admin2 §1/§5, аудит mw8a2dns3fp1 от 09.11.2026):
- ТОЛЬКО чтение: GET messenger/v2/accounts/{uid}/chats (листинг + маркеры
  карточных событий) и GET messenger/v3/accounts/{uid}/chats/{u2i}/messages/.
  Методов отправки/редактирования в клиенте НЕ СУЩЕСТВУЕТ (whitelist §whitelist).
- Ничего не пишет в боевой Авито, Б24, CRM и модуль dev_agent.
- Ключи client_credentials читаются из защищённого хранилища
  (~/Avito/avito-api-credentials.json, путь переопределяется env), в логи и
  ответы НЕ попадают (маскирование в transport).
- Боевой режим (сеть) выключен по умолчанию: требует AVITO_ADAPTER_LIVE=1.
"""
__version__ = "0.1.0"
