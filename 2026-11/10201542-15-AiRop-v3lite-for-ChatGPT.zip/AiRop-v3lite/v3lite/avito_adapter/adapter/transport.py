"""Транспорт адаптера: HTTP GET/POST, отделён от логики (подмена в тестах).

Каждый вызов проходит whitelist ДО соединения: GET — только листинг/сообщения,
POST — только token-адрес. Секрет не попадает в исключения: в detail уходит
только адрес без query и код статуса.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request

from .errors import NetworkError
from .whitelist import Whitelist

_UA = "airop-v3lite-avito-adapter/0.1 (read-only)"


class HttpResult:
    __slots__ = ("status", "headers", "body")

    def __init__(self, status: int, headers: dict, body: bytes):
        self.status = status
        self.headers = headers
        self.body = body

    def json(self):
        return json.loads(self.body.decode("utf-8"))


def build_get_url(base: str, path: str, params: dict | None) -> str:
    url = f"{base.rstrip('/')}{path}"
    if params:
        clean = {k: v for k, v in params.items() if v is not None}
        if clean:
            url += "?" + urllib.parse.urlencode(clean, doseq=True)
    return url


class Transport:
    """Синхронный транспорт. FakeTransport в тестах подменяет этот класс."""

    name = "urllib"

    def __init__(self, whitelist: Whitelist | None = None):
        self.whitelist = whitelist

    def get(self, url: str, timeout: float, headers: dict | None = None) -> HttpResult:
        if self.whitelist:
            self.whitelist.check_get(url)
        req = urllib.request.Request(url, method="GET",
                                     headers={"User-Agent": _UA, **(headers or {})})
        return self._open(req, timeout, url)

    def post(self, url: str, payload: dict, timeout: float) -> HttpResult:
        if self.whitelist:
            self.whitelist.check_post(url)
        req = urllib.request.Request(
            url, method="POST", data=urllib.parse.urlencode(payload or {}).encode(),
            headers={"Content-Type": "application/x-www-form-urlencoded",
                     "User-Agent": _UA})
        return self._open(req, timeout, url)

    def _open(self, req: urllib.request.Request, timeout: float, url: str) -> HttpResult:
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return HttpResult(r.status, dict(r.headers), r.read())
        except urllib.error.HTTPError as e:
            return HttpResult(e.code, dict(e.headers or {}), e.read())
        except Exception as e:  # сеть/DNS/таймаут
            raise NetworkError(f"{type(e).__name__}: {e}", source=url.split("?")[0].rsplit("/", 1)[-1]) from e
