"""u2i-chatId ↔ chatNNN: персистентный индекс (спека §5, аудит §4).

Источники пары:
- entity_id/userCode Б24: `avito|{lineId}|{u2i}|{connector_user_id}`
  [ФАКТ, аудит §1] — парсится из строк im.dialog.get / v2.Session.list;
- индекс боевого бота openline_index.json (read-only импорт, map u2i→chatId);
- inline-маппинг из запроса.

Хранилище — sqlite ТОЛЬКО адаптера (своя база, прод не трогается; calls.db и
v3_cache.db не используются). Non-avito линии (userCode не с префикса avito|N)
в индекс не попадают (фикстура C).
"""
from __future__ import annotations

import json
import os
import sqlite3

_ENTITY_RE = None  # lazy


def parse_entity_id(value) -> dict | None:
    """'avito|2|u2i-xxx|990' → {'channel':'avito','line':2,'u2i':'u2i-xxx',
    'connector_user_id':990}. Не-авито / мусор → None."""
    if not value or not isinstance(value, str):
        return None
    parts = value.split("|")
    if len(parts) < 3 or parts[0] != "avito":
        return None
    line = parts[1]
    if not line.isdigit():
        return None
    out = {"channel": "avito", "line": int(line), "u2i": parts[2],
           "connector_user_id": None}
    if len(parts) >= 4 and parts[3].isdigit():
        out["connector_user_id"] = int(parts[3])
    return out


class ChatIndex:
    def __init__(self, db_path: str | None = None):
        self.db_path = db_path
        self._mem: dict[str, dict] = {}   # u2i → {chat_id, line, source}
        if db_path:
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
            con = sqlite3.connect(db_path)
            try:
                con.execute(
                    "CREATE TABLE IF NOT EXISTS chat_map ("
                    " u2i TEXT PRIMARY KEY, chat_id INTEGER NOT NULL,"
                    " line INTEGER, source TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)")
                con.commit()
            finally:
                con.close()
            self._load()

    def _load(self) -> None:
        con = sqlite3.connect(self.db_path)
        try:
            for u2i, cid, line, src in con.execute(
                    "SELECT u2i, chat_id, line, source FROM chat_map"):
                self._mem[str(u2i)] = {"chat_id": int(cid), "line": line, "source": src}
        finally:
            con.close()

    # ---------------------------------------------------------------- writes
    def put(self, u2i: str, chat_id: int, *, line: int | None = None,
            source: str = "inline") -> None:
        rec = {"chat_id": int(chat_id), "line": line, "source": source}
        self._mem[str(u2i)] = rec
        if not self.db_path:
            return
        con = sqlite3.connect(self.db_path)
        try:
            con.execute(
                "INSERT INTO chat_map (u2i, chat_id, line, source, updated_at)"
                " VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)"
                " ON CONFLICT(u2i) DO UPDATE SET chat_id=excluded.chat_id,"
                " line=excluded.line, source=excluded.source,"
                " updated_at=CURRENT_TIMESTAMP",
                (str(u2i), int(chat_id), line, source))
            con.commit()
        finally:
            con.close()

    def put_dialog_rows(self, rows: list[dict]) -> int:
        """Строки im.dialog.get (entity_id, id) → индекс. Возвращает число новых."""
        added = 0
        for r in rows or []:
            ent = parse_entity_id(r.get("entity_id"))
            if ent and r.get("id") is not None:
                before = len(self._mem)
                self.put(ent["u2i"], int(r["id"]), line=ent["line"], source="dialog")
                added += 1 if len(self._mem) > before else 0
        return added

    def put_session_rows(self, rows: list[dict]) -> int:
        """Строки v2.Session.list (userCode, chatId) → индекс (фикстура C)."""
        added = 0
        for r in rows or []:
            ent = parse_entity_id(r.get("userCode"))
            if ent and r.get("chatId") is not None:
                before = len(self._mem)
                self.put(ent["u2i"], int(r["chatId"]), line=ent["line"], source="session")
                added += 1 if len(self._mem) > before else 0
        return added

    def import_bot_index(self, path: str, *, max_records: int | None = None) -> int:
        """Read-only импорт индекса боевого бота {map: {u2i: chatId}}."""
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (FileNotFoundError, ValueError):
            return 0
        m = data.get("map") or {}
        n = 0
        for u2i, cid in m.items():
            if max_records is not None and n >= max_records:
                break
            try:
                self.put(str(u2i), int(cid), source="bot_index")
                n += 1
            except (TypeError, ValueError):
                continue
        return n

    # ----------------------------------------------------------------- reads
    def get(self, u2i: str) -> int | None:
        rec = self._mem.get(str(u2i))
        return rec["chat_id"] if rec else None

    def reverse(self, chat_id: int) -> str | None:
        for u2i, rec in self._mem.items():
            if rec["chat_id"] == int(chat_id):
                return u2i
        return None

    def __len__(self) -> int:
        return len(self._mem)
