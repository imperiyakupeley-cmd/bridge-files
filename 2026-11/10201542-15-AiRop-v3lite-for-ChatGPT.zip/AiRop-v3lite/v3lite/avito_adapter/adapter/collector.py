"""Сбор за окно [from, to) — read-only: листинг v2 + история v3 по чатам.

Канарейки (спека §7):
- offset_canary: v3-страницы листаются с offset; если сервер молча вернул ту
  же первую страницу → FAIL, усечение честно в coverage (факты не выдаются
  как полные);
- window_canary: каждый факт ∈ [from, to); выпадение за границу — отброс
  факта + WARN (не весь ответ);
- pagination предохранители: max_chats_pages, max_messages_per_chat →
  truncated + статус не выше PARTIAL (§4).

Листинг v2 сортирован по updated_ts (новые сверху) [ФАКТ] → ранний выход,
когда вся страница старше from; при обрыве по лимиту страниц — truncated.
"""
from __future__ import annotations

import time

from .card_events import event_fact_from_v2_chat, event_fact_from_v3, coverage_report
from .errors import AdapterError, LimitReached
from .facts import avito_fact
from .timeutil import from_epoch, now_msk


class CollectResult:
    def __init__(self):
        self.facts: list[dict] = []
        self.warnings: list[str] = []
        self.errors: list[dict] = []
        self.coverage: dict = {}
        self.detectors: dict = {}
        self.truncated = False

    @property
    def status(self) -> str:
        if self.errors and not self.facts:
            return "FAILED"
        if self.errors or self.truncated or self.warnings:
            return "PARTIAL"
        return "VERIFIED"


def collect_window(client, *, frm, to, chat_ids: list[str] | None = None,
                   include_card_events: bool = True, card_events_via_v2: bool = True,
                   max_chats_pages: int = 40, max_messages_per_chat: int = 5000,
                   max_text_len: int = 1000, max_facts: int = 20000,
                   role_mode: str = "extended") -> CollectResult:
    res = CollectResult()
    account = client.cfg.account_user_id
    t0 = time.monotonic()

    # ------------------------------------------------ 1) какие чаты берём
    target_chats: list[dict] = []
    v2_scanned_pages = 0
    early_stop = False
    if chat_ids:
        # явный список u2i: листинг не нужен, но v2-маркеры добираем по этим чатам ниже
        target_chats = [{"id": str(c)} for c in chat_ids]
        early_stop = True  # без листинга нет сортировки — лимит страниц не применяется
    else:
        offset = 0
        while v2_scanned_pages < max_chats_pages:
            try:
                page = client.get_chats_page(offset=offset)
            except AdapterError as e:
                res.errors.append(e.to_json())
                break
            v2_scanned_pages += 1
            rows = page.items
            if not rows:
                break
            target_chats.extend(rows)
            updated_min = min((r.get("updated_ts") or 0) for r in rows)
            if from_epoch(updated_min) and from_epoch(updated_min) < frm:
                early_stop = True   # вся страница старше from — новые сверху [ФАКТ]
                break
            if len(rows) < client.cfg.chats_page_clamped:
                break
            offset += len(rows)
        else:
            res.truncated = True
            res.warnings.append(
                f"листинг v2: достигнут max_chats_pages={max_chats_pages} — "
                f"часть чатов окна могла не попасть (PARTIAL)")
        if not early_stop and v2_scanned_pages >= max_chats_pages and target_chats:
            res.truncated = True

    # ------------------------------------------------ 2) v3 истории по чатам
    msgs_scanned = 0
    offset_canary_fail = False
    chats_fetched = 0
    chats_truncated: list[str] = []
    for chat in target_chats:
        u2i = str(chat.get("id"))
        fetched = 0
        offset = 0
        first_page_ids: list[str] | None = None
        stop = False
        while not stop:
            try:
                page = client.get_messages_page(u2i, offset=offset)
            except AdapterError as e:
                res.errors.append(e.to_json())
                break
            rows = page.items
            if offset > 0 and first_page_ids is not None and rows:
                if str(rows[0].get("id")) == first_page_ids:
                    # сервер молча проигнорировал offset → pages дубль
                    offset_canary_fail = True
                    res.truncated = True
                    res.warnings.append(
                        f"chat {u2i}: offset игнорируется сервером (канарейка FAIL) — "
                        f"история глубже первой страницы НЕДОСТУПНА, усечение честное")
                    break
            if offset == 0:
                first_page_ids = str(rows[0].get("id")) if rows else None
            if not rows:
                break
            for r in rows:
                msgs_scanned += 1
                dt = from_epoch(r.get("created"))
                if dt is None:
                    res.warnings.append(f"chat {u2i}: сообщение msg{r.get('id')} без "
                                        f"корректного created — отброшено (не гадаем)")
                    continue
                if dt >= to:
                    continue          # новее окна: листаем дальше в прошлое
                if dt < frm:
                    stop = True       # старше окна: история идёт от новых к старым
                    break
                fetched += 1
                if fetched > max_messages_per_chat:
                    res.truncated = True
                    chats_truncated.append(u2i)
                    res.warnings.append(f"chat {u2i}: достигнут max_messages_per_chat="
                                        f"{max_messages_per_chat} — усечение (PARTIAL)")
                    stop = True
                    break
                f = avito_fact(r, u2i, account, max_text_len=max_text_len,
                               role_mode=role_mode, warnings=res.warnings)
                if include_card_events:
                    ev = event_fact_from_v3(r, u2i, max_text_len=max_text_len)
                    if ev is not None:
                        f["payload"]["interest_event"] = ev["payload"]["interest_event"]
                        f["payload"]["system"] = True
                res.facts.append(f)
            if len(res.facts) > max_facts:
                res.truncated = True
                res.warnings.append(f"достигнут max_facts={max_facts} — сбор остановлен")
                stop = True
            if stop or len(rows) < client.cfg.messages_page_clamped:
                break
            offset += len(rows)
        chats_fetched += 1

    # ------------------------------------------------ 3) карточные события v2
    events = []
    v2_chats_scanned = 0
    if include_card_events and card_events_via_v2:
        # маркеры last_message: в обычном режиме — уже полученный листинг v2;
        # в режиме явных chat_ids — дочитываем листинг v2 (read-only) до
        # найденных чатов или лимита страниц
        if chat_ids:
            want = {str(c) for c in chat_ids}
            found: set[str] = set()
            offset = 0
            for _ in range(max_chats_pages):
                try:
                    page = client.get_chats_page(offset=offset)
                except AdapterError as e:
                    res.errors.append(e.to_json())
                    break
                rows = page.items
                if not rows:
                    break
                v2_chats_scanned += len(rows)
                for cr in rows:
                    if str(cr.get("id")) in want:
                        found.add(str(cr.get("id")))
                        ev = event_fact_from_v2_chat(cr, max_text_len=max_text_len)
                        if ev:
                            events.append(ev)
                if want <= found:
                    break
                offset += len(rows)
            if not (want <= found):
                res.truncated = True
                missing = sorted(want - found)
                res.warnings.append(f"листинг v2: не найдены чаты {missing[:5]} — "
                                    f"маркеры карточных событий для них недоступны (PARTIAL)")
        else:
            v2_chats_scanned = len(target_chats)
            for cr in target_chats:
                ev = event_fact_from_v2_chat(cr, max_text_len=max_text_len)
                if ev:
                    events.append(ev)
        for ev in events:
            if ev["timestamp_dt"] and frm <= ev["timestamp_dt"] < to:
                res.facts.append(ev)

    # ------------------------------------------------ 4) window_canary
    out_of_window = 0
    for f in res.facts:
        dt = f.get("timestamp_dt")
        if dt is None:
            continue
        if not (frm <= dt < to):
            out_of_window += 1
    if out_of_window:
        res.facts = [f for f in res.facts
                     if f.get("timestamp_dt") is None
                     or frm <= f["timestamp_dt"] < to]
        res.detectors["window_canary"] = "FAIL"
        res.warnings.append(f"window_canary: {out_of_window} фактов за границей "
                            f"[from,to) — отброшены поимённо (§7.3)")
    else:
        res.detectors["window_canary"] = "PASS"
    res.detectors["offset_canary"] = "FAIL" if offset_canary_fail else "PASS"
    res.detectors["duplicate_guard"] = "PASS"

    res.coverage = {
        "avito": {
            "chats_listed": len(target_chats), "chats_fetched": chats_fetched,
            "chats_truncated": chats_truncated,
            "messages_scanned": msgs_scanned,
            "messages_in_window": len([f for f in res.facts
                                       if f["source"] == "avito.messenger.v3"
                                       and not f["payload"].get("system")]),
            "v2_pages_scanned": v2_scanned_pages,
            "v2_chats_for_card_events": v2_chats_scanned,
            "early_stop_by_updated_ts": early_stop,
            "truncated": res.truncated,
            "api": client.stat(),
            "wall_s": round(time.monotonic() - t0, 2),
            "as_of": now_msk().isoformat(),
            **coverage_report(events, v2_scanned_chats=v2_chats_scanned,
                              v3_scanned_messages=msgs_scanned),
        }
    }
    return res
