"""Whitelist сетевых вызовов — ЖЁСТКАЯ гарантия read-only (до любого байта в сеть).

Разрешено ТОЛЬКО:
- POST {token_url}            — client_credentials (auth.py, единственный POST);
- GET  {api}/messenger/v2/accounts/{uid}/chats?limit&offset        (листинг);
- GET  {api}/messenger/v3/accounts/{uid}/chats/{chat}/messages/?limit&offset.

Методов «отправить/прочитать-и-пометить/изменить чат» в адаптере НЕТ: url вне
белого списка → SecurityError ещё до открытия соединения. uid — только цифры,
chat_id — строгий шаблон [u2i/uuid] — защита от инъекций в путь.
"""
from __future__ import annotations

import re

from .errors import SecurityError

_UID = r"\d{1,12}"
# боевые u2i содержат «~» (замер 09.11: u2i-JzW7xj5vnZ3n~eIla~CyaA); точки и
# слэши запрещены — отсекают «..» и инъекции пути
_CHAT = r"[A-Za-z0-9_\-~]{1,80}"

_RE_CHATS = re.compile(
    rf"^{re.escape('__API__')}/messenger/v2/accounts/({_UID})/chats/?(\?.*)?$")
_RE_MESSAGES = re.compile(
    rf"^{re.escape('__API__')}/messenger/v3/accounts/({_UID})/chats/({_CHAT})/messages/?(\?.*)?$")


class Whitelist:
    def __init__(self, api_base: str, token_url: str):
        self.api_base = api_base.rstrip("/")
        self.token_url = token_url

    # ------------------------------------------------------------- checks
    def check_get(self, url: str) -> None:
        if url.startswith(self.token_url):
            # GET токена не бывает: client_credentials только POST → запрещаем.
            raise SecurityError("GET по token-адресу вне whitelist (client_credentials — только POST)")
        if _RE_CHATS.match(url.replace(self.api_base, "__API__", 1)) or \
                _RE_MESSAGES.match(url.replace(self.api_base, "__API__", 1)):
            return
        raise SecurityError(f"GET вне whitelist: {self._mask(url)}")

    def check_post(self, url: str) -> None:
        if url.rstrip("/").rstrip("/") == self.token_url.rstrip("/"):
            return
        raise SecurityError(f"POST вне whitelist (адаптер read-only): {self._mask(url)}")

    # -------------------------------------------------------------- utils
    @staticmethod
    def _mask(url: str) -> str:
        # секретов в url нет (токен уходит в заголовке), но хвост query не логируем
        return url.split("?")[0]
