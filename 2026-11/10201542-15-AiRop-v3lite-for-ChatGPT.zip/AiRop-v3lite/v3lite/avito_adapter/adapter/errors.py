"""Коды ошибок адаптера — таксономия контракта admin2 §4 (как в модуле messages).

SCHEMA | SOURCE_429 | SOURCE_5XX | SOURCE_NET | SOURCE_ERROR |
ACCESS_DENIED | NOT_FOUND | NOT_IMPLEMENTED | FILTER_CANARY | LIMIT | SECURITY
"""
from __future__ import annotations


class AdapterError(Exception):
    code = "SOURCE_ERROR"

    def __init__(self, detail: str = "", *, source: str = ""):
        super().__init__(detail or self.code)
        self.detail = detail or self.code
        self.source = source

    def to_json(self) -> dict:
        # detail не содержит токен/ключи: транспорт маскирует секреты.
        return {"code": self.code, "source": self.source, "detail": self.detail[:500]}


class SchemaError(AdapterError):
    """Нарушение контракта запроса. FAILED ДО любого сетевого вызова."""
    code = "SCHEMA"


class SecurityError(AdapterError):
    """Попытка недопустимого вызова (не read-only / не whitelist). Запрет ДО сети."""
    code = "SECURITY"


class SourceError(AdapterError):
    """Источник упал после всех ретраев."""
    code = "SOURCE_ERROR"


class RateLimitError(SourceError):
    code = "SOURCE_429"


class ServerError(SourceError):
    code = "SOURCE_5XX"


class NetworkError(SourceError):
    code = "SOURCE_NET"


class AccessDenied(SourceError):
    code = "ACCESS_DENIED"


class NotFoundError(SourceError):
    code = "NOT_FOUND"


class LimitReached(SourceError):
    """Административный лимит (страницы, max_facts, max_messages_per_chat)."""
    code = "LIMIT"
