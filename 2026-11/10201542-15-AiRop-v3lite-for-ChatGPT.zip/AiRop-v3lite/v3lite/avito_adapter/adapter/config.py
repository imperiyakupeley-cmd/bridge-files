"""Конфиг адаптера. Изолирован: не импортирует core/messages и прод-код.

Безопасность:
- ключи client_credentials — из защищённого файла (env AVITO_CREDENTIALS_JSON,
  по умолчанию ~/Avito/avito-api-credentials.json [ФАКТ, аудит 09.11 §4]);
- сеть МОЖНО включить ТОЛЬКО явным AVITO_ADAPTER_LIVE=1 (offline по умолчанию:
  боевой режим не включается молча — решение владельца, как в модуле messages).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

_CREDS_DEFAULT = os.path.expanduser("~/Avito/avito-api-credentials.json")

# --- проверенные константы API [ФАКТ, аудит 09.11] -----------------------------
MESSAGES_PAGE = 100            # ?limit=100 работает (v3 messages)
MESSAGES_PAGE_MAX = 100
CHATS_PAGE = 50                # v2 листинг, консервативно; сервер может отдать меньше
CHATS_PAGE_MAX = 100
RATE_RPS = 2.0                 # лимиты Avito не замеряны → консервативно (спека §5)
TIMEOUT_S = 20.0
RETRIES_MAX = 3                # §7.6: максимум 3 ретрая с backoff
BACKOFF_BASE_S = 0.7
BACKOFF_CAP_S = 20.0

MAX_FACTS_DEFAULT = 20_000
MAX_TEXT_LEN_DEFAULT = 1000    # потолок 4000 (как в модуле messages)
MAX_MESSAGES_PER_CHAT_DEFAULT = 5000
MAX_CHATS_PAGES_DEFAULT = 40   # предохранитель листинга v2

# маркеткеры карточных событий (аудит §3, фикстура D): [Системное сообщение] …
SYSTEM_PREFIX = "[Системное сообщение]"


def _read_env_file(path: str) -> dict:
    env: dict[str, str] = {}
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env[k.strip()] = v.strip().strip('"').strip("'")
    except (FileNotFoundError, PermissionError):
        pass
    return env


@dataclass
class AvitoConfig:
    live: bool = False             # False → ЛЮБОЙ сетевой вызов запрещён
    creds_path: str = _CREDS_DEFAULT
    api_base: str = "https://api.avito.ru"
    token_url: str = "https://api.avito.ru/token"
    account_user_id: int | None = None
    rate_rps: float = RATE_RPS
    timeout_s: float = TIMEOUT_S
    retries_max: int = RETRIES_MAX
    backoff_base_s: float = BACKOFF_BASE_S
    backoff_cap_s: float = BACKOFF_CAP_S
    chats_page: int = CHATS_PAGE
    messages_page: int = MESSAGES_PAGE
    max_facts: int = MAX_FACTS_DEFAULT
    max_text_len: int = MAX_TEXT_LEN_DEFAULT
    max_messages_per_chat: int = MAX_MESSAGES_PER_CHAT_DEFAULT
    max_chats_pages: int = MAX_CHATS_PAGES_DEFAULT
    index_db: str = field(
        default_factory=lambda: os.path.expanduser(
            "~/AiRop/v3lite/avito_adapter/avito_chat_index.db"))
    bot_index_path: str = os.path.expanduser("~/Avito/night-bot/openline_index.json")
    author_role_mode: str = "extended"   # extended: UNKNOWN как роль; contract: UNKNOWN→CONNECTOR

    @property
    def messages_page_clamped(self) -> int:
        return max(1, min(self.messages_page, MESSAGES_PAGE_MAX))

    @property
    def chats_page_clamped(self) -> int:
        return max(1, min(self.chats_page, CHATS_PAGE_MAX))


def load_config(env: dict | None = None, environ: dict | None = None) -> AvitoConfig:
    """env — содержимое .env (тесты), environ — os.environ-подобный словарь.

    Секреты из файла ключей ЗДЕСЬ не читаются (их читает auth при живом вызове):
    конфиг остаётся безопасно печатаемым, offline-конфиг — по умолчанию.
    """
    e = dict(_read_env_file(_CREDS_DEFAULT) if env is None else env)
    o = dict(os.environ if environ is None else environ)
    cfg = AvitoConfig(
        live=o.get("AVITO_ADAPTER_LIVE", "").strip() == "1",
        creds_path=o.get("AVITO_CREDENTIALS_JSON") or _CREDS_DEFAULT,
        index_db=o.get("AVITO_ADAPTER_INDEX_DB") or os.path.expanduser(
            "~/AiRop/v3lite/avito_adapter/avito_chat_index.db"),
        rate_rps=float(o.get("AVITO_RATE_RPS") or RATE_RPS),
        timeout_s=float(o.get("AVITO_TIMEOUT_S") or TIMEOUT_S),
        author_role_mode=o.get("AVITO_ROLE_MODE", "extended"),
    )
    if cfg.author_role_mode not in ("extended", "contract"):
        cfg.author_role_mode = "extended"
    return cfg
