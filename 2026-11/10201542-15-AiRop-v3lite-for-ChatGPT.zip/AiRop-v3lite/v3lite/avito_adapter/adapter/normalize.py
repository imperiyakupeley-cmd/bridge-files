"""Нормализация текстов и атрибуция авторов (спека §5/§8, аудит §3/§4).

Подпись исходящих на Авито-стороне: коннектор ОЛ добавляет «Имя Фамилия: » /
«Михаил: » к тексту. Снятие — слоёное: сначала строгий регэксп спеки §5,
затем расширенный (инициалы «Тестов Т.», две формы имени) — только для
direction=out и только если после снятия остаётся непустой текст. Для склейки
сравниваются ОБА варианта (сырой и без подписи) — неверное снятие подписи
нарушает равенство (пропуск склейки), но не создаёт ложной склейки.

Роли адаптера: WE | CLIENT | BOT | CONNECTOR (системные зеркала) | UNKNOWN.
UNKNOWN — неразрешённый/неподдержанный автор (спека §6: ответ менеджера из
приложения Авито не встречался в выборке 0/16 — при direction=out с чужим
author_id факту роль UNKNOWN + WARN, никогда не CLIENT без проверки).
Режим author_role_mode=contract сериализует UNKNOWN как CONNECTOR
(совместимость с замороженным enum §4) + payload.author_resolved=false.
"""
from __future__ import annotations

import re

from .config import SYSTEM_PREFIX

# строгий регэксп спеки §5: ^([А-ЯЁA-Z][а-яёА-ЯЁA-Z ]{1,40}):\s*
SPEC_SIGNATURE_RE = re.compile(r"^([А-ЯЁA-Z][а-яёА-ЯЁA-Z ]{1,40}):\s*")
# расширенный: «Фамилия Имя», «Имя», «Фамилия И.», «Имя О.», до 40 символов имени
EXT_SIGNATURE_RE = re.compile(
    r"^\s*([А-ЯЁA-Z][а-яёА-ЯЁA-Z]{1,30}(?:\s[А-ЯЁA-Z][а-яёА-ЯЁA-Z]{1,30})?"
    r"(?:\s[А-ЯЁA-Z]\.?)?)\s*:\s+")

_WS = re.compile(r"\s+")


def normalize_text(s) -> str:
    """Пробелы схлопнуть, края обрезать, регистр снять (спека §5)."""
    return _WS.sub(" ", str(s or "")).strip().lower()


def strip_signature(s) -> str:
    """Снять подпись «Имя: » с начала. Без совпадения — текст как есть."""
    t = str(s or "")
    m = SPEC_SIGNATURE_RE.match(t)
    if m and t[m.end():].strip():
        return t[m.end():]
    m = EXT_SIGNATURE_RE.match(t)
    if m and t[m.end():].strip():
        return t[m.end():]
    return t


def text_variants(s) -> frozenset:
    """Множество нормализованных вариантов текста (raw и без подписи)."""
    t = str(s or "")
    return frozenset({normalize_text(t), normalize_text(strip_signature(t))})


def is_system_text(s) -> bool:
    t = str(s or "")
    if t.startswith(SYSTEM_PREFIX):
        return True
    low = t.lower()
    return low.startswith("[системное сообщение]")


_CARD_MARKERS = (
    ("viewed_phone", re.compile(r"посмотрел\s+номер\s+телефона", re.I)),
    ("chat_created_no_message", re.compile(r"создал\s+чат,?\s+но\s+(пока\s+)?не\s+написал", re.I)),
    ("card_call", re.compile(r"(звонок\s+из\s+(карточки|объявления)|позвонил\s+из\s+объявления)", re.I)),
)


def classify_card_marker(s) -> str | None:
    """Маркер карточного события → ключ или None (фикстура D, аудит §3)."""
    t = str(s or "")
    if is_system_text(t):
        t = t[len(SYSTEM_PREFIX):] if t.startswith(SYSTEM_PREFIX) else ""
    for key, rx in _CARD_MARKERS:
        if rx.search(t):
            return key
    if is_system_text(str(s or "")):
        return "system_other"
    return None


# ------------------------------------------------------------------ авторы
ROLE_CONTRACT_MAP = {"UNKNOWN": "CONNECTOR"}   # режим contract (enum §4)


def serialize_role(role: str, mode: str = "extended") -> str:
    if mode == "contract" and role in ROLE_CONTRACT_MAP:
        return ROLE_CONTRACT_MAP[role]
    return role


def resolve_avito_role(direction, author_id, account_user_id) -> tuple[str, bool]:
    """Роль по направлению/автору Avito. Возвращает (роль, resolved).

    - out + автор = наш аккаунт → WE (человек или бот на стороне Авито не
      различим — sender_is_account фиксируется в payload);
    - in + чужой автор → CLIENT;
    - out + ЧУЖОЙ автор → UNKNOWN (возможный ответ из приложения Авито, §6);
    - in + НАШ автор → UNKNOWN (аномалия);
    - нет direction/author → UNKNOWN.
    """
    if direction not in ("in", "out") or author_id is None:
        return "UNKNOWN", False
    ours = (account_user_id is not None and str(author_id) == str(account_user_id))
    if direction == "out":
        return ("WE", True) if ours else ("UNKNOWN", False)
    return ("CLIENT", True) if not ours else ("UNKNOWN", False)
