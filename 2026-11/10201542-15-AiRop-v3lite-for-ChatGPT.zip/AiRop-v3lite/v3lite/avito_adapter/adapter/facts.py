"""Фабрика фактов адаптера — normalized schema admin2 §4 (подмножество сообщений).

fact_type: message (карточные события — message с payload.interest_event, т.к.
enum §4 расширенных типов не содержит; предложение v1.2 — см. README).
source: avito.messenger.v3 | avito.messenger.v2 | b24.ol | merged.b24+avito.v3
source_entity_id:
  b24:   chat{N}#msg{M}
  avito: avito:{u2i}#msg:{id}
  merged:chat{N}#msg{M}+avito:{u2i}#msg:{id}
author_role: WE | CLIENT | BOT | CONNECTOR | UNKNOWN (режимы сериализации —
см. normalize.serialize_role; UNKNOWN + author_resolved=false = неразрешённый
или неподдержанный автор, факт не выбрасывается — спека §4 fail-closed п.3).
Текст усечён до max_text_len; медиа не копируются (только признак).
"""
from __future__ import annotations

from .normalize import (classify_card_marker, is_system_text, resolve_avito_role,
                        serialize_role)
from .timeutil import datetime as _dt  # noqa: F401  (типизация в docstring)
from .timeutil import fmt_iso


class FactError(ValueError):
    pass


def _clip(text, max_len: int):
    t = str(text) if text is not None else None
    if t is None:
        return None
    return t[:max_len]


def make_fact(*, fact_type: str, source: str, source_entity_id: str,
              timestamp, author_id, author_role: str, crm_entity: dict | None = None,
              payload: dict | None = None, evidence: dict | None = None,
              role_mode: str = "extended") -> dict:
    if fact_type != "message":
        raise FactError(f"fact_type {fact_type!r} вне enum контракта §4")
    fact = {
        "fact_type": fact_type,
        "source": source,
        "source_entity_id": source_entity_id,
        "timestamp_dt": timestamp,
        "author_id": author_id,
        "author_role": author_role,
        "crm_entity": crm_entity,
        "payload": payload or {},
        "evidence": evidence or {},
    }
    fact["author_role_serialized"] = serialize_role(author_role, role_mode)
    return fact


def serialize_facts(facts: list[dict]) -> list[dict]:
    """timestamp_dt → ISO Europe/Moscow; служебные ключи убрать, роль — по режиму."""
    out = []
    for f in facts:
        g = {k: v for k, v in f.items() if k != "timestamp_dt"}
        g["timestamp"] = fmt_iso(f.get("timestamp_dt"))
        mode = f.get("author_role_serialized")
        if mode is not None:
            g["author_role"] = mode
            g.pop("author_role_serialized", None)
        out.append(g)
    return out


# ------------------------------------------------------------------- B24 сторона
def b24_role(users_map: dict, author_id) -> tuple[str, bool]:
    """Роль по users-блоку диалога (спека §8): connector→CLIENT, bot→BOT,
    0→CONNECTOR (системная строка), прочие→WE. Неразрешённый id → WE +
    resolved=False (не молча: warning добавляет joiner)."""
    if author_id in (0, "0", None, ""):
        return "CONNECTOR", (author_id is None)
    u = users_map.get(int(author_id)) if isinstance(author_id, (int, str)) and str(author_id).lstrip("-").isdigit() else None
    if not u:
        return "WE", False
    if u.get("connector") or u.get("external_auth_id") == "imconnector":
        return "CLIENT", True
    if u.get("bot"):
        return "BOT", True
    return "WE", True


def connector_mid(row: dict):
    """Значение CONNECTOR_MID из params (ключ склейки входящих §5)."""
    p = row.get("params") or {}
    v = p.get("CONNECTOR_MID")
    if isinstance(v, list):
        v = v[0] if v else None
    return str(v) if v not in (None, "") else None


def is_system_row(row: dict, role: str) -> bool:
    """Системная строка Б24: author 0, CODE (CHAT_TRANSFER…) или текст-маркер."""
    p = row.get("params") or {}
    if (row.get("author_id") in (0, "0")) or p.get("CODE"):
        return True
    return role == "CONNECTOR" or is_system_text(row.get("text"))


# ------------------------------------------------------------------ Avito сторона
def avito_role(row: dict, account_user_id) -> tuple[str, bool, str | None]:
    """Роль по direction/author_id + поддержка контента.

    Неподдержанный контент (не text): текста нет → факт с
    payload.content_supported=false, для фаззи-склейки не годится (joiner).
    """
    direction = row.get("direction")
    author_id = row.get("author_id")
    item = row.get("content") or {}
    ctype = row.get("type") or item.get("type") or "text"
    role, resolved = resolve_avito_role(direction, author_id, account_user_id)
    return role, resolved, ctype


def avito_fact(row: dict, chat_u2i: str, account_user_id, *, max_text_len: int = 1000,
               role_mode: str = "extended", warnings: list | None = None) -> dict:
    author_id = row.get("author_id")
    text = None
    item = row.get("content") or {}
    if isinstance(item, dict):
        text = item.get("text")
    elif isinstance(item, str):
        text = item
    ctype = row.get("type") or "text"
    if ctype == "system" or author_id in (0, "0"):
        # [ФАКТ, живой замер 09.11.2026]: v3 присылает type=system, author_id=0,
        # content.text присутствует (+ flow_id) — это системные строки, роль
        # CONNECTOR, автор не разрешается (не CLIENT!)
        role, resolved = "CONNECTOR", False
        system = True
        supported = bool(text)
    else:
        role, resolved, _t = avito_role(row, account_user_id)
        system = bool(text) and is_system_text(text)
        supported = ctype == "text"
    marker = classify_card_marker(text) if text else None
    payload = {
        "text": _clip(text, max_text_len) if text else None,
        "content_type": ctype,
        "content_supported": supported,
        "system": system,
        "direction": row.get("direction"),
        "chat_u2i": chat_u2i,
        "author_resolved": resolved,
        "sender_is_account": (account_user_id is not None and author_id is not None
                              and str(author_id) == str(account_user_id)),
    }
    if marker:
        payload["interest_event"] = marker
    if not supported and warnings is not None:
        warnings.append(
            f"avito {chat_u2i}#msg{row.get('id')}: неподдержанный тип контента "
            f"{ctype!r} — текста нет, в текстовую склейку не входит")
    ev = {"avito_message_id": str(row.get("id")),
          "avito_created_epoch": row.get("created")}
    from .timeutil import from_epoch
    return make_fact(
        fact_type="message", source="avito.messenger.v3",
        source_entity_id=f"avito:{chat_u2i}#msg:{row.get('id')}",
        timestamp=from_epoch(row.get("created")), author_id=author_id,
        author_role=role, payload=payload, evidence=ev, role_mode=role_mode)
