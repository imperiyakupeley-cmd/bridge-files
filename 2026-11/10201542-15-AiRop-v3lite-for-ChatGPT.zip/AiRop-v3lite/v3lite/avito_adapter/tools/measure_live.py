#!/usr/bin/env python3
"""Замеры READ-ONLY доступа к Avito messenger API (лимиты не были замерены —
спека §5/§6: политика 429 обязательна; этот инструмент закрывает пробел).

Что меряет (без текстов и личных данных в выгрузке):
- auth: время получения client_credentials-токена, число fetch;
- v2 листинг: латентность/страницу, размер страницы, заголовки rate-limit;
- v3 сообщения: латентность/страницу, поддержка offset (канарейка), размер;
- окно суток: сколько чатов/сообщений попадает, вызовы, wall-time.

Запуск (двойная защита: флаг + env, без них сети нет):
  AVITO_ADAPTER_LIVE=1 python3 tools/measure_live.py --pages 2 --chats 2
Результат: out/measure_avito_<UTC>.json (секретов и текстов НЕТ).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

from adapter.auth import Credentials, TokenManager        # noqa: E402
from adapter.client import AvitoClient                    # noqa: E402
from adapter.config import AvitoConfig                    # noqa: E402
from adapter.errors import AdapterError                   # noqa: E402
from adapter.timeutil import OFFSET, from_epoch           # noqa: E402
from adapter.transport import Transport                   # noqa: E402


def _mask_chat(u2i: str) -> str:
    """u2i → хеш-префикс: в выгрузке нет ни чат-id, ни текстов."""
    import hashlib
    return "chat_" + hashlib.sha256(str(u2i).encode()).hexdigest()[:10]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pages", type=int, default=2, help="страниц листинга v2")
    ap.add_argument("--chats", type=int, default=2, help="чатов для v3-замера")
    ap.add_argument("--day", default=None, help="сутки окна YYYY-MM-DD (МСК), по умолчанию вчера")
    ap.add_argument("--out", default=None)
    ap.add_argument("--live", action="store_true", help="разрешить сеть (нужен ещё и env=1)")
    args = ap.parse_args()

    if not args.live or os.environ.get("AVITO_ADAPTER_LIVE") != "1":
        print(json.dumps({"skipped": "нет --live и/или AVITO_ADAPTER_LIVE=1 — сети не было"},
                         ensure_ascii=False))
        return 0

    cfg = AvitoConfig(live=True)
    client = AvitoClient(cfg, Transport())
    out: dict = {"measured_at": datetime.now(OFFSET).isoformat(),
                 "account": cfg.account_user_id, "pages": args.pages,
                 "chats": args.chats, "readonly": True}

    # ---------------------------------------------------------------- auth
    creds = Credentials(cfg.creds_path)
    tm = TokenManager(creds, client.transport, timeout_s=cfg.timeout_s)
    t0 = time.monotonic()
    tm.token()
    out["auth"] = {"token_fetches": tm.fetches, "first_fetch_s": round(time.monotonic() - t0, 2)}

    # ---------------------------------------------------------------- v2
    lat, sizes = [], []
    for p in range(args.pages):
        t = time.monotonic()
        try:
            page = client.get_chats_page(offset=p * cfg.chats_page_clamped)
        except AdapterError as e:
            out["v2_error"] = e.to_json()
            break
        lat.append(round(time.monotonic() - t, 2))
        sizes.append(len(page.items))
    out["v2_chats"] = {"pages": len(lat), "latency_s_per_page": lat,
                       "page_sizes": sizes, "api": client.stat()}

    # ---------------------------------------------------------------- v3
    target = []
    for p in range(len(lat)):
        t = time.monotonic()
        page = client.get_chats_page(offset=p * cfg.chats_page_clamped)
        target.extend(str(c.get("id")) for c in page.items)
        del t
    target = target[:args.chats]
    per_chat = []
    for u2i in target:
        t = time.monotonic()
        try:
            page1 = client.get_messages_page(u2i)
        except AdapterError as e:
            per_chat.append({"chat": _mask_chat(u2i), "error": e.to_json()})
            continue
        dt1 = round(time.monotonic() - t, 2)
        n1 = len(page1.items)
        offset_supported = None
        dt2 = None
        if n1 >= cfg.messages_page_clamped:      # есть вторая страница — проверяем offset
            t = time.monotonic()
            page2 = client.get_messages_page(u2i, offset=n1)
            dt2 = round(time.monotonic() - t, 2)
            offset_supported = bool(page2.items) and \
                str(page2.items[0].get("id")) != (str(page1.items[0].get("id")) if page1.items else "")
        per_chat.append({"chat": _mask_chat(u2i), "page1_s": dt1, "page1_size": n1,
                         "page2_s": dt2, "offset_supported": offset_supported,
                         "first_created": (page1.items[0].get("created") if page1.items else None)})
    out["v3_messages"] = {"chats": per_chat, "api": client.stat()}

    # ---------------------------------------------------------------- окно
    day = args.day or (datetime.now(OFFSET) - timedelta(days=1)).strftime("%Y-%m-%d")
    frm = datetime.fromisoformat(day + "T00:00:00+03:00")
    to = frm + timedelta(days=1)
    calls_before = client.total_calls
    t0 = time.monotonic()
    in_window_msgs, chats_with_window = 0, 0
    for u2i in target:
        offset = 0
        while offset < 3000:
            try:
                page = client.get_messages_page(u2i, offset=offset)
            except AdapterError:
                break
            rows = page.items
            if not rows:
                break
            older = False
            for r in rows:
                dt = from_epoch(r.get("created"))
                if dt and frm <= dt < to:
                    in_window_msgs += 1
                if dt and dt < frm:
                    older = True
            if older or len(rows) < cfg.messages_page_clamped:
                break
            offset += len(rows)
        chats_with_window += 1
    out["window"] = {"day": day, "chats_sampled": chats_with_window,
                     "messages_in_window": in_window_msgs,
                     "api_calls_window_phase": client.total_calls - calls_before,
                     "wall_s": round(time.monotonic() - t0, 2)}
    out["rate_limit_headers_seen"] = client.rate_limit_seen

    path = args.out or os.path.join(
        HERE, "out", f"measure_avito_{datetime.now().strftime('%Y%m%d-%H%M%S')}.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    print(json.dumps({"ok": True, "output": path,
                      "summary": {"auth_s": out["auth"]["first_fetch_s"],
                                  "v2_pages": len(lat),
                                  "v2_latency_s": lat,
                                  "offset_supported": [c.get("offset_supported")
                                                       for c in out["v3_messages"]["chats"]],
                                  "window_day": out["window"]["day"],
                                  "window_msgs": in_window_msgs,
                                  "rate_headers": client.rate_limit_seen}},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
