#!/usr/bin/env python3
"""Живая приёмка протокола привязки Avito→CRM — §7.1–7.2 MAPPING_PROTOCOL.md.

Директива владельца 09.11.2026 (мость mw912vdyd7fq): перед любым боевым
включением — 3+ живых обезличенных кейса strict-join + кейсы дублей.
НИКАКОГО боевого включения здесь не происходит: чтение Б24 read-only
(вебхук), Avito read-only через адаптер (AVITO_ADAPTER_LIVE=1 на время
прогона, переменная не сохраняется нигде).

ЧТО ДЕЛАЕТ:
  1. imopenlines.v2.Session.list → первые страницы, фильтр avito-сессий
     (userCode avito|line|u2i|connector_user_id, есть chatId). Берёт 4 чата.
  2. im.dialog.get → entity_id; ДВУСТОРОННЯЯ сверка: entity_id.u2i == userCode.u2i
     (несовпадение → чат в отчёт как AMBIGUOUS-источник, в merge не идёт).
  3. im.dialog.messages.get (пагинация LAST_ID) → messages + users.
  4. Три прогона адаптера run.py avito_merge (+collect за 24ч, AVITO_ADAPTER_LIVE=1):
     A. правильный mapping      → ожидание LINKED-чаты, склейки только exact;
     B. mapping ПЕРЕПУТАН (swap u2i двух чатов) → 0 склеек, всё UNLINKED —
        неверная карта НЕ создаёт ложных принадлежностей (анти-контаминация);
     C. коллизия (один u2i у двух чатов) → оба AMBIGUOUS, 0 склеек.
  5. Отчёт обезличен: id-ы хешируются (sha256[:10]), тексты/телефоны/имена
     НЕ печатаются НИГДЕ. Секреты не печатаются.

Запуск:  python3 tools/acceptance_live_mw912vdyd7fq.py [--chats 4] [--hours 24]
Отчёт:   out/acceptance_avito_live_<штамп>.json + печать сводки на stdout.
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

from adapter.index import parse_entity_id  # noqa: E402

RUN = os.path.join(HERE, "run.py")
ENV_FILE = os.path.expanduser("~/AiRop/.env")
MSK = timezone(timedelta(hours=3))


def _h(val) -> str:
    """Обезличивание id для отчёта."""
    return "h" + hashlib.sha256(str(val).encode()).hexdigest()[:10]


def load_env(path: str) -> dict:
    env = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
    return env


def b24(webhook: str, method: str, params: dict, timeout: float = 25.0):
    body = json.dumps(params).encode()
    req = urllib.request.Request(webhook.rstrip("/") + "/" + method, data=body,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode())


def fetch_dialog_messages(webhook: str, chat_id: int, limit: int = 50,
                          max_pages: int = 6) -> dict:
    """im.dialog.messages.get пагинацией LAST_ID до дна (потолок max_pages*limit).
    Конверт вебхука разворачивается: {result: {messages, users}}."""
    rows, users = [], []
    last_id = None
    for _ in range(max_pages):
        params = {"DIALOG_ID": f"chat{chat_id}", "LIMIT": limit}
        if last_id is not None:
            params["LAST_ID"] = last_id
        res = b24(webhook, "im.dialog.messages.get", params)
        env = res.get("result") if isinstance(res, dict) and isinstance(
            res.get("result"), dict) else {}
        if not env:
            break
        users = env.get("users") or users
        page = env.get("messages") or []
        if not page:
            break
        rows.extend(page)
        last_id = min(int(m.get("id")) for m in page if m.get("id") is not None)
        if len(page) < limit:
            break
    return {"users": users, "messages": rows}


def run_adapter(request: dict, index_db: str, timeout: float = 240.0) -> dict:
    env = dict(os.environ)
    env["AVITO_ADAPTER_LIVE"] = "1"          # только на время прогона
    env["AVITO_ADAPTER_INDEX_DB"] = index_db
    p = subprocess.run([sys.executable, RUN], input=json.dumps(request),
                       capture_output=True, text=True, env=env, timeout=timeout)
    if p.returncode != 0:
        return {"status": "FAILED", "errors": [{"detail": p.stderr[:400]}]}
    return json.loads(p.stdout)


def merge_request(chats: dict, mapping: dict, u2is: list[str], hours: int,
                  account: int) -> dict:
    now = datetime.now(MSK).replace(microsecond=0)   # парсер адаптера: без долей секунд
    return {
        "request_id": f"acceptance-{int(time.time())}",
        "intent": "avito_merge",
        "account_user_id": account,
        "b24": {"chats": chats},
        "mapping": mapping,
        "collect": {"from": (now - timedelta(hours=hours)).isoformat(),
                    "to": now.isoformat(),
                    "options": {"chat_ids": u2is, "include_card_events": False,
                                "max_chats_pages": 6}},
    }


def summarize(out: dict) -> dict:
    """Обезличенная сводка ответа адаптера: только счётчики и хеши."""
    cov = out.get("coverage") or {}
    merge_cov = cov.get("merge") or {}
    per_chat = {}
    for k, v in merge_cov.items():
        if isinstance(v, dict) and k != "_totals":
            per_chat[_h(k)] = {kk: (v.get(kk) or 0) for kk in
                               ("chat_binding", "b24_rows", "avito_rows",
                                "joined_exact", "unlinked", "ambiguous")
                               if kk != "chat_binding"} | {
                               "chat_binding": v.get("chat_binding")}
    kinds = [((f.get("evidence") or {}).get("join") or {}).get("kind")
             for f in out.get("facts") or []]
    warn_kinds = {}
    for w in out.get("warnings") or []:
        key = ("collision" if "коллиз" in w or "заявлен несколькими" in w
               else "no_binding" if "нет подтверждённого сопоставления" in w
               else "no_pair" if "CONNECTOR_MID не найден" in w or "без пары" in w
               else "author_canary" if "СОВПАДЕНИЕ НЕ ЯВЛЯЕТСЯ" in w or "не разрешён" in w
               else "role_crosscheck" if "расхождение ролей" in w
               else "other")
        warn_kinds[key] = warn_kinds.get(key, 0) + 1
    return {"status": out.get("status"), "chats": per_chat,
            "facts_total": len(out.get("facts") or []),
            "merged": kinds.count("exact_connector_mid"),
            "kinds_set": sorted({k for k in kinds if k}),
            "warnings_total": len(out.get("warnings") or []),
            "warnings_kinds": warn_kinds,
            "errors": [e.get("code") for e in out.get("errors") or []]}


def main() -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--chats", type=int, default=4)
    ap.add_argument("--hours", type=int, default=24)
    ap.add_argument("--session-pages", type=int, default=6)
    args = ap.parse_args()

    envf = load_env(ENV_FILE)
    webhook = envf.get("BX_WEBHOOK")
    if not webhook:
        print("FAIL: BX_WEBHOOK не найден", file=sys.stderr)
        return 2

    # ── 1. avito-сессии: фильтр source=avito; u2i — из entity_id диалога
    # (протокол §2 источник №1); userCode — вторичная сверка, если парсится
    # (в проде формат userCode отличается от фикстурного avito|N|u2i|conn).
    # Листинг недатирован и перемешивается — собираем все страницы, сортируем
    # по dateCreate и берём САМЫЕ СВЕЖИЕ (у них есть живые сообщения в окне).
    picked_rows: list[dict] = []
    for page in range(args.session_pages):
        res = b24(webhook, "imopenlines.v2.Session.list",
                  {"limit": 200, "offset": page * 200})
        rows = (res.get("result") or {}).get("sessions") or []
        if not rows:
            break
        picked_rows.extend(r for r in rows
                           if r.get("source") == "avito" and r.get("chatId") is not None)
    picked_rows.sort(key=lambda r: str(r.get("dateCreate") or ""), reverse=True)
    picked: dict[str, dict] = {}
    for r in picked_rows[:args.chats]:
        picked[f"chat{r['chatId']}"] = {"chat_id": int(r["chatId"]),
                                        "session": r.get("id"),
                                        "usercode": r.get("userCode"),
                                        "created": str(r.get("dateCreate") or "")[:19]}
    if len(picked) < 3:
        print(json.dumps({"verdict": "FAIL", "reason": f"avito-сессий найдено "
                          f"{len(picked)} < 3 на первых {args.session_pages} страницах"},
                         ensure_ascii=False))
        return 1

    # ── 2. dialogs: entity_id — единственный авторитет u2i (протокол §2 п.1);
    # если userCode тоже парсится как avito-сущность, он обязан совпасть
    chats: dict[str, dict] = {}
    mapping: dict[str, str] = {}
    mismatch = []
    for key, meta in picked.items():
        cid = meta["chat_id"]
        res = b24(webhook, "im.dialog.get", {"DIALOG_ID": f"chat{cid}"})
        dlg = res.get("result") if isinstance(res.get("result"), dict) else {}
        ent_id = dlg.get("entity_id")
        parsed = parse_entity_id(ent_id)
        if not parsed:
            mismatch.append({"chat": _h(cid), "reason": "entity_id не avito"})
            continue
        uc = parse_entity_id(meta.get("usercode"))
        if uc and uc["u2i"] != parsed["u2i"]:
            mismatch.append({"chat": _h(cid), "reason": "userCode≠entity_id"})
            continue
        hist = fetch_dialog_messages(webhook, cid)
        chats[str(cid)] = {"users": hist["users"], "messages": hist["messages"],
                           "dialog": {"id": cid, "entity_id": ent_id}}
        mapping[str(cid)] = parsed["u2i"]
    if len(chats) < 3:
        print(json.dumps({"verdict": "FAIL", "reason": f"после сверки entity_id "
                          f"осталось чатов {len(chats)} < 3; отклонено: {mismatch}"},
                         ensure_ascii=False))
        return 1

    # ── 3. account_user_id из хранилища кредов адаптера
    from adapter.auth import Credentials
    from adapter.config import load_config
    cfg = load_config()
    account = int(Credentials(cfg.creds_path).user_id)

    u2is = list(mapping.values())
    idx_db = os.path.join(HERE, "out", f"acc_idx_{int(time.time())}.db")
    os.makedirs(os.path.dirname(idx_db), exist_ok=True)

    report: dict = {"when": datetime.now(MSK).isoformat(),
                    "directive": "mw912vdyd7fq / §7.1–7.2 MAPPING_PROTOCOL.md",
                    "chats_picked": len(chats),
                    "chat_hashes": sorted(_h(c) for c in chats),
                    "u2i_hashes": sorted(_h(u) for u in u2is),
                    "live": True, "read_only": True,
                    "battle_mode_enabled": False}

    # ── 4A. правильный mapping
    out_a = run_adapter(merge_request(chats, mapping, u2is, args.hours, account), idx_db)
    rep_a = summarize(out_a)
    report["A_correct_mapping"] = rep_a
    ok_a = (rep_a["status"] in ("VERIFIED", "PARTIAL")
            and rep_a["merged"] == sum(c["joined_exact"] for c in rep_a["chats"].values())
            and set(rep_a["kinds_set"]) <= {"exact_connector_mid"})
    meaningful = rep_a["facts_total"] > 0 and rep_a["merged"] > 0
    # анти-контаминация: слитый факт ссылается только на u2i СВОЕГО чата
    contamin = 0
    for f in out_a.get("facts") or []:
        if f.get("source") == "merged.b24+avito.v3":
            seid = f.get("source_entity_id", "")
            chat_part = seid.split("+")[0]              # "chat30300#msg1"
            chat_id = chat_part.split("#")[0][len("chat"):]
            u2i_part = (f.get("payload") or {}).get("u2i")
            if mapping.get(chat_id) != u2i_part:
                contamin += 1
    report["A_cross_client_contaminated_facts"] = contamin

    def _c(rep, cid):
        return rep["chats"].get(_h(cid)) or {}

    # ── 4B. перепутанный mapping (swap u2i первой пары чатов). Ожидание:
    # перепутанные чаты — AMBIGUOUS, 0 склеек; НЕЗАТРОНУТЫЕ чаты ведут себя
    # как в A (их подтверждённые пары остаются истинными утверждениями).
    cids = sorted(mapping)
    swapped = dict(mapping)
    swapped[cids[0]], swapped[cids[1]] = mapping[cids[1]], mapping[cids[0]]
    out_b = run_adapter(merge_request(chats, swapped, u2is, args.hours, account),
                        idx_db + ".b")
    rep_b = summarize(out_b)
    report["B_swapped_mapping"] = rep_b
    changed_b = [c for c in chats if swapped.get(str(c)) != mapping.get(str(c))]
    ok_b = rep_b["status"] in ("VERIFIED", "PARTIAL") and all(
        _c(rep_b, c)["chat_binding"] == "AMBIGUOUS"
        and _c(rep_b, c)["joined_exact"] == 0 for c in changed_b)
    ok_b = ok_b and all(
        _c(rep_b, c)["joined_exact"] == _c(rep_a, c)["joined_exact"]
        for c in chats if swapped.get(str(c)) == mapping.get(str(c)))

    # ── 4C. коллизия: один u2i на два чата (заявка первого дублируется вторым).
    # Ожидание: оба участника коллизии AMBIGUOUS с 0 склеек; остальные — как в A.
    collision = dict(mapping)
    collision[cids[1]] = mapping[cids[0]]
    out_c = run_adapter(merge_request(chats, collision, u2is, args.hours, account),
                        idx_db + ".c")
    rep_c = summarize(out_c)
    report["C_collision_mapping"] = rep_c
    colliding = {cids[0], cids[1]}
    ok_c = rep_c["status"] in ("VERIFIED", "PARTIAL") and all(
        _c(rep_c, c)["chat_binding"] == "AMBIGUOUS"
        and _c(rep_c, c)["joined_exact"] == 0 for c in colliding)
    ok_c = ok_c and all(
        _c(rep_c, c)["joined_exact"] == _c(rep_a, c)["joined_exact"]
        for c in chats if str(c) not in colliding)

    report["verdict"] = ("PASS" if (ok_a and meaningful and contamin == 0
                                    and ok_b and ok_c)
                         else "INCONCLUSIVE" if (ok_a and ok_b and ok_c
                                                 and not meaningful)
                         else "FAIL")
    report["checks"] = {"A_kinds_only_exact": ok_a,
                        "A_no_cross_client": contamin == 0,
                        "A_meaningful_live_joins": meaningful,
                        "B_swapped_zero_joins": ok_b,
                        "C_collision_ambiguous": ok_c}

    stamp = datetime.now(MSK).strftime("%Y%m%d-%H%M%S")
    out_path = os.path.join(HERE, "out", f"acceptance_avito_live_{stamp}.json")
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=1)
    print(json.dumps(report, ensure_ascii=False, indent=1))
    print("saved:", out_path)
    return 0 if report["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
