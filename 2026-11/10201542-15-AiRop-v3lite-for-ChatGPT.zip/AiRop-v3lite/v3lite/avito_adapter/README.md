# avito_adapter — read-only источник Avito messenger API (v3lite, изолированный)

Независимый адаптер по проверенным находкам аудита mw8a2dns3fp1
(~/AiRop/out/audit_avito_source_20261109.md) и контракту admin2 v1.1
(~/AiRop/spec_v3lite_admin2.md §5, §9.6, §11.5–11.6). Закрывает второй
ОБЯЗАТЕЛЬНЫЙ источник сообщений Авито: без него день менеджера теряет
~200–300 наших исходящих в месяц (fallback бота прямым API + прогрев до
создания диалога ОЛ) и все карточные события.

Границы: ТОЛЬКО чтение. Ничего не отправляет клиентам, не правит объявления,
CRM, боевые файлы ~/AiRop и модуль dev_agent. Методов записи в коде НЕ
СУЩЕСТВУЕТ (whitelist до любого сетевого байта — adapter/whitelist.py).
Боевые каталоги не тронуты: всё живёт в этом каталоге.

## Запуск

```bash
cd ~/AiRop/v3lite/avito_adapter
echo '<JSON-запрос>' | python3 run.py
```

stdin JSON → stdout JSON (как в модуле messages и стыке §10). НИКАКОЙ сети
по умолчанию: без AVITO_ADAPTER_LIVE=1 — FAILED/LIMIT до единого сетевого
вызова. Боевой режим включается только явно (решение владельца).

## Тесты

```bash
cd ~/AiRop/v3lite/avito_adapter && python3 -m pytest tests/ -q
# 91 passed (включая 10 сценариев cross-client contamination —
# tests/test_mapping_strict.py, строгую матрицу test_join_pair.py и
# cap-статуса test_status_cap.py). Сеть не используется; фикстуры immutable:
# перед прогоном проверяется SHA256SUMS (§11.6), расхождение = стоп.
```

## Живая приёмка §7 протокола (09.11.2026 — PASS, боевой режим НЕ включён)

`python3 tools/acceptance_live_mw912vdyd7fq.py --chats 4 --hours 2160` —
read-only: Б24 (сессии/диалоги через вебхук) + Авито (адаптер, живой сбор).
4 реальных чата, 143 факта, 7 точных склеек, только exact_connector_mid,
0 кросс-клиентской контаминации; перепутанный mapping и коллизия u2i не
создают ни одной ложной принадлежности (отчёт: out/acceptance_avito_live_*.json,
id-ы хешированы, без текстов). Ограничение: доступен ОДИН аккаунт Авито —
мульти-аккаунтность живьём не проверялась (синтетика:
test_multi_account_indexes_are_isolated, сценарий E strict-датасета).

## Замеры (read-only, 09.11.2026, аккаунт обезличен в выгрузке)

`AVITO_ADAPTER_LIVE=1 python3 tools/measure_live.py --live --pages 2 --chats 2 --day 2026-11-09`
→ out/measure_avito_*.json (без секретов, без текстов, чаты хешированы).

Замерено живьём: auth 0,3–1,3 с; листинг v2 — 50 чатов/страницу, 0,5–1,2 с;
v3 сообщения — 0,24 с/страницу; сутки (09.11) на 50 свежих чатах: 79
сообщений просканировано, 31 в окне, полный проход канареек PASS.
НЕ удалось подтвердить живьём: поддержка offset на v3 (450 свежих чатов —
ни одной полной страницы из 100). Канарейка offset в рантайме сама детектирует
молчаливое игнорирование и честно режет статус до PARTIAL (fail-closed §7.2).
Заголовки rate-limit в ответах не встретились; политика 429 — 3 ретрая с
backoff, затем SOURCE_429 в errors (§7.6).

## Контракт запроса (stdin)

### intent avito_merge — офлайн-слияние готовых страниц (сети не нужно)

```json
{"request_id": "<uuid4>", "intent": "avito_merge", "account_user_id": 83739743,
 "b24": {"chats": {"30300": {"users": [<users-блок im.dialog.messages.get>],
                              "messages": [<строки>],
                              "dialog": {"id": 30300, "entity_id": "avito|2|u2i-…|990"}}}},
 "avito": {"u2i-…": [<строки v3 messages>]},
 "mapping": {"30300": "u2i-…"},
 "options": {"max_text_len": 1000, "role_mode": "extended"}}
```

С mapping/диалогов заполняется персистентный индекс u2i↔chatId
(avito_chat_index.db, база ТОЛЬКО адаптера; дополнительно читается read-only
импорт из индекса боевого бота — путь в конфиге). Чат без сопоставления →
факты Авито выдаются unmapped + WARN (привязка не выдумывается).

Живой вариант: те же поля + `"collect": {"from": …, "to": …}` (и
AVITO_ADAPTER_LIVE=1) — Авито добирается из API в том же запросе и сливается
с переданным Б24.

### intent avito_collect — живой сбор за окно [from, to)

```json
{"request_id": "<uuid4>", "intent": "avito_collect",
 "from": "2026-11-09T00:00:00+03:00", "to": "2026-11-10T00:00:00+03:00",
 "options": {"chat_ids": ["u2i-…"], "include_card_events": true,
              "card_events_via_v2": true, "max_chats_pages": 40,
              "max_messages_per_chat": 5000, "max_text_len": 1000,
              "max_facts": 20000, "role_mode": "extended"}}
```

Листинг v2 сортирован по updated_ts (новые сверху) — ранний выход, когда
страница целиком старше from; обрыв по лимиту страниц/сообщений → честный
PARTIAL. Без chat_ids листинг полный; с chat_ids — только указанные чаты
(+ дозабор их v2-маркеров).

## Контракт ответа (stdout)

`{request_id, intent, status VERIFIED|PARTIAL|FAILED, as_of, facts[],
coverage{}, warnings[], errors[], detectors{}}` — как §4. В warnings и
coverage НЕТ текстов сообщений (только id и счётчики). Статус VERIFIED
возможен только при пустых warnings/errors И ПОЛНОМ отсутствии
UNLINKED/AMBIGUOUS фактов: есть непривязанные — статус не выше PARTIAL
с поимённой причиной (§3 протокола привязки; живая приёмка 09.11 показала
разрыв, тест tests/test_status_cap.py).

Факт (normalized schema §4 + расширения, см. «Предложения v1.2»):

```json
{"fact_type": "message",
 "source": "avito.messenger.v3 | avito.messenger.v2 | b24.ol | merged.b24+avito.v3",
 "source_entity_id": "avito:{u2i}#msg:{id} | chat{N}#msg{M} | chat{N}#msg{M}+avito:{u2i}#msg:{id}",
 "timestamp": "2026-11-09T15:03:11+03:00",
 "author_id": 999000, "author_role": "WE | CLIENT | BOT | CONNECTOR | UNKNOWN",
 "crm_entity": null,
 "payload": {"text": "≤max_text_len", "system": false, "direction": "in|out",
              "chat_u2i": "u2i-…", "connector_mid": "<значение у b24/merged>",
              "author_resolved": true, "sender_is_account": false,
              "content_type": "text|system|…", "content_supported": true,
              "interest_event": "viewed_phone|chat_created_no_message|card_call|system_other",
              "pre_dialog": false, "params_keys": [...≤10 имён],
              "chat_binding": "LINKED|UNLINKED|AMBIGUOUS",
              "join_status": "LINKED|UNLINKED|AMBIGUOUS",
              "join_reason": "exact_connector_mid|no_exact_key|..."},
 "evidence": {"avito_message_id": "…", "b24": {...}, "avito": {...},
               "join": {"kind": "exact_connector_mid"}}}
У Б24/merged-фактов payload включает chat_id и u2i. chat_binding/join_status/
join_reason есть у КАЖДОГО факта (директива 09.11, MAPPING_PROTOCOL.md §3).
```

## Роли авторов (CLIENT/WE/UNKNOWN, спека §6/§8)

- out + автор = наш аккаунт → WE (человек или бот на стороне Авито неразличимы
  — payload.sender_is_account; ботовость определяет dev_agent по своей карте).
- in + чужой автор → CLIENT.
- out + ЧУЖОЙ автор → UNKNOWN + WARN (возможный ответ из приложения Авито,
  0/16 в выборке аудита — не подтверждён и не снят; никогда не CLIENT).
- in + наш автор, нет direction/author → UNKNOWN + WARN.
- type=system / author_id=0 → CONNECTOR, system=true (живое подтверждение
  09.11: v3 присылает type=system с текстом и flow_id).
- Неподдержанный контент (не text, текста нет) → факт сохраняется с
  content_supported=false + WARN, в текстовую склейку не входит.
- role_mode: extended (по умолчанию) — UNKNOWN как есть; contract — UNKNOWN
  сериализуется как CONNECTOR + payload.author_resolved=false (совместимость
  с замороженным enum §4).

## Правила слияния — СТРОГИЙ exact-IDs-only (директивы 09.11, MAPPING_PROTOCOL.md)

ЗАПРЕЩЕНО: склейка клиента/чата/сообщения по похожести текста, подписи,
телефону, имени или окну времени (±10 минут и любое другое) — включая режим
«как кандидаты». Fuzzy-опции в запросе отклоняются с SCHEMA. Прежние виды
склейки fuzzy_text_time и system_mirror УДАЛЕНЫ из движка физически.

1. Чат: u2i↔chatId — ТОЛЬКО подтверждённые источники (entity_id диалога,
   inline-mapping, индекс, наполненный только ими). Коллизия (u2i у 2+
   чатов или чат у 2+ u2i) → связка AMBIGUOUS, склейки нет, WARN. Чат без
   связки → все его факты UNLINKED (no_chat_binding), выдумывание запрещено.
2. Сообщение: единственная сшивка — CONNECTOR_MID == avito.id, 1:1 в обе
   стороны, внутри подтверждённой пары чатов. Дубль ключа с любой стороны
   или ключ, заявленный чужим чатом → AMBIGUOUS (спорный ключ «ядовит» для
   всех). Одна сшивка НЕ доказывает привязку кластера карточек CRM.
3. Роль и атрибуция сотрудника слитого факта — ТОЛЬКО от копии Б24;
   author_id Авито НЕ равен Bitrix user_id (совпадение числом — канарейка
   WARN «СОВПАДЕНИЕ НЕ ЯВЛЯЕТСЯ соответствием»).
4. Остаток Авито — самостоятельные факты (fallback/прогрев): pre_dialog=true
   с WARN для сообщений до первого сообщения Б24; входящее без пары → WARN.
   Атрибуции сотруднику у Avito-фактов НЕТ никогда.
5. Любой UNLINKED/AMBIGUOUS → статус ответа не выше PARTIAL. duplicate_guard:
   дедуп по (source, source_entity_id), счётчики после.

## Карточные события: честная полнота (§9.6-D)

- «создал чат, но пока не написал» — приходит в v3 как клиентская
  системная строка → отдельное событие интереса (payload.interest_event).
- «посмотрел номер телефона», звонок из карточки — в истории v3 НЕТ, в Б24
  НЕ попадают; видны только как last_message листинга v2 → событие с
  evidence.via=v2_last_message_sampling и пометкой неполноты (виден только
  ПОСЛЕДНИЙ маркер чата — историческая полнота не гарантируется).
- coverage.card_events.gaps перечисляет недоступное; события не фабрикуются
  никогда (PASS-критерий D: 0 выдуманных).

## Канарейки/детекторы (§7)

offset_canary (повтор первой страницы → FAIL + PARTIAL), window_canary
(каждый факт ∈ [from, to), нарушители отбрасываются поимённо),
duplicate_guard PASS, author_crosscheck WARN n. 429/5xx/сеть: 3 ретрая,
backoff, затем ошибка источника в errors, сбор продолжается (§7.6).

## Конфигурация (env)

- AVITO_ADAPTER_LIVE=1 — разрешить сеть (по умолчанию offline);
- AVITO_CREDENTIALS_JSON — путь к хранилищу ключей (по умолчанию
  ~/Avito/avito-api-credentials.json, client_credentials; читает только auth,
  секреты не печатаются и не попадают в ответы);
- AVITO_ADAPTER_INDEX_DB — база индекса u2i↔chatId адаптера;
- AVITO_RATE_RPS (2.0), AVITO_TIMEOUT_S (20), AVITO_FUZZY_WINDOW_MIN (10),
- AVITO_ROLE_MODE (extended|contract).

## Стык с dev_agent (интеграция)

1. dev_agent получает Б24-сторону от модуля messages (строки
   im.dialog.messages.get + users-блок + im.dialog.get entity_id) и передаёт
   их в avito_merge (или сам вызывает avito_collect и делает слияние через
   библиотеку: `from adapter.joiner import merge_chats`).
2. Слияние идёт по ключам; значения CONNECTOR_MID обязательны во входных
   строках Б24 (в фактах модуля messages значения параметров обрезаны —
   передавайте СЫРЫЕ строки методов, а не готовые факты).
3. account_user_id передаётся из защищённого хранилища владельцем; без него
   роли наших/чужих на стороне Авито = UNKNOWN + WARN.
4. Ограничение: адаптер сам НЕ ходит в Б24 — двух-источниковая полнота
   собирается стыком messages (Б24) + avito_adapter (Авито), как §11.5.

## Предложения к спеке (v1.2, не заморожено)

- author_role: добавить UNKNOWN в enum §4 (сейчас совместимый режим contract);
- payload.connector_mid: разрешить значение ключа в фактах (нужно для склейки);
- type=system строки v3: заводить как system-факты с role CONNECTOR
  (подтверждено живьём 09.11).

## Известные ограничения (честно)

- offset v3 не подтверждён живьём (нет чата с полной страницей в выборке);
  канарейка fail-closed прикрывает.
- Лимиты/квоты Avito не замерялись; rps консервативно 2, 429-политика §7.6.
- Файлы/картинки чатов не выкачиваются (только признак content_supported=false).
- v2-маркеры карточных событий — сэмплинг last_message, полнота не гарантируется.
