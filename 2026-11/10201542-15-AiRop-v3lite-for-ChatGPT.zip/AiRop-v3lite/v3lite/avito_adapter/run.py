#!/usr/bin/env python3
"""CLI адаптера Avito: stdin JSON-запрос → stdout JSON-ответ (стык для dev_agent).

Запуск (сеть ТОЛЬКО с AVITO_ADAPTER_LIVE=1; без него — FAILED offline,
ни одного сетевого байта — боевой режим не включается молча):

  echo '{"intent":"avito_merge","request_id":"<uuid4>","b24":{...},"avito":{...}}' \
    | python3 ~/AiRop/v3lite/avito_adapter/run.py

Интенты:
- avito_merge  — офлайн-слияние готовых страниц: b24 {chats}, avito {chats},
                 mapping {chat_id→u2i}; сети не нужно.
- avito_merge  + "collect": {from, to, ...} — ДОБРАТЬ Авито живьём (read-only)
                 и слить с переданным Б24 (нужен AVITO_ADAPTER_LIVE=1).
- avito_collect — живой сбор за окно [from,to): листинг v2 + истории v3 +
                 карточные события + gaps/coverage (нужен AVITO_ADAPTER_LIVE=1).

Ответ: {request_id, intent, status VERIFIED|PARTIAL|FAILED, as_of, facts[],
coverage{}, warnings[], errors[], detectors{}} — как в контракте admin2 §4.
"""
from __future__ import annotations

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from adapter.auth import Credentials                     # noqa: E402
from adapter.card_events import coverage_report          # noqa: E402
from adapter.client import AvitoClient                   # noqa: E402
from adapter.collector import collect_window             # noqa: E402
from adapter.config import load_config                   # noqa: E402
from adapter.errors import AdapterError, SchemaError     # noqa: E402
from adapter.facts import serialize_facts                # noqa: E402
from adapter.index import ChatIndex                      # noqa: E402
from adapter.joiner import merge_chats                   # noqa: E402
from adapter.timeutil import TimeError, now_msk, parse_iso  # noqa: E402
from adapter.transport import Transport                  # noqa: E402
from adapter.whitelist import Whitelist                  # noqa: E402

_COLLECT_OPT = {"chat_ids", "include_card_events", "card_events_via_v2",
                "max_chats_pages", "max_messages_per_chat", "max_text_len",
                "max_facts", "role_mode"}
_MERGE_OPT = {"max_text_len", "role_mode"}


def _envelope(request_id, intent, status, *, facts=None, coverage=None,
              warnings=None, errors=None, detectors=None) -> dict:
    return {
        "request_id": request_id, "intent": intent, "status": status,
        "as_of": now_msk().isoformat(),
        "facts": facts or [], "coverage": coverage or {},
        "warnings": warnings or [], "errors": errors or [],
        "detectors": detectors or {},
    }


def _validate_top(req: dict) -> None:
    if not isinstance(req, dict):
        raise SchemaError("запрос должен быть JSON-объектом")
    if req.get("intent") not in ("avito_collect", "avito_merge"):
        raise SchemaError(f"intent {req.get('intent')!r}: допустимы avito_collect | avito_merge")
    rid = req.get("request_id")
    if not isinstance(rid, str) or not rid.strip():
        raise SchemaError("request_id обязателен (строка, uuid4)")
    for key in req.keys():
        if key not in {"intent", "request_id", "from", "to", "b24", "avito",
                       "mapping", "collect", "options", "account_user_id"}:
            raise SchemaError(f"неизвестное поле запроса: {key!r}")
    auid = req.get("account_user_id")
    if auid is not None and not (isinstance(auid, int) and auid > 0):
        raise SchemaError("account_user_id должен быть положительным целым")


def _window(req: dict) -> tuple:
    try:
        frm = parse_iso(req["from"], field="from")
        to = parse_iso(req["to"], field="to")
    except KeyError as e:
        raise SchemaError(f"не хватает поля {e}") from e
    except TimeError as e:
        raise SchemaError(str(e)) from e
    if to <= frm:
        raise SchemaError("to должно быть больше from (полуинтервал [from,to))")
    return frm, to


def _opts(req: dict, allowed: set) -> dict:
    from adapter.joiner import FORBIDDEN_JOIN_OPTIONS
    o = req.get("options") or {}
    if not isinstance(o, dict):
        raise SchemaError("options должен быть объектом")
    for k in o:
        if k in FORBIDDEN_JOIN_OPTIONS:
            raise SchemaError(
                f"опция {k!r} — эвристика сшивки, ЗАПРЕЩЕНА директивой 09.11 "
                f"(mw912vdyd7fq): привязка только по точным ID")
        if k not in allowed:
            raise SchemaError(f"неизвестная опция: {k!r}")
    return o


def _client(cfg):
    if not cfg.live:
        raise SchemaError(
            "offline-режим: сетевые вызовы запрещены — задайте AVITO_ADAPTER_LIVE=1 "
            "(боевой режим не включается молча)")
    return AvitoClient(cfg, Transport())


def _do_collect(req: dict, cfg, frm, to) -> dict:
    o = _opts(req, _COLLECT_OPT)
    try:
        client = _client(cfg)
    except SchemaError as e:
        return _envelope(req.get("request_id"), "avito_collect", "FAILED",
                         errors=[{"code": "LIMIT", "source": "avito",
                                  "detail": str(e)}])
    try:
        res = collect_window(
            client, frm=frm, to=to,
            chat_ids=o.get("chat_ids"),
            include_card_events=bool(o.get("include_card_events", True)),
            card_events_via_v2=bool(o.get("card_events_via_v2", True)),
            max_chats_pages=int(o.get("max_chats_pages", cfg.max_chats_pages)),
            max_messages_per_chat=int(o.get("max_messages_per_chat", cfg.max_messages_per_chat)),
            max_text_len=int(o.get("max_text_len", cfg.max_text_len)),
            max_facts=int(o.get("max_facts", cfg.max_facts)),
            role_mode=o.get("role_mode", cfg.author_role_mode))
    except AdapterError as e:
        return _envelope(req.get("request_id"), "avito_collect", "FAILED",
                         errors=[e.to_json()])
    return _envelope(req.get("request_id"), "avito_collect", res.status,
                     facts=serialize_facts(res.facts), coverage=res.coverage,
                     warnings=res.warnings, errors=res.errors, detectors=res.detectors)


def _do_merge(req: dict, cfg) -> dict:
    o = _opts(req, _MERGE_OPT)
    b24 = req.get("b24") or {}
    avito = req.get("avito") or {}
    mapping = req.get("mapping") or {}
    for name, val in (("b24", b24), ("avito", avito), ("mapping", mapping)):
        if not isinstance(val, dict):
            raise SchemaError(f"{name} должен быть объектом")
    collect = req.get("collect")
    warnings: list[str] = []
    errors: list[dict] = []
    detectors: dict = {"offset_canary": "SKIP", "window_canary": "SKIP",
                       "duplicate_guard": "PASS", "author_crosscheck": "PASS"}
    avito_live: dict = {}
    if collect is not None:
        if not isinstance(collect, dict):
            raise SchemaError("collect должен быть объектом {from,to,...}")
        sub = dict(req)
        sub = {**req, "intent": "avito_collect", "from": collect.get("from"),
               "to": collect.get("to"), "options": collect.get("options") or {},
               "request_id": req.get("request_id")}
        for k in ("chat_ids",):
            if k in collect:
                sub["options"] = {**sub["options"], k: collect[k]}
        frm, to = _window(sub)
        cres = _do_collect(sub, cfg, frm, to)
        warnings.extend(cres["warnings"])
        errors.extend(cres["errors"])
        detectors.update({k: v for k, v in cres["detectors"].items()
                          if v != "SKIP"})
        for f in cres["facts"]:
            u2i = (f.get("payload") or {}).get("chat_u2i")
            if not u2i:
                continue
            row = {
                "id": (f.get("evidence") or {}).get("avito_message_id"),
                "author_id": f.get("author_id"),
                "created": (f.get("evidence") or {}).get("avito_created_epoch"),
                "type": (f.get("payload") or {}).get("content_type", "text"),
                "direction": (f.get("payload") or {}).get("direction"),
                "content": {"text": (f.get("payload") or {}).get("text")},
                "read": None,
            }
            avito_live.setdefault(u2i, []).append(row)
        avito = {**avito_live, **avito}

    account = req.get("account_user_id")
    if account is None and cfg.live:
        try:
            account = int(Credentials(cfg.creds_path).user_id)
        except AdapterError:
            account = None
    if account is None:
        warnings.append("account_user_id не передан и не получен из хранилища — "
                        "«наши»/«чужие» авторы на стороне Авито неразличимы (UNKNOWN)")
    if not b24 and not avito:
        raise SchemaError("нужен хотя бы один из b24/avito (или collect)")

    idx = ChatIndex(cfg.index_db)
    # подтверждённые заявления привязки: inline-mapping запроса + entity_id
    # диалогов Б24. Никаких других источников; коллизии в индекс НЕ пишутся.
    from adapter.index import parse_entity_id
    claims: list[tuple[str, str, str]] = []
    for chat_id, u2i in mapping.items():
        try:
            claims.append((str(chat_id), str(u2i), "inline"))
        except (TypeError, ValueError) as e:
            raise SchemaError(f"mapping: пара {chat_id!r}→{u2i!r} не (chat_id, u2i)") from e
    chats = b24.get("chats") or {}
    for chat_id, payload in chats.items():
        dlg = (payload or {}).get("dialog") or {}
        ent = dlg.get("entity_id")
        if ent and dlg.get("id") is not None:
            parsed = parse_entity_id(ent)
            if parsed:
                claims.append((str(dlg["id"]), parsed["u2i"], "dialog"))
    # коллизии привязок (u2i у 2+ чатов, чат у 2+ u2i) — в индекс не вносить
    seen_u2i: dict = {}
    seen_chat: dict = {}
    for c, u, _src in claims:
        seen_u2i.setdefault(u, set()).add(c)
        seen_chat.setdefault(c, set()).add(u)
    ok_claims = [(c, u, src) for c, u, src in claims
                 if len(seen_u2i[u]) == 1 and len(seen_chat[c]) == 1]
    for c, u, src in ok_claims:
        if src == "dialog":
            # line возьмём из диалога ещё раз (уже проверено parse_entity_id)
            for chat_id, payload in chats.items():
                dlg = (payload or {}).get("dialog") or {}
                if str(dlg.get("id")) == c:
                    parsed = parse_entity_id(dlg.get("entity_id"))
                    if parsed:
                        idx.put(u, int(c), line=parsed["line"], source=src)
                    break
        else:
            try:
                idx.put(u, int(c), source=src)
            except (TypeError, ValueError) as e:
                raise SchemaError(f"mapping: пара {c!r}→{u!r} не (chat_id, u2i)") from e

    rep = merge_chats(chats, avito, [(c, u) for c, u, _s in claims],
                      account_user_id=account,
                      max_text_len=int(o.get("max_text_len", cfg.max_text_len)),
                      role_mode=o.get("role_mode", cfg.author_role_mode))
    warnings = warnings + rep.warnings
    cross_warn = sum(1 for w in warnings if "расхождение ролей" in w or "автор" in w.lower())
    if cross_warn:
        detectors["author_crosscheck"] = f"WARN {cross_warn}"
    # §3 протокола привязки (mw912vdyd7fq): есть факты без уникальной связи —
    # статус ответа НЕ выше PARTIAL, даже если warnings больше нет. VERIFIED
    # при непривязанных фактах запрещён: неполнота привязки не маскируется.
    n_unbound = sum(1 for f in rep.facts
                    if f.get("payload", {}).get("join_status") in ("UNLINKED", "AMBIGUOUS"))
    if n_unbound:
        warnings.append(
            f"{n_unbound} фактов без уникальной связи (UNLINKED/AMBIGUOUS) — "
            f"привязка неполна, статус не выше PARTIAL (§3 протокола привязки)")
    status = "FAILED" if errors and not rep.facts else (
        "PARTIAL" if (warnings or errors) else "VERIFIED")
    coverage = {"merge": rep.coverage}
    if avito_live:
        coverage["collect"] = {"note": "живой сбор выполнен в том же запросе",
                               "chats": len(avito_live)}
    return _envelope(req.get("request_id"), "avito_merge", status,
                     facts=serialize_facts(rep.facts), coverage=coverage,
                     warnings=warnings, errors=errors, detectors=detectors)


def main() -> int:
    raw = sys.stdin.read()
    try:
        req = json.loads(raw)
    except ValueError as e:
        out = _envelope("unknown", "unknown", "FAILED",
                        errors=[{"code": "SCHEMA", "source": "stdin",
                                 "detail": f"запрос не JSON: {e}"}])
        print(json.dumps(out, ensure_ascii=False))
        return 0
    cfg = load_config()
    try:
        _validate_top(req)
        intent = req["intent"]
        if intent == "avito_collect":
            frm, to = _window(req)
            out = _do_collect(req, cfg, frm, to)
        else:
            out = _do_merge(req, cfg)
    except SchemaError as e:
        out = _envelope(req.get("request_id") if isinstance(req, dict) else "unknown",
                        req.get("intent") if isinstance(req, dict) else "unknown",
                        "FAILED", errors=[e.to_json()])
    except AdapterError as e:
        out = _envelope(req.get("request_id") if isinstance(req, dict) else "unknown",
                        req.get("intent") if isinstance(req, dict) else "unknown",
                        "FAILED", errors=[e.to_json()])
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
