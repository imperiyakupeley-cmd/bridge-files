"""Тестовое окружение адаптера: FakeAvito (мини-эмуляция Avito API) + загрузчик
immutable-фикстур с проверкой SHA256SUMS (спека §11.6).

Все данные ОБЕЗЛИЧЕННЫЕ (фикстуры ~/AiRop/v3lite/messages/fixtures): вымышленные
id/имена, u2i-TEST-*, ни токенов. Сеть в тестах не используется НИКОГДА.

ВАЖНО о часах фикстур: эпохи `created` в фикстурах СИНТЕТИЧЕСКИЕ и не выровнены
с датами Б24 (в проде часы общие — одна платформа). Тест выравнивает их по
ЗАЯВЛЕННОЙ точной паре expected_merge.in_matches (артефакт загрузки фикстуры,
не логика адаптера); сами окна ±10 минут проверяются отдельными юнит-тестами
с нулевым сдвигом (test_normalize/test_join_pair).
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import urllib.parse
from datetime import datetime, timedelta, timezone

import pytest

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

from adapter.config import AvitoConfig                 # noqa: E402
from adapter.transport import HttpResult, Transport    # noqa: E402

FIXTURES_DIR = os.path.join(os.path.dirname(HERE), "messages", "fixtures")
OFF = timezone(timedelta(hours=3))
ACCOUNT = 999000  # обезличенный наш аккаунт (в проде 83739743)


# ------------------------------------------------------------------ фикстуры
def _verify_sha() -> None:
    sums_path = os.path.join(FIXTURES_DIR, "SHA256SUMS")
    with open(sums_path, encoding="utf-8") as fh:
        expected = {}
        for line in fh:
            line = line.strip()
            if not line:
                continue
            h, name = line.split(maxsplit=1)
            expected[name.strip().lstrip("*")] = h
    for name, want in expected.items():
        p = os.path.join(FIXTURES_DIR, name)
        if not os.path.exists(p):
            raise AssertionError(f"фикстура заявлена в SHA256SUMS, но отсутствует: {name}")
        got = hashlib.sha256(open(p, "rb").read()).hexdigest()
        assert got == want, f"фикстура изменена: {name} (SHA256 не сошёлся)"


@pytest.fixture(scope="session", autouse=True)
def fixtures_integrity():
    _verify_sha()


def load_fixture(name: str) -> dict:
    with open(os.path.join(FIXTURES_DIR, name), encoding="utf-8") as fh:
        return json.load(fh)


def _b24_epoch(iso: str) -> float:
    return datetime.fromisoformat(iso).timestamp()


def aligned_avito_rows(fixture: dict) -> list[dict]:
    """Строки avito.v3.messages с выровненными часами (по точной паре in_matches).

    Выравнивание: сдвиг = avito_epoch(пары) − b24_epoch(пары); применяется
    ПОСТОЯННО ко всем строкам чата (фикстуры имеют единый синтетический сдвиг
    часов; точная пара задаёт нуль отсчёта)."""
    fx = fixture["methods"]
    rows = list(fx["avito.v3.messages"]["rows"])
    exp = fx.get("expected_merge") or {}
    in_matches = exp.get("in_matches") or []
    if not in_matches:
        return rows
    b24_id, av_id = in_matches[0]
    b24_row = next(r for r in fx["im.dialog.messages.get"]["rows"]
                   if str(r.get("id")) == str(b24_id))
    av_row = next(r for r in rows if str(r.get("id")) == str(av_id))
    skew = av_row["created"] - _b24_epoch(b24_row["date"])
    return [{**r, "created": r["created"] - skew} for r in rows]


# ------------------------------------------------------------------- FakeAvito
class FakeAvito:
    """Эмуляция: token (POST), v2 chats (GET), v3 messages (GET). Read-only.

    - ignore_offset=True: сервер «молча игнорирует offset» (канарейка);
    - fail: {path_substr: http_status} — отказы по требованию;
    - calls: журнал для ассертов (что реально запрошено)."""

    def __init__(self, chats: list[dict] | None = None, messages: dict[str, list] | None = None,
                 ignore_offset: bool = False):
        self.chats = chats or []          # v2-строки (id, updated_ts, last_message…)
        self.messages = messages or {}    # u2i → [строки v3, новые сверху]
        self.ignore_offset = ignore_offset
        self.fail = {}
        self.calls = []
        self._token_n = 0

    # -------------------------------------------------------------- endpoints
    def token(self) -> dict:
        self._token_n += 1
        return {"access_token": f"test-token-{self._token_n}", "expires_in": 86400}

    def v2_chats(self, limit: int, offset: int) -> dict:
        rows = sorted(self.chats, key=lambda c: c.get("updated_ts") or 0, reverse=True)
        return {"chats": rows[offset:offset + limit]}

    def v3_messages(self, chat: str, limit: int, offset: int) -> dict:
        rows = self.messages.get(chat, [])
        if self.ignore_offset and offset > 0:
            offset = 0                    # сервер вернул бы опять первую страницу
        return {"messages": rows[offset:offset + limit]}


class FakeTransport(Transport):
    name = "fake"

    def __init__(self, fake: FakeAvito):
        super().__init__(whitelist=None)
        self.fake = fake

    def get(self, url: str, timeout: float, headers: dict | None = None) -> HttpResult:
        self.fake.calls.append(("GET", url.split("?")[0]))
        parts = urllib.parse.urlparse(url)
        qs = {k: v for k, v in urllib.parse.parse_qsl(parts.query)}
        path = parts.path
        for sub, status in self.fake.fail.items():
            if sub in path:
                return HttpResult(status, {}, b"{}")
        if "/messenger/v2/accounts/" in path and path.rstrip("/").endswith("chats"):
            body = self.fake.v2_chats(int(qs.get("limit", 50)), int(qs.get("offset", 0)))
            return HttpResult(200, {}, json.dumps(body).encode())
        if "/messenger/v3/accounts/" in path and "/messages/" in path:
            chat = path.rstrip("/").rpartition("/chats/")[2].split("/")[0]
            body = self.fake.v3_messages(chat, int(qs.get("limit", 100)), int(qs.get("offset", 0)))
            return HttpResult(200, {}, json.dumps(body).encode())
        return HttpResult(404, {}, b"{}")

    def post(self, url: str, payload: dict, timeout: float) -> HttpResult:
        self.fake.calls.append(("POST", url.split("?")[0]))
        if url.rstrip("/").endswith("/token"):
            return HttpResult(200, {}, json.dumps(self.fake.token()).encode())
        return HttpResult(404, {}, b"{}")


def make_client(fake: FakeAvito, account: int = ACCOUNT, **cfg_kw):
    from adapter.client import AvitoClient
    kw = dict(rate_rps=1000.0, timeout_s=5.0, retries_max=2,
              backoff_base_s=0.001, backoff_cap_s=0.002)
    kw.update(cfg_kw)
    cfg = AvitoConfig(live=True, account_user_id=account, **kw)
    return AvitoClient(cfg, FakeTransport(fake), throttle=False)


@pytest.fixture
def cfg_offline():
    return AvitoConfig(live=False)


# -------------------------------------------------------------- B24-хелперы
def b24_users(*spec) -> list[dict]:
    """spec: (id, kind) kind in {connector, bot, human} → users-блок диалога."""
    out = []
    for uid, kind in spec:
        u = {"id": uid, "name": f"Тест-{uid}"}
        if kind == "connector":
            u["connector"] = True
            u["external_auth_id"] = "imconnector"
        elif kind == "bot":
            u["bot"] = True
        out.append(u)
    return out


def iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S+03:00")
