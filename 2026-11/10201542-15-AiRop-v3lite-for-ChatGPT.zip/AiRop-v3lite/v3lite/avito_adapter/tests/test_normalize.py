"""Нормализация текста, снятие подписи, роли авторов, маркеры карточных событий."""
from __future__ import annotations

import pytest
from datetime import datetime

from adapter.config import SYSTEM_PREFIX
from adapter.normalize import (classify_card_marker, is_system_text, normalize_text,
                               resolve_avito_role, serialize_role, strip_signature,
                               text_variants)
from adapter.timeutil import from_epoch, parse_iso, parse_iso_loose

ACC = 999000


# ------------------------------------------------------------------ подпись
@pytest.mark.parametrize("raw,want", [
    ("Тестов Т.: Тест, расчёт по чаше сделаем сегодня", "Тест, расчёт по чаше сделаем сегодня"),
    ("Михаил: Здравствуйте", "Здравствуйте"),
    ("Галина Жирнова: Хорошо, ждём", "Хорошо, ждём"),
    ("Анна: привет", "привет"),
    ("Просто текст без подписи", "Просто текст без подписи"),
    ("Только подпись:", "Только подпись:"),        # после снятия пусто → не трогаем
    ("", ""),
    (None, ""),
])
def test_strip_signature(raw, want):
    assert strip_signature(raw) == want


def test_spec_regex_is_first_layer():
    # «Иванов Иван» покрывается строгим регэкспом спеки §5
    assert strip_signature("Иванов Иван: ок") == "ок"


def test_variants_include_raw_and_stripped():
    v = text_variants("Тестов Т.: Привет, мир")
    assert normalize_text("Привет, мир") in v
    assert normalize_text("Тестов Т.: Привет, мир") in v


def test_variants_never_empty_only():
    assert text_variants("   ") == frozenset({""})


# -------------------------------------------------------------------- роли
def test_roles_out_account_is_we():
    assert resolve_avito_role("out", ACC, ACC) == ("WE", True)


def test_roles_in_stranger_is_client():
    assert resolve_avito_role("in", 999001, ACC) == ("CLIENT", True)


def test_roles_out_stranger_is_unknown():
    # возможный ответ менеджера из приложения Авито (спека §6, 0/16 в выборке)
    assert resolve_avito_role("out", 999009, ACC) == ("UNKNOWN", False)


def test_roles_in_account_is_unknown():
    assert resolve_avito_role("in", ACC, ACC) == ("UNKNOWN", False)


def test_roles_missing_direction_or_author_unknown():
    assert resolve_avito_role(None, ACC, ACC) == ("UNKNOWN", False)
    assert resolve_avito_role("out", None, ACC) == ("UNKNOWN", False)


def test_role_mode_contract_maps_unknown_to_connector():
    assert serialize_role("UNKNOWN", "contract") == "CONNECTOR"
    assert serialize_role("UNKNOWN", "extended") == "UNKNOWN"
    assert serialize_role("WE", "contract") == "WE"


# -------------------------------------------------------- карточные маркеры
def test_marker_chat_created():
    t = SYSTEM_PREFIX + " ✏️ Пользователь создал чат, но пока не написал сообщение"
    assert is_system_text(t)
    assert classify_card_marker(t) == "chat_created_no_message"


def test_marker_viewed_phone():
    assert classify_card_marker("Пользователь посмотрел номер телефона из объявления") \
        == "viewed_phone"


def test_marker_card_call():
    assert classify_card_marker("Звонок из карточки объявления") == "card_call"


def test_marker_plain_text_is_none():
    assert classify_card_marker("Здравствуйте, актуально?") is None
    assert classify_card_marker("обычное сообщение") is None


# --------------------------------------------------------------------- время
def test_epoch_to_msk():
    dt = from_epoch(1794164430)
    assert dt is not None and dt.tzinfo is not None
    assert dt.utcoffset().total_seconds() == 3 * 3600


def test_epoch_garbage_is_none_not_guess():
    assert from_epoch(None) is None
    assert from_epoch("abc") is None
    assert from_epoch(True) is None


def test_parse_iso_requires_offset():
    with pytest.raises(ValueError):
        parse_iso("2026-11-05T12:00:30", field="x")


def test_parse_iso_loose_bad_input_none():
    assert parse_iso_loose("not-a-date") is None
    assert parse_iso_loose(None) is None
    assert parse_iso_loose("") is None
