"""§9.6-D: карточные события — учитываются, не фабрикуются, gaps видны.

Фикстура dataset_avito_card_events.json (immutable)."""
from __future__ import annotations

from adapter.card_events import (coverage_report, event_fact_from_v2_chat,
                                 event_fact_from_v3)
from adapter.joiner import merge_chat
from adapter.timeutil import from_epoch

from tests.conftest import ACCOUNT, aligned_avito_rows, load_fixture


def test_v3_system_prefix_becomes_interest_event():
    fx = load_fixture("dataset_avito_card_events.json")
    rows = fx["methods"]["avito.v3.messages"]["rows"]
    dd10 = next(r for r in rows if str(r["id"]).startswith("dd10"))
    ev = event_fact_from_v3(dd10, "u2i-TEST-card-0005")
    assert ev is not None
    assert ev["payload"]["interest_event"] == "chat_created_no_message"
    assert ev["payload"]["system"] is True
    assert "не фабрикуются" not in ev["payload"]["text"]  # текст без префикса
    assert "Пользователь создал чат" in ev["payload"]["text"]


def test_v3_plain_text_is_not_event():
    fx = load_fixture("dataset_avito_card_events.json")
    rows = fx["methods"]["avito.v3.messages"]["rows"]
    ee11 = next(r for r in rows if str(r["id"]).startswith("ee11"))
    assert event_fact_from_v3(ee11, "u2i-TEST-card-0005") is None


def test_v3_typed_system_author0_becomes_event():
    """[ФАКТ, живой замер 09.11.2026]: v3 type=system, author_id=0, есть text."""
    row = {"id": "sys1", "author_id": 0, "created": 1794400000, "type": "system",
           "direction": "in", "content": {"text": "Диалог закрыт", "flow_id": "f1"}}
    ev = event_fact_from_v3(row, "u2i-X")
    assert ev is not None
    assert ev["author_role"] == "CONNECTOR"
    assert ev["payload"]["interest_event"] == "system_other"
    assert ev["payload"]["text"] == "Диалог закрыт"


def test_avito_fact_system_type_not_client():
    """type=system/author 0 — не CLIENT: роль CONNECTOR, автор не разрешён."""
    from adapter.facts import avito_fact
    row = {"id": "sys9", "author_id": 0, "created": 1794400000, "type": "system",
           "direction": "in", "content": {"text": "что-то системное"}}
    f = avito_fact(row, "u2i-X", ACCOUNT)
    assert f["author_role"] == "CONNECTOR"
    assert f["payload"]["author_resolved"] is False
    assert f["payload"]["system"] is True


def test_v2_last_message_viewed_phone_with_honest_completeness():
    fx = load_fixture("dataset_avito_card_events.json")
    sample = fx["methods"]["avito.v2.chats.last_message_sample"]["rows"]
    card6 = next(r for r in sample if r["chat"] == "u2i-TEST-card-0006")
    chat_row = {"id": card6["chat"], "updated_ts": 1794400100,
                "last_message": {"type": card6["last_message_type"],
                                 "text": card6["last_message_text"],
                                 "created": 1794400050}}
    ev = event_fact_from_v2_chat(chat_row)
    assert ev is not None
    assert ev["payload"]["interest_event"] == "viewed_phone"
    assert ev["source"] == "avito.messenger.v2"
    assert "только ПОСЛЕДНИЙ маркер" in ev["payload"]["completeness"]


def test_no_fabricated_events_anywhere():
    """PASS-критерий D: 0 выдуманных карточных событий."""
    fx = load_fixture("dataset_avito_card_events.json")
    m = fx["methods"]
    b24 = {"users": m["im.dialog.messages.get"]["users"],
           "messages": m["im.dialog.messages.get"]["rows"]}
    rep = merge_chat(b24, aligned_avito_rows(fx), "u2i-TEST-card-0005", 30400,
                     account_user_id=ACCOUNT)
    # ни один факт не заявляет viewed_phone
    assert not [f for f in rep.facts
                if f["payload"].get("interest_event") == "viewed_phone"]
    # «создал чат, но не написал» присутствует как событие интереса (не молча)
    created = [f for f in rep.facts
               if f["payload"].get("interest_event") == "chat_created_no_message"]
    assert len(created) == 1
    assert created[0]["payload"].get("pre_dialog") is True
    # ожидания фикстуры: в Б24 этих событий нет
    exp = fx["methods"]["expected"]
    assert exp["b24_has_created_chat_event"] is False
    assert exp["b24_has_viewed_phone_event"] is False
    assert exp["avito_v3_history_has_viewed_phone_event"] is False


def test_coverage_report_lists_gaps():
    ev = event_fact_from_v2_chat(
        {"id": "u2i-TEST-card-0006", "updated_ts": 1794400100,
         "last_message": {"type": "system",
                          "text": "Пользователь посмотрел номер телефона из объявления",
                          "created": 1794400050}})
    rep = coverage_report([ev], v2_scanned_chats=1, v3_scanned_messages=2)
    ce = rep["card_events"]
    assert ce["detected_total"] == 1
    assert ce["by_kind"] == {"viewed_phone": 1}
    assert ce["by_source"] == {"avito.messenger.v2": 1}
    assert ce["gaps"]["v3_history_has_card_events"] is False
    assert "viewed_phone (история)" in ce["gaps"]["not_available_anywhere"]
    assert "не фабрикуются" in ce["note"]
