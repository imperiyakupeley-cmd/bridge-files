"""Cross-client contamination: СТРОГИЙ протокол привязки Avito→CRM
(директива владельца 09.11, мость mw912vdyd7fq — уточнение к mw90nr8thi84).

Риск: при прямом Avito API перепутать клиентов. Запрещено склеивать
клиента/чат/сообщение по похожести текста, подписи, телефону, имени или
±10 минутам. Разрешены только подтверждённые соответствия стабильных
технических ID. Эти тесты ломают наивную склейку «похожими» клиентами:
одинаковые тексты, одинаковые подписи/телефоны/имена, одновременные
рассылки, дубли клиентов в Б24, несколько аккаунтов Авито.

Все данные ОБЕЗЛИЧЕННЫЕ: вымышленные id (999xxx, u2i-TEST-*, +7-900-…),
ни токенов, ни текстов реальных клиентов. Сеть не используется.
"""
from __future__ import annotations

import copy
import json

from adapter.config import AvitoConfig
from adapter.index import ChatIndex
from adapter.joiner import merge_chat, merge_chats
from adapter.timeutil import parse_iso_loose

from tests.conftest import ACCOUNT

BASE = parse_iso_loose("2026-11-05T12:00:00+03:00").timestamp()

# два РАЗНЫХ клиента, но ТЕКСТЫ ИДЕНТИЧНЫ (типовая рассылка/типовой вопрос)
TEXT = "Здравствуйте, подскажите, пожалуйста, по условиям"
PHONE = "+7 900 000-00-00"          # фиктивный номер, ОДИНАКОВ в подписях обоих
NAME = "Иванов И."                  # одинаковая подпись-имя в обоих чатах


def _client_chat(chat_id, u2i, msg_id_b24, msg_id_av, *, author_av=999001):
    """Чат клиента: входящее с одинаковым текстом и подписью (телефон+имя)."""
    b24 = {"users": [{"id": 990, "connector": True, "external_auth_id": "imconnector"}],
           "messages": [{"id": msg_id_b24, "chat_id": chat_id, "author_id": 990,
                         "date": "2026-11-05T12:00:00+03:00",
                         "text": f"{TEXT}\n{NAME}, {PHONE}",
                         "params": {}}]}
    av = [{"id": msg_id_av, "author_id": author_av, "created": BASE + 60,
           "type": "text", "direction": "in", "read": None,
           "content": {"text": f"{TEXT}\n{NAME}, {PHONE}"}}]
    return b24, av


# ── 1. одинаковые тексты двух клиентов не склеиваются ────────────────────────
def test_identical_texts_two_clients_stay_separate():
    b24_a, av_a = _client_chat(101, "u2i-CLI-A", 1, "avA1")
    b24_b, av_b = _client_chat(202, "u2i-CLI-B", 2, "avB1")
    rep = merge_chats({"101": b24_a, "202": b24_b},
                      {"u2i-CLI-A": av_a, "u2i-CLI-B": av_b},
                      [("101", "u2i-CLI-A"), ("202", "u2i-CLI-B")],
                      account_user_id=ACCOUNT)
    assert rep.coverage["_totals"]["collisions_total"] == 0
    # склеек нет вообще: точных ключей не было
    assert all(f["payload"]["join_status"] != "LINKED"
               or f["payload"]["join_reason"] == "exact_connector_mid"
               for f in rep.facts)
    # ИЗОЛЯЦИЯ ЧАТОВ: каждый факт ссылается только на свой чат/свой u2i
    def _serializable(f):
        return json.dumps({k: v for k, v in f.items() if k != "timestamp_dt"},
                          ensure_ascii=False, default=str)
    for f in rep.facts:
        p = f["payload"]
        if p.get("chat_id") == 101 or p.get("chat_u2i") == "u2i-CLI-A":
            assert "CLI-B" not in _serializable(f), \
                "факт клиента A не должен ссылаться на клиента B"
        if p.get("chat_id") == 202 or p.get("chat_u2i") == "u2i-CLI-B":
            assert "CLI-A" not in _serializable(f), \
                "факт клиента B не должен ссылаться на клиента A"


# ── 2. обмен текстами между чатами НЕ меняет слияние (контент не участвует) ──
def test_swapping_texts_between_clients_changes_nothing():
    b24_a, av_a = _client_chat(101, "u2i-CLI-A", 1, "avA1")
    b24_b, av_b = _client_chat(202, "u2i-CLI-B", 2, "avB1")
    # правильный расклад
    rep1 = merge_chats({"101": b24_a, "202": b24_b},
                       {"u2i-CLI-A": av_a, "u2i-CLI-B": av_b},
                       [("101", "u2i-CLI-A"), ("202", "u2i-CLI-B")],
                       account_user_id=ACCOUNT)
    # ОБМЕН текстами: клиенту A подсунули текст клиента B и наоборот
    b24_a2, av_a2 = _client_chat(101, "u2i-CLI-A", 1, "avA1")
    b24_b2, av_b2 = _client_chat(202, "u2i-CLI-B", 2, "avB1")
    b24_a2["messages"][0]["text"] = "СОВСЕМ ДРУГОЙ ТЕКСТ B"
    av_a2[0]["content"]["text"] = "СОВСЕМ ДРУГОЙ ТЕКСТ B"
    b24_b2["messages"][0]["text"] = TEXT + "\n" + NAME + ", " + PHONE
    av_b2[0]["content"]["text"] = TEXT + "\n" + NAME + ", " + PHONE
    rep2 = merge_chats({"101": b24_a2, "202": b24_b2},
                       {"u2i-CLI-A": av_a2, "u2i-CLI-B": av_b2},
                       [("101", "u2i-CLI-A"), ("202", "u2i-CLI-B")],
                       account_user_id=ACCOUNT)
    st1 = sorted((f["source"], f["payload"]["join_status"], f["payload"]["join_reason"])
                 for f in rep1.facts)
    st2 = sorted((f["source"], f["payload"]["join_status"], f["payload"]["join_reason"])
                 for f in rep2.facts)
    assert st1 == st2, "результат слияния не может зависеть от содержимого текстов"


# ── 3. одинаковые телефон и имя в двух чатах — НЕ основание для привязки ─────
def test_same_phone_and_name_not_a_key():
    b24_a, av_a = _client_chat(101, "u2i-CLI-A", 1, "avA1")
    b24_b, av_b = _client_chat(202, "u2i-CLI-B", 2, "avB1")
    rep = merge_chats({"101": b24_a, "202": b24_b},
                      {"u2i-CLI-A": av_a, "u2i-CLI-B": av_b},
                      [("101", "u2i-CLI-A"), ("202", "u2i-CLI-B")],
                      account_user_id=ACCOUNT)
    joined = [f for f in rep.facts if f["payload"]["join_status"] == "LINKED"]
    assert joined == [], "совпадение телефона/имени/текста не может склеивать"


# ── 4. одновременная рассылка-дубль в оба чата в одну минуту ─────────────────
def test_simultaneous_bulk_outgoing_not_merged():
    bulk = "Акция только сегодня!"     # одинаковая рассылка обоим клиентам
    b24_a = {"users": [], "messages": [{"id": 1, "chat_id": 101, "author_id": 402,
                                        "date": "2026-11-05T12:00:00+03:00",
                                        "text": bulk, "params": {}}]}
    b24_b = {"users": [], "messages": [{"id": 2, "chat_id": 202, "author_id": 402,
                                        "date": "2026-11-05T12:00:30+03:00",
                                        "text": bulk, "params": {}}]}
    av = {"u2i-CLI-A": [{"id": "avA1", "author_id": ACCOUNT, "created": BASE + 10,
                         "type": "text", "direction": "out", "read": None,
                         "content": {"text": "Менеджер: " + bulk}}],
          "u2i-CLI-B": [{"id": "avB1", "author_id": ACCOUNT, "created": BASE + 40,
                         "type": "text", "direction": "out", "read": None,
                         "content": {"text": "Менеджер: " + bulk}}]}
    rep = merge_chats({"101": b24_a, "202": b24_b}, av,
                      [("101", "u2i-CLI-A"), ("202", "u2i-CLI-B")],
                      account_user_id=ACCOUNT)
    assert rep.coverage["101"]["joined_exact"] == 0
    assert rep.coverage["202"]["joined_exact"] == 0
    # обе копии в каждом чате остались раздельными фактами
    assert rep.coverage["101"]["b24_out_without_avito_pair"] == 1
    assert rep.coverage["202"]["b24_out_without_avito_pair"] == 1


# ── 5. одна точная сшивка НЕ доказывает привязку кластера карточек ───────────
def test_one_exact_match_does_not_prove_cluster():
    """Совпадение CONNECTOR_MID у одного сообщения: сшито только это сообщение;
    остальные сообщения чата остаются UNLINKED — кластер карточек CRM не
    доказан и downstream не переносит привязку на дубли клиента."""
    mid = "aa11aabbccddeeff00112233445566aa"
    b24 = {"users": [], "messages": [
        {"id": 1, "chat_id": 10, "author_id": 990, "date": "2026-11-05T12:00:00+03:00",
         "text": "с ключом", "params": {"CONNECTOR_MID": [mid]}},
        {"id": 2, "chat_id": 10, "author_id": 990, "date": "2026-11-05T12:00:20+03:00",
         "text": "без ключа, тот же клиент", "params": {}},
        {"id": 3, "chat_id": 10, "author_id": 402, "date": "2026-11-05T12:01:00+03:00",
         "text": "ответ менеджера", "params": {}}]}
    av = [{"id": mid, "author_id": 999001, "created": BASE, "type": "text",
           "direction": "in", "read": None, "content": {"text": "с ключом"}},
          {"id": "av2", "author_id": 999001, "created": BASE + 20, "type": "text",
           "direction": "in", "read": None, "content": {"text": "без ключа, тот же клиент"}}]
    rep = merge_chat(b24, av, "u2i-ONE", 10, account_user_id=ACCOUNT)
    assert rep.coverage["joined_exact"] == 1
    by_status = {}
    for f in rep.facts:
        by_status.setdefault(f["payload"]["join_status"], []).append(f)
    assert len(by_status.get("LINKED", [])) == 1, "сшито ровно одно сообщение"
    # непарные — UNLINKED, в том числе сообщение с тем же текстом и тем же клиентом
    assert len(by_status.get("UNLINKED", [])) == 3
    unjoined_client_msg = next(f for f in by_status["UNLINKED"]
                               if f["source"].startswith("avito."))
    assert unjoined_client_msg["payload"]["join_reason"] == "no_exact_key"


# ── 6. дубли клиентов в Б24: один u2i заявлен двумя чатами → AMBIGUOUS ───────
def test_duplicate_client_cards_ambiguous():
    b24_a, av_a = _client_chat(101, "u2i-DUP", 1, "avD1")
    b24_b, av_b = _client_chat(202, "u2i-DUP", 2, "avD1")
    rep = merge_chats({"101": b24_a, "202": b24_b},
                      {"u2i-DUP": av_a + av_b},
                      [("101", "u2i-DUP"), ("202", "u2i-DUP")],
                      account_user_id=ACCOUNT)
    assert rep.coverage["101"]["chat_binding"] == "AMBIGUOUS"
    assert rep.coverage["202"]["chat_binding"] == "AMBIGUOUS"
    assert any("заявлен несколькими чатами" in w for w in rep.warnings)
    # ни одному клиенту ничего не приписано: все факты AMBIGUOUS
    assert all(f["payload"]["join_status"] == "AMBIGUOUS" for f in rep.facts)


# ── 7. unmapped чат: факты UNLINKED, coverage PARTIAL, без приписки ──────────
def test_unmapped_client_stays_unlinked():
    b24_a, av_a = _client_chat(101, "u2i-CLI-A", 1, "avA1")
    rep = merge_chats({"101": b24_a}, {"u2i-CLI-A": av_a}, [],
                      account_user_id=ACCOUNT)
    assert rep.coverage["101"]["chat_binding"] == "UNLINKED"
    assert all(f["payload"]["join_status"] == "UNLINKED" for f in rep.facts)
    assert any("нет подтверждённого сопоставления" in w for w in rep.warnings)


# ── 8. несколько аккаунтов Авито: индексы привязок изолированы ───────────────
def test_multi_account_indexes_are_isolated(tmp_path):
    """Каждый аккаунт Авито — свой индекс привязок (fail-closed изоляция):
    пара u2i↔chatId аккаунта A недоступна аккаунту B; одинаковый u2i у
    двух аккаунтов не смешивается."""
    db_a = str(tmp_path / "idx_a.db")
    db_b = str(tmp_path / "idx_b.db")
    cfg = AvitoConfig()
    cfg.index_db = db_a
    ia = ChatIndex(db_a)
    ia.put("u2i-SHARED", 101, source="dialog")
    ib = ChatIndex(db_b)
    # аккаунт B НЕ видит пару аккаунта A
    assert ib.reverse(101) is None
    assert ib.get("u2i-SHARED") is None
    # внутри аккаунта A пара есть
    assert ia.reverse(101) == "u2i-SHARED"
    cfg.index_db = db_b
    assert cfg.index_db == db_b


# ── 9. исходящие Авито без проверенного автора — UNKNOWN, не менеджер ────────
def test_unverified_out_author_not_manager():
    b24 = {"users": [{"id": 402, "name": "Менеджер", "connector": False, "bot": False}],
           "messages": []}
    av = [{"id": "a1", "author_id": 402, "created": BASE, "type": "text",
           "direction": "out", "read": None, "content": {"text": "ок"}},
          {"id": "a2", "author_id": ACCOUNT, "created": BASE + 1, "type": "text",
           "direction": "out", "read": None, "content": {"text": "наш аккаунт"}}]
    rep = merge_chat(b24, av, "u2i-OUT", 10, account_user_id=ACCOUNT)
    facts = {f["evidence"]["avito_message_id"]: f for f in rep.facts}
    # author_id числово равен id сотрудника Б24 — приписывание запрещено
    assert facts["a1"]["author_role"] == "UNKNOWN"
    assert facts["a1"]["payload"]["sender_is_account"] is False
    assert any("СОВПАДЕНИЕ НЕ ЯВЛЯЕТСЯ" in w for w in rep.warnings)
    # наш проверенный аккаунт — WE (роль стороны, не id менеджера)
    assert facts["a2"]["author_role"] == "WE"
    assert facts["a2"]["payload"]["sender_is_account"] is True
    for f in facts.values():
        assert "employee_id" not in f["payload"] and "employee" not in f["payload"]


# ── 10. option-level запрет: fuzzy-опции не проходят через CLI (см. test_cli) ─
def test_forbidden_join_options_documented():
    from adapter.joiner import FORBIDDEN_JOIN_OPTIONS
    for opt in ("window_minutes", "text_similarity", "match_by_text",
                "match_by_phone", "match_by_name", "strip_signature", "fuzzy"):
        assert opt in FORBIDDEN_JOIN_OPTIONS, opt
