"""§9.6-A: спаренный чат Б24/Avito — СТРОГИЙ exact-join (директива 09.11,
мосты mw912x028ygf + mw912vdyd7fq).

Фикстура dataset_avito_b24_pair.json (immutable, SHA256 проверен conftest).

Главное: склейка ТОЛЬКО по точному ключу CONNECTOR_MID == avito.id, 1:1,
внутри подтверждённой пары чатов. Сшивка по тексту/подписи/времени (±N минут)
ЗАПРЕЩЕНА — прежние виды fuzzy_text_time/system_mirror в движке не существуют;
непарные строки остаются отдельными фактами UNLINKED (данные не теряются).
"""
from __future__ import annotations

from adapter import joiner
from adapter.joiner import merge_chat, merge_chats
from adapter.timeutil import parse_iso_loose

from tests.conftest import ACCOUNT, aligned_avito_rows, load_fixture


def setup():
    fx = load_fixture("dataset_avito_b24_pair.json")
    m = fx["methods"]
    b24 = {"users": m["im.dialog.messages.get"]["users"],
           "messages": m["im.dialog.messages.get"]["rows"]}
    avito = aligned_avito_rows(fx)
    dlg = m["im.dialog.get"]["rows"][0]
    return fx, b24, avito, dlg


def test_pair_merge_strict_matrix():
    fx, b24, avito, dlg = setup()
    rep = merge_chat(b24, avito, "u2i-TEST-chatpair-0001", 30300, account_user_id=ACCOUNT)

    kinds = [f["evidence"]["join"]["kind"] for f in rep.facts
             if f.get("evidence", {}).get("join")]
    assert kinds.count("exact_connector_mid") == 2      # входящие 1:1 по точному ключу
    assert set(kinds) == {"exact_connector_mid"}        # других видов склейки НЕТ
    assert not hasattr(joiner, "_pair_candidates")      # fuzzy-движок удалён физически

    # статусы: 2 LINKED, остальные UNLINKED (остаются фактами, не теряются)
    js = [f["payload"]["join_status"] for f in rep.facts]
    assert js.count("LINKED") == 2 and js.count("UNLINKED") == 2 + rep.coverage["avito_rows"] - 2
    assert rep.coverage["ambiguous"] == 0

    # нет дублей и потерь: все 4 строки Б24 и все 4 строки Авито учтены ровно раз
    assert rep.coverage["duplicate_guard_dropped"] == 0
    assert rep.coverage["avito_rows"] == 4 and rep.coverage["b24_rows"] == 4
    assert rep.coverage["collisions"] == 0

    # каждый слитый факт несёт evidence обеих копий
    for f in rep.facts:
        if f["source"] == "merged.b24+avito.v3":
            assert f["evidence"]["b24"]["source_entity_id"].startswith("chat30300#")
            assert f["evidence"]["avito"]["source_entity_id"].startswith("avito:u2i-TEST-chatpair-0001#")

    # exact-пары совпадают с expected_merge.in_matches
    m = fx["methods"]["expected_merge"]
    got_in = {f["evidence"]["b24"]["source_entity_id"]: f["evidence"]["avito"]["message_id"]
              for f in rep.facts
              if f.get("evidence", {}).get("join", {}).get("kind") == "exact_connector_mid"}
    for b24_id, av_id in m["in_matches"]:
        assert got_in.get(f"chat30300#msg{b24_id}") == av_id

    # исходящая пара, заявленная в out_matches, БОЛЬШЕ НЕ СШИВАЕТСЯ (fuzzy отменён):
    # обе копии остаются отдельными фактами
    out_pair = m["out_matches"][0]
    b24_out_ids = {f["source_entity_id"].split("+")[0] for f in rep.facts}
    assert f"chat30300#msg{out_pair[0]}" in b24_out_ids
    av_ids_in_facts = {f.get("evidence", {}).get("avito_message_id",
                      (f.get("evidence", {}).get("avito") or {}).get("message_id"))
                      for f in rep.facts}
    assert out_pair[1] in av_ids_in_facts
    # и это не merged-факт
    merged_refs = {f["source_entity_id"] for f in rep.facts if f["source"].startswith("merged")}
    assert all(f"msg{out_pair[0]}" in r and f"msg:{out_pair[1]}" not in r
               for r in merged_refs) or all("+" not in r or f"msg{out_pair[0]}" not in r
                                            for r in merged_refs)

    # роли из users-блока, не из подписи: 990=CLIENT, 401=BOT
    by_b24id = {f["source_entity_id"].split("+")[0]: f for f in rep.facts}
    assert by_b24id["chat30300#msg1999004"]["author_role"] == "CLIENT"
    # 1999006: в Б24 автор 402 (WE), на Авито direction=in (CLIENT) → конфликт,
    # роль слитого факта — Б24 (приоритет §5), WARN
    f6 = by_b24id["chat30300#msg1999006"]
    assert f6["author_role"] == "WE"
    assert f6["payload"]["join_status"] == "LINKED"
    assert any("расхождение ролей Б24=WE vs Авито=CLIENT" in w and "1999006" in w
               for w in rep.warnings)


def test_no_text_leak_into_warnings():
    fx, b24, avito, dlg = setup()
    rep = merge_chat(b24, avito, "u2i-TEST-chatpair-0001", 30300, account_user_id=ACCOUNT)
    texts = ["расчёт по чаше", "Добро пожаловать", "подскажите стоимость"]
    for w in rep.warnings:
        assert not any(t in w for t in texts), "тексты сообщений не попадают в warnings"


def test_fuzzy_trap_identical_text_time_is_NOT_merged():
    """Ловушка прежнего fuzzy-режима: равные тексты, подпись снята, разница 599 с
    (< 10 мин) — СШИВКИ НЕТ. Директива 09.11: эвристики запрещены даже когда
    «очевидно пара»."""
    b24 = {"users": [{"id": 401, "name": "Тест-Бот", "bot": True}],
           "messages": [{"id": 1, "chat_id": 10, "author_id": 401,
                         "date": "2026-11-05T12:00:00+03:00",
                         "text": "Привет, займёмся расчётом",
                         "params": {"CONNECTOR_MID": ["1"]}}]}
    base = parse_iso_loose("2026-11-05T12:00:00+03:00").timestamp()
    av = [{"id": "av1", "author_id": ACCOUNT, "created": base + 599,
           "type": "text", "direction": "out", "read": None,
           "content": {"text": "Тестов Т.: Привет, займёмся расчётом"}}]
    rep = merge_chat(b24, av, "u2i-UNIT", 10, account_user_id=ACCOUNT)
    assert rep.coverage["joined_exact"] == 0
    js = {f["payload"]["join_status"] for f in rep.facts}
    assert js == {"UNLINKED"}
    # обе копии в ответе отдельными фактами
    assert any(f["source"] == "b24.ol" for f in rep.facts)
    assert any(f["source"].startswith("avito.") for f in rep.facts)


def test_outside_ten_minutes_never_candidate():
    """±10 минут больше не параметр: окно не существует ни в каком виде."""
    b24 = {"users": [], "messages": [{"id": 1, "chat_id": 10, "author_id": 402,
                                      "date": "2026-11-05T12:00:00+03:00",
                                      "text": "Привет, займёмся расчётом",
                                      "params": {}}]}
    base = parse_iso_loose("2026-11-05T12:00:00+03:00").timestamp()
    av = [{"id": "av1", "author_id": ACCOUNT, "created": base + 601, "type": "text",
           "direction": "out", "read": None,
           "content": {"text": "Тестов Т.: Привет, займёмся расчётом"}}]
    rep = merge_chat(b24, av, "u2i-UNIT", 10, account_user_id=ACCOUNT)
    assert rep.coverage["joined_exact"] == 0
    assert rep.coverage["avito_only_out"] == 1          # остаётся фактом Авито
    assert rep.coverage["b24_out_without_avito_pair"] == 1


def test_no_content_evidence_join_is_id_only():
    """Структурное доказательство: затирание ВСЕХ текстов и сдвиг всех времён
    НЕ меняют слияние — движок при склейке контент не читает."""
    fx, b24, avito, dlg = setup()
    import copy, random
    rng = random.Random(42)
    av2 = copy.deepcopy(avito)
    for r in av2:
        item = r.get("content")
        if isinstance(item, dict) and "text" in item:
            item["text"] = f"ЗАТИРАТОР {rng.random()}"
        elif isinstance(item, str):
            r["content"] = f"ЗАТИРАТОР {rng.random()}"
        r["created"] = (r.get("created") or 0) + rng.randint(-86400, 86400)
    b24b = copy.deepcopy(b24)
    for r in b24b["messages"]:
        r["text"] = f"ЗАТИРАТОР {rng.random()}"
        r["date"] = "2030-01-01T00:00:00+03:00"
    rep_a = merge_chat(b24, avito, "u2i-TEST-chatpair-0001", 30300, account_user_id=ACCOUNT)
    rep_b = merge_chat(b24b, av2, "u2i-TEST-chatpair-0001", 30300, account_user_id=ACCOUNT)
    pairs_a = sorted((f["evidence"]["b24"]["source_entity_id"],
                      f["evidence"]["avito"]["message_id"])
                     for f in rep_a.facts if f.get("evidence", {}).get("join"))
    pairs_b = sorted((f["evidence"]["b24"]["source_entity_id"],
                      f["evidence"]["avito"]["message_id"])
                     for f in rep_b.facts if f.get("evidence", {}).get("join"))
    assert pairs_a == pairs_b, "склейка не может зависеть от текста/времени"


def test_exact_key_collision_is_not_joined():
    """Один avito id в CONNECTOR_MID у двух строк Б24 → склейки нет (1:1 в обе
    стороны), обе строки AMBIGUOUS."""
    mid = "9c01aabbccddeeff00112233445566aa"
    b24 = {"users": [], "messages": [
        {"id": 1, "chat_id": 10, "author_id": 990, "date": "2026-11-05T12:00:00+03:00",
         "text": "первая", "params": {"CONNECTOR_MID": [mid]}},
        {"id": 2, "chat_id": 10, "author_id": 990, "date": "2026-11-05T12:00:10+03:00",
         "text": "вторая", "params": {"CONNECTOR_MID": [mid]}}]}
    base = parse_iso_loose("2026-11-05T12:00:00+03:00").timestamp()
    av = [{"id": mid, "author_id": 999001, "created": base, "type": "text",
           "direction": "in", "read": None, "content": {"text": "первая"}}]
    rep = merge_chat(b24, av, "u2i-UNIT", 10, account_user_id=ACCOUNT)
    assert rep.coverage["joined_exact"] == 0
    assert rep.coverage["ambiguous"] == 3   # 2 строки Б24 + строка Авито
    assert any("коллизия точного ключа" in w for w in rep.warnings)
    amb = [f for f in rep.facts if f["payload"]["join_status"] == "AMBIGUOUS"]
    assert {f["payload"]["join_reason"] for f in amb} == {"connector_mid_collision"}


def test_connector_mid_of_foreign_chat_is_ambiguous():
    """CONNECTOR_MID заявлен ДРУГИМ чатом (кросс-чат) → AMBIGUOUS, не склейка."""
    mid = "9c01aabbccddeeff00112233445566aa"
    b24_a = {"users": [], "messages": [
        {"id": 1, "chat_id": 10, "author_id": 990, "date": "2026-11-05T12:00:00+03:00",
         "text": "кто владеет ключом?", "params": {"CONNECTOR_MID": [mid]}}]}
    b24_b = {"users": [], "messages": [
        {"id": 2, "chat_id": 20, "author_id": 991, "date": "2026-11-05T12:00:05+03:00",
         "text": "другой клиент", "params": {"CONNECTOR_MID": [mid]}}]}
    base = parse_iso_loose("2026-11-05T12:00:00+03:00").timestamp()
    av = {"u2i-A": [{"id": mid, "author_id": 999001, "created": base, "type": "text",
                     "direction": "in", "read": None, "content": {"text": "да?"}}],
          "u2i-B": [{"id": "zz9", "author_id": 999002, "created": base + 5,
                     "type": "text", "direction": "in", "read": None,
                     "content": {"text": "другой"}}]}
    rep = merge_chats({"10": b24_a, "20": b24_b}, av,
                      [("10", "u2i-A"), ("20", "u2i-B")], account_user_id=ACCOUNT)
    assert rep.coverage["_totals"]["collisions_total"] >= 1
    cov_a = rep.coverage["10"]
    cov_b = rep.coverage["20"]
    assert cov_a["joined_exact"] == 0 and cov_b["joined_exact"] == 0
    assert any(f["payload"]["join_status"] == "AMBIGUOUS" for f in rep.facts)


def test_mapping_collision_same_u2i_two_chats():
    """Один u2i заявлен двумя чатами (дубли клиентов) → обе связки AMBIGUOUS,
    склейки нет, ни одному клиенту не приписано."""
    b24_a = {"users": [], "messages": [{"id": 1, "chat_id": 10, "author_id": 402,
                                        "date": "2026-11-05T12:00:00+03:00",
                                        "text": "а", "params": {}}]}
    b24_b = {"users": [], "messages": [{"id": 2, "chat_id": 20, "author_id": 403,
                                        "date": "2026-11-05T12:01:00+03:00",
                                        "text": "б", "params": {}}]}
    av = {"u2i-SHARED": [{"id": "x1", "author_id": 999001, "created": 1,
                          "type": "text", "direction": "in", "read": None,
                          "content": {"text": "общий чат"}}]}
    rep = merge_chats({"10": b24_a, "20": b24_b}, av,
                      [("10", "u2i-SHARED"), ("20", "u2i-SHARED")], account_user_id=ACCOUNT)
    assert rep.coverage["10"]["chat_binding"] == "AMBIGUOUS"
    assert rep.coverage["20"]["chat_binding"] == "AMBIGUOUS"
    assert any("заявлен несколькими чатами" in w for w in rep.warnings)
    for f in rep.facts:
        assert f["payload"]["join_status"] == "AMBIGUOUS"
        assert f["payload"]["join_reason"] == "chat_binding_collision"


def test_unmapped_chat_unlinked_no_binding_invented():
    """Чат без подтверждённой пары → UNLINKED: факты есть, привязки нет,
    выдумывание запрещено."""
    b24 = {"users": [], "messages": [{"id": 1, "chat_id": 10, "author_id": 402,
                                      "date": "2026-11-05T12:00:00+03:00",
                                      "text": "текст", "params": {}}]}
    av = [{"id": "a1", "author_id": 999001, "created": 1000, "type": "text",
           "direction": "in", "read": None, "content": {"text": "привет"}}]
    rep = merge_chats({"10": b24}, {"u2i-UNKNOWN": av}, [])
    assert any("нет подтверждённого сопоставления" in w for w in rep.warnings)
    assert any(f["source"].startswith("avito.") for f in rep.facts)  # факты не потеряны
    for f in rep.facts:
        assert f["payload"]["join_status"] == "UNLINKED"
        assert f["payload"]["join_reason"] == "no_chat_binding"


def test_incoming_never_fuzzy():
    """Входящие Авито (direction=in) без точного ключа НЕ склеиваются по тексту."""
    b24 = {"users": [{"id": 990, "connector": True, "external_auth_id": "imconnector"}],
           "messages": [{"id": 1, "chat_id": 10, "author_id": 990,
                         "date": "2026-11-05T12:00:00+03:00", "text": "Здравствуйте",
                         "params": {"CONNECTOR_MID": ["b24-local-1"]}}]}
    base = parse_iso_loose("2026-11-05T12:00:00+03:00").timestamp()
    av = [{"id": "av9", "author_id": 999001, "created": base, "type": "text",
           "direction": "in", "read": None, "content": {"text": "Здравствуйте"}}]
    rep = merge_chat(b24, av, "u2i-UNIT", 10, account_user_id=ACCOUNT)
    assert rep.coverage["joined_exact"] == 0
    assert rep.coverage["avito_only_out"] == 0          # направление in — не исходящее
    assert any("входящее без пары в Б24" in w or "CONNECTOR_MID не найден" in w
               for w in rep.warnings)


def test_avito_author_id_is_not_b24_employee():
    """author_id Авито ≠ Bitrix user_id: приписывание запрещено. Числовое
    совпадение с id сотрудника — канарейка WARN, роль исходящего — WE по
    аккаунту, employee-атрибуции нет."""
    b24 = {"users": [{"id": 402, "name": "Менеджер", "connector": False, "bot": False}],
           "messages": [{"id": 1, "chat_id": 10, "author_id": 402,
                         "date": "2026-11-05T12:00:00+03:00", "text": "ок",
                         "params": {}}]}
    base = parse_iso_loose("2026-11-05T12:00:00+03:00").timestamp()
    av = [{"id": "a1", "author_id": 402, "created": base + 30, "type": "text",
           "direction": "out", "read": None, "content": {"text": "ок"}}]
    rep = merge_chat(b24, av, "u2i-UNIT", 10, account_user_id=ACCOUNT)
    assert any("СОВПАДЕНИЕ НЕ ЯВЛЯЕТСЯ соответствием" in w for w in rep.warnings), rep.warnings
    av_fact = next(f for f in rep.facts if f["source"].startswith("avito."))
    # направление out, но author_id не совпадает с проверенным аккаунтом →
    # UNKNOWN (никому не приписано), НЕ WE и НЕ id сотрудника 402
    assert av_fact["author_role"] == "UNKNOWN"
    assert av_fact["payload"]["sender_is_account"] is False
    assert av_fact["payload"]["author_resolved"] is False
    assert "employee_id" not in av_fact["payload"]  # атрибуции сотруднику нет


def test_merge_chats_unmapped_chat_warns():
    fx, b24, avito, dlg = setup()
    rep = merge_chats({"30300": b24}, {"u2i-TEST-chatpair-0001": avito}, [])
    assert any("нет подтверждённого сопоставления" in w for w in rep.warnings)
    assert any(f["source"].startswith("avito.") for f in rep.facts)  # факты не потеряны
