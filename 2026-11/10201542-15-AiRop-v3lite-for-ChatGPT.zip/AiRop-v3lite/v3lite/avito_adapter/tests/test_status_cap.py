"""§3 протокола привязки (директива mw912vdyd7fq): VERIFIED запрещён при
наличии UNLINKED/AMBIGUOUS фактов — неполнота привязки не маскируется.

Кейс: чат Б24 без авито-пар и без каких-либо warnings — раньше адаптер
отвечал VERIFIED, хотя факты остались непривязанными. Живая приёмка
09.11 (out/acceptance_avito_live_*.json) поймала этот разрыв.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUN = os.path.join(HERE, "run.py")


def run_cli(stdin: str) -> dict:
    env = dict(os.environ)
    env.pop("AVITO_ADAPTER_LIVE", None)
    env["AVITO_ADAPTER_INDEX_DB"] = "/tmp/avito_adapter_status_cap.db"
    p = subprocess.run([sys.executable, RUN], input=stdin, capture_output=True,
                       text=True, env=env, timeout=60)
    assert p.returncode == 0, p.stderr
    return json.loads(p.stdout)


def test_verified_capped_to_partial_when_unlinked_exist():
    """Только Б24-чат без привязки и без пар: 0 warnings от движка, но есть
    UNLINKED-факты → статус обязан быть PARTIAL с поимённой причиной."""
    req = {"request_id": "cap-1", "intent": "avito_merge",
           "b24": {"chats": {"10": {"users": [], "messages": [
               {"id": 1, "chat_id": 10, "author_id": 402,
                "date": "2026-11-05T12:00:00+03:00", "text": "текст",
                "params": {}}]}}},
           "mapping": {}}
    out = run_cli(json.dumps(req))
    assert out["status"] == "PARTIAL"
    assert any("UNLINKED/AMBIGUOUS" in w and "PARTIAL" in w
               for w in out["warnings"])
    js = [f["payload"]["join_status"] for f in out["facts"]]
    assert js and set(js) == {"UNLINKED"}


def test_verified_possible_only_without_unlinked_and_warnings():
    """Пустой merge (нет данных) — фактов нет, VERIFIED не выдаётся без оснований;
    при полном отсутствии фактов и замечаний статус VERIFIED допустим."""
    out = run_cli(json.dumps({"request_id": "cap-2", "intent": "avito_merge",
                              "b24": {"chats": {}}}))
    assert out["status"] in ("VERIFIED", "PARTIAL")
    assert out["facts"] == []
