"""CLI-стык dev_agent: stdin JSON → stdout JSON, offline-режим, схема контракта."""
from __future__ import annotations

import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUN = os.path.join(HERE, "run.py")

from adapter.index import parse_entity_id

from tests.conftest import ACCOUNT, aligned_avito_rows, load_fixture


def run_cli(stdin: str, env_extra: dict | None = None) -> dict:
    env = dict(os.environ)
    env.pop("AVITO_ADAPTER_LIVE", None)
    env["AVITO_ADAPTER_INDEX_DB"] = "/tmp/avito_adapter_test_index.db"
    env.update(env_extra or {})
    p = subprocess.run([sys.executable, RUN], input=stdin, capture_output=True,
                       text=True, env=env, timeout=60)
    assert p.returncode == 0, p.stderr
    assert p.stdout.strip(), "stdout пуст"
    return json.loads(p.stdout)


def merge_request():
    fx = load_fixture("dataset_avito_b24_pair.json")
    m = fx["methods"]
    dlg = m["im.dialog.get"]["rows"][0]
    parsed = parse_entity_id(dlg["entity_id"])
    return {
        "request_id": "11111111-2222-3333-4444-555555555555",
        "intent": "avito_merge",
        "account_user_id": ACCOUNT,
        "b24": {"chats": {"30300": {
            "users": m["im.dialog.messages.get"]["users"],
            "messages": m["im.dialog.messages.get"]["rows"],
            "dialog": dlg}}},
        "avito": {"u2i-TEST-chatpair-0001": aligned_avito_rows(fx)},
        "mapping": {"30300": "u2i-TEST-chatpair-0001"},
    }


def test_merge_offline_happy_path():
    out = run_cli(json.dumps(merge_request()))
    assert out["request_id"].startswith("11111111")
    assert out["intent"] == "avito_merge"
    assert out["status"] == "PARTIAL"          # WARN расхождения ролей 1999006
    assert out["errors"] == []
    kinds = [f.get("evidence", {}).get("join", {}).get("kind") for f in out["facts"]]
    # СТРОГИЙ режим (директива 09.11): единственный вид сшивки — exact-ключ.
    # Никаких fuzzy_text_time/system_mirror существовать не может.
    assert kinds.count("exact_connector_mid") == 2
    assert {k for k in kinds if k} == {"exact_connector_mid"}
    js = [f["payload"]["join_status"] for f in out["facts"]]
    assert js.count("LINKED") == 2 and "AMBIGUOUS" not in js
    cov = out["coverage"]["merge"]["30300"]
    assert cov["duplicate_guard_dropped"] == 0
    assert cov["joined_exact"] == 2 and cov["chat_binding"] == "LINKED"
    assert out["detectors"]["duplicate_guard"] == "PASS"
    # роль в выдаче сериализована по умолчанию (extended: UNKNOWN как есть)
    roles = {f["author_role"] for f in out["facts"]}
    assert roles <= {"WE", "CLIENT", "BOT", "CONNECTOR", "UNKNOWN"}
    # таймштампы ISO с офсетом МСК
    assert all(f["timestamp"].endswith("+03:00") for f in out["facts"])


def test_merge_rejects_fuzzy_options():
    """Директива 09.11: эвристики сшивки нельзя даже ПЕРЕДАТЬ — SchemaError."""
    for opt in ("window_minutes", "text_similarity", "match_by_phone",
                "strip_signature", "fuzzy", "similarity_threshold"):
        req = merge_request()
        req["options"] = {opt: 10}
        out = run_cli(json.dumps(req))
        assert out["status"] == "FAILED", opt
        assert out["errors"] and out["errors"][0]["code"] == "SCHEMA", opt
        assert "ЗАПРЕЩЕНА" in out["errors"][0]["detail"], opt
        assert out["facts"] == []


def test_offline_collect_never_touches_network():
    out = run_cli(json.dumps({
        "request_id": "abc", "intent": "avito_collect",
        "from": "2026-11-07T00:00:00+03:00", "to": "2026-11-08T00:00:00+03:00"}))
    assert out["status"] == "FAILED"
    assert out["errors"][0]["code"] == "LIMIT"
    assert out["facts"] == []


def test_schema_violations_fail_before_anything():
    bad = [
        '{"intent":"unknown_intent","request_id":"x"}',
        '{"intent":"avito_merge"}',
        '{"intent":"avito_merge","request_id":"","b24":{}}',
        json.dumps({"intent": "avito_merge", "request_id": "x", "b24": {}, "avito": {},
                    "mapping": {}, "surprise_key": 1}),
        json.dumps({"intent": "avito_merge", "request_id": "x", "b24": {}, "avito": {},
                    "mapping": {}, "options": {"wrong_opt": 1}}),
        json.dumps({"intent": "avito_collect", "request_id": "x",
                    "from": "2026-11-07T00:00:00", "to": "2026-11-08T00:00:00+03:00"}),
        json.dumps({"intent": "avito_collect", "request_id": "x",
                    "from": "2026-11-08T00:00:00+03:00", "to": "2026-11-07T00:00:00+03:00"}),
        "not json at all",
    ]
    for raw in bad:
        out = run_cli(raw)
        assert out["status"] == "FAILED", raw
        assert out["errors"] and out["errors"][0]["code"] == "SCHEMA", raw
        assert out["facts"] == []


def test_merge_requires_input():
    out = run_cli(json.dumps({"intent": "avito_merge", "request_id": "x"}))
    assert out["status"] == "FAILED" and out["errors"][0]["code"] == "SCHEMA"


def test_unmapped_avito_chat_still_emits_facts():
    fx = load_fixture("dataset_avito_b24_pair.json")
    req = {"request_id": "x", "intent": "avito_merge",
           "avito": {"u2i-TEST-chatpair-0001": aligned_avito_rows(fx)}}
    out = run_cli(json.dumps(req))
    assert out["status"] == "PARTIAL"
    assert any(f["source"].startswith("avito.") for f in out["facts"])
    assert any("нет chatId в подтверждённом индексе" in w or "нет сопоставления" in w
               for w in out["warnings"])
    # все факты unmapped-чата: chat_binding/join_status UNLINKED
    for f in out["facts"]:
        assert f["payload"]["join_status"] == "UNLINKED"
        assert f["payload"]["join_reason"] == "no_chat_binding"


def test_no_real_secrets_in_output():
    out = json.dumps(run_cli(json.dumps(merge_request())))
    assert "83739743" not in out          # боевой account id не утекает (фикстуры обезличены)
    assert "access_token" not in out
