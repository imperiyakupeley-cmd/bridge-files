"""§9.6-B: прогрев и fallback-исходящие, которых в Б24 нет — факты не теряются.

Фикстура dataset_avito_gap_fallback.json (immutable)."""
from __future__ import annotations

from adapter.joiner import merge_chat

from tests.conftest import ACCOUNT, aligned_avito_rows, load_fixture


def setup():
    fx = load_fixture("dataset_avito_gap_fallback.json")
    m = fx["methods"]
    b24 = {"users": m["im.dialog.messages.get"]["users"],
           "messages": m["im.dialog.messages.get"]["rows"]}
    avito = aligned_avito_rows(fx)
    return fx, b24, avito


def test_gap_fallback_nothing_lost():
    fx, b24, avito = setup()
    rep = merge_chat(b24, avito, "u2i-TEST-gapfb-0002", 30310, account_user_id=ACCOUNT)

    exp = fx["methods"]["expected_merge"]
    # точная входящая — как заявлено; исходящая пара fuzzy БОЛЬШЕ НЕ СШИВАЕТСЯ
    assert rep.coverage["joined_exact"] == 1
    joined = [(f["evidence"]["b24"]["source_entity_id"], f["evidence"]["avito"]["message_id"])
              for f in rep.facts if f.get("evidence", {}).get("join")]
    assert (f"chat30310#msg{exp['in_matches'][0][0]}", exp['in_matches'][0][1]) in joined
    # бывшая «фаззи» пара: обе копии остались отдельными фактами, без склейки
    assert (f"chat30310#msg{exp['out_matches'][0][0]}", exp['out_matches'][0][1]) not in joined

    # ВСЕ 8 строк Авито присутствуют в ответе (ничего не потеряно и не выдумано)
    avito_evid: set[str] = set()
    for f in rep.facts:
        ev = f.get("evidence") or {}
        if ev.get("avito_message_id"):
            avito_evid.add(str(ev["avito_message_id"]))
        if (ev.get("avito") or {}).get("message_id"):
            avito_evid.add(str(ev["avito"]["message_id"]))
    for row in fx["methods"]["avito.v3.messages"]["rows"]:
        assert str(row["id"]) in avito_evid, f"потеряно сообщение Авито {row['id']}"

    # исходящие только-в-Авито: 6 из 6 (бывшая фаззи-пара стала avito-only:
    # fallback 5 + прогрев 2 — предпервое сообщение Б24)
    assert rep.coverage["avito_out_total"] == 6
    assert rep.coverage["avito_only_out"] == 6
    assert rep.coverage["avito_only_out_fallback"] == 4
    assert rep.coverage["avito_only_out_warming"] == 2
    assert rep.coverage["b24_out_without_avito_pair"] == 1
    assert rep.coverage["duplicate_guard_dropped"] == 0

    # прогрев помечен и объяснён в warnings
    warming = [f for f in rep.facts if f["source"].startswith("avito.")
               and f["payload"].get("pre_dialog")]
    assert len(warming) == 2
    assert exp["out_pre_dialog_only_in_avito"][0] in \
        {w["evidence"]["avito_message_id"] for w in warming}
    assert any("прогрев/догрев" in w for w in rep.warnings)

    # fallback-исходящие = WE (наш аккаунт), source avito, атрибуции менеджеру нет
    fallback = [f for f in rep.facts if f["source"].startswith("avito.")
                and f["payload"].get("direction") == "out"
                and not f["payload"].get("pre_dialog")]
    assert len(fallback) == 4
    assert all(f["author_role"] == "WE" for f in fallback)
    assert all(f["payload"]["sender_is_account"] for f in fallback)
    assert all("employee_id" not in f["payload"] for f in fallback)

    # входящее Авито без пары в Б24 («Нет, спасибо») — не потеряно, CLIENT, WARN
    dd04 = next(f for f in rep.facts
                if f.get("evidence", {}).get("avito_message_id") == "dd04eeff00aabbcc11223344556677ff")
    assert dd04["author_role"] == "CLIENT"
    assert any("dd04eeff" in w and "входящее без пары" in w for w in rep.warnings)


def test_coverage_quantifies_b24_gap():
    """Честная количественная оценка пропуска: без Авито-источника день менеджера
    теряет исходящие этого чата (спека §11.5 — одно-источниковая реализация
    отклоняется)."""
    fx, b24, avito = setup()
    rep = merge_chat(b24, avito, "u2i-TEST-gapfb-0002", 30310, account_user_id=ACCOUNT)
    cov = rep.coverage
    # в Б24 этого чата есть только ОДНО исходящее (1999019) — точной пары у него
    # нет (бывшая фаззи-склейка отменена) → честно UNLINKED без пары
    assert cov["b24_out"] == 1
    assert cov["joined_exact"] == 1
    assert cov["b24_out_without_avito_pair"] == 1
    assert cov["avito_only_out"] == 6
