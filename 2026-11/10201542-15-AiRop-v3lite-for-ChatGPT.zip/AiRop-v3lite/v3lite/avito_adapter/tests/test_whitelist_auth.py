"""Whitelist read-only и аутентификация: гарантии до любого сетевого байта."""
from __future__ import annotations

import pytest

from adapter.auth import Credentials, TokenManager
from adapter.config import AvitoConfig
from adapter.errors import AccessDenied, SecurityError, SourceError
from adapter.transport import Transport
from adapter.whitelist import Whitelist

API = "https://api.avito.ru"
TOKEN = "https://api.avito.ru/token"


def wl():
    return Whitelist(API, TOKEN)


# ------------------------------------------------------------------ whitelist
def test_whitelist_allows_two_read_endpoints():
    wl().check_get(f"{API}/messenger/v2/accounts/83739743/chats?limit=50&offset=0")
    wl().check_get(f"{API}/messenger/v3/accounts/83739743/chats/u2i-abCD_12/messages/?limit=100")
    # боевой формат u2i содержит «~» (замер 09.11.2026)
    wl().check_get(f"{API}/messenger/v3/accounts/83739743/chats/u2i-JzW7xj5vnZ3n~eIla~CyaA/messages/")


def test_whitelist_denies_everything_else():
    bad = [
        f"{API}/messenger/v1/accounts/1/chats/1/messages",          # другая версия
        f"{API}/messenger/v2/accounts/1/chats/u2i-x/messages",      # v2 с messages
        f"https://evil.example/messenger/v2/accounts/1/chats",      # чужой хост
        f"{API}/messenger/v3/accounts/1/chats/../messages/",        # инъекция пути
        f"{API}/messenger/v3/accounts/1/chats/u2i x/messages/",     # пробел в пути
        TOKEN,                                                      # GET токена
    ]
    for url in bad:
        with pytest.raises(SecurityError):
            wl().check_get(url)


def test_whitelist_post_only_token():
    wl().check_post(TOKEN)
    for url in (f"{API}/messenger/v2/accounts/1/chats",
                f"{API}/messenger/v3/accounts/1/chats/u2i-1/messages/",
                f"{API}/messages/send"):
        with pytest.raises(SecurityError):
            wl().check_post(url)


def test_real_transport_enforces_whitelist_before_network():
    t = Transport(wl())
    with pytest.raises(SecurityError):
        t.get(f"{API}/messenger/v1/accounts/1/chats", timeout=1)
    with pytest.raises(SecurityError):
        t.post(f"{API}/messenger/v3/accounts/1/chats/u2i-1/messages/", {}, timeout=1)


def test_client_has_no_write_methods():
    from adapter.client import AvitoClient
    write_like = [m for m in dir(AvitoClient)
                  if any(w in m.lower() for w in ("send", "post_msg", "create", "edit",
                                                  "delete", "mark_", "update"))]
    assert write_like == [], f"у read-only клиента не должно быть методов записи: {write_like}"


# ---------------------------------------------------------------------- auth
def test_offline_config_forbids_client(tmp_path):
    cfg = AvitoConfig(live=False, index_db=str(tmp_path / "idx.db"))
    with pytest.raises(SecurityError):
        __import__("adapter.client", fromlist=["AvitoClient"]).AvitoClient(cfg)


def test_credentials_missing_file(tmp_path):
    with pytest.raises(SourceError):
        Credentials(str(tmp_path / "nope.json"))


def test_credentials_repr_masks_secret(tmp_path):
    p = tmp_path / "creds.json"
    p.write_text('{"client_id":"id1","client_secret":"TOPSECRET","user_id":83739743,'
                 '"api_base":"https://api.avito.ru","token_url":"https://api.avito.ru/token"}')
    c = Credentials(str(p))
    r = repr(c)
    assert "TOPSECRET" not in r and "id1" not in r
    assert c.user_id == 83739743


class _T:
    def __init__(self, statuses=(200,), bodies=None):
        self.statuses = list(statuses)
        self.bodies = bodies or []
        self.posts = 0

    def post(self, url, payload, timeout):
        self.posts += 1
        from adapter.transport import HttpResult
        st = self.statuses.pop(0) if len(self.statuses) > 1 else self.statuses[0]
        body = self.bodies.pop(0) if self.bodies else b'{"access_token":"t1","expires_in":3600}'
        return HttpResult(st, {}, body)


def test_token_cached_and_invalidated_on_401(tmp_path):
    p = tmp_path / "creds.json"
    p.write_text('{"client_id":"i","client_secret":"s","user_id":1}')
    creds = Credentials(str(p))
    t = _T()
    tm = TokenManager(creds, t, timeout_s=5)
    tok1 = tm.token()
    tok2 = tm.token()                     # кэш: нового POST нет
    assert tok1 == tok2 and t.posts == 1
    tm.invalidate()
    tm.token()
    assert t.posts == 2


def test_token_denied_maps_to_access_denied(tmp_path):
    p = tmp_path / "creds.json"
    p.write_text('{"client_id":"i","client_secret":"s","user_id":1}')
    t = _T(statuses=(401,), bodies=[b'{"error":"invalid_client"}'])
    with pytest.raises(AccessDenied):
        TokenManager(Credentials(str(p)), t, timeout_s=5).token()


def test_client_401_refreshes_token_and_retries_once(make_fake):
    fake = make_fake()
    client = make_client_for(fake)
    # эмулируем просроченный токен: первый ответ 401, после обновления — 200
    calls = {"n": 0}

    class RT:
        whitelist = None

        def get(self, url, timeout, headers=None):
            calls["n"] += 1
            from adapter.transport import HttpResult
            return HttpResult(401 if calls["n"] == 1 else 200, {},
                              b'{"messages": []}')

        def post(self, url, payload, timeout):
            from adapter.transport import HttpResult
            return HttpResult(200, {}, b'{"access_token":"fresh","expires_in":3600}')

    client.transport = RT()
    page = client.get_messages_page("u2i-x")
    assert page.items == []
    # токен: первичное получение + обновление после 401, затем успех без нового
    assert calls["n"] == 2 and client.tokens.fetches == 2


# ------------------------------------------------------------------ хелперы
@pytest.fixture
def make_fake():
    def _f(chats=None, messages=None):
        from tests.conftest import FakeAvito
        return FakeAvito(chats=chats, messages=messages)
    return _f


def make_client_for(fake, **kw):
    from tests.conftest import ACCOUNT, FakeTransport, make_client
    return make_client(fake, account=kw.pop("account", ACCOUNT), **kw)
