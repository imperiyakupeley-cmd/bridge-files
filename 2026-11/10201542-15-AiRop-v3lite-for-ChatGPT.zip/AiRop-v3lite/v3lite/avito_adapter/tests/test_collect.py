"""Сбор за окно: пагинация, канарейки, границы [from,to), отказы источника."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from adapter.collector import collect_window
from adapter.errors import RateLimitError
from adapter.timeutil import OFFSET, from_epoch

from tests.conftest import FakeAvito, FakeTransport
from tests.test_whitelist_auth import make_client_for

ACC = 999000
DAY = datetime(2026, 11, 9, tzinfo=OFFSET)


def ep(dt: datetime) -> int:
    return int(dt.timestamp())


def msg(i, dt, direction="in", author=999001, text="текст"):
    return {"id": f"id{i:04}", "author_id": author, "created": ep(dt),
            "type": "text", "direction": direction, "read": None,
            "content": {"text": text}}


def chat_row(u2i, updated_dt, last=None):
    row = {"id": u2i, "updated_ts": ep(updated_dt)}
    if last:
        row["last_message"] = last
    return row


def test_window_semantics_and_sorting():
    u2i = "u2i-T1"
    msgs = [
        msg(1, DAY + timedelta(hours=25), "out", ACC, "послезавтра — мимо"),
        msg(2, DAY + timedelta(hours=10), "in", 999001, "внутри окна 1"),
        msg(3, DAY + timedelta(hours=12), "out", ACC, "внутри окна 2"),
        msg(4, DAY - timedelta(hours=1), "out", ACC, "вчера — мимо"),
    ]
    fake = FakeAvito(chats=[chat_row(u2i, DAY + timedelta(hours=12))],
                     messages={u2i: msgs})
    client = make_client_for(fake)
    res = collect_window(client, frm=DAY, to=DAY + timedelta(hours=24),
                         include_card_events=False)
    got = [f["payload"]["text"] for f in res.facts]
    assert got == ["внутри окна 1", "внутри окна 2"]   # [from, to): границы точные
    assert res.status == "VERIFIED"
    assert res.detectors["window_canary"] == "PASS"
    assert res.detectors["offset_canary"] == "PASS"
    cov = res.coverage["avito"]
    assert cov["messages_in_window"] == 2
    assert cov["messages_scanned"] == len(msgs)


def test_pagination_stops_at_window_floor_and_canary_pass():
    u2i = "u2i-P1"
    msgs = [msg(i, DAY + timedelta(hours=10) - timedelta(minutes=5 * i), "out", ACC,
                f"стр {i}") for i in range(50)] + \
           [msg(100, DAY - timedelta(days=2), "out", ACC, "глубокая старина")]
    fake = FakeAvito(chats=[chat_row(u2i, DAY + timedelta(hours=10))],
                     messages={u2i: msgs})
    client = make_client_for(fake, messages_page=30)
    res = collect_window(client, frm=DAY, to=DAY + timedelta(hours=24),
                         include_card_events=False)
    assert res.detectors["offset_canary"] == "PASS"
    assert res.coverage["avito"]["messages_in_window"] == 50


def test_offset_ignored_by_server_is_fail_closed():
    u2i = "u2i-O1"
    msgs = [msg(i, DAY + timedelta(hours=10) - timedelta(minutes=i), "out", ACC,
                f"стр {i}") for i in range(40)]
    fake = FakeAvito(chats=[chat_row(u2i, DAY + timedelta(hours=10))],
                     messages={u2i: msgs}, ignore_offset=True)
    client = make_client_for(fake, messages_page=25)
    res = collect_window(client, frm=DAY, to=DAY + timedelta(hours=24),
                         include_card_events=False)
    assert res.detectors["offset_canary"] == "FAIL"
    assert res.truncated and res.status == "PARTIAL"
    assert any("offset игнорируется" in w for w in res.warnings)


def test_listing_early_stop_by_updated_ts():
    old = chat_row("u2i-OLD", DAY - timedelta(days=30))
    fresh = chat_row("u2i-FRESH", DAY + timedelta(hours=1))
    fake = FakeAvito(chats=[fresh, old],
                     messages={"u2i-FRESH": [msg(1, DAY + timedelta(hours=1))],
                               "u2i-OLD": [msg(2, DAY - timedelta(days=29))]})
    client = make_client_for(fake, chats_page=1)
    res = collect_window(client, frm=DAY, to=DAY + timedelta(hours=24),
                         include_card_events=False)
    assert res.coverage["avito"]["early_stop_by_updated_ts"] is True
    assert not any("старина" in (f["payload"]["text"] or "") for f in res.facts)


def test_chats_pages_cap_truncates_honestly():
    chats = [chat_row(f"u2i-C{i}", DAY + timedelta(hours=1)) for i in range(6)]
    fake = FakeAvito(chats=chats,
                     messages={c["id"]: [msg(1, DAY + timedelta(hours=2))] for c in chats})
    client = make_client_for(fake, chats_page=2)
    res = collect_window(client, frm=DAY, to=DAY + timedelta(hours=24),
                         max_chats_pages=2, include_card_events=False)
    assert res.truncated and res.status == "PARTIAL"
    assert any("max_chats_pages" in w for w in res.warnings)


def test_max_messages_per_chat_guard():
    u2i = "u2i-M1"
    msgs = [msg(i, DAY + timedelta(hours=10) - timedelta(seconds=i), "out", ACC,
                f"m{i}") for i in range(30)]
    fake = FakeAvito(chats=[chat_row(u2i, DAY + timedelta(hours=10))],
                     messages={u2i: msgs})
    client = make_client_for(fake)
    res = collect_window(client, frm=DAY, to=DAY + timedelta(hours=24),
                         max_messages_per_chat=10, include_card_events=False)
    assert res.truncated and res.status == "PARTIAL"
    assert u2i in res.coverage["avito"]["chats_truncated"]


def test_429_after_retries_partial_with_errors():
    u2i = "u2i-R1"
    fake = FakeAvito(chats=[chat_row(u2i, DAY + timedelta(hours=1))],
                     messages={u2i: [msg(1, DAY + timedelta(hours=1))]})
    fake.fail = {"/messages/": 429}
    client = make_client_for(fake, retries_max=2, backoff_base_s=0.001,
                             backoff_cap_s=0.002)
    res = collect_window(client, frm=DAY, to=DAY + timedelta(hours=24),
                         include_card_events=False)
    assert res.status in ("PARTIAL", "FAILED")
    assert res.errors and res.errors[0]["code"] == "SOURCE_429"


def test_card_events_from_v2_last_message_only():
    viewed = {"type": "system", "text": "Пользователь посмотрел номер телефона из объявления",
              "created": ep(DAY + timedelta(hours=2))}
    fake = FakeAvito(chats=[chat_row("u2i-V1", DAY + timedelta(hours=3), last=viewed)],
                     messages={"u2i-V1": [msg(1, DAY + timedelta(hours=3), "in", 999001,
                                              "обычное сообщение")]})
    client = make_client_for(fake)
    res = collect_window(client, frm=DAY, to=DAY + timedelta(hours=24))
    evs = [f for f in res.facts if f["source"] == "avito.messenger.v2"]
    assert len(evs) == 1 and evs[0]["payload"]["interest_event"] == "viewed_phone"
    assert "НЕ гарантируется" in evs[0]["payload"]["completeness"]
    assert res.coverage["avito"]["card_events"]["gaps"]["v3_history_has_card_events"] is False


def test_unknown_created_dropped_not_guessed():
    u2i = "u2i-N1"
    bad = {"id": "bad1", "author_id": ACC, "created": "не-эпоха", "direction": "out",
           "type": "text", "content": {"text": "х"}}
    fake = FakeAvito(chats=[chat_row(u2i, DAY + timedelta(hours=1))],
                     messages={u2i: [bad, msg(1, DAY + timedelta(hours=2))]})
    client = make_client_for(fake)
    res = collect_window(client, frm=DAY, to=DAY + timedelta(hours=24),
                         include_card_events=False)
    assert len(res.facts) == 1
    assert any("без корректного created" in w for w in res.warnings)
