"""§9.6-C: индекс u2i↔chatId — разбор entity_id/userCode, скоуп линий, immutability.

Фикстура dataset_avito_sessions.json (immutable)."""
from __future__ import annotations

from adapter.index import ChatIndex, parse_entity_id

from tests.conftest import load_fixture


def test_parse_entity_id_avito_line():
    p = parse_entity_id("avito|2|u2i-TEST-sess-0003|992")
    assert p == {"channel": "avito", "line": 2, "u2i": "u2i-TEST-sess-0003",
                 "connector_user_id": 992}


def test_parse_entity_id_non_avito_is_none():
    # линия WhatsApp/MAX: userCode не с префикса avito|N (фикстура C, sess 29490)
    assert parse_entity_id("fe0a3b21-85a5|6|79000000001|994") is None
    assert parse_entity_id(None) is None
    assert parse_entity_id("") is None
    assert parse_entity_id("avito|x|u2i|1") is None


def test_session_rows_feed_index_only_avito_lines():
    fx = load_fixture("dataset_avito_sessions.json")
    rows = fx["methods"]["imopenlines.v2.Session.list"]["rows"]
    idx = ChatIndex(None)
    added = idx.put_session_rows(rows)
    assert added == 2                      # только авито-строки (2 из 3)
    assert idx.get("u2i-TEST-sess-0003") == 31656
    assert idx.get("u2i-TEST-sess-0004") == 31000
    assert idx.reverse(30900) is None      # не-авито чат в индекс не попал
    assert idx.reverse(31656) == "u2i-TEST-sess-0003"


def test_line_separation_avito_vs_other():
    fx = load_fixture("dataset_avito_sessions.json")
    rows = fx["methods"]["imopenlines.v2.Session.list"]["rows"]
    avito = [r for r in rows if parse_entity_id(r.get("userCode"))]
    other = [r for r in rows if not parse_entity_id(r.get("userCode"))]
    assert len(avito) == 2 and all(r["configId"] in (2, 4) for r in avito)
    assert len(other) == 1 and other[0]["configId"] == 6


def test_no_open_sessions_older_than_31_days_claimed():
    """AUTO_CLOSE_TIME=2678400 (31 день) — открытых старше 31 дня не бывает;
    индекс никогда не заявляет «открыта» для закрытых строк."""
    fx = load_fixture("dataset_avito_sessions.json")
    rows = fx["methods"]["imopenlines.v2.Session.list"]["rows"]
    for r in rows:
        if r.get("dateClose") is None:
            created = r["dateCreate"][:10]
            # открытая строка обязана быть свежее 31 дня (фикстура это соблюдает)
            assert created >= "2026-10-09"


def test_dialog_rows_and_inline_mapping(tmp_path):
    fx = load_fixture("dataset_avito_b24_pair.json")
    dlg = fx["methods"]["im.dialog.get"]["rows"][0]
    idx = ChatIndex(str(tmp_path / "idx.db"))
    assert idx.put_dialog_rows([dlg]) == 1
    assert idx.get("u2i-TEST-chatpair-0001") == 30300
    # персистентность: новый экземпляр видит запись
    idx2 = ChatIndex(str(tmp_path / "idx.db"))
    assert idx2.get("u2i-TEST-chatpair-0001") == 30300
    # inline-маппинг тоже валиден
    idx2.put("u2i-INLINE", 42, source="inline")
    assert idx2.get("u2i-INLINE") == 42
