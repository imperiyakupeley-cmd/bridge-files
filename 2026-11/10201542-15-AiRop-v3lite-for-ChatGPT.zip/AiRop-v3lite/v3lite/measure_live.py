#!/usr/bin/env python3
"""Сквозные замеры v3 core на реальном портале (read-only). Печатает только
агрегаты (статусы/счётчики/времена), без персональных данных и payload'ов.

python3 measure_live.py
"""
import json
import os
import sqlite3
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.collect import run_request

DAY = "2026-11-06"   # пятница


def brief(resp):
    facts = resp.get("facts", [])
    by_type = {}
    for f in facts:
        by_type[f["fact_type"]] = by_type.get(f["fact_type"], 0) + 1
    out = {
        "status": resp.get("status"),
        "facts_total": len(facts),
        "facts_by_type": by_type,
        "warnings": len(resp.get("warnings", [])),
        "errors": [e.get("code") for e in resp.get("errors", [])],
        "detectors": {k: v for k, v in resp.get("detectors", {}).items()
                      if k in ("filter_canary", "pagination_canary",
                               "window_canary", "author_crosscheck")},
        "meta": resp.get("meta"),
    }
    cov = resp.get("coverage", {})
    out["coverage_keys"] = {
        k: {kk: vv for kk, vv in v.items()
            if kk in ("rows", "total", "pages", "truncated", "stop_reason",
                      "duplicates_dropped", "matched_voximpl",
                      "unmatched_activities", "last_row", "leads",
                      "first_touch_in_window", "first_touch_outside_window",
                      "without_any_activity", "activities", "classification")}
        for k, v in cov.items() if isinstance(v, dict)}
    return out


def main():
    # менеджер с наибольшим числом звонков в пятницу (из calls.db, read-only)
    con = sqlite3.connect(f"file:{os.path.expanduser('~/AiRop/calls.db')}?mode=ro",
                          uri=True)
    mgr = con.execute(
        "SELECT manager_id, COUNT(*) c FROM calls WHERE start_date >= ? AND "
        "start_date < ? GROUP BY manager_id ORDER BY c DESC LIMIT 1",
        (f"{DAY}T00:00:00+03:00", "2026-11-07T00:00:00+03:00")).fetchone()
    con.close()
    mgr_id = mgr[0] if mgr else 20116
    n_calls = mgr[1] if mgr else 0
    print(json.dumps({"manager_for_manager_day": mgr_id,
                      "voximpl_calls_that_day": n_calls}, ensure_ascii=False))

    frm, to = f"{DAY}T00:00:00+03:00", "2026-11-07T00:00:00+03:00"
    cases = [
        ("leads_day", {"intent": "leads_day", "request_id": "m-leads",
                       "from": frm, "to": to}),
        ("leads_day (повтор — кэш)", {"intent": "leads_day",
                                      "request_id": "m-leads", "from": frm,
                                      "to": to}),
        ("calls_day", {"intent": "calls_day", "request_id": "m-calls",
                       "from": frm, "to": to}),
        ("manager_day", {"intent": "manager_day", "request_id": "m-mgr",
                         "employee_id": mgr_id, "from": frm, "to": to}),
        ("resolve_employee", {"intent": "resolve_employee",
                              "request_id": "m-emp", "employee_id": mgr_id}),
    ]
    for name, req in cases:
        t0 = time.monotonic()
        resp = run_request(req)
        wall = int((time.monotonic() - t0) * 1000)
        b = brief(resp)
        b["wall_ms"] = wall
        print(f"\n=== {name} ===")
        print(json.dumps(b, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
