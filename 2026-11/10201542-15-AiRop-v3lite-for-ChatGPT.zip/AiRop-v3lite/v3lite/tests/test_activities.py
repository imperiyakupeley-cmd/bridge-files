"""get_activities / manager_day: TODO TYPE_ID=6, автор vs ответственный, дедуп."""
from datetime import datetime

from core.client import BitrixClient
from core.sources import activities

REQ = {"intent": "manager_day", "request_id": "rid-mgr-1", "employee_id": 401,
       "from": "2026-11-07T00:00:00+03:00", "to": "2026-11-08T00:00:00+03:00"}


def run(cfg, portal):
    from conftest import FakeTransport
    t = FakeTransport(portal)
    c = BitrixClient(cfg, transport=t, sleep=lambda s: None)
    from core.contract import validate_request
    return activities.collect(c, validate_request(REQ),
                              exclude_users=cfg.exclude_users), t


class TestClassification:
    def test_todo_type6_provider_todo(self, cfg, portal):
        portal.add_activity(7001, datetime(2026, 11, 7, 10), type_id=6,
                            pti="TODO", responsible=401, author=401,
                            subject="Позвонить клиенту", owner=("deal", 9001))
        resp, _ = run(cfg, portal)
        f = resp["facts"][0]
        assert f["fact_type"] == "task_todo"
        assert f["payload"]["kind"] == "todo"
        assert f["author_id"] == 401          # ручное TODO: автор = AUTHOR_ID
        assert f["crm_entity"] == {"type": "deal", "id": 9001}

    def test_message_index_author_is_responsible_not_author1(self, cfg, portal):
        """AUTHOR_ID=1 — коннектор: фактический автор исходящего = RESPONSIBLE_ID."""
        portal.add_activity(7002, datetime(2026, 11, 7, 11), type_id=6,
                            pti="CONFIGURABLE", responsible=401, author=1,
                            subject="Исходящее сообщение", owner=("lead", 101))
        resp, _ = run(cfg, portal)
        f = [x for x in resp["facts"]
             if x["source_entity_id"] == "activity:7002"][0]
        assert f["fact_type"] == "message"
        assert f["author_id"] == 401 and f["author_role"] == "WE"
        assert f["evidence"]["AUTHOR_ID_raw"] == 1
        assert f["payload"]["chat_ref"] == "lead:101"

    def test_incoming_message_is_client(self, cfg, portal):
        portal.add_activity(7003, datetime(2026, 11, 7, 12), type_id=6,
                            pti="CONFIGURABLE", responsible=401, author=1,
                            subject="Входящее сообщение", owner=("contact", 55))
        resp, _ = run(cfg, portal)
        f = [x for x in resp["facts"]
             if x["source_entity_id"] == "activity:7003"][0]
        assert f["author_role"] == "CLIENT" and f["author_id"] is None

    def test_foreign_responsible_not_collected(self, cfg, portal):
        # входящее на бота (17316) — не день менеджера 401
        portal.add_activity(7013, datetime(2026, 11, 7, 12), type_id=6,
                            pti="CONFIGURABLE", responsible=17316, author=1,
                            subject="Входящее сообщение")
        resp, _ = run(cfg, portal)
        assert all(f["source_entity_id"] != "activity:7013"
                   for f in resp["facts"])

    def test_call_activity_author_responsible(self, cfg, portal):
        portal.add_activity(7004, datetime(2026, 11, 7, 13), type_id=2,
                            responsible=401, author=1, subject="Исходящий на X")
        resp, _ = run(cfg, portal)
        f = [x for x in resp["facts"]
             if x["source_entity_id"] == "activity:7004"][0]
        assert f["fact_type"] == "call" and f["author_id"] == 401

    def test_meeting_maps_to_task_todo_kind(self, cfg, portal):
        portal.add_activity(7005, datetime(2026, 11, 7, 14), type_id=1,
                            responsible=401, author=401, subject="Встреча")
        resp, _ = run(cfg, portal)
        f = resp["facts"][0]
        assert f["fact_type"] == "task_todo" and f["payload"]["kind"] == "meeting"


class TestAuthorVsResponsible:
    def test_by_author_collects_connector_free_rows(self, cfg, portal):
        # активность, где 401 автор, но ответственный другой сотрудник
        portal.add_activity(7006, datetime(2026, 11, 7, 15), type_id=6,
                            pti="TODO", responsible=999, author=401,
                            subject="Ручное дело 401")
        resp, _ = run(cfg, portal)
        assert any(f["source_entity_id"] == "activity:7006" for f in resp["facts"])

    def test_author1_never_collected_as_author(self, cfg, portal):
        # AUTHOR_ID=1, RESPONSIBLE=999 — не должна прилететь по автору
        portal.add_activity(7007, datetime(2026, 11, 7, 16), type_id=6,
                            pti="CONFIGURABLE", responsible=999, author=1,
                            subject="Чужое", owner=("deal", 7))
        resp, _ = run(cfg, portal)
        assert all(f["source_entity_id"] != "activity:7007" for f in resp["facts"])

    def test_dedup_between_two_queries(self, cfg, portal):
        # одна активность: responsible=401 И author=401 → один факт
        portal.add_activity(7008, datetime(2026, 11, 7, 17), type_id=6,
                            pti="TODO", responsible=401, author=401, subject="X")
        resp, _ = run(cfg, portal)
        assert len(resp["facts"]) == 1


class TestManagerDayBoundary:
    def test_partial_due_openlines_stub(self, cfg, portal):
        portal.add_activity(7009, datetime(2026, 11, 7, 18), type_id=6,
                            pti="CONFIGURABLE", responsible=401, subject="Y")
        resp, t = run(cfg, portal)
        assert resp["status"] == "PARTIAL"     # тексты сообщений — модуль dev_agent
        codes = [e["code"] for e in resp["errors"]]
        assert "NOT_IMPLEMENTED" in codes
        assert "imopenlines" not in " ".join(t.urls)  # core не ходит в ОЛ

    def test_coverage_kinds(self, cfg, portal):
        portal.add_activity(7010, datetime(2026, 11, 7, 19), type_id=6,
                            pti="TODO", responsible=401, author=401, subject="Z")
        resp, _ = run(cfg, portal)
        assert resp["coverage"]["classification"]["task_todo"] == 1


class TestBotTaskGC1:
    """C13/GC-1 (приёмка admin2 09.11): задачи бота PROVIDER=TASKS_TASK/
    CRM_WEBDAV_TASK («Отложенный клиент», бот dogrev 15780) — автор бот,
    НЕ менеджер. Живой эталон: у Галины 20116 две таких задачи при 15 своих
    просрочках — активность бота завышала показатели менеджера."""

    def test_tasks_task_bot_author(self, cfg, portal):
        # RESPONSIBLE=401 (менеджер), AUTHOR=15780 (бот dogrev)
        portal.add_activity(7101, datetime(2026, 11, 7, 9, 30), type_id=6,
                            pti="TASKS_TASK", responsible=401, author=15780,
                            subject="Отложенный клиент", owner=("deal", 9001),
                            provider_id="TASKS_TASK")
        resp, _ = run(cfg, portal)
        f = [x for x in resp["facts"] if x["source_entity_id"] == "activity:7101"]
        assert len(f) == 1
        f = f[0]
        assert f["fact_type"] == "task_todo"
        assert f["payload"]["kind"] == "bot_task"          # НЕ todo менеджера
        assert f["author_id"] == 15780                     # AUTHOR_ID-бот
        assert f["author_role"] == "BOT"                   # боту, не менеджеру
        assert f["author_id"] != 401

    def test_crm_webdav_task_provider_id_only(self, cfg, portal):
        # PROVIDER_TYPE_ID пустой, различение по PROVIDER_ID=CRM_WEBDAV_TASK
        portal.add_activity(7102, datetime(2026, 11, 7, 9, 40), type_id=6,
                            pti="", responsible=401, author=15780,
                            subject="Отложенный клиент", owner=("deal", 9001),
                            provider_id="CRM_WEBDAV_TASK")
        resp, _ = run(cfg, portal)
        f = [x for x in resp["facts"] if x["source_entity_id"] == "activity:7102"][0]
        assert f["payload"]["kind"] == "bot_task"
        assert f["author_role"] == "BOT"

    def test_bot_task_not_counted_as_manager_todo(self, cfg, portal):
        # день с 1 ручным TODO + 2 задачами бота: у менеджера только 1 todo
        portal.add_activity(7103, datetime(2026, 11, 7, 10), type_id=6,
                            pti="TODO", responsible=401, author=401,
                            subject="Связаться с клиентом", owner=("deal", 9001))
        portal.add_activity(7104, datetime(2026, 11, 7, 10, 30), type_id=6,
                            pti="TASKS_TASK", responsible=401, author=15780,
                            subject="Отложенный клиент", owner=("deal", 9001),
                            provider_id="TASKS_TASK")
        portal.add_activity(7105, datetime(2026, 11, 7, 11), type_id=6,
                            pti="TASKS_TASK", responsible=401, author=15780,
                            subject="Отложенный клиент", owner=("deal", 9001),
                            provider_id="TASKS_TASK")
        resp, _ = run(cfg, portal)
        todo = [f for f in resp["facts"] if f["payload"]["kind"] == "todo"]
        bot = [f for f in resp["facts"] if f["payload"]["kind"] == "bot_task"]
        assert len(todo) == 1 and todo[0]["author_id"] == 401
        assert len(bot) == 2 and all(b["author_role"] == "BOT" for b in bot)
        cls = resp["coverage"]["classification"]
        assert cls["task_todo"] == 3            # факты есть, но kind развёден
        # provider-различие видно в payload (GC-1 PASS-критерий)
        assert bot[0]["payload"]["provider_id"] == "TASKS_TASK"
        assert todo[0]["payload"].get("provider_id") is None


class TestAuthorIdInt:
    """Спека §4: author_id всегда int|None (приёмка admin2: нестабильный тип)."""

    def test_author_ids_always_int_or_none(self, cfg, portal):
        portal.add_activity(7110, datetime(2026, 11, 7, 12), type_id=6,
                            pti="TODO", responsible="401", author="401",
                            subject="Дело")           # Bitrix отдаёт строки
        portal.add_activity(7111, datetime(2026, 11, 7, 12, 30), type_id=2,
                            responsible="401", author="1", subject="Звонок")
        portal.add_activity(7112, datetime(2026, 11, 7, 13), type_id=6,
                            pti="CONFIGURABLE", responsible="401", author="1",
                            subject="Входящее сообщение")
        resp, _ = run(cfg, portal)
        for f in resp["facts"]:
            assert f["author_id"] is None or isinstance(f["author_id"], int), f
        call = [f for f in resp["facts"]
                if f["source_entity_id"] == "activity:7111"][0]
        assert call["author_id"] == 401          # str "401" → int (роль WE)


class TestOwnerDangleGC8:
    """D5/GC-8 (приёмка admin2 09.11): activity 1001974 висит на контакте,
    которого нет (имели в виду сделку с тем же ID) — не молча и не VERIFIED."""

    def test_dangle_warning_partial_payload_marker(self, cfg, portal):
        # контакт 8888 НЕ создаём: звонок-активность на призраке
        portal.add_activity(7120, datetime(2026, 11, 7, 14), type_id=2,
                            responsible=401, author=1,
                            subject="Исходящий звонок (13 мин)",
                            owner=("contact", 8888))
        resp, _ = run(cfg, portal)
        assert resp["status"] == "PARTIAL"            # warning ≠ VERIFIED
        assert any("owner dangle" in w for w in resp["warnings"])
        f = [x for x in resp["facts"]
             if x["source_entity_id"] == "activity:7120"][0]
        assert f["payload"]["owner_status"] == "dangling"
        assert f["crm_entity"] == {"type": "contact", "id": 8888}  # не выброшен
        oc = resp["coverage"]["owner_check"]
        assert oc["checked"] >= 1 and oc["dangling"] == 1
        assert oc["dangling_refs"] == ["contact:8888"]

    def test_existing_owner_stays_verified_path(self, cfg, portal):
        portal.add_activity(7121, datetime(2026, 11, 7, 15), type_id=2,
                            responsible=401, author=1, subject="Звонок",
                            owner=("contact", 77))    # контакт существует
        resp, _ = run(cfg, portal)
        # звонок без пары voximpl → предупреждение про calls.db, но НЕ dangle
        assert not any("owner dangle" in w for w in resp["warnings"])
        oc = resp["coverage"]["owner_check"]
        assert oc["dangling"] == 0
