"""client_dossier (F3): идентификация GC-4, кластер GC-2/5, owner dangle GC-8,
этапы GC-9, тексты-стаб GC-10. Обезличенный аналог живого кластера
«два Михаила»: contact 3001/3002 (один телефон), lead 2001 CONVERTED,
deal 5001 без звонков; звонки кластера 5+7+9=21 (эталон GC-2).
"""
import json
from datetime import datetime

import pytest

from core.collect import run_request

PHONE = "+79000000001"
IM = "imol|avito|2|u2i-testprofile0001"


def _mk_cluster(portal, calls_db):
    from conftest import insert_call
    # контакты-дубли: один телефон, один IM-профиль (2 ключа → «вероятный дубль»)
    portal.add_contact(3001, "Михаил Тест", phones=[PHONE], ims=[IM])
    portal.add_contact(3002, "Михаил Тест", phones=[PHONE], ims=[IM])
    # лид кластера (CONVERTED → contact 3001)
    lead = portal.add_lead(2001, datetime(2026, 10, 5, 9), status="CONVERTED")
    lead["CONTACT_ID"] = 3001
    # сделка на основном контакте — БЕЗ звонков (эталон GC-2)
    portal.add_deal(5001, contact_id=3001, title="Михаил — Авито (тест)")
    portal.add_stage(5001, "NEW", datetime(2026, 10, 6, 10))
    portal.add_stage(5001, "PREPARATION", datetime(2026, 10, 20, 12), user_id=401)
    # дубли по телефону: оба контакта + лид (сделка в findbycomm не попадает)
    portal.dups_by_phone["79000000001"] = {"CONTACT": [3001, 3002],
                                           "LEAD": [2001]}
    # звонки кластера: 5 на лид + 7 на дубль + 9 на основной контакт
    aid = 6000
    for k in range(5):
        portal.add_activity(aid + k, datetime(2026, 10, 5, 10 + k), type_id=2,
                            responsible=401, author=1, subject="Исходящий",
                            owner=("lead", 2001))
    for k in range(7):
        portal.add_activity(aid + 10 + k, datetime(2026, 10, 6, 10 + k),
                            type_id=2, responsible=401, author=1,
                            subject="Исходящий", owner=("contact", 3002))
    for k in range(9):
        adt = datetime(2026, 10, 7, 10 + k)
        portal.add_activity(aid + 20 + k, adt, type_id=2, responsible=401,
                            author=1, subject="Исходящий", owner=("contact", 3001))
        # voximpl-пары только для 9 звонков основного контакта
        insert_call(calls_db, bx_stat_id=f"77{k:02d}",
                    activity_id=str(aid + 20 + k), entity_type="CONTACT",
                    entity_id="3001", phone=PHONE,
                    start_date=adt.strftime("%Y-%m-%dT%H:%M:%S+03:00"))
    # сообщение на сделке (индекс без текста, GC-10)
    portal.add_activity(6100, datetime(2026, 10, 8, 15), type_id=6,
                        pti="CONFIGURABLE", responsible=401, author=1,
                        subject="Исходящее сообщение", owner=("deal", 5001))


def _run(cfg, rt, entity, **extra):
    req = {"intent": "client_dossier", "request_id": "dossier-t",
           "entity": entity, **extra}
    return run_request(req, cfg=cfg, transport=rt, use_cache=False)


@pytest.fixture
def stand(cfg, portal, calls_db):
    _mk_cluster(portal, calls_db)
    from conftest import FakeTransport
    return FakeTransport(portal)


class TestIdentificationGateGC4:
    def test_echo_id_and_gate(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        assert resp["result"]["identification"]["echo"] == "contact:3001"
        assert "точного" in resp["result"]["identification"]["gate"] or \
            "exact_type_id" in resp["result"]["identification"]["gate"]

    def test_ghost_entity_not_found(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 9999})
        assert resp["status"] == "FAILED"
        assert resp["errors"][0]["code"] == "NOT_FOUND"
        assert resp["facts"] == []          # досье по призраку не строится

    def test_name_is_not_a_key(self, cfg, portal, stand):
        resp = run_request({"intent": "client_dossier", "request_id": "d-n",
                            "entity": {"type": "contact", "id": 3001},
                            "name": "Михаил"},
                           cfg=cfg, transport=stand, use_cache=False)
        assert resp["status"] == "FAILED"
        assert resp["errors"][0]["code"] == "SCHEMA"   # имя — не ключ запроса


class TestClusterGC2GC5:
    def test_cluster_calls_5_7_9(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        cs = resp["result"]["calls_summary"]
        assert cs["by_entity"]["lead:2001"] == 5
        assert cs["by_entity"]["contact:3002"] == 7
        assert cs["by_entity"]["contact:3001"] == 9
        assert cs["cluster_calls"] == 21          # эталон GC-2

    def test_deal_without_calls_is_crm_fact_not_accusation(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        cs = resp["result"]["calls_summary"]
        assert cs["deals_without_calls"] == [{"deal_id": 5001,
                                              "title": "Михаил — Авито (тест)"}]
        w = " ".join(resp["warnings"])
        assert "привязка звонков сломана" in w
        assert "НЕ обвинение менеджера" in w        # этичная формулировка

    def test_duplicate_judgement_two_keys(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        contacts = resp["result"]["cluster"]["contacts"]
        main = [c for c in contacts if c["id"] == 3001][0]
        dup = [c for c in contacts if c["id"] == 3002][0]
        assert main["judgement"] == "исходная запись досье"
        assert dup["judgement"] == "вероятный дубль (2+ ключа)"
        assert set(dup["match_keys"]) == {"phone", "im_profile"}

    def test_duplicate_one_key_is_possible_only(self, cfg, portal, calls_db):
        # дубль с тем же телефоном, но ДРУГИМ IM-профилем: 1 ключ
        portal.add_contact(3001, "Михаил Тест", phones=[PHONE], ims=[IM])
        portal.add_contact(3003, "Михаил Тест", phones=[PHONE],
                           ims=["imol|avito|2|u2i-other999"])
        portal.dups_by_phone["79000000001"] = {"CONTACT": [3001, 3003]}
        from conftest import FakeTransport
        rt = FakeTransport(portal)
        resp = _run(cfg, rt, {"type": "contact", "id": 3001})
        dup = [c for c in resp["result"]["cluster"]["contacts"]
               if c["id"] == 3003][0]
        assert dup["judgement"].startswith("возможный дубль (1 ключ)")
        assert "не сливаются" in dup["judgement"]

    def test_histories_not_merged(self, cfg, portal, stand):
        # факты дубля 3002 остаются на 3002, не переименовываются в 3001
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        ents = {json.dumps(f["crm_entity"], sort_keys=True)
                for f in resp["facts"] if f["fact_type"] == "call"}
        assert any("3002" in e for e in ents)
        assert any("3001" in e for e in ents)

    def test_ambiguity_warning_and_no_autoselect(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        w = " ".join(resp["warnings"])
        assert "неоднозначность идентификации" in w
        assert "досье строго по contact:3001" in w

    def test_converted_lead_link(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "lead", "id": 2001})
        links = resp["result"]["cluster"]["converted_links"]
        assert any("lead:2001→contact:3001" in l for l in links)


class TestOwnerDangleGC8:
    def test_ghost_call_from_calls_db(self, cfg, portal, calls_db):
        """Звонок из calls.db, активность на призраке contact 8888 (нет в CRM)
        — эталон activity 1001974/контакт 17016: warning + PARTIAL, не молча."""
        from conftest import insert_call
        portal.add_contact(3001, "Михаил Тест", phones=[PHONE], ims=[IM])
        portal.dups_by_phone["79000000001"] = {"CONTACT": [3001]}
        # активность-звонок на НЕсуществующем контакте 8888
        portal.add_activity(7000, datetime(2026, 10, 9, 16), type_id=2,
                            responsible=401, author=1, subject="Исходящий (13 мин)",
                            owner=("contact", 8888))
        insert_call(calls_db, bx_stat_id="78001", activity_id="7000",
                    entity_type="CONTACT", entity_id="8888", phone=PHONE,
                    start_date="2026-10-09T16:00:00+03:00")
        from conftest import FakeTransport
        rt = FakeTransport(portal)
        resp = _run(cfg, rt, {"type": "contact", "id": 3001})
        assert resp["status"] == "PARTIAL"
        w = " ".join(resp["warnings"])
        assert "owner dangle" in w and "contact:8888" in w
        cs = resp["result"]["calls_summary"]
        assert cs["dangling_calls"] == 1
        dang = [f for f in resp["facts"]
                if f["payload"].get("owner_status") == "dangling"]
        assert len(dang) == 1                      # факт сохранён, не выброшен
        assert dang[0]["crm_entity"] == {"type": "contact", "id": 8888}
        oc = resp["coverage"]["owner_check"]
        assert "contact:8888" in oc["dangling_refs"]


class TestTimeline:
    def test_voximpl_primary_pair_dedup(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        vox = [f for f in resp["facts"]
               if f["source"] == "voximplant.statistic"]
        act_calls = [f for f in resp["facts"]
                     if f["source"] == "crm.activity.list"
                     and f["fact_type"] == "call"]
        assert len(vox) == 9                    # 9 voximpl-записей
        assert len(act_calls) == 12             # 5+7 без пары в calls.db
        for v in vox:
            assert v["evidence"].get("crosscheck_activity_id")  # пара связана

    def test_stage_change_facts_no_transfer_claims(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        stages = [f for f in resp["facts"] if f["fact_type"] == "stage_change"]
        assert len(stages) == 2
        blob = json.dumps(stages, ensure_ascii=False)
        assert "перенос" not in blob             # GC-9: без утверждений о переносах
        authored = [s for s in stages if s["author_id"] is not None]
        assert authored[0]["author_id"] == 401   # USER_ID из stagehistory
        unauthored = [s for s in stages if s["author_id"] is None]
        assert unauthored[0]["author_role"] == "CONNECTOR"

    def test_texts_stub_no_subject_guessing(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        msgs = [f for f in resp["facts"]
                if f["payload"].get("kind") == "message_index"]
        assert len(msgs) == 1
        assert msgs[0]["payload"]["text"] is None          # текст не выдуман
        assert "SUBJECT не парсится" in msgs[0]["payload"]["text_source"]
        assert resp["result"]["texts"]["status"] == "stub_core"
        codes = [e["code"] for e in resp["errors"]]
        assert "NOT_IMPLEMENTED" in codes    # тексты — модуль messages (§10)

    def test_window_filters_timeline(self, cfg, portal, stand):
        portal.add_activity(6200, datetime(2026, 11, 7, 12), type_id=2,
                            responsible=401, author=1, subject="Звонок в окне",
                            owner=("contact", 3001))
        resp = _run(cfg, stand, {"type": "contact", "id": 3001},
                    **{"from": "2026-11-07T00:00:00+03:00",
                       "to": "2026-11-08T00:00:00+03:00"})
        ids = {f["source_entity_id"] for f in resp["facts"]}
        assert "activity:6200" in ids
        assert not any(f["source_entity_id"] == "activity:6000"
                      for f in resp["facts"])     # вне окна отброшены
        assert resp["result"]["window_note"]

    def test_bot_task_in_dossier_timeline(self, cfg, portal, stand):
        # задача бота в таймлайне кластера → боту (GC-1 внутри досье)
        portal.add_activity(6300, datetime(2026, 10, 10, 9, 30), type_id=6,
                            pti="TASKS_TASK", responsible=401, author=15780,
                            subject="Отложенный клиент", owner=("contact", 3001),
                            provider_id="TASKS_TASK")
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        bt = [f for f in resp["facts"]
              if f["source_entity_id"] == "activity:6300"][0]
        assert bt["payload"]["kind"] == "bot_task"
        assert bt["author_role"] == "BOT" and bt["author_id"] == 15780


class TestHonesty:
    def test_status_partial_with_stub(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        assert resp["status"] == "PARTIAL"      # тексты не собраны core-ом
        assert resp["coverage"]["_rest_calls"] >= 1

    def test_phones_masked_everywhere(self, cfg, portal, stand):
        resp = _run(cfg, stand, {"type": "contact", "id": 3001})
        blob = json.dumps(resp, ensure_ascii=False)
        assert "79000000001" not in blob
        assert "****0001" in blob

    def test_readonly_callsdb(self, cfg, portal, stand, calls_db):
        import hashlib
        before = hashlib.sha256(calls_db.read_bytes()).hexdigest()
        _run(cfg, stand, {"type": "contact", "id": 3001})
        assert hashlib.sha256(calls_db.read_bytes()).hexdigest() == before
