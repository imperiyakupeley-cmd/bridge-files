"""resolve_employee / resolve_client / dedup по findbycomm."""
import pytest

from core.client import BitrixClient
from core.sources import clients, employees
from core.sources.clients import normalize_phone


def client(cfg, portal):
    from conftest import FakeTransport
    return BitrixClient(cfg, transport=FakeTransport(portal), sleep=lambda s: None)


class TestNormalizePhone:
    def test_8_to_7(self):
        assert normalize_phone("89001234567") == "79001234567"
    def test_plus(self):
        assert normalize_phone("+7 900 123-45-67") == "79001234567"


class TestResolveEmployee:
    def test_card(self, cfg, portal):
        c = client(cfg, portal)
        v = {"request_id": "r1", "intent": "resolve_employee", "employee_id": 401}
        resp = employees.collect(c, v, exclude_users=cfg.exclude_users)
        assert resp["status"] == "VERIFIED"
        assert resp["result"]["id"] == 401 and resp["result"]["active"] is True
        assert resp["result"]["is_bot"] is False

    def test_bot_flag(self, cfg, portal):
        c = client(cfg, portal)
        v = {"request_id": "r2", "intent": "resolve_employee", "employee_id": 17316}
        resp = employees.collect(c, v, exclude_users=cfg.exclude_users)
        assert resp["result"]["is_bot"] is True

    def test_not_found_failed(self, cfg, portal):
        c = client(cfg, portal)
        v = {"request_id": "r3", "intent": "resolve_employee", "employee_id": 777777}
        resp = employees.collect(c, v, exclude_users=cfg.exclude_users)
        assert resp["status"] == "FAILED"
        assert resp["errors"][0]["code"] == "NOT_FOUND"


class TestResolveClient:
    def test_by_phone_dedup_warning(self, cfg, portal):
        """Инцидент §9.4: дубликаты контактов перечислены, чужие не подтянуты."""
        portal.dups_by_phone["79000000001"] = {"CONTACT": [111, 112]}
        portal.contacts[111] = {"ID": 111, "NAME": "Тест", "LAST_NAME": "А",
                                "ASSIGNED_BY_ID": 401,
                                "PHONE": [{"VALUE": "+79000000001"}]}
        portal.contacts[112] = {"ID": 112, "NAME": "Тест", "LAST_NAME": "А-дубль",
                                "ASSIGNED_BY_ID": 402,
                                "PHONE": [{"VALUE": "+79000000001"}]}
        c = client(cfg, portal)
        v = {"request_id": "rc1", "intent": "resolve_client",
             "phone": "+79000000001"}
        resp = clients.collect(c, v, exclude_users=cfg.exclude_users)
        assert resp["status"] == "PARTIAL"        # warning о дублях → PARTIAL
        assert any("дубликаты контактов" in w for w in resp["warnings"])
        assert resp["result"]["duplicates"] == {"contact": [111, 112]}
        assert len(resp["result"]["cards"]) == 2
        # телефоны в карточках маскированы
        assert all(ph.startswith("****") for card in resp["result"]["cards"]
                   for ph in card["phones"])

    def test_by_entity(self, cfg, portal):
        portal.leads_by_id[331] = portal.add_lead(331, __import__("datetime")
                                                  .datetime(2026, 11, 7, 10))
        c = client(cfg, portal)
        v = {"request_id": "rc2", "intent": "resolve_client",
             "entity": {"type": "lead", "id": 331}}
        resp = clients.collect(c, v, exclude_users=cfg.exclude_users)
        assert resp["status"] == "VERIFIED"
        assert resp["result"]["entity"]["id"] == 331

    def test_entity_not_found(self, cfg, portal):
        c = client(cfg, portal)
        v = {"request_id": "rc3", "intent": "resolve_client",
             "entity": {"type": "contact", "id": 424242}}
        resp = clients.collect(c, v, exclude_users=cfg.exclude_users)
        assert resp["status"] == "FAILED"
        assert resp["errors"][0]["code"] == "NOT_FOUND"

    def test_empty_phone_verified(self, cfg, portal):
        c = client(cfg, portal)
        v = {"request_id": "rc4", "intent": "resolve_client",
             "phone": "79995550000"}
        resp = clients.collect(c, v, exclude_users=cfg.exclude_users)
        assert resp["status"] == "VERIFIED"
        assert resp["result"]["duplicates"] == {}
