"""Контракт запроса/ответа: схемы, обязательность, статусы, [from,to)."""
from datetime import datetime

import pytest

from core.contract import make_response, validate_request
from core.errors import SchemaError
from core.timeutil import TimeError, day_bounds, fmt_iso, parse_iso


def req(**kw):
    base = {"intent": "leads_day", "request_id": "rid-1",
            "from": "2026-11-07T00:00:00+03:00",
            "to": "2026-11-08T00:00:00+03:00"}
    base.update(kw)
    return {k: v for k, v in base.items() if v is not None}


class TestRequestSchema:
    def test_ok(self):
        v = validate_request(req())
        assert v["intent"] == "leads_day"

    def test_unknown_key(self):
        with pytest.raises(SchemaError):
            validate_request(req(extra_key=1))

    def test_bad_intent(self):
        with pytest.raises(SchemaError):
            validate_request(req(intent="everything_day"))

    def test_missing_request_id(self):
        with pytest.raises(SchemaError):
            validate_request(req(request_id=None))

    def test_bad_tz(self):
        with pytest.raises(SchemaError):
            validate_request(req(tz="Europe/Kirov"))

    def test_bad_time(self):
        with pytest.raises(SchemaError):
            validate_request(req(**{"from": "07.11.2026"}))  # пара from без to
        with pytest.raises(SchemaError):
            validate_request(req(**{"to": "2026-11-08 00:00:00"}))  # без T/офсета

    def test_from_ge_to(self):
        with pytest.raises(SchemaError):
            validate_request(req(**{"to": "2026-11-07T00:00:00+03:00"}))

    def test_leads_day_forbids_employee(self):
        with pytest.raises(SchemaError):
            validate_request(req(employee_id=17316))

    def test_manager_day_requires_employee(self):
        with pytest.raises(SchemaError):
            validate_request(req(intent="manager_day"))
        v = validate_request(req(intent="manager_day", employee_id=401))
        assert v["employee_id"] == 401

    def test_resolve_client_needs_entity_or_phone(self):
        with pytest.raises(SchemaError):
            validate_request(req(intent="resolve_client",
                                 **{"from": None, "to": None}))
        v = validate_request(req(intent="resolve_client", phone="79000000001",
                                 **{"from": None, "to": None}))
        assert v["phone"] == "79000000001"

    def test_bad_phone(self):
        with pytest.raises(SchemaError):
            validate_request(req(intent="resolve_client", phone="abc",
                                 **{"from": None, "to": None}))

    def test_options_unknown(self):
        with pytest.raises(SchemaError):
            validate_request(req(options={"deep_thought": 42}))


class TestWindow:
    def test_half_open_interval(self):
        from datetime import timedelta
        frm, to = day_bounds("2026-11-07")
        mid = parse_iso("2026-11-07T12:00:00+03:00")
        assert frm <= mid < to
        assert not (frm <= frm - timedelta(microseconds=1))
        edge_to = parse_iso("2026-11-08T00:00:00+03:00")
        assert not (frm <= edge_to < to)   # to исключён


class TestResponseStatuses:
    def _v(self):
        return validate_request(req())

    def test_verified_clean(self):
        r = make_response(self._v(), facts=[{"fact_type": "lead_new"}],
                          coverage={}, warnings=[], errors=[], detectors={},
                          as_of="x")
        assert r["status"] == "VERIFIED"

    def test_verified_zero_facts_alive_sources(self):
        r = make_response(self._v(), facts=[], coverage={"m": {"rows": 0}},
                          warnings=[], errors=[], detectors={}, as_of="x")
        assert r["status"] == "VERIFIED"

    def test_partial_on_warning(self):
        r = make_response(self._v(), facts=[{"fact_type": "lead_new"}],
                          coverage={}, warnings=["w"], errors=[], detectors={},
                          as_of="x")
        assert r["status"] == "PARTIAL"

    def test_partial_on_source_error_with_facts(self):
        r = make_response(self._v(), facts=[{"fact_type": "lead_new"}],
                          coverage={}, warnings=[], errors=[
                              {"code": "SOURCE_429", "source": "x", "detail": ""}],
                          detectors={}, as_of="x")
        assert r["status"] == "PARTIAL"

    def test_failed_no_facts_error(self):
        r = make_response(self._v(), facts=[], coverage={}, warnings=[],
                          errors=[{"code": "SOURCE_ERROR", "source": "x",
                                   "detail": ""}], detectors={}, as_of="x")
        assert r["status"] == "FAILED"

    def test_failed_schema(self):
        r = make_response(self._v(), facts=[], coverage={}, warnings=[],
                          errors=[{"code": "SCHEMA", "source": "",
                                   "detail": "x"}], detectors={}, as_of="x")
        assert r["status"] == "FAILED"

    def test_partial_on_canary_fail(self):
        r = make_response(self._v(), facts=[], coverage={}, warnings=["w"],
                          errors=[], detectors={"filter_canary": "FAIL"},
                          as_of="x")
        assert r["status"] == "PARTIAL"
