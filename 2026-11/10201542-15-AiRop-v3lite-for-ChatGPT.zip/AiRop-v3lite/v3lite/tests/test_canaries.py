"""Канарейки: filter_canary, window_canary, duplicate_guard, pagination."""
from datetime import datetime

from core.canaries import (dedup_facts, filter_canary, pagination_from_stats,
                           window_check)


def fact(ts=None, sid="a:1"):
    return {"fact_type": "call", "source": sid.split(":")[0],
            "source_entity_id": sid, "timestamp_dt": ts}


class TestWindowCanary:
    def test_boundaries(self):
        frm = datetime(2026, 11, 7)
        to = datetime(2026, 11, 8)
        w = []
        kept, status = window_check(
            [fact(frm), fact(to), fact(datetime(2026, 11, 7, 12)), fact(None)],
            frm, to, warnings=w)
        assert status == "FAIL"          # факт на to (ровно граница) отброшен
        # остались: факт на from (включён), середина, факт без времени (не окно)
        assert len(kept) == 3
        assert any("отброшен" in x for x in w)


class TestDedup:
    def test_dedup_and_counters(self):
        c = {}
        out = dedup_facts([fact(sid="a:1"), fact(sid="a:1"), fact(sid="b:2")],
                          counters=c)
        assert len(out) == 2
        assert c["duplicate_guard_dropped"] == 1


class TestPaginationAgg:
    def test_all_pass(self):
        st = {"m1": {"truncated": False, "stop_reason": "complete"}}
        assert pagination_from_stats(st, warnings=[]) == "PASS"

    def test_truncated_fails(self):
        w = []
        st = {"m1": {"truncated": True, "stop_reason": "page_limit",
                     "rows": 100, "total": 500}}
        assert pagination_from_stats(st, warnings=w) == "FAIL"
        assert any("page_limit" in x for x in w)

    def test_non_paged_ignored(self):
        st = {"helper": {"non_paged": True, "stop_reason": "n/a"}}
        assert pagination_from_stats(st, warnings=[]) == "PASS"


class TestFilterCanary:
    def test_pass(self, cfg, fake, portal):
        from core.client import BitrixClient
        c = BitrixClient(cfg, transport=fake, sleep=lambda s: None)
        assert filter_canary(c, "crm.lead.list",
                             {">DATE_CREATE": "01.01.2099 00:00:00"}) == "PASS"

    def test_fail_when_server_ignores_filters(self, cfg, portal):
        from core.client import BitrixClient
        from conftest import FakeTransport
        portal.add_lead(1, datetime(2026, 11, 7, 10))
        portal.ignore_filters = True
        c = BitrixClient(cfg, transport=FakeTransport(portal), sleep=lambda s: None)
        assert filter_canary(c, "crm.lead.list",
                             {">DATE_CREATE": "01.01.2099 00:00:00"}) == "FAIL"

    def test_fail_closed_on_error(self, cfg, fake):
        """Ошибка транспорта ≠ «фильтры игнорируются»: это ERROR (транзиентно)."""
        from core.client import BitrixClient
        fake.fail_times = [(500, {})] * 10
        c = BitrixClient(cfg, transport=fake, sleep=lambda s: None)
        assert filter_canary(c, "crm.lead.list",
                             {">DATE_CREATE": "01.01.2099 00:00:00"}) == "ERROR"
