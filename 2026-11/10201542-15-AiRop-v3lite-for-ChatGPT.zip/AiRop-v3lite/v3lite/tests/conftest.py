"""Тестовое окружение v3 core: FakeTransport + фикстурный «портал».

Все данные ОБЕЗЛИЧЕННЫЕ: вымышленные id/имена («Тестов Т.», менеджер 401),
телефоны вида +79000000001. Ни одного реального токена/порта в фикстурах.
"""
from __future__ import annotations

import json
import os
import sqlite3
import sys
import urllib.parse
from datetime import datetime, timedelta

import pytest

V3LITE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, V3LITE)

from core.config import Config            # noqa: E402
from core.transport import HttpResult, Transport  # noqa: E402

MSK_TZ = "+03:00"


def iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S+03:00")


def bx(dt: datetime) -> str:
    return dt.strftime("%d.%m.%Y %H:%M:%S")


def parse_bx(s: str) -> datetime:
    return datetime.strptime(s, "%d.%m.%Y %H:%M:%S")


# ------------------------------------------------------------------ портал
class FixturePortal:
    """Мини-эмуляция Bitrix REST: pagination по 50, фильтры, batch, канарейки.

    Флаги для негативных сценариев:
      ignore_filters — канарейка фильтра FAIL (сервер игнорит фильтры);
      return_out_of_window — подсунуть строку вне окна (window_canary FAIL);
      duplicate_rows — сервер возвращает одни и те же строки (нестабильное окно).
    """

    PAGE = 50

    def __init__(self):
        self.leads = []            # dict: ID, TITLE, DATE_CREATE, ...
        self.activities = []       # dict: ID, TYPE_ID, PROVIDER_TYPE_ID, ...
        self.users = {}            # id -> row
        self.dups_by_phone = {}    # phone -> {"CONTACT": [...], "LEAD": [...]}
        self.contacts = {}         # id -> row
        self.deals = {}            # id -> row (client_dossier)
        self.stagehistory = {}     # deal_id -> [rows] (client_dossier)
        self.leads_by_id = {}
        self.ignore_filters = False
        self.return_out_of_window = False
        self.duplicate_rows = False
        self.fail_next = []        # очередь (status, body) для 429/5xx-тестов

    # --- данные
    def add_lead(self, lid, created, **kw):
        row = {"ID": lid, "TITLE": kw.get("title", f"Тестовый лид {lid}"),
               "DATE_CREATE": iso(created), "ASSIGNED_BY_ID": kw.get("assigned", 401),
               "CREATED_BY_ID": kw.get("created_by", 401),
               "STATUS_ID": kw.get("status", "NEW"), "SOURCE_ID": "WEB",
               "DATE_MODIFY": iso(created), "COMMENTS": ""}
        self.leads.append(row)
        self.leads_by_id[lid] = row
        return row

    def add_activity(self, aid, created, *, type_id=6, pti="CONFIGURABLE",
                     responsible=401, author=1, subject="", owner=None, **kw):
        row = {"ID": aid, "TYPE_ID": type_id, "PROVIDER_TYPE_ID": pti,
               "PROVIDER_ID": kw.get("provider_id", "openlines"),
               "RESPONSIBLE_ID": responsible, "AUTHOR_ID": author,
               "CREATED": iso(created), "LAST_UPDATED": iso(created),
               "SUBJECT": subject, "COMPLETED": "N",
               "DEADLINE": kw.get("deadline"), "DESCRIPTION": kw.get("description", "")}
        if owner:
            row["OWNER_TYPE_ID"] = {"lead": 1, "contact": 2, "deal": 3}[owner[0]]
            row["OWNER_ID"] = owner[1]
        else:
            row["OWNER_TYPE_ID"] = kw.get("owner_type_id", 3)
            row["OWNER_ID"] = kw.get("owner_id", 9001)
        self.activities.append(row)
        return row

    def add_user(self, uid, name, active="Y"):
        first, _, last = name.partition(" ")
        self.users[uid] = {"ID": uid, "NAME": first, "LAST_NAME": last or "",
                           "ACTIVE": active, "EMAIL": f"user{uid}@test.test",
                           "UF_DEPARTMENT": [3], "USER_TYPE": "employee"}

    def add_contact(self, cid, name="Клиент Тестов", phones=(), ims=(),
                    assigned=401, created=None):
        first, _, last = name.partition(" ")
        self.contacts[cid] = {
            "ID": cid, "NAME": first, "LAST_NAME": last or "",
            "ASSIGNED_BY_ID": assigned,
            "DATE_CREATE": iso(created or datetime(2026, 10, 1, 10)),
            "PHONE": [{"VALUE": p} for p in phones],
            "IM": [{"VALUE": i} for i in ims],
            "EMAIL": [],
        }
        return self.contacts[cid]

    def add_deal(self, did, contact_id, title="Тестовая сделка", stage="NEW",
                 opportunity="10000", assigned=401, created=None):
        self.deals[did] = {
            "ID": did, "TITLE": title, "STAGE_ID": stage,
            "ASSIGNED_BY_ID": assigned, "CONTACT_ID": contact_id,
            "OPPORTUNITY": opportunity,
            "DATE_CREATE": iso(created or datetime(2026, 10, 2, 11)),
            "CLOSEDATE": None, "LEAD_ID": None,
        }
        return self.deals[did]

    def add_stage(self, deal_id, stage_id, created, user_id=None):
        rows = self.stagehistory.setdefault(deal_id, [])
        rows.append({"ID": len(rows) + 1, "STAGE_ID": stage_id,
                     "CREATED_TIME": bx(created), "USER_ID": user_id})
        return rows[-1]

    # --- фильтрация
    def _flt_date(self, rows, params, field, fmt_iso_key):
        import re as _re
        ops = []
        for k, v in params.items():
            if not k.startswith("FILTER[") or not k.endswith("]"):
                continue
            inner = k[len("FILTER["):-1]
            m = _re.match(r"^([=!%<>]{0,2})([A-Za-z0-9_.]+)$", inner)
            if not m or m.group(2) != field:
                continue
            ops.append((m.group(1), parse_bx(v[0] if isinstance(v, list) else v)))
        out = []
        for r in rows:
            ts = datetime.strptime(r[fmt_iso_key], "%Y-%m-%dT%H:%M:%S+03:00")
            ok = True
            for op, bound in ops:
                if op == ">" and not ts > bound:
                    ok = False
                if op == ">=" and not ts >= bound:
                    ok = False
                if op == "<" and not ts < bound:
                    ok = False
            out.append(ok)
        return [r for r, ok in zip(rows, out) if ok]

    # --- REST-методы
    def handle(self, method: str, params: dict) -> dict:
        if method == "crm.lead.list":
            rows = list(self.leads)
            if not self.ignore_filters:
                rows = self._flt_date(rows, params, "DATE_CREATE", "DATE_CREATE")
                rows = flt_eq_int(rows, params, "ID")
            if self.return_out_of_window and rows:
                rows = rows + [dict(rows[0], ID=999999,
                                    DATE_CREATE=iso(datetime(2030, 1, 1, 12)))]
            return self._page(rows, params, id_field="ID")
        if method == "crm.activity.list":
            rows = list(self.activities)
            if not self.ignore_filters:
                rows = self._flt_date(rows, params, "CREATED", "CREATED")
                for f in ("OWNER_TYPE_ID", "OWNER_ID", "RESPONSIBLE_ID",
                          "AUTHOR_ID", "TYPE_ID", "PROVIDER_TYPE_ID"):
                    rows = flt_eq_int(rows, params, f)
            if self.return_out_of_window and rows:
                rows = rows + [dict(rows[0], ID=999998,
                                    CREATED=iso(datetime(2030, 1, 1, 12)))]
            if self.duplicate_rows and rows:
                rows = rows + [dict(rows[0])]
            sort_desc = any(k.startswith("order[CREATED]") and
                            str(v).upper() == "DESC"
                            for k, v in _flat_items(params))
            rows = sorted(rows, key=lambda r: (r.get("CREATED") or "", r.get("ID")),
                          reverse=sort_desc)
            return self._page(rows, params, id_field="ID")
        if method == "crm.lead.get":
            rid = int(_get_param(params, "ID"))
            row = self.leads_by_id.get(rid)
            if row is None:
                return {"error": "NOT_FOUND", "error_description": "Lead not found"}
            return {"result": row}
        if method == "crm.contact.get":
            rid = int(_get_param(params, "ID"))
            row = self.contacts.get(rid)
            if row is None:
                return {"error": "NOT_FOUND", "error_description": "Contact not found"}
            return {"result": row}
        if method == "crm.deal.get":
            rid = int(_get_param(params, "ID"))
            row = self.deals.get(rid)
            if row is None:
                return {"error": "NOT_FOUND", "error_description": "Deal not found"}
            return {"result": row}
        if method == "crm.deal.list":
            rows = list(self.deals.values())
            if not self.ignore_filters:
                for f in ("CONTACT_ID", "ID"):
                    rows = flt_eq_int(rows, params, f)
            return self._page(rows, params, id_field="ID")
        if method == "crm.activity.get":
            aid = _get_param(params, "ID")
            row = next((a for a in self.activities if str(a.get("ID")) == str(aid)),
                       None)
            if row is None:
                return {"error": "NOT_FOUND", "error_description": "Activity not found"}
            return {"result": row}
        if method == "crm.stagehistory.list":
            # [ФАКТ, live 09.11] боевой формат: camelCase + result.items;
            # UPPER — легаси-fallback
            camel = "entityTypeId" in params or "entityId" in params
            eid = _get_param(params, "entityId") or _get_param(params, "ENTITY_ID")
            etype = (_get_param(params, "entityTypeId")
                     or _get_param(params, "ENTITY_TYPE"))
            if str(etype) not in ("1", 1):
                return {"result": {"items": []} if camel else []}
            rows = self.stagehistory.get(int(eid), [])
            # боевой CREATED_TIME — ISO с офсетом (мок отдаёт битрикс-формат —
            # core парсит оба)
            if camel:
                return {"result": {"items": rows,
                                   "total": len(rows)}}
            return self._page(rows, params, id_field="ID")
        if method == "user.get":
            uid = int(_get_param(params, "ID"))
            row = self.users.get(uid)
            return {"result": [row] if row else []}
        if method == "crm.duplicate.findbycomm":
            phone = _get_param(params, "VALUES[]")
            return {"result": self.dups_by_phone.get(phone, {})}
        raise AssertionError(f"FixturePortal: неожиданный метод {method}")

    def _page(self, rows, params, id_field):
        start = int(_get_param(params, "start") or 0)
        page = rows[start:start + self.PAGE]
        out = {"result": page}
        if len(rows) > start + self.PAGE:
            out["next"] = start + self.PAGE
        out["total"] = len(rows)
        return out


def _flat_items(params):
    for k, v in params.items():
        if isinstance(v, list):
            for item in v:
                yield k, item
        else:
            yield k, v


def _flt_eq_int(rows, params, field):
    val = None
    for k, v in params.items():
        if k.startswith("FILTER[") and k.endswith("]") \
                and k[len("FILTER["):-1] == field:
            val = v[0] if isinstance(v, list) else v
    if val is None:
        return rows
    return [r for r in rows if str(r.get(field)) == str(val)]


def _get_param(params, key):
    v = params.get(key)
    if isinstance(v, list):
        return v[0] if v else None
    return v


def flt_eq_int(rows, params, field):
    val = None
    for k, v in params.items():
        if k.startswith("FILTER[") and k.endswith("]") \
                and k[len("FILTER["):-1] == field:
            val = v[0] if isinstance(v, list) else v
    if val is None:
        return rows
    return [r for r in rows if str(r.get(field)) == str(val)]


class FakeTransport(Transport):
    """Транспорт на FixturePortal + запись всех URL (для evidence/тестов).

    batch_faults: {"<cmd_idx>": "error"|"missing"} — инъекция сбоев отдельных
    команд batch ("error" → per-key error в result_error, "missing" — сервер
    потерял команду: ни результата, ни ошибки).
    """

    name = "fake"

    def __init__(self, portal: FixturePortal, fail_times: list | None = None):
        self.portal = portal
        self.urls: list[str] = []
        self.fail_times = list(fail_times or [])   # [(status, json_body), ...]
        self.batch_faults: dict[str, str] = {}

    def get(self, url: str, timeout: float) -> HttpResult:
        self.urls.append(url)
        if self.fail_times:
            status, body = self.fail_times.pop(0)
            return HttpResult(status, {}, json.dumps(body).encode())
        parsed = urllib.parse.urlsplit(url)
        method = parsed.path.rsplit("/", 1)[-1].removesuffix(".json")
        params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        if method == "batch":
            cmds = []
            for k in sorted((p for p in params if p.startswith("cmd[")),
                            key=lambda s: int(s[4:-1])):
                raw = params[k][0]
                m, _, qs = raw.partition("?")
                inner = urllib.parse.parse_qs(qs, keep_blank_values=True)
                cmds.append((m, inner))
            result, errors = {}, {}
            for i, (m, p) in enumerate(cmds):
                fault = self.batch_faults.get(str(i))
                if fault == "missing":
                    continue
                if fault == "error":
                    errors[str(i)] = {"error": "NOT_FOUND",
                                      "error_description": "fault injection"}
                    continue
                try:
                    r = self.portal.handle(m, p)
                    if "error" in r:
                        errors[str(i)] = r
                    else:
                        result[str(i)] = r.get("result", r)
                except AssertionError as e:
                    errors[str(i)] = {"error": str(e)}
            # БОЕВАЯ форма конверта [ФАКТ: live-проба 09.11.2026, спека §5]:
            # batch оборачивает ответ в result.result; плотные числовые ключи
            # → LIST, разреженные (часть команд упала) → dict, пустой → [].
            return HttpResult(200, {}, json.dumps(
                {"result": {"result": _php_packed(result),
                            "result_error": _php_packed(errors),
                            "result_total": {}, "result_next": {},
                            "result_time": {}}}).encode())
        data = self.portal.handle(method, params)
        return HttpResult(200, {}, json.dumps(data).encode())


def _php_packed(m: dict):
    """Сериализация PHP/Bitrix: dict с плотными ключами '0'..'n-1' → список
    (json_encode packed array), пустой → []. Разреженные остаются dict."""
    if not m:
        return []
    if sorted(m) == [str(i) for i in range(len(m))]:
        return [m[str(i)] for i in range(len(m))]
    return dict(m)


# ------------------------------------------------------------------ фикстуры
@pytest.fixture
def portal():
    p = FixturePortal()
    p.add_user(401, "Тест Тестов")
    p.add_user(402, "Бот Анна")
    p.add_user(17316, "Бот Анна Прод")
    # «чистые» владельцы по умолчанию: insert_call → CONTACT:77,
    # add_activity без owner → deal:9001 (owner-dangle проверка GC-8
    # не должна срабатывать на корректных данных)
    p.add_contact(77, "Клиент Тестов", phones=["+79000000001"])
    p.add_deal(9001, contact_id=77)
    return p


@pytest.fixture
def fake(portal):
    return FakeTransport(portal)


@pytest.fixture
def cfg(tmp_path):
    return Config(
        webhook="https://portal.example.test/rest/1/xxxxx",
        exclude_users={17316, 15780},
        rate_rps=10_000.0,          # тесты не спят на rate limit
        retries_max=3,
        calls_db=str(tmp_path / "calls.db"),
        cache_db=str(tmp_path / "v3_cache.db"),
    )


@pytest.fixture
def calls_db(tmp_path):
    """Обезличенная копия схемы calls.db (прод-структура, пустая)."""
    path = tmp_path / "calls.db"
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE calls (id INTEGER PRIMARY KEY AUTOINCREMENT,
      bx_stat_id TEXT UNIQUE, bx_call_id TEXT, activity_id TEXT,
      manager_id INTEGER, entity_type TEXT, entity_id TEXT, deal_id TEXT,
      contact_id TEXT, deal_title TEXT, deal_stage TEXT, deal_opportunity TEXT,
      client_name TEXT, phone TEXT, call_type TEXT, start_date TEXT,
      duration INTEGER, record_url TEXT, record_path TEXT, transcript TEXT,
      analysis_json TEXT, score REAL, comm_type TEXT, risk INTEGER,
      sale_probability INTEGER, client_temp TEXT, status TEXT DEFAULT 'collected',
      error TEXT, created_at TEXT DEFAULT (datetime('now')),
      comm_id INTEGER, fail_code TEXT, portal_number TEXT);
    """)
    con.commit()
    con.close()
    return path


def insert_call(path, *, bx_stat_id, activity_id=None, manager_id=401,
                entity_type="CONTACT", entity_id="77", phone="+79000000001",
                call_type="исходящий", start_date="2026-11-07T10:11:12+03:00",
                duration=60, status="collected", fail_code=None):
    con = sqlite3.connect(path)
    con.execute(
        "INSERT INTO calls(bx_stat_id, activity_id, manager_id, entity_type,"
        " entity_id, phone, call_type, start_date, duration, status, fail_code)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (bx_stat_id, activity_id, manager_id, entity_type, entity_id, phone,
         call_type, start_date, duration, status, fail_code))
    con.commit()
    con.close()


DAY_FRI = datetime(2026, 11, 6)     # пятница (контрольный день)
DAY_SAT = datetime(2026, 11, 7)     # суббота
