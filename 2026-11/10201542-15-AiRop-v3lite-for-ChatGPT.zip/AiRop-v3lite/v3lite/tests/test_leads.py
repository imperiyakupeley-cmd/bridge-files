"""leads_day: лиды окна + первые касания, канарейки, честность статусов."""
from datetime import datetime

from core.client import BitrixClient
from core.sources import leads

from conftest import iso

REQ = {"intent": "leads_day", "request_id": "rid-leads-1",
       "from": "2026-11-07T00:00:00+03:00", "to": "2026-11-08T00:00:00+03:00"}


def run(cfg, portal, transport=None):
    from conftest import FakeTransport
    t = transport or FakeTransport(portal)
    c = BitrixClient(cfg, transport=t, sleep=lambda s: None)
    from core.contract import validate_request
    return leads.collect(c, validate_request(REQ), exclude_users=cfg.exclude_users), t


class TestLeadsDay:
    def test_happy_day_with_first_touch(self, cfg, portal):
        portal.add_lead(101, datetime(2026, 11, 7, 9, 15))
        portal.add_lead(102, datetime(2026, 11, 7, 18, 0))
        portal.add_lead(103, datetime(2026, 11, 8, 1, 0))   # вне окна
        portal.add_activity(5001, datetime(2026, 11, 7, 10, 0),
                            responsible=401, subject="Исходящее сообщение",
                            owner=("lead", 101))
        portal.add_activity(5002, datetime(2026, 11, 9, 10, 0),
                            responsible=401, subject="Входящее сообщение",
                            owner=("lead", 102))            # касание завтра
        resp, t = run(cfg, portal)
        assert resp["status"] == "VERIFIED"
        ids = {f["source_entity_id"] for f in resp["facts"]}
        assert ids == {"lead:101", "lead:102", "activity:5001"}
        ft = resp["coverage"]["first_touch"]
        assert ft["leads"] == 2 and ft["first_touch_in_window"] == 1 \
            and ft["first_touch_outside_window"] == 1
        # DATE_CREATE-фильтр реально ушёл в REST
        assert any("DATE_CREATE" in u for u in t.urls)

    def test_no_touches_coverage(self, cfg, portal):
        portal.add_lead(201, datetime(2026, 11, 7, 12))
        resp, _ = run(cfg, portal)
        assert resp["status"] == "VERIFIED"
        ft = resp["coverage"]["first_touch"]
        assert ft["without_any_activity"] == 1

    def test_zero_leads_is_verified(self, cfg, portal):
        resp, _ = run(cfg, portal)
        assert resp["status"] == "VERIFIED" and resp["facts"] == []
        assert resp["coverage"]["crm.lead.list"]["rows"] == 0

    def test_filter_canary_fail_discards_facts(self, cfg, portal):
        portal.add_lead(301, datetime(2026, 11, 7, 12))
        portal.ignore_filters = True
        resp, t = run(cfg, portal)
        # единственный источник отброшен fail-closed → фактов нет → FAILED
        # (статус «не выше PARTIAL», §4: фактов нет = FAILED)
        assert resp["status"] == "FAILED"
        assert resp["facts"] == []       # fail-closed: факты отброшены
        assert resp["errors"][0]["code"] == "FILTER_CANARY"
        assert resp["detectors"]["filter_canary"] == "FAIL"

    def test_out_of_window_row_dropped(self, cfg, portal):
        portal.add_lead(401, datetime(2026, 11, 7, 12))
        portal.return_out_of_window = True
        resp, _ = run(cfg, portal)
        assert resp["detectors"]["window_canary"] == "FAIL"
        assert all(f["source_entity_id"] != "lead:999999" for f in resp["facts"])
        assert resp["status"] == "PARTIAL"

    def test_bot_author_marked(self, cfg, portal):
        portal.add_lead(501, datetime(2026, 11, 7, 12), created_by=17316)
        resp, _ = run(cfg, portal)
        f = [x for x in resp["facts"] if x["source_entity_id"] == "lead:501"][0]
        assert f["author_role"] == "BOT" and f["author_id"] == 17316

    def test_never_uses_date_modify(self, cfg, portal):
        """Инцидент 15.08 (§9.3): DATE_MODIFY запрещён как ФИЛЬТР дня.
        (select DATE_MODIFY допустим — это просто поле на выдаче.)"""
        import re
        import urllib.parse
        portal.add_lead(601, datetime(2026, 11, 7, 12))
        resp, t = run(cfg, portal)
        for u in t.urls:
            decoded = urllib.parse.unquote(u)
            assert not re.search(r"FILTER\[[^\]]*DATE_MODIFY\]", decoded), decoded


class TestFirstTouchBattleRegression:
    """Регресс КРИТИЧЕСКОГО инцидента 08.11 (integ-ld-1): batch-конверт боевого
    портала (result.result = СПИСОК при плотных ключах) не разбирался → все
    ответы MISSING_IN_BATCH → первые касания терялись МОЛЧА при статусе
    VERIFIED (нарушение fail-closed). Тестовый транспорт теперь отдаёт боевую
    форму (conftest._php_packed), эти тесты фиксируют «после»:
    известные касания на месте, любая недостача ломает VERIFIED.
    """

    KNOWN = {  # lead → (activity_id, точный timestamp первого касания)
        "101": ("activity:9001", "2026-11-07T10:01:30+03:00"),
        "102": ("activity:9002", "2026-11-07T12:31:10+03:00"),
        "103": ("activity:9003", "2026-11-07T23:59:30+03:00"),
    }

    def _day(self, portal):
        portal.add_lead(101, datetime(2026, 11, 7, 10, 0))
        portal.add_lead(102, datetime(2026, 11, 7, 12, 30))
        portal.add_lead(103, datetime(2026, 11, 7, 23, 59))
        portal.add_activity(9001, datetime(2026, 11, 7, 10, 1, 30),
                            owner=("lead", 101), subject="Исходящее сообщение")
        portal.add_activity(9002, datetime(2026, 11, 7, 12, 31, 10),
                            owner=("lead", 102), subject="Входящее сообщение")
        portal.add_activity(9003, datetime(2026, 11, 7, 23, 59, 30),
                            owner=("lead", 103), subject="Исходящее сообщение")
        # шум: поздний звонок по лиду 101 — НЕ должен вытеснить первое касание
        portal.add_activity(9004, datetime(2026, 11, 7, 11, 0),
                            owner=("lead", 101), type_id=2, pti="CALL",
                            subject="Исходящий на +79000000001")

    def test_known_first_touch_present_strict(self, cfg, portal):
        """ДО фикса: 0 касаний, статус VERIFIED (ложь, integ-ld-1 08.11).
        ПОСЛЕ: все 3 известных касания, точные таймстампы, VERIFIED честный."""
        self._day(portal)
        resp, _ = run(cfg, portal)
        assert resp["status"] == "VERIFIED", (resp["errors"], resp["warnings"])
        touches = {str(f["crm_entity"]["id"]): f for f in resp["facts"]
                   if f["fact_type"] == "message"}
        assert set(touches) == set(self.KNOWN), resp["facts"]
        for lead_id, (eid, ts) in self.KNOWN.items():
            f = touches[lead_id]
            assert f["source_entity_id"] == eid
            assert f["timestamp"] == ts, (lead_id, f["timestamp"])
            assert f["crm_entity"]["type"] == "lead"
        cov = resp["coverage"]["first_touch"]
        assert cov["with_any_activity"] == 3
        assert cov["first_touch_in_window"] == 3
        assert cov["cmd_error"] == 0 and cov["cmd_missing"] == 0
        assert resp["coverage"]["batch:lead_first_touch"]["ok"] == 3

    def test_cmd_error_breaks_verified(self, cfg, portal, fake):
        """Одна команда batch упала (per-key error) → касания недополучены →
        статус НЕ VERIFIED, ошибка источника в ответе (fail-closed)."""
        from conftest import FakeTransport
        self._day(portal)
        t = FakeTransport(portal)
        t.batch_faults = {"1": "error"}      # lead 102: касание потеряно
        resp, _ = run(cfg, portal, transport=t)
        assert resp["status"] == "PARTIAL"
        assert any(e["source"] == "batch:crm.activity.list"
                   and "недополучены" in e["detail"] for e in resp["errors"])
        cov = resp["coverage"]["first_touch"]
        assert cov["cmd_error"] == 1 and cov["cmd_missing"] == 0
        assert cov["first_touch_in_window"] == 2   # остальные на месте

    def test_lost_cmd_breaks_verified(self, cfg, portal):
        """Сервер потерял команду (MISSING_IN_BATCH) → НЕ VERIFIED."""
        from conftest import FakeTransport
        self._day(portal)
        t = FakeTransport(portal)
        t.batch_faults = {"2": "missing"}     # lead 103: ответ исчез
        resp, _ = run(cfg, portal, transport=t)
        assert resp["status"] == "PARTIAL"
        assert any("MISSING_IN_BATCH" in e["detail"] for e in resp["errors"])
        cov = resp["coverage"]["first_touch"]
        assert cov["cmd_missing"] == 1
        assert resp["coverage"]["batch:lead_first_touch"]["missing"] == 1

    def test_all_touches_lost_is_not_verified_even_with_lead_facts(self, cfg, portal):
        """Худший случай инцидента: ВСЕ касания потеряны, но лиды есть —
        статус PARTIAL (не VERIFIED), ошибка источника явная."""
        from conftest import FakeTransport
        self._day(portal)
        t = FakeTransport(portal)
        t.batch_faults = {str(i): "missing" for i in range(3)}
        resp, _ = run(cfg, portal, transport=t)
        assert resp["status"] == "PARTIAL"
        assert any(f["fact_type"] == "lead_new" for f in resp["facts"])
        assert not any(f["fact_type"] == "message" for f in resp["facts"])
        assert resp["coverage"]["first_touch"]["cmd_missing"] == 3
