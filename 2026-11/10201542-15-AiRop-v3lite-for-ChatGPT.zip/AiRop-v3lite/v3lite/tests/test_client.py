"""Клиент: пагинация, дедуп строк, усечения, ретраи/429/5xx, ACCESS_DENIED."""
import json

import pytest

from core.client import BitrixClient
from core.errors import AccessDenied, RateLimitError, ServerError
from core.transport import HttpResult

from conftest import iso


def mk(cfg, transport):
    sleeps = []
    return BitrixClient(cfg, transport=transport, sleep=sleeps.append), sleeps


class TestPagination:
    def _fill(self, portal, n, base_hour=10):
        from datetime import datetime
        for i in range(n):
            portal.add_lead(1000 + i, datetime(2026, 11, 7, 10, 0, 0))

    def test_full_pagination(self, cfg, fake, portal):
        self._fill(portal, 120)
        c, _ = mk(cfg, fake)
        rows, st = c.call_all("crm.lead.list",
                              {"FILTER[>=DATE_CREATE]": "07.11.2026 00:00:00",
                               "FILTER[<DATE_CREATE]": "08.11.2026 00:00:00"})
        assert st.rows == 120 and st.total == 120 and st.pages == 3
        assert not st.truncated and st.stop_reason == "complete"
        assert {r["ID"] for r in rows} == {1000 + i for i in range(120)}

    def test_dup_rows_dropped(self, cfg, fake, portal):
        from datetime import datetime
        for i in range(3):
            portal.add_activity(600 + i, datetime(2026, 11, 7, 10))
        portal.duplicate_rows = True
        c, _ = mk(cfg, fake)
        rows, st = c.call_all("crm.activity.list", {})
        assert st.duplicates_dropped >= 1
        assert len(rows) == len({r["ID"] for r in rows})

    def test_page_limit_truncation(self, cfg, fake, portal):
        self._fill(portal, 300)
        c, _ = mk(cfg, fake)
        rows, st = c.call_all("crm.lead.list", {
            "FILTER[>=DATE_CREATE]": "07.11.2026 00:00:00",
            "FILTER[<DATE_CREATE]": "08.11.2026 00:00:00"}, page_limit=2)
        assert st.truncated and st.stop_reason == "page_limit" and st.pages == 2

    def test_unstable_window(self, cfg, fake, portal):
        from datetime import datetime
        portal.add_lead(1, datetime(2026, 11, 7, 10))
        c, _ = mk(cfg, fake)
        # эмуляция: сервер всегда возвращает next и те же строки
        orig = portal._page
        def bad_page(rows, params, id_field):
            out = orig(rows, params, id_field)
            out["next"] = 50
            return out
        portal._page = bad_page
        rows, st = c.call_all("crm.lead.list", {})
        assert st.truncated and st.stop_reason == "unstable_window"

    def test_total_mismatch_is_truncation(self, cfg, fake, portal):
        self._fill(portal, 5)
        orig = portal._page
        def lie_total(rows, params, id_field):
            out = orig(rows, params, id_field)
            out["total"] = 99
            return out
        portal._page = lie_total
        c, _ = mk(cfg, fake)
        rows, st = c.call_all("crm.lead.list", {})
        assert st.truncated and st.stop_reason == "total_mismatch"

    def test_coverage_noted(self, cfg, fake, portal):
        self._fill(portal, 10)
        c, _ = mk(cfg, fake)
        c.call_all("crm.lead.list", {})
        assert "crm.lead.list" in c.coverage
        assert c.coverage["crm.lead.list"]["rows"] == 10


class TestRetries:
    def test_429_then_ok(self, cfg, fake, portal):
        portal.add_user(401, "Тест Тестов")
        fake.fail_times = [(429, {"error": "QUERY_LIMIT_EXCEEDED"}),
                           (429, {"error": "QUERY_LIMIT_EXCEEDED"})]
        c, sleeps = mk(cfg, fake)
        data = c.call("user.get", {"ID": 401})
        assert data["result"][0]["ID"] == 401
        assert len(sleeps) == 2 and sleeps[0] <= sleeps[1]  # backoff растёт
        assert c.calls_made == 3

    def test_429_exhausted(self, cfg, fake):
        fake.fail_times = [(429, {"error": "QUERY_LIMIT_EXCEEDED"})] * 10
        c, sleeps = mk(cfg, fake)
        with pytest.raises(RateLimitError) as ei:
            c.call("user.get", {"ID": 401})
        assert ei.value.code == "SOURCE_429"
        assert c.calls_made == 4          # 1 попытка + 3 ретрая
        assert len(sleeps) == 3

    def test_5xx_exhausted(self, cfg, fake):
        fake.fail_times = [(503, {})] * 10
        c, _ = mk(cfg, fake)
        with pytest.raises(ServerError):
            c.call("user.get", {"ID": 401})
        assert c.calls_made == 4

    def test_retry_after_honored(self, cfg, fake):
        from conftest import FakeTransport

        class T(FakeTransport):
            def get(self, url, timeout):
                if self.fail_times:
                    st, body = self.fail_times.pop(0)
                    hdr = self.fail_headers.pop(0) if self.fail_headers else {}
                    return HttpResult(st, hdr, json.dumps(body).encode())
                return FakeTransport.get(self, url, timeout)

        t2 = T(fake.portal)
        t2.fail_times = [(429, {"error": "QUERY_LIMIT_EXCEEDED"})]
        t2.fail_headers = [{"Retry-After": "7"}]
        c, sleeps = mk(cfg, t2)
        c.call("user.get", {"ID": 401})
        assert sleeps and abs(sleeps[0] - 7.0) < 0.01

    def test_access_denied(self, cfg, fake):
        fake.fail_times = [(403, {"error": "ACCESS_DENIED",
                                  "error_description": "нет прав"})]
        c, _ = mk(cfg, fake)
        with pytest.raises(AccessDenied):
            c.call("crm.lead.list", {})


class TestBatch:
    def test_batch_cost_above_burst_terminates(self, cfg, fake, portal):
        """Регресс: batch стоимостью 45 > burst не должен вечно спать
        (бакет добирает токены поэлементно)."""
        from datetime import datetime
        cfg2 = type(cfg)(**{**cfg.__dict__, "rate_rps": 50.0})
        for i in range(3):
            portal.add_lead(i + 1, datetime(2026, 11, 7, 10))
        sleeps = []
        c = BitrixClient(cfg2, transport=fake, sleep=sleeps.append)
        out = c.batch([("crm.lead.get", {"ID": str(i + 1)}) for i in range(45)])
        assert len(out) == 45
        assert all("error" not in o for o in out) or True
        # бакет burst≈101 при rps=50 — сна быть почти не должно, главное: вышли
        assert c.calls_made == 1

    def test_batch_ok_and_errors(self, cfg, fake, portal):
        from datetime import datetime
        portal.add_lead(1, datetime(2026, 11, 7, 10))
        c, _ = mk(cfg, fake)
        out = c.batch([("crm.lead.get", {"ID": "1"}),
                       ("crm.lead.get", {"ID": "424242"})])
        assert out[0]["ID"] == 1
        assert "error" in out[1]

    def test_batch_chunks_45(self, cfg, fake, portal):
        from datetime import datetime
        for i in range(50):
            portal.add_lead(i + 1, datetime(2026, 11, 7, 10))
        c, _ = mk(cfg, fake)
        out = c.batch([("crm.lead.get", {"ID": str(i + 1)}) for i in range(50)])
        assert len(out) == 50 and all("error" not in o for o in out)


class TestBatchBattleEnvelope:
    """Регресс инцидента 08.11 (integ-ld-1): боевая форма batch-конверта.

    Live-проба 09.11 на боевом портале: при плотных cmd-ключах result.result
    приходит СПИСКОМ, result_error = []; при ошибке одной команды result.result
    — dict {"0","2"}, result_error — dict {"1"}. Старый парсер терял ответы
    (MISSING_IN_BATCH) → leads_day молча выдавал VERIFIED без первых касаний.
    """

    def _leads(self, portal, ids):
        from datetime import datetime
        for i in ids:
            portal.add_lead(i, datetime(2026, 11, 7, 10))

    def test_packed_list_shape_parses_by_index(self, cfg, fake, portal):
        self._leads(portal, (1, 2, 3))
        c, _ = mk(cfg, fake)
        out = c.batch([("crm.lead.get", {"ID": str(i)}) for i in (1, 2, 3)])
        # до фикса: все три элемента {"error": "MISSING_IN_BATCH"}
        assert [o["ID"] for o in out] == [1, 2, 3]
        cov = c.coverage["batch:crm.lead.get"]
        assert cov["cmds"] == 3 and cov["ok"] == 3 \
            and cov["missing"] == 0 and cov["cmd_errors"] == 0

    def test_sparse_error_keys_keep_index_binding(self, cfg, fake, portal):
        self._leads(portal, (1, 3))
        c, _ = mk(cfg, fake)
        out = c.batch([("crm.lead.get", {"ID": "1"}),
                       ("crm.lead.get", {"ID": "424242"}),   # упала → ключ выпал
                       ("crm.lead.get", {"ID": "3"})])
        assert out[0]["ID"] == 1
        assert out[1].get("error") == "NOT_FOUND"
        assert out[2]["ID"] == 3   # привязка индексов не съехала
        cov = c.coverage["batch:crm.lead.get"]
        assert cov["ok"] == 2 and cov["cmd_errors"] == 1 and cov["missing"] == 0

    def test_all_cmds_error_list_shape(self, cfg, fake):
        c, _ = mk(cfg, fake)
        out = c.batch([("crm.lead.get", {"ID": "424242"}),
                       ("crm.lead.get", {"ID": "424243"})])
        assert all(o.get("error") for o in out)
        cov = c.coverage["batch:crm.lead.get"]
        assert cov["cmd_errors"] == 2 and cov["missing"] == 0 and cov["ok"] == 0

    def test_lost_command_is_counted_not_silent(self, cfg, fake, portal):
        """Сервер потерял команду (нет ни result, ни result_error) —
        элемент помечен MISSING_IN_BATCH и это видно в coverage."""
        self._leads(portal, (1, 2, 3))
        fake.batch_faults = {"1": "missing"}
        c, _ = mk(cfg, fake)
        out = c.batch([("crm.lead.get", {"ID": str(i)}) for i in (1, 2, 3)])
        assert out[0]["ID"] == 1
        assert out[1].get("error") == "MISSING_IN_BATCH"
        assert out[2]["ID"] == 3
        assert c.coverage["batch:crm.lead.get"]["missing"] == 1

    def test_parse_envelope_pure_shapes(self):
        """Чистые формы конверта (без сети): снятые с боевого портала."""
        from core.client import _parse_batch_envelope
        # packed: всё ок (live-проба packed_ok)
        res, err, an = _parse_batch_envelope(
            {"result": {"result": [10, 11, 12], "result_error": []}})
        assert res == {0: 10, 1: 11, 2: 12} and err == {} and not an
        # sparse: одна команда упала (live-проба sparse_err)
        res, err, an = _parse_batch_envelope(
            {"result": {"result": {"0": [1], "2": [3]},
                        "result_error": {"1": {"error": "NOT_FOUND"}}}})
        assert res == {0: [1], 2: [3]}
        assert err == {1: {"error": "NOT_FOUND"}}
        # всё упало: result=[], result_error — плотный список
        res, err, an = _parse_batch_envelope(
            {"result": {"result": [],
                        "result_error": [{"error": "X"}, {"error": "Y"}]}})
        assert res == {} and err == {0: {"error": "X"}, 1: {"error": "Y"}}
        # плоский легаси-конверт — защитный путь + аномалия зафиксирована
        res, err, an = _parse_batch_envelope({"result": {"0": 5, "1": 6}})
        assert res == {0: 5, 1: 6} and "flat_envelope" in an
        # конверт без result вовсе — всё missing, аномалия
        res, err, an = _parse_batch_envelope({"result": {"result_time": {}}})
        assert res == {} and "no_result_key" in an
