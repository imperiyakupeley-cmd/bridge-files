"""calls_day: voximpl(calls.db RO) + кросс-чек activity TYPE_ID=2.

Матрица §9.1 (инцидент 05.08 «один звонок — лучший и худший»): пара
voximpl+activity = ОДИН факт, 0 дублей, счётчики == уникальным фактам.
"""
from datetime import datetime

from core.client import BitrixClient
from core.sources import calls

from conftest import insert_call

REQ = {"intent": "calls_day", "request_id": "rid-calls-1",
       "from": "2026-11-07T00:00:00+03:00", "to": "2026-11-08T00:00:00+03:00"}


def run(cfg, portal, calls_db_path):
    from conftest import FakeTransport
    t = FakeTransport(portal)
    c = BitrixClient(cfg, transport=t, sleep=lambda s: None)
    from core.contract import validate_request
    return calls.collect(c, validate_request(REQ),
                         exclude_users=cfg.exclude_users,
                         calls_db_path=str(calls_db_path)), t


class TestIncident0508:
    def test_one_call_one_fact(self, cfg, portal, calls_db):
        insert_call(calls_db, bx_stat_id="67301", activity_id="8801",
                    start_date="2026-11-07T11:00:00+03:00")
        # свежесть БД: запись за 08.11 (вне окна [from,to)) — сборщик жив
        insert_call(calls_db, bx_stat_id="67399",
                    start_date="2026-11-08T23:00:00+03:00")
        portal.add_activity(8801, datetime(2026, 11, 7, 11, 0), type_id=2,
                            responsible=401, subject="Исходящий на клиент")
        resp, _ = run(cfg, portal, calls_db)
        assert resp["status"] == "VERIFIED", resp["warnings"]
        keys = [(f["source"], f["source_entity_id"]) for f in resp["facts"]]
        assert len(keys) == len(set(keys))      # 0 дублей
        assert keys == [("voximplant.statistic", "voximpl:67301")]
        assert resp["coverage"]["activity_crosscheck"]["matched_voximpl"] == 1
        assert resp["coverage"]["activity_crosscheck"]["unmatched_activities"] == 0
        ev = resp["facts"][0]["evidence"]
        assert ev.get("crosscheck_activity_id") == "8801"

    def test_unmatched_activity_warning(self, cfg, portal, calls_db):
        insert_call(calls_db, bx_stat_id="67302",
                    start_date="2026-11-07T12:00:00+03:00")
        portal.add_activity(8802, datetime(2026, 11, 7, 12, 30), type_id=2,
                            responsible=401, subject="Исходящий на другой")
        resp, _ = run(cfg, portal, calls_db)
        assert resp["status"] == "PARTIAL"
        assert any("без записи voximpl" in w for w in resp["warnings"])
        sources = [f["source"] for f in resp["facts"]]
        assert sources.count("crm.activity.list") == 1

    def test_db_error_failed(self, cfg, portal, tmp_path):
        resp, _ = run(cfg, portal, tmp_path / "missing.db")
        assert resp["status"] == "FAILED"
        assert resp["errors"][0]["code"] == "SOURCE_ERROR"


class TestHonesty:
    def test_lag_warning(self, cfg, portal, calls_db):
        insert_call(calls_db, bx_stat_id="67303",
                    start_date="2026-11-07T10:00:00+03:00")
        # окно до 08.11, последняя запись 07.11 10:00 → отставание > 6ч
        resp, _ = run(cfg, portal, calls_db)
        assert resp["status"] == "PARTIAL"
        assert any("отстаёт" in w for w in resp["warnings"])

    def test_fresh_no_warning(self, cfg, portal, calls_db):
        insert_call(calls_db, bx_stat_id="67304",
                    start_date="2026-11-07T23:30:00+03:00")
        resp, _ = run(cfg, portal, calls_db)
        assert resp["status"] == "VERIFIED"

    def test_phones_masked(self, cfg, portal, calls_db):
        insert_call(calls_db, bx_stat_id="67305",
                    phone="+79161234567",
                    start_date="2026-11-07T15:00:00+03:00")
        resp, _ = run(cfg, portal, calls_db)
        ph = resp["facts"][0]["payload"]["phone"]
        assert ph == "****4567" and "79161234567" not in __import__("json").dumps(resp)

    def test_boundary_from_included_to_excluded(self, cfg, portal, calls_db):
        insert_call(calls_db, bx_stat_id="67306",
                    start_date="2026-11-07T00:00:00+03:00")
        insert_call(calls_db, bx_stat_id="67307",
                    start_date="2026-11-08T00:00:00+03:00")
        resp, _ = run(cfg, portal, calls_db)
        ids = {f["source_entity_id"] for f in resp["facts"]}
        assert "voximpl:67306" in ids and "voximpl:67307" not in ids

    def test_callsdb_never_written(self, cfg, portal, calls_db):
        import hashlib
        before = hashlib.sha256(calls_db.read_bytes()).hexdigest()
        run(cfg, portal, calls_db)
        after = hashlib.sha256(calls_db.read_bytes()).hexdigest()
        assert before == after
        assert not calls_db.with_suffix(".db-wal").exists()


class TestAuthorCrosscheck:
    def test_respponsible_mismatch_warns(self, cfg, portal, calls_db):
        insert_call(calls_db, bx_stat_id="67308", activity_id="8808",
                    manager_id=401, start_date="2026-11-07T16:00:00+03:00")
        portal.add_activity(8808, datetime(2026, 11, 7, 16, 0), type_id=2,
                            responsible=402, subject="Звонок")
        resp, _ = run(cfg, portal, calls_db)
        assert resp["detectors"]["author_crosscheck"] == "WARN"
        assert any("RESPONSIBLE_ID" in w for w in resp["warnings"])
        # приоритет voximpl: автор остался 401
        f = [x for x in resp["facts"] if x["source_entity_id"] == "voximpl:67308"][0]
        assert f["author_id"] == 401
