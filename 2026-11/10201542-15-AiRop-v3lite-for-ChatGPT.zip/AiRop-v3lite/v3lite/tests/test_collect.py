"""Сквозные тесты collect.run_request: stdin-контракт, кэш-идемпотентность,
SCHEMA до REST, границы интентов (матрица §9.5)."""
import json
from datetime import datetime

import pytest

from core.collect import run_request


@pytest.fixture
def rt(cfg, portal):
    from conftest import FakeTransport
    return FakeTransport(portal)


LEADS_REQ = {"intent": "leads_day", "request_id": "e2e-1",
             "from": "2026-11-07T00:00:00+03:00",
             "to": "2026-11-08T00:00:00+03:00"}


class TestEndToEnd:
    def test_leads_day_full(self, cfg, portal, rt):
        portal.add_lead(901, datetime(2026, 11, 7, 9))
        resp = run_request(LEADS_REQ, cfg=cfg, transport=rt, use_cache=False)
        assert resp["status"] == "VERIFIED"
        assert resp["facts"][0]["source_entity_id"] == "lead:901"
        assert resp["meta"]["rest_calls"] >= 1
        assert resp["as_of"].endswith("+03:00")

    def test_schema_fail_no_rest(self, cfg, portal, rt):
        bad = dict(LEADS_REQ, hack=1)
        resp = run_request(bad, cfg=cfg, transport=rt, use_cache=False)
        assert resp["status"] == "FAILED"
        assert resp["errors"][0]["code"] == "SCHEMA"
        assert rt.urls == []                    # в REST не ходили (§9.5-10)

    def test_invalid_json(self, cfg, rt):
        resp = run_request("{not json", cfg=cfg, transport=rt, use_cache=False)
        assert resp["status"] == "FAILED"
        assert resp["errors"][0]["code"] == "SCHEMA"

    def test_client_dossier_ghost_not_found(self, cfg, portal, rt):
        # F3 (GC-8): несуществующий ID → NOT_FOUND, досье по призраку
        # не строится, никакого автоподбора «похожих» (GC-4)
        resp = run_request({"intent": "client_dossier", "request_id": "d1",
                            "entity": {"type": "lead", "id": 1}},
                           cfg=cfg, transport=rt, use_cache=False)
        assert resp["status"] == "FAILED"
        assert resp["errors"][0]["code"] == "NOT_FOUND"
        assert "не найдена" in resp["errors"][0]["detail"]


class TestIdempotencyCache:
    def test_same_request_same_answer(self, cfg, portal, rt):
        portal.add_lead(911, datetime(2026, 11, 7, 10))
        r1 = run_request(LEADS_REQ, cfg=cfg, transport=rt)
        calls_after_first = len(rt.urls)
        r2 = run_request(LEADS_REQ, cfg=cfg, transport=rt)
        assert len(rt.urls) == calls_after_first    # повтор не ходил в REST
        assert r1["facts"] == r2["facts"]           # факты не удвоились (§9.5-3)
        assert r2["meta"]["cache"] == "hit"
        # всё, кроме meta (as_of/coverage/facts), совпадает дословно
        strip = lambda d: {k: v for k, v in d.items() if k != "meta"}
        assert json.dumps(strip(r1), sort_keys=True) == \
            json.dumps(strip(r2), sort_keys=True)

    def test_transient_not_cached(self, cfg, portal, rt):
        portal.add_lead(912, datetime(2026, 11, 7, 11))
        rt.fail_times = [(503, {}), (503, {}), (503, {}), (503, {})]
        r1 = run_request(LEADS_REQ, cfg=cfg, transport=rt)
        # все попытки упали → SOURCE_5XX; после ретраев ответ не из кэша
        rt.fail_times = []
        r2 = run_request(LEADS_REQ, cfg=cfg, transport=rt)
        assert r2["meta"]["cache"] == "miss"

    def test_different_request_id_no_hit(self, cfg, portal, rt):
        portal.add_lead(913, datetime(2026, 11, 7, 12))
        run_request(LEADS_REQ, cfg=cfg, transport=rt)
        r2 = run_request(dict(LEADS_REQ, request_id="e2e-other"),
                         cfg=cfg, transport=rt)
        assert r2["meta"]["cache"] == "miss"
