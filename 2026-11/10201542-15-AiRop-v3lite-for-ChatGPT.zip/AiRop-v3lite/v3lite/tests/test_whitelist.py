"""Whitelist/фильтры: мутаторы и чужие параметры не проходят до сети."""
import pytest

from core.client import BitrixClient
from core.errors import FilterRejected, SecurityError


def mk_client(cfg, transport):
    sleeps = []
    c = BitrixClient(cfg, transport=transport, sleep=sleeps.append)
    return c, sleeps


class TestMethodWhitelist:
    def test_mutator_blocked(self, cfg, fake):
        c, _ = mk_client(cfg, fake)
        with pytest.raises(SecurityError):
            c.call("crm.lead.add", {"TITLE": "x"})
        with pytest.raises(SecurityError):
            c.call("crm.lead.delete", {"ID": 1})
        with pytest.raises(SecurityError):
            c.call("im.message.add", {"MESSAGE": "x"})
        assert fake.urls == []  # ни одного сетевого вызова

    def test_unknown_method_blocked(self, cfg, fake):
        c, _ = mk_client(cfg, fake)
        with pytest.raises(SecurityError):
            c.call("crm.telephony.call", {})
        assert fake.urls == []

    def test_unknown_param_blocked(self, cfg, fake):
        c, _ = mk_client(cfg, fake)
        with pytest.raises(SecurityError):
            c.call("crm.lead.list", {"FILTER[DATE_CREATE]": "01.01.2026 00:00:00",
                                     "HACK": 1})
        assert fake.urls == []

    def test_allowed_params_pass(self, cfg, fake):
        c, _ = mk_client(cfg, fake)
        c.call("crm.lead.list", {"FILTER[>=DATE_CREATE]": "01.11.2026 00:00:00",
                                 "select[]": ["ID", "TITLE"], "start": 0})
        assert len(fake.urls) == 1

    def test_batch_validates_cmds(self, cfg, fake):
        c, _ = mk_client(cfg, fake)
        with pytest.raises(SecurityError):
            c.batch([("crm.lead.update", {"ID": "1"})])
        assert fake.urls == []


class TestFilterValidation:
    def test_unknown_field(self, cfg, fake):
        c, _ = mk_client(cfg, fake)
        with pytest.raises(FilterRejected):
            c.call("crm.lead.list",
                   {"FILTER[SECRET_FIELD]": "01.01.2026 00:00:00"})
        assert fake.urls == []

    def test_bad_date_format(self, cfg, fake):
        c, _ = mk_client(cfg, fake)
        with pytest.raises(FilterRejected):
            c.call("crm.lead.list",
                   {"FILTER[>=DATE_CREATE]": "2026-11-01T00:00:00+03:00"})
        assert fake.urls == []

    def test_bad_operator(self, cfg, fake):
        c, _ = mk_client(cfg, fake)
        with pytest.raises(FilterRejected):
            c.call("crm.activity.list", {"FILTER[~CREATED]": "01.01.2026 00:00:00"})

    def test_bad_field_activity(self, cfg, fake):
        c, _ = mk_client(cfg, fake)
        with pytest.raises(FilterRejected):
            c.call("crm.activity.list",
                   {"FILTER[DATE_CREATE]": "01.01.2026 00:00:00"})  # у activity CREATED
