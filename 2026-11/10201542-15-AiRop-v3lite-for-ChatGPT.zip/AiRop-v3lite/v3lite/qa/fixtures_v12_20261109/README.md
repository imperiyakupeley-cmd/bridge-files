# Негативные фикстуры спеки v1.2 §9.7 (A2–D2) — Release Gate admin2

Созданы 09.11.2026 (мост mw9kv1iszlu4) отдельно от фикстур §9.6
(immutable-правило: существующие каталоги не правятся, новые — с датой).

- dataset_neg_A2_two_clients.json — fuzzy-ловушка: два клиента, близкие
  тексты, ±10 минут; сшивка только exact CONNECTOR_MID, кросс-контаминации нет.
- dataset_neg_B2_unattributed.json — исходящие только-в-Авито; числовое
  совпадение authorId с сотрудником Б24 — канарейка, НЕ атрибуция.
- dataset_neg_C2_collisions.json — коллизии u2i↔chat и CRM-сущности,
  неверифицированный аккаунт: AMBIGUOUS/UNLINKED, склейки нет.
- dataset_neg_D2_dangling_owner.json — GC-8: contact 17016 не существует,
  deal 17016 существует; dangling → warning + PARTIAL, без перепривязки.

Движки: messages/msg/join.py (join_exact) и core/sources/owners.py
(verify_fact_owners, ответы портала — фейковый client.batch, без сети).
Прогон: qa/acceptance_admin2.py --suite v12 (проверки E1–E4).
Фикстуры НЕ редактировать: изменение = новый каталог с новой датой.
