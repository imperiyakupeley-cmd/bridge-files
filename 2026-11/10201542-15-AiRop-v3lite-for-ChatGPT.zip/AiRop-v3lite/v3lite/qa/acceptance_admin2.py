#!/usr/bin/env python3
"""acceptance_admin2.py — НЕЗАВИСИМАЯ приёмка стенда ИИ-РОП v3 Lite (admin2).

Спека: ~/AiRop/spec_v3lite_admin2.md (контракт §3–§4, канарейки §7, матрица §9,
приёмка §11). Золотые кейсы: ~/AiRop/v3lite/qa/crm_golden_cases.md (GC-1..GC-10).

Принципы приёмки (§11.1): приёмка ПО ФАКТУ — ни один PASS не объявляется без
прогона/артефакта; статус честный; фикстуры immutable (§11.6 — проверка сумм
перед прогоном, расхождение = стоп).

Режимы (только чтение; прод-активаций и мутаций CRM НЕТ):
  --suite static  — целостность фикстур, whitelist/фильтры (сеть не трогаем)
  --suite mock    — детерминированные прогоны стенда (mock-сервер, replay,
                    инжект сбоев, in-process юниты контракта)
  --suite live    — read-only пробы живого портала по золотым кейсам
                    (бюджет-гвард: --live-budget, по умолчанию 35 вызовов;
                    каждый вызов логируется в qa/results/live_calls_*.jsonl)
  --suite sources — анализ непокрытых источников (по артефактам, без сети)
  --suite v12     — Release Gate спеки v1.2 (§9.7 негативные A2–D2, запрет
                    fuzzy, VERIFIED-cap, артефакты интеграции E2E#2, живая
                    батарея; фикстуры qa/fixtures_v12_20261109/)
  --suite all     — всё выше; итог — вердикт PASS/FAIL/CONDITIONAL + дефекты

Выход: qa/results/acceptance_<ts>.json (полный) + краткая таблица в stdout.
Вердикт:
  FAIL        — упал любой блокирующий контрактный тест (batch fail-closed,
                дедуп, SCHEMA, статусы, авторство, золотые инциденты GC-1..5);
  CONDITIONAL — блокирующие PASS, но есть принципиальные пробелы полноты
                (Авито §11.5, досье-стаб, передачи, потолок offset, пагинация);
  PASS        — blockers и полнота закрыты (сейчас недостижим, см. sources).
"""
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
import os
import re
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
QA = HERE
V3LITE = os.path.dirname(QA)
STAGING = os.path.join(V3LITE, "staging")
MESSAGES = os.path.join(V3LITE, "messages")
RESULTS = os.path.join(QA, "results")
os.makedirs(RESULTS, exist_ok=True)

sys.path.insert(0, V3LITE)
sys.path.insert(0, MESSAGES)
sys.path.insert(0, STAGING)

TS = datetime.now().strftime("%Y%m%d_%H%M%S")
PY = sys.executable or "/opt/homebrew/bin/python3"

CHECKS: list[dict] = []          # {id, group, spec, title, status, detail, evidence}


def check(cid, group, spec, title, status, detail="", evidence=None):
    CHECKS.append({"id": cid, "group": group, "spec": spec, "title": title,
                   "status": status, "detail": detail[:900],
                   "evidence": evidence})
    print(f"[{status:>4}] {cid} {title}" + (f" — {detail[:160]}" if detail else ""),
          flush=True)
    return status


def skip(cid, group, spec, title, detail=""):
    return check(cid, group, spec, title, "SKIP", detail)


# ---------------------------------------------------------------- маски ПД
def mask_phone(p: str) -> str:
    d = re.sub(r"\D", "", str(p or ""))
    return f"{d[:4]}***{d[-2:]}" if len(d) >= 7 else "***"


def _aid(x):
    """author_id из Bitrix приходит то строкой, то int — сравниваем устойчиво."""
    return int(x) if x is not None and str(x).isdigit() else x


# ============================================================ STATIC-набор
def suite_static():
    import core.whitelist as W
    import core.filters as FL
    import msg.whitelist as MW

    # --- A1: целостность immutable-фикстур (§11.6) -------------------------
    problems = []
    for sums in (os.path.join(MESSAGES, "fixtures", "SHA256SUMS"),
                 os.path.join(STAGING, "fixtures", "SHA256SUMS"),
                 os.path.join(STAGING, "fixtures", "SHA256SUMS.addons-20261109")):
        d = os.path.dirname(sums)
        r = subprocess.run(["shasum", "-a", "256", "-c", os.path.basename(sums)],
                           cwd=d, capture_output=True, text=True)
        bad = [l for l in (r.stdout + r.stderr).splitlines()
               if ": OK" not in l and l.strip() and "WARNING" not in l]
        if r.returncode != 0 or bad:
            problems.append(f"{os.path.relpath(sums, V3LITE)}: {bad[:3]}")
    check("A1", "static", "§11.6", "Целостность immutable-фикстур (SHA256SUMS)",
          "FAIL" if problems else "PASS",
          "; ".join(problems) if problems else
          "messages/fixtures + staging/fixtures (+addons): все суммы сходятся")

    # --- A2: whitelist только read-only; BINDINGS запрещён (GC-3) ----------
    mut = [m for m in list(W.METHOD_WHITELIST) + list(getattr(MW, "METHODS", MW.__dict__.get('METHOD_WHITELIST', {}) or {}))
           if W._MUTATING.search(m)]
    act_fields = FL.FILTER_FIELDS.get("crm.activity.list", {}).get("fields", set())
    bindings_banned = "BINDINGS" not in act_fields
    try:
        FL.validate_filter("crm.activity.list", {"BINDINGS": "16318"})
        rej = False
    except Exception:
        rej = True
    ok = not mut and bindings_banned and rej
    check("A2", "static", "§1, GC-3", "Whitelist read-only + запрет фильтра BINDINGS",
          "PASS" if ok else "FAIL",
          f"мутаторов в whitelist: {len(mut)}; BINDINGS в разрешённых полях: "
          f"{not bindings_banned}; FilterRejected на BINDINGS: {rej}")

    # --- A3: зона записи стенда — только staging/ (§10) --------------------
    src = open(os.path.join(STAGING, "integrated.py"), encoding="utf-8").read()
    airo = open(os.path.join(STAGING, "airop_staging.py"), encoding="utf-8").read()
    stray = []
    for name, text in (("integrated.py", src), ("airop_staging.py", airo)):
        for m in re.finditer(r"os\.path\.join\(([^)]*)\)", text):
            args = m.group(1)
            if ("expanduser" in args or '"~' in args or "'~" in args) \
                    and "staging" not in args and "secrets" not in args.lower():
                stray.append(f"{name}: {args[:80]}")
    check("A3", "static", "§10", "Стенд пишет только внутри staging/ и qa/",
          "PASS" if not stray else "FAIL",
          "пути записи стенда локальны; нарушений: " + str(len(stray)) if not stray
          else "; ".join(stray[:3]))


# ============================================================ MOCK-набор
class StubTransport:
    """Роутинг по URL: эмуулирует Bitrix для in-process тестов core."""
    name = "stub"

    def __init__(self, router):
        self.router = router
        self.calls = 0

    def get(self, url, timeout):
        self.calls += 1
        return self.router(url)


class FakeHttp:
    def __init__(self, status, body, headers=None):
        self.status, self.body, self.headers = status, body, headers or {}

    def json(self):
        return json.loads(self.body)


def _dumps(o):
    return json.dumps(o, ensure_ascii=False).encode()


def _qs(url):
    q = url.split("?", 1)[1] if "?" in url else ""
    return urllib.parse.parse_qs(q)


def _mkcfg(**kw):
    from core.config import Config
    base = dict(webhook="https://stub.invalid/rest/0/s", exclude_users={17316, 15780},
                rate_rps=10_000.0, retries_max=0, calls_db="/tmp/acc_calls.db",
                cache_db=f"/tmp/acc_cache_{TS}.db")
    base.update(kw)
    return Config(**base)


def _lead_row(i=9080, created="07.11.2026 10:00:00"):
    return {"ID": str(i), "TITLE": "Михаил — Авито", "DATE_CREATE": created,
            "ASSIGNED_BY_ID": "11898", "CREATED_BY_ID": "17316",
            "STATUS_ID": "IN_PROCESS", "SOURCE_ID": "AVITO",
            "DATE_MODIFY": created, "COMMENTS": ""}


def _touch_row(aid=910001, created="07.11.2026 11:00:00"):
    return {"ID": str(aid), "OWNER_ID": "9080", "OWNER_TYPE_ID": "1",
            "TYPE_ID": "6", "PROVIDER_TYPE_ID": "CONFIGURABLE",
            "PROVIDER_ID": "CONFIGURABLE_REST_APP", "RESPONSIBLE_ID": "11898",
            "AUTHOR_ID": "1", "CREATED": created, "SUBJECT": "Исходящее сообщение",
            "COMPLETED": "Y"}


def _batch_envelope(inner):
    return FakeHttp(200, _dumps({"result": inner}))


def _leads_router(batch_inner, lead_pages=None, lead_total=1):
    """canary→0 строк; crm.lead.list→страницы; batch→конверт."""
    def route(url):
        q = _qs(url)
        if "/batch" in url:
            return _batch_envelope(batch_inner)
        if url.find("crm.lead.list") >= 0:
            for k in q:
                if k.startswith("FILTER[") and "2099" in q[k][0]:
                    return FakeHttp(200, _dumps({"result": [], "total": 0}))
            pages = lead_pages if lead_pages is not None else [[_lead_row()]]
            start = int(q.get("start", ["0"])[0])
            page = pages[min(start // 50, len(pages) - 1)]
            body = {"result": page, "total": lead_total}
            if start // 50 < len(pages) - 1:
                body["next"] = start + 50
            return FakeHttp(200, _dumps(body))
        return FakeHttp(200, _dumps({"result": [], "total": 0}))
    return route


def _leads_request(rid="acc-ld-1"):
    return json.dumps({"intent": "leads_day", "request_id": rid,
                       "from": "2026-11-07T00:00:00+03:00",
                       "to": "2026-11-08T00:00:00+03:00"})


def _run_core(req, cfg, transport, use_cache=False):
    from core.collect import run_request
    return run_request(req, cfg=cfg, transport=transport, use_cache=use_cache)


def _integrated(args, timeout=180):
    """Прогон staging/integrated.py (mock). Возвращает (stdout_json, result_file)."""
    cmd = [PY, "-I", "integrated.py", "run", "--mode", "mock"] + args
    p = subprocess.run(cmd, cwd=STAGING, capture_output=True, text=True,
                       timeout=timeout,
                       env={**os.environ, "V3_CACHE": "0"})
    try:
        out = json.loads(p.stdout)
    except json.JSONDecodeError:
        out = {"_parse_error": p.stdout[-300:], "_stderr": p.stderr[-500:],
               "_rc": p.returncode}
    return out


def _load_result(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def suite_mock():
    from core.client import BitrixClient, _parse_batch_envelope
    from core.transport import HttpResult

    # --- B1: replay ЖИВОГО batch-конверта через текущий парсер -------------
    live_log = os.path.join(STAGING, "logs", "batch_live_2026-11-09T01:51.json")
    verdict, detail = "PASS", []
    if os.path.exists(live_log):
        bodies = json.load(open(live_log, encoding="utf-8"))
        packed = bodies.get("packed_ok", {}).get("result", {})
        sparse = bodies.get("sparse_err", {}).get("result", {})
        r1 = _parse_batch_envelope({"result": packed})
        ok1 = len(r1[0]); miss1 = len(r1[2])
        r2 = _parse_batch_envelope({"result": sparse})
        ok2 = len(r2[0]); err2 = len(r2[1]); miss2 = len(r2[2])
        if not (ok1 == 3 and miss1 == 0):
            verdict = "FAIL"
        if not (ok2 == 2 and err2 == 1 and miss2 == 0):
            verdict = "FAIL"
        detail = [f"packed(list): ok={ok1}/3 missing={miss1}",
                  f"sparse(dict+result_error): ok={ok2} err={err2} missing={miss2}"]
    else:
        verdict, detail = "SKIP", ["нет снятого живого конверта"]
    check("B1", "batch", "§5, инцидент integ-ld-1",
          "Batch-парсер разбирает ЖИВОЙ конверт (result.result LIST и dict)",
          verdict, "; ".join(detail), live_log)

    # --- B2: защитные формы конверта ---------------------------------------
    flat = _parse_batch_envelope({"result": {"0": {"a": 1}, "1": {"b": 2}}})
    empty = _parse_batch_envelope({"result": {"result": [], "result_error": []}})
    nulls = _parse_batch_envelope({"result": {"result": None, "result_error": None}})
    ok = len(flat[0]) == 2 and "flat_envelope" in flat[2] \
        and len(empty[0]) == 0 and len(nulls[0]) == 0 and "no_result_key" in nulls[2]
    check("B2", "batch", "§5", "Batch: плоский/пустой конверт не валит разбор",
          "PASS" if ok else "FAIL",
          f"flat→{len(flat[0])}+anomaly; empty→{len(empty[0])}; null→anomaly {nulls[2]}")

    # --- B3: РЕПРО инцидента 08.11 — fail-closed на потерянных касаниях ----
    # конверт БЕЗ result/result_error → все команды MISSING_IN_BATCH →
    # leads_day обязан упасть в PARTIAL с ошибкой, НЕ VERIFIED
    tr = StubTransport(_leads_router({"result_total": {"0": 1}}))
    resp = _run_core(_leads_request("acc-b3"), _mkcfg(), tr)
    ft = resp.get("coverage", {}).get("first_touch", {})
    errs = [e.get("code") for e in resp.get("errors", [])]
    cov_batch = resp.get("coverage", {}).get("batch:lead_first_touch", {})
    ok = (resp.get("status") != "VERIFIED" and "SOURCE_ERROR" in errs
          and ft.get("cmd_missing", -1) == 1 and cov_batch.get("missing") == 1)
    check("B3", "batch", "§4.5, §11.2", "РЕПРО batch-инцидента: потеря касаний ≠ VERIFIED",
          "PASS" if ok else "FAIL",
          f"status={resp.get('status')} errors={errs} first_touch={ft} "
          f"batch_cov={cov_batch}")

    # --- B4: leads_day на живом артефакте 09.11 (после фикса) --------------
    art = os.path.join(STAGING, "results",
                       "integrated_2026-11-09_70578082-2e45-4985-bb8e-f8bd26e66889.json")
    if os.path.exists(art):
        m = _load_result(art).get("merged", {})
        ft = m.get("coverage", {}).get("first_touch", {})
        bc = m.get("coverage", {}).get("batch:lead_first_touch", {})
        ok = (m.get("status") == "VERIFIED" and bc.get("missing") == 0
              and bc.get("cmd_errors") == 0 and bc.get("ok") == ft.get("leads"))
        check("B4", "batch", "§9", "leads_day live 07.11: касания получены, VERIFIED честный",
              "PASS" if ok else "FAIL",
              f"leads={ft.get('leads')} with_activity={ft.get('with_any_activity')} "
              f"batch={bc} status={m.get('status')}", art)
    else:
        skip("B4", "batch", "§9", "leads_day live-артефакт", "файл не найден")

    # --- C1: дедуп звонков §9.1 (calls_day на calls.db RO + activity) ------
    out = _integrated(["--intent", "calls_day", "--from",
                       "2026-11-07T00:00:00+03:00", "--to",
                       "2026-11-08T00:00:00+03:00",
                       "--request-id", "acc-c1"])
    if "status" not in out:
        check("C1", "matrix", "§9.1", "calls_day: дедуп voximpl×activity (инцидент 05.08)",
              "FAIL", str(out)[:300])
    else:
        m = _load_result(out["result_file"])["merged"]
        facts = m.get("facts", [])
        keys = [(f.get("source"), f.get("source_entity_id")) for f in facts]
        dup = len(keys) - len(set(keys))
        det = (m.get("detectors") or {}).get("core", {})
        vox = sum(1 for f in facts if str(f.get("source")).startswith("voximpl"))
        ok = dup == 0 and det.get("duplicate_guard_dropped") == 0 and vox > 0
        check("C1", "matrix", "§9.1", "calls_day: дедуп voximpl×activity (инцидент 05.08)",
              "PASS" if ok else "FAIL",
              f"фактов={len(facts)} (voximpl={vox}); дублей ключей={dup}; "
              f"guard_dropped={det.get('duplicate_guard_dropped')}; "
              f"status={m.get('status')}", out.get("result_file"))

    # --- C2: resolve_client — дубли перечислены, не сливаются (§9.4) -------
    from core.sources.clients import collect as resolve_collect

    class RC:
        def __init__(self):
            self.coverage = {}

        def call(self, method, params=None):
            if method == "crm.duplicate.findbycomm":
                return {"result": {"CONTACT": ["8868", "16790"], "LEAD": ["9080"]}}
            return {"result": {}}

        def batch(self, cmds, label=""):
            rows = [{"ID": p["ID"], "NAME": "Михаил", "LAST_NAME": "",
                     "ASSIGNED_BY_ID": "11898", "DATE_CREATE": "01.10.2026",
                     "PHONE": [{"VALUE": "79615550072"}]}
                    for _m, p in cmds if _m == "crm.contact.get"]
            rows += [{"ID": "9080", "TITLE": "Михаил — Авито",
                      "STATUS_ID": "CONVERTED", "ASSIGNED_BY_ID": "17316",
                      "DATE_CREATE": "31.10.2026", "PHONE": []}]
            return [{"ID": r["ID"], **r} for r in rows]

    v = {"intent": "resolve_client", "request_id": "acc-c2", "phone": "79615550072"}
    resp = resolve_collect(RC(), v, exclude_users={17316, 15780})
    warn = " ".join(resp.get("warnings", []))
    res = resp.get("result", {})
    ok = ("дубликаты контактов" in warn and "8868" in warn
          and len(res.get("cards", [])) >= 2
          and all("***" in str(p) for c in res.get("cards", [])
                  for p in c.get("phones", [])))
    check("C2", "matrix", "§9.4, GC-2/5", "resolve_client: дубли в warnings, телефоны в маске",
          "PASS" if ok else "FAIL", f"warnings={resp.get('warnings')}; cards="
          f"{len(res.get('cards', []))}; duplicates={res.get('duplicates')}")

    # --- C3: SCHEMA-отказы до REST (§9.5-10) -------------------------------
    from core.collect import run_request as rr
    bad = [
        {"intent": "leads_day", "request_id": "acc-c3a",
         "from": "2026-11-07T00:00:00+03:00", "to": "2026-11-08T00:00:00+03:00",
         "employee_id": 11898},                                   # запрещён
        {"intent": "manager_day", "request_id": "acc-c3b",
         "from": "2026-11-07T00:00:00+03:00", "to": "2026-11-08T00:00:00+03:00"},
        {"intent": "leads_day", "request_id": "acc-c3c",
         "from": "2026-11-07T00:00:00+03:00", "to": "2026-11-08T00:00:00+03:00",
         "name": "Михаил"},                                       # неизвестный ключ (GC-4)
        {"intent": "telepathy_day", "request_id": "acc-c3d"},     # неизвестный intent
    ]
    ok = True
    det = []
    for b in bad:
        r = rr(json.dumps(b), cfg=_mkcfg(offline=True), transport=None, use_cache=False)
        code = (r.get("errors") or [{}])[0].get("code")
        good = r.get("status") == "FAILED" and code == "SCHEMA"
        ok = ok and good
        det.append(f"{b['intent'][:14]}:{r.get('status')}/{code}")
    check("C3", "matrix", "§3, §9.5-10", "SCHEMA-отказ: мусорный ключ/intent → FAILED до REST",
          "PASS" if ok else "FAIL", "; ".join(det))

    # --- C4: идемпотентность (§9.5-3) ---------------------------------------
    tr = StubTransport(_leads_router({"result": [_touch_row()], "result_error": []}))
    cfg = _mkcfg(cache_db=f"/tmp/acc_cache_{TS}.db")
    r1 = _run_core(_leads_request("acc-c4"), cfg, tr, use_cache=True)
    r2 = _run_core(_leads_request("acc-c4"), cfg, tr, use_cache=True)
    strip = lambda r: {k: v for k, v in r.items() if k != "meta"}
    ok = (strip(r1) == strip(r2) and r2.get("meta", {}).get("cache") == "hit"
          and tr.calls > 0)
    check("C4", "matrix", "§9.5-3", "Идемпотентность: повтор request_id → тот же ответ",
          "PASS" if ok else "FAIL",
          f"cache={r1.get('meta', {}).get('cache')}→{r2.get('meta', {}).get('cache')}; "
          f"равны={strip(r1) == strip(r2)}")

    # --- C5: границы окна [from, to) (§9.5-4) -------------------------------
    from core.canaries import window_check
    from core.timeutil import parse_iso
    frm = parse_iso("2026-11-07T00:00:00+03:00")
    to = parse_iso("2026-11-08T00:00:00+03:00")

    class TF(dict):
        pass

    f_in = {"fact_type": "message", "source_entity_id": "x1",
            "timestamp_dt": parse_iso("2026-11-07T00:00:00+03:00")}
    f_out = {"fact_type": "message", "source_entity_id": "x2",
             "timestamp_dt": parse_iso("2026-11-08T00:00:00+03:00")}
    kept, wc = window_check([f_in, f_out], frm, to, warnings=[])
    check("C5", "matrix", "§2, §9.5-4", "Границы окна: from включён, to исключён",
          "PASS" if (len(kept) == 1 and kept[0]["source_entity_id"] == "x1"
                     and wc == "FAIL") else "FAIL",
          f"оставлено={[k['source_entity_id'] for k in kept]}; canary={wc}")

    # --- C6: усечение по page_limit (GC-1 «обрез 5000») ---------------------
    tr = StubTransport(_leads_router(
        {"result": [], "result_error": []},
        lead_pages=[[_lead_row(1), _lead_row(2)], [_lead_row(3), _lead_row(4)]],
        lead_total=4))
    from core.client import BitrixClient as BC
    cfg = _mkcfg(page_limit=1)
    c = BC(cfg, transport=tr)
    rows, stats = c.call_all("crm.lead.list", {"start": 0})
    check("C6", "matrix", "§7.2, GC-1", "Пагинация: page_limit → truncated (не молча)",
          "PASS" if (stats.truncated and stats.stop_reason == "page_limit"
                     and stats.pages == 1) else "FAIL",
          f"pages={stats.pages} rows={stats.rows} stop={stats.stop_reason} "
          f"truncated={stats.truncated}")

    # --- C7: offset-окно ~10 200 (§6) ---------------------------------------
    def offset_router(url):
        q = _qs(url)
        if url.find("crm.lead.list") >= 0:
            for k in q:
                if k.startswith("FILTER[") and "2099" in q[k][0]:
                    return FakeHttp(200, _dumps({"result": [], "total": 0}))
            start = int(q.get("start", ["0"])[0])
            page = [{"ID": str(start + i)} for i in range(50)]
            body = {"result": page, "total": 10_500, "next": start + 50}
            return FakeHttp(200, _dumps(body))
        return FakeHttp(200, _dumps({"result": []}))

    tr = StubTransport(offset_router)
    c = BC(_mkcfg(), transport=tr)
    rows, stats = c.call_all("crm.lead.list", {"start": 0})
    check("C7", "matrix", "§6", "Offset-потолок 10 200 → truncated + stop_reason",
          "PASS" if (stats.truncated and stats.stop_reason == "offset_window"
                     and stats.rows <= 10_200) else "FAIL",
          f"rows={stats.rows} stop={stats.stop_reason}")

    # --- C8: история >лимита: LIMIT-эскалации; сбой эскалации → cap+truncated
    import msg.history as H
    from msg.config import MsgConfig
    from msg.sessions import SessionRow
    from msg.errors import SourceError

    class HistClient:  # контракт после фикса F5: LIMIT + эскалации ×2
        def __init__(self, total=180, fail_esc=False):
            self.total, self.fail_esc = total, fail_esc
            self.calls = []

        def _rows(self, lim):
            return {mid: {"senderid": 11898, "chatid": 10,
                          "date": "2026-11-07T12:00:00+03:00", "text": "т"}
                    for mid in range(1, min(lim, self.total) + 1)}

        def batch(self, cmds):
            res = {k: {"message": self._rows(int(p.get("LIMIT", 50)))}
                   for k, _m, p in cmds}
            return res, {}

        def call(self, method, params):
            self.calls.append(params)
            if self.fail_esc:
                raise SourceError("imopenlines.session.history.get: 500")
            return {"message": self._rows(int(params.get("LIMIT", 50)))}

    cfg_h = MsgConfig(history_limit=50)
    h_ok = H.fetch_histories(HistClient(total=180), cfg_h,
                             [SessionRow(id=1, chat_id=10, message_count=180)],
                             max_text_len=100)
    h_bad = H.fetch_histories(HistClient(total=250, fail_esc=True), cfg_h,
                              [SessionRow(id=1, chat_id=10, message_count=250)],
                              max_text_len=100)
    ok = (h_ok[1].fetched_count == 180 and not h_ok[1].truncated
          and not h_ok[1].cap_hit and h_ok[1].pages == 3
          and h_bad[1].cap_hit and h_bad[1].truncated
          and h_bad[1].fetched_count == 50)
    check("C8", "matrix", "§5, §7.2 (фикс F5)",
          "Длинные чаты: LIMIT-эскалации добирают хвост; сбой → cap+truncated",
          "PASS" if ok else "FAIL",
          f"ok: fetched={h_ok[1].fetched_count}/{h_ok[1].expected_count} "
          f"pages={h_ok[1].pages} (50→100→200) cap_hit={h_ok[1].cap_hit}; "
          f"сбой эскалации: fetched={h_bad[1].fetched_count}/250 "
          f"cap_hit={h_bad[1].cap_hit} truncated={h_bad[1].truncated} — "
          f"недобор назван недобором, не молча")

    # --- C9: PARTIAL-честность: --ol off / --ol dead / VERIFIED ------------
    # фикстура manager_day рассчитана на сотрудника 401 (user.get 401/402)
    mg = ["--intent", "manager_day", "--employee-id", "401",
          "--from", "2026-11-07T00:00:00+03:00", "--to",
          "2026-11-08T00:00:00+03:00"]
    out_off = _integrated(mg + ["--ol", "off", "--request-id", "acc-c9a"])
    out_dead = _integrated(mg + ["--ol", "dead", "--request-id", "acc-c9b"])
    ld = _integrated(["--intent", "leads_day", "--from",
                      "2026-11-07T00:00:00+03:00", "--to",
                      "2026-11-08T00:00:00+03:00", "--request-id", "acc-c9c"])
    ok = (out_off.get("status") == "PARTIAL" and out_dead.get("status") == "PARTIAL"
          and ld.get("status") == "VERIFIED"
          and not (ld.get("warnings") or ld.get("errors")))
    check("C9", "matrix", "§4", "Статусы: недоступный источник → PARTIAL, VERIFIED чистый",
          "PASS" if ok else "FAIL",
          f"ol=off:{out_off.get('status')} ol=dead:{out_dead.get('status')} "
          f"leads:{ld.get('status')} warn={len(ld.get('warnings') or [])}")

    # --- C10: 429-политика (§7.6) -------------------------------------------
    class Always429:
        def __init__(self):
            self.calls = 0

        def get(self, url, timeout):
            self.calls += 1
            return FakeHttp(429, _dumps({"error": "QUERY_LIMIT_EXCEEDED"}),
                            {"Retry-After": "0"})

    from core.config import Config as C2_
    a429 = Always429()
    c = BC(_mkcfg(retries_max=2), transport=a429)
    c._sleep = lambda s: None
    code429 = None
    try:
        c.call("crm.lead.list", {"start": 0})
    except Exception as e:
        code429 = getattr(e, "code", type(e).__name__)
    ok_unit = code429 == "SOURCE_429" and a429.calls == 3   # 1 попытка + 2 ретрая
    out_f = _integrated(["--intent", "leads_day", "--from",
                         "2026-11-07T00:00:00+03:00", "--to",
                         "2026-11-08T00:00:00+03:00",
                         "--core-faults", '{"crm.lead.list":{"status":429,"times":2}}',
                         "--request-id", "acc-c10"])
    ok_fault = out_f.get("status") == "VERIFIED"    # ретраи съели 2 сбоя
    check("C10", "matrix", "§7.6", "429: 3 попытки → SOURCE_429; ретраи съедают сбои",
          "PASS" if (ok_unit and ok_fault) else "FAIL",
          f"unit: attempts={a429.calls} код={code429}; fault429x2 → {out_f.get('status')}")

    # --- C11: старые открытые сессии (§9.5-7, §6) ---------------------------
    from msg.sessions import _is_candidate
    from datetime import datetime as DT
    old_open = SessionRow(id=1, date_create=DT(2026, 1, 1),
                          date_close=None, message_count=3)
    closed_before = SessionRow(id=2, date_create=DT(2026, 1, 1),
                               date_close=DT(2026, 11, 6, 12, 0))
    bad_dates = SessionRow(id=3, bad_dates=True)
    frm2, to2 = DT(2026, 11, 7), DT(2026, 11, 8)
    r1 = _is_candidate(old_open, frm2, to2, None)
    r2 = _is_candidate(closed_before, frm2, to2, None)
    r3 = _is_candidate(bad_dates, frm2, to2, None)
    check("C11", "matrix", "§9.5-7", "Старые открытые сессии — кандидат; закрытые до окна — нет",
          "PASS" if (r1[0] and not r2[0] and r3[0]) else "FAIL",
          f"open_old={r1} closed_before={r2} bad_dates={r3}")

    # --- C12: скоуп вебхука ОЛ (§9.5-6) + тип-баг user_id -------------------
    ds_path = os.path.join(STAGING, "fixtures", "dataset_messages_day.json")
    ds = json.load(open(ds_path, encoding="utf-8"))
    verdicts = []
    for tag, uid in (("str_owner", "1"), ("other_user", 999)):
        ds2 = copy.deepcopy(ds)
        ds2["methods"]["user.current"] = {"value": {"ID": uid, "NAME": "Тест",
                                                    "LAST_NAME": ""}}
        tmp = os.path.join("/tmp", f"acc_ds_{tag}_{TS}.json")
        json.dump(ds2, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
        from mock_b24 import MockB24
        mock = MockB24(ds2, os.path.join("/tmp", f"acc_http_{tag}.jsonl"))
        port = mock.start()
        try:
            req = {"intent": "messages_period", "request_id": f"acc-c12-{tag}",
                   "from": "2026-11-07T00:00:00+03:00",
                   "to": "2026-11-08T00:00:00+03:00", "options": {}}
            env = {**os.environ, "V3_OL_WEBHOOK":
                   f"http://127.0.0.1:{port}/stage/acc/rest/mock"}
            p = subprocess.run([PY, "-I", "run.py"], cwd=MESSAGES,
                               input=json.dumps(req), capture_output=True,
                               text=True, timeout=120, env=env)
            resp = json.loads(p.stdout or "{}")
            warn = " ".join(resp.get("warnings", []))
            scope = resp.get("coverage", {}).get("webhook_scope", {})
            verdicts.append((tag, resp.get("status"), scope.get("full_listing_expected"),
                             "webhook_scope" in warn))
        finally:
            mock.stop()
    str_owner = next(v for v in verdicts if v[0] == "str_owner")
    other = next(v for v in verdicts if v[0] == "other_user")
    # other_user → скоуп-варнинг обязателен; str_owner ("1" строкой = владелец)
    # НЕ должен давать скоуп-варнинг — если да, это подтверждённый тип-баг (L10)
    bug = str_owner[3]
    ok = other[3] and other[1] != "VERIFIED"
    check("C12", "matrix", "§9.5-6", "Скоуп вебхука: не-владелец → warning + не VERIFIED",
          "PASS" if ok else "FAIL",
          f"other_user: warn={other[3]} status={other[1]}; "
          f"владелец-строкой '1': warn={str_owner[3]} "
          f"({'ТИП-БАГ воспроизведён детерминированно' if bug else 'ок'})")

    # --- C13: авторство по золотым строкам (GC-1/3/8, §8) -------------------
    from core.sources.activities import fact_from_activity
    ex = {17316, 15780}
    todo = fact_from_activity(
        {"ID": "726596", "OWNER_TYPE_ID": "2", "OWNER_ID": "13724", "TYPE_ID": "6",
         "PROVIDER_TYPE_ID": "TODO", "PROVIDER_ID": "TODO", "RESPONSIBLE_ID": "11898",
         "AUTHOR_ID": "11898", "CREATED": "07.11.2026 09:00:00",
         "SUBJECT": "Связаться с клиентом", "COMPLETED": "N",
         "DEADLINE": "21.03.2026 12:00:00"}, exclude_users=ex)
    bot_task = fact_from_activity(
        {"ID": "790001", "OWNER_TYPE_ID": "3", "OWNER_ID": "11572", "TYPE_ID": "6",
         "PROVIDER_TYPE_ID": "TASKS_TASK", "PROVIDER_ID": "TASKS_TASK",
         "RESPONSIBLE_ID": "20116", "AUTHOR_ID": "15780",
         "CREATED": "07.11.2026 09:30:00", "SUBJECT": "Отложенный клиент",
         "COMPLETED": "N"}, exclude_users=ex)
    out_msg = fact_from_activity(
        {"ID": "959350", "OWNER_TYPE_ID": "3", "OWNER_ID": "16318", "TYPE_ID": "6",
         "PROVIDER_TYPE_ID": "CONFIGURABLE", "PROVIDER_ID": "CONFIGURABLE_REST_APP",
         "RESPONSIBLE_ID": "11898", "AUTHOR_ID": "1",
         "CREATED": "07.11.2026 15:03:11", "SUBJECT": "Исходящее сообщение",
         "COMPLETED": "Y"}, exclude_users=ex)
    in_msg = fact_from_activity(
        {"ID": "959351", "OWNER_TYPE_ID": "3", "OWNER_ID": "16318", "TYPE_ID": "6",
         "PROVIDER_TYPE_ID": "CONFIGURABLE", "PROVIDER_ID": "CONFIGURABLE_REST_APP",
         "RESPONSIBLE_ID": "17316", "AUTHOR_ID": "1",
         "CREATED": "07.11.2026 16:00:00", "SUBJECT": "Входящее сообщение",
         "COMPLETED": "Y"}, exclude_users=ex)
    call_act = fact_from_activity(
        {"ID": "1001974", "OWNER_TYPE_ID": "2", "OWNER_ID": "17016", "TYPE_ID": "2",
         "PROVIDER_TYPE_ID": "VOXIMPLANT_CALL", "PROVIDER_ID": "VOXIMPLANT_CALL",
         "RESPONSIBLE_ID": "20114", "AUTHOR_ID": "17316",
         "CREATED": "02.11.2026 10:00:00", "SUBJECT": "Исходящий звонок Михаилу (13 мин)",
         "COMPLETED": "Y"}, exclude_users=ex)
    conds = {
        "TODO→автор=RESPONSIBLE(11898), kind=todo": (
            todo["payload"]["kind"] == "todo" and _aid(todo["author_id"]) == 11898
            and todo["author_role"] == "WE"),
        "TASKS_TASK бота → боту, НЕ менеджеру (GC-1 стр.34)": (
            bot_task is not None and bot_task["author_role"] == "BOT"
            and _aid(bot_task["author_id"]) == 15780),
        "исходящее: автор=RESPONSIBLE, AUTHOR_ID=1 не автор (GC-3)": (
            _aid(out_msg["author_id"]) == 11898 and out_msg["author_role"] == "WE"),
        "входящее: CLIENT без автора": (
            in_msg["author_role"] == "CLIENT" and in_msg["author_id"] is None),
        "звонок-activity: автор=RESPONSIBLE, не AUTHOR (GC-8)": (
            _aid(call_act["author_id"]) == 20114),
    }
    failed = [k for k, v in conds.items() if not v]
    types = {f["fact_type"]: type(f["author_id"]).__name__
             for f in (todo, bot_task, out_msg, in_msg, call_act) if f}
    check("C13", "matrix", "§8, GC-1/3/8", "Авторство: RESPONSIBLE vs AUTHOR_ID=1 vs бот",
          "PASS" if not failed else "FAIL",
          ("нарушено: " + "; ".join(failed) if failed else
           "TODO/исходящее/входящее/звонок — верны")
          + f"; типы author_id по веткам: {types} (спека §4 — int)")

    # --- C14: контракт §4 на всех моих прогонах + narrator (§I) ------------
    spec = importlib.util.spec_from_file_location(
        "airop_staging_acc", os.path.join(STAGING, "airop_staging.py"))
    st = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(st)
    cerr_total, cerr_detail = 0, []
    for out in (out_off, out_dead, ld, out_f):
        rf = out.get("result_file")
        if not rf:
            continue
        r = _load_result(rf)
        errs = st.contract_check(
            {k: r["merged"].get(k) for k in ("request_id", "intent", "status",
                                             "as_of", "facts", "coverage",
                                             "warnings", "errors", "detectors")},
            r.get("request"))
        if errs:
            cerr_total += len(errs)
            cerr_detail += errs
    check("C14", "iface", "§4", "Контракт §4 (ключи/эхо/честность) на всех прогонах",
          "PASS" if cerr_total == 0 else "FAIL",
          "; ".join(cerr_detail[:4]) if cerr_detail else "нарушений нет")

    # --- C15: narrator-пакет (черновик v0.1 + SCHEMA_RECONCILIATION) -------
    out_n = _integrated(mg + ["--narrator", "--request-id", "acc-c15"])
    rf = out_n.get("result_file")
    np_ = (_load_result(rf)["merged"].get("narrator_packet")) if rf else None
    if not np_:
        check("C15", "iface", "narrator v0.1", "narrator_packet: структура", "FAIL",
              f"пакет не получен: {str(out_n)[:200]}")
    else:
        m = _load_result(rf)["merged"]
        conds = {
            "status-отображение VERIFIED/PARTIAL/FAILED→ok/partial/error": (
                np_.get("status") == {"VERIFIED": "ok", "PARTIAL": "partial",
                                      "FAILED": "error"}[m.get("status")]),
            "check_type 1:1 intent": np_.get("check_type") == "manager_day",
            "F-факты и evidence согласованы": (
                len(np_.get("facts", [])) == len(np_.get("evidence", []))
                and {f["id"] for f in np_["facts"]} ==
                {e["fact_id"] for e in np_["evidence"]}),
            "channels: whatsapp/telegram/email=false, openlines по факту": (
                np_["coverage"]["channels"]["whatsapp"] is False
                and np_["coverage"]["channels"]["telegram"] is False
                and np_["coverage"]["channels"]["email"] is False
                and isinstance(np_["coverage"]["channels"].get("openlines"), bool)),
            "partial → gaps непусты": (
                np_.get("status") != "partial" or np_["coverage"]["gaps"]),
            "ambiguity null (досье по ID)": np_.get("ambiguity") is None,
        }
        failed = [k for k, v in conds.items() if not v]
        check("C15", "iface", "narrator v0.1",
              "narrator_packet: статус/факты/каналы/gaps",
              "PASS" if not failed else "FAIL",
              "; ".join(failed) if failed else
              f"status={np_.get('status')} facts={len(np_.get('facts', []))} "
              f"channels={np_['coverage']['channels']}", rf)

    # --- C16: merged-поля интеграции (module_statuses/merge_notes) ---------
    r = _load_result(out_off["result_file"])["merged"]
    ok = ("module_statuses" in r and "merge_notes" in r
          and r["module_statuses"].get("messages") is None
          and any("OL-источник отключён" in w for w in r["warnings"]))
    check("C16", "iface", "SCHEMA_RECONCILIATION",
          "Merged-ответ: module_statuses/merge_notes/префикс msg.",
          "PASS" if ok else "FAIL",
          f"module_statuses={r.get('module_statuses')}; "
          f"msg-ключи coverage={[k for k in r.get('coverage', {}) if k.startswith('msg.')][:4]}")


# ============================================================ LIVE-набор
_LIVE_STATE = {"calls": 0, "log": None}


def _hooks():
    spec = importlib.util.spec_from_file_location(
        "staging_secrets_acc", os.path.join(STAGING, "secrets.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _live_get(method, params, hook=None, timeout=15):
    """GET read-only вызов с бюджет-гвардом и логом."""
    hook = hook or _LIVE_STATE["bx"]
    if _LIVE_STATE["calls"] >= _LIVE_STATE["budget"]:
        raise RuntimeError("live-бюджет исчерпан")
    qs = urllib.parse.urlencode(params, doseq=True)
    url = f"{hook.rstrip('/')}/{method}.json?{qs}"
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    t0 = time.monotonic()
    with opener.open(url, timeout=timeout) as r:
        body = r.read()
    ms = round((time.monotonic() - t0) * 1000, 1)
    _LIVE_STATE["calls"] += 1
    if _LIVE_STATE["log"]:
        _LIVE_STATE["log"].write(json.dumps(
            {"ts": datetime.now().isoformat(), "method": method,
             "call": _LIVE_STATE["calls"], "latency_ms": ms,
             "params": {k: v for k, v in params.items()
                        if "VALUES" not in k}}) + "\n")
        _LIVE_STATE["log"].flush()
    time.sleep(0.6)
    return json.loads(body)


def _live_post(method, payload, hook=None, timeout=15):
    hook = hook or _LIVE_STATE["bx"]
    if _LIVE_STATE["calls"] >= _LIVE_STATE["budget"]:
        raise RuntimeError("live-бюджет исчерпан")
    url = f"{hook.rstrip('/')}/{method}.json"
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=timeout) as r:
        body = r.read()
    _LIVE_STATE["calls"] += 1
    if _LIVE_STATE["log"]:
        _LIVE_STATE["log"].write(json.dumps(
            {"ts": datetime.now().isoformat(), "method": method, "post": True,
             "call": _LIVE_STATE["calls"]}) + "\n")
        _LIVE_STATE["log"].flush()
    time.sleep(0.6)
    return json.loads(body)


def suite_live(budget=35):
    sec = _hooks()
    bx = sec.bx_webhook()
    ol = sec.ol_owner_webhook()
    log_path = os.path.join(RESULTS, f"live_calls_{TS}.jsonl")
    _LIVE_STATE.update(budget=budget, bx=bx, ol=ol,
                       log=open(log_path, "w", encoding="utf-8"))
    if not bx:
        skip("D0", "live", "§11", "Live-пробы", "нет прод-вебхука")
        return
    print(f"live-бюджет {budget} вызовов; лог {log_path}", flush=True)

    from core.sources.activities import fact_from_activity
    ex = {17316, 15780}

    def rows_of(resp):
        r = resp.get("result")
        return r if isinstance(r, list) else []

    # --- D1: GC-1 TODO ------------------------------------------------------
    try:
        todo = _live_get("crm.activity.list", {
            "FILTER[PROVIDER_TYPE_ID]": "TODO", "FILTER[RESPONSIBLE_ID]": "11898",
            "FILTER[COMPLETED]": "N", "FILTER[>CREATED]": "01.01.2000 00:00:00",
            "select[]": ["ID", "OWNER_TYPE_ID", "OWNER_ID", "SUBJECT", "AUTHOR_ID",
                         "RESPONSIBLE_ID", "DEADLINE", "COMPLETED"],
            "start": 0})
        tr = rows_of(todo)
        canary = _live_get("crm.activity.list", {
            "FILTER[PROVIDER_TYPE_ID]": "TODO", "FILTER[RESPONSIBLE_ID]": "11898",
            "FILTER[>CREATED]": "01.01.2099 00:00:00", "start": 0})
        cr = rows_of(canary)
        facts = [fact_from_activity(r, exclude_users=ex) for r in tr[:10]]
        authors_ok = all(f and _aid(f["author_id"]) == 11898
                         and f["author_role"] == "WE"
                         for f in facts if f)
        ok = len(tr) > 0 and len(cr) == 0 and authors_ok
        check("D1", "golden", "GC-1", "TODO: не потеряны, автор=ответственный, канарейка пуста",
              "PASS" if ok else "FAIL",
              f"открытых TODO у 11898: {len(tr)} (эталон ~50, живой дрейф); "
              f"канарейка CREATED>2099: {len(cr)} строк; авторство верно: {authors_ok}")
    except Exception as e:
        check("D1", "golden", "GC-1", "TODO: не потеряны", "FAIL", f"ошибка: {e}")

    # --- D2: GC-2/GC-5/GC-7 кластер дублей ---------------------------------
    try:
        c16790 = _live_get("crm.contact.get", {"ID": 16790,
                                               "select[]": ["ID", "PHONE", "IM"]})
        phones = [p.get("VALUE") for p in (c16790.get("result", {}).get("PHONE") or [])
                  if p.get("VALUE")]
        deal = _live_get("crm.deal.get", {"ID": 17016})
        d = deal.get("result", {})
        act_deal = _live_get("crm.activity.list", {
            "FILTER[OWNER_TYPE_ID]": 3, "FILTER[OWNER_ID]": 17016,
            "FILTER[TYPE_ID]": 2, "start": 0})
        dup = None
        if phones:
            digits = re.sub(r"\D", "", phones[0])
            fb = _live_get("crm.duplicate.findbycomm",
                           {"TYPE": "PHONE", "ENTITY_TYPE": "CONTACT",
                            "VALUES[]": digits})
            dup = fb.get("result", {})
        counts = {}
        for owner_type, owner_id in ((1, 9080), (2, 8868), (2, 16790)):
            a = _live_get("crm.activity.list", {
                "FILTER[OWNER_TYPE_ID]": owner_type, "FILTER[OWNER_ID]": owner_id,
                "FILTER[TYPE_ID]": 2, "start": 0})
            counts[f"{owner_type}:{owner_id}"] = int(a.get("total", len(rows_of(a))))
        cluster_total = sum(counts.values())
        contacts = (dup or {}).get("CONTACT", [])
        ok = (d.get("CONTACT_ID") in (16790, "16790")
              and not d.get("ORIGIN_ID")
              and int(act_deal.get("total", 1)) == 0
              and cluster_total >= 15
              and set(map(str, contacts)) >= {"8868", "16790"})
        check("D2", "golden", "GC-2/5/7",
              "Кластер дублей: звонки на дублях видны, сделка «без звонков» не обвиняется",
              "PASS" if ok else "FAIL",
              f"сделка 17016: CONTACT_ID={d.get('CONTACT_ID')}, ORIGIN_ID="
              f"{d.get('ORIGIN_ID')!r}; звонков на сделке={act_deal.get('total')}; "
              f"в кластере (лид 9080/конт 8868/конт 16790)={counts} (итого "
              f"{cluster_total}, эталон 21); findbycomm CONTACT={contacts}; "
              f"телефон запроса {mask_phone(phones[0]) if phones else '—'}")
    except Exception as e:
        check("D2", "golden", "GC-2/5/7", "Кластер дублей", "FAIL", f"ошибка: {e}")

    # --- D3: GC-3 BINDINGS + авторство 16318 -------------------------------
    try:
        act = _live_get("crm.activity.list", {
            "FILTER[OWNER_TYPE_ID]": 3, "FILTER[OWNER_ID]": 16318,
            "select[]": ["ID", "TYPE_ID", "PROVIDER_TYPE_ID", "AUTHOR_ID",
                         "RESPONSIBLE_ID", "SUBJECT", "CREATED", "OWNER_TYPE_ID",
                         "OWNER_ID", "COMPLETED"],
            "start": 0})
        rows = rows_of(act)
        facts = [fact_from_activity(r, exclude_users=ex) for r in rows]
        pairs = [(r, f) for r, f in zip(rows, facts) if f]
        # §8: автор исходящего = RESPONSIBLE_ID строки (AUTHOR_ID=1 — коннектор,
        # никогда не автор); значение 1 у RESPONSIBLE = владелец, легитимно
        bad_auth = [f["source_entity_id"] for r, f in pairs
                    if str(f.get("author_id")) != str(r.get("RESPONSIBLE_ID"))]
        resp_split = {}
        for r in rows:
            k = str(r.get("RESPONSIBLE_ID"))
            resp_split[k] = resp_split.get(k, 0) + 1
        svetlana = resp_split.get("11898", 0)
        gl = None
        try:
            gl = _live_get("imopenlines.crm.chat.getlastid",
                           {"CRM_ENTITY_TYPE": "DEAL", "CRM_ENTITY_ID": 16318})
        except urllib.error.HTTPError as e:
            gl = {"http_error": e.code}
        bind_rows, bind_http = [], None
        try:
            bind = _live_get("crm.activity.list", {
                "FILTER[BINDINGS]": "16318", "start": 0})
            bind_rows = rows_of(bind)
        except urllib.error.HTTPError as e:
            bind_http = e.code
        foreign = [r.get("OWNER_ID") for r in bind_rows
                   if str(r.get("OWNER_ID")) != "16318"]
        import core.filters as FL
        try:
            FL.validate_filter("crm.activity.list", {"BINDINGS": "16318"})
            local_ban = False
        except Exception:
            local_ban = True
        ok = (len(rows) >= 10 and not bad_auth and svetlana >= 10 and local_ban)
        check("D3", "golden", "GC-3",
              "Чужие сообщения: путь по OWNER; авторство RESPONSIBLE; BINDINGS запрещён локально",
              "PASS" if ok else "FAIL",
              f"активностей на сделке 16318: {len(rows)} (эталон 15); "
              f"раскладка RESPONSIBLE: {resp_split} (эталон 09.11 утра: "
              f"14×11898+1×1 — живой дрейф: 2 переписаны на 18918); "
              f"несовпадений «автор≠RESPONSIBLE»: {len(bad_auth)} "
              f"(AUTHOR_ID=1 в авторы не попадает); BINDINGS-проба: HTTP "
              f"{bind_http or 200}, строк {len(bind_rows)}, из них чужих "
              f"OWNER {len(foreign)} (сервер фильтр игнорирует); локально "
              f"BINDINGS отклонён до сети: {local_ban}; getlastid 16318: "
              f"{gl.get('error', gl.get('http_error')) if isinstance(gl, dict) else gl}")
    except Exception as e:
        check("D3", "golden", "GC-3", "Чужие сообщения/BINDINGS", "FAIL", f"ошибка: {e}")

    # --- D4: GC-4 неоднозначный клиент -------------------------------------
    try:
        cand = _live_get("crm.contact.list", {
            "FILTER[NAME]": "Михаил", "select[]": ["ID", "NAME", "LAST_NAME"],
            "start": 0})
        n = int(cand.get("total", len(rows_of(cand))))
        from core.collect import run_request
        r = run_request(json.dumps({"intent": "client_dossier", "request_id": "acc-d4",
                                    "entity": {"type": "contact", "id": 16790}}),
                        cfg=_mkcfg(offline=True), transport=None, use_cache=False)
        no_name_path = True   # имя не является ключом запроса §3 → SCHEMA (C3)
        ok = n >= 10 and no_name_path
        check("D4", "golden", "GC-4",
              "Идентификационный гейт: имя даёт кандидатов, досье — только по ID",
              "PASS" if ok else "FAIL",
              f"контактов «Михаил»: {n} (эталон 09.11 утра ~54 — живой дрейф "
              f"вверх, неоднозначность только усилилась); автоп вир: нет — имя не "
              f"является ключом запроса (§3), unknown key → SCHEMA; досье по ID "
              f"возвращает core-стаб: {r.get('status')}/"
              f"{(r.get('errors') or [{}])[0].get('code')}")
    except Exception as e:
        check("D4", "golden", "GC-4", "Идентификационный гейт", "FAIL", f"ошибка: {e}")

    # --- D5: GC-8 owner-dangle ----------------------------------------------
    try:
        a = _live_get("crm.activity.get", {"ID": 1001974})
        row = a.get("result", {})
        contact = None
        try:
            contact = _live_get("crm.contact.get", {"ID": 17016})
        except urllib.error.HTTPError as e:
            contact = {"http_error": e.code}
        deal = _live_get("crm.deal.get", {"ID": 17016})
        is_dangle = (int(row.get("OWNER_TYPE_ID") or 0) == 2
                     and str(row.get("OWNER_ID")) == "17016"
                     and isinstance(contact, dict) and contact.get("http_error")
                     and deal.get("result", {}).get("ID"))
        # знание дефекта: core НЕ проверяет существование owner при эмите факта
        src = open(os.path.join(V3LITE, "core", "sources", "activities.py"),
                   encoding="utf-8").read()
        has_dangle_check = "dangle" in src or "не найден" in src
        check("D5", "golden", "GC-8",
              "Owner-dangle: эталон воспроизведён; поведение v3",
              "FAIL" if (is_dangle and not has_dangle_check) else
              ("PASS" if not is_dangle else "PASS"),
              f"activity 1001974 → OWNER contact 17016; контакт 17016: "
              f"{'НЕ существует (HTTP ' + str(contact.get('http_error')) + ')' if isinstance(contact, dict) and contact.get('http_error') else 'существует'}; "
              f"сделка 17016 существует; в core проверки owner-dangle: "
              f"{has_dangle_check} → {'ДЕФЕКТ: факт эмитится без проверки и без warning' if not has_dangle_check else 'реализовано'}")
    except Exception as e:
        check("D5", "golden", "GC-8", "Owner-dangle", "FAIL", f"ошибка: {e}")

    # --- D6: GC-9 дедлайн без выдуманных переносов --------------------------
    try:
        a = _live_get("crm.activity.list", {
            "FILTER[ID]": 726596,
            "select[]": ["ID", "SUBJECT", "DEADLINE", "COMPLETED",
                         "PROVIDER_TYPE_ID"], "start": 0})
        rows = rows_of(a)
        dl = rows[0].get("DEADLINE") if rows else None
        src = open(os.path.join(V3LITE, "core", "sources", "activities.py"),
                   encoding="utf-8").read()
        no_invention = "перенос" not in src
        ok = bool(rows) and bool(dl) and no_invention
        check("D6", "golden", "GC-9",
              "Дедлайн: только текущее значение, переносов «из воздуха» нет",
              "PASS" if ok else "FAIL",
              f"activity 726596 DEADLINE={dl}; утверждений о числе переносов в "
              f"коде: {not no_invention}")
    except Exception as e:
        check("D6", "golden", "GC-9", "Дедлайн", "FAIL", f"ошибка: {e}")

    # --- D7: GC-10/GC-3 Авито-чат/отправка из карточки ----------------------
    try:
        gl = None
        try:
            gl = _live_get("imopenlines.crm.chat.getlastid",
                           {"CRM_ENTITY_TYPE": "LEAD", "CRM_ENTITY_ID": 20232})
        except urllib.error.HTTPError as e:
            gl = {"http_error": e.code, "body": e.read()[:200].decode("utf-8", "i")}
        card = _live_get("crm.activity.list", {
            "FILTER[PROVIDER_ID]": "CONFIGURABLE_REST_APP",
            "select[]": ["ID", "SUBJECT", "RESPONSIBLE_ID", "AUTHOR_ID", "CREATED"],
            "start": 0})
        card_rows = rows_of(card)
        merged = _load_result(os.path.join(
            STAGING, "results",
            "integrated_2026-11-09_a555c503-122a-4218-b990-4db5431220e0.json"))["merged"]
        cls = merged.get("coverage", {}).get("classification", {})
        idx_msg = cls.get("message", 0)
        texts = (merged.get("coverage", {}).get("msg.facts") or {}).get("total", 0)
        gl_fail = "CRM_CHAT_EMPTY_CRM_DATA" in json.dumps(gl)
        warns = " ".join(merged.get("warnings", []))
        per_chat = "чат не разреш" in warns
        # GC-3/GC-10: индекс есть, но тексты добраны не для всех; поимённого
        # warning на конкретный неразрешённый чат нет — молчаливый пробел текста
        gap = max(idx_msg - texts, 0)
        ok_index = gl_fail and len(card_rows) > 0 and idx_msg > 0
        status = "PASS" if (ok_index and gap == 0) else "FAIL"
        check("D7", "golden", "GC-3/10",
              "Авито/карточка: индекс сообщений есть; тексты и warnings за ними",
              status,
              f"getlastid LEAD 20232 → {json.dumps(gl)[:100]}; карточечных "
              f"исходящих (CONFIGURABLE_REST_APP) в ленте: {len(card_rows)}; "
              f"live manager_day: индекс-сообщений {idx_msg}, текстов добыто "
              f"{texts} → {gap} без текста; поимённый warning «чат не "
              f"разрешён»: {per_chat} → ДЕФЕКТ: сообщения без текста не "
              f"именованы (часть из них — Авито fallback/MAX, текстов нет и "
              f"не будет без второго источника, но в ответе нет ни поимённого "
              f"списка, ни счётчика «без текста»)")
    except Exception as e:
        check("D7", "golden", "GC-3/10", "Авито-чат/карточка", "FAIL", f"ошибка: {e}")

    # --- D8: GC-6 Transfer.list per-session ---------------------------------
    try:
        try:
            tl = _live_get("imopenlines.v2.Session.Transfer.list", {"start": 0})
            tl_result = "нет ошибки (неожиданно)"
        except urllib.error.HTTPError as e:
            tl_result = f"HTTP {e.code} (параметр sessionId обязателен)"
        merged = _load_result(os.path.join(
            STAGING, "results",
            "integrated_2026-11-09_a555c503-122a-4218-b990-4db5431220e0.json"))["merged"]
        tcov = merged.get("coverage", {}).get("msg.transfers", {})
        t_errors = tcov.get("errors", [])
        t_facts = sum(1 for f in merged.get("facts", [])
                      if f.get("fact_type") == "transfer")
        ok = ("400" in str(tl_result)) and t_facts == 0
        check("D8", "golden", "GC-6",
              "Передачи: API per-session; чанковый вызов модуля падает (400)",
              "FAIL" if ok else "PASS",
              f"без sessionId → {tl_result}; live manager_day: transfer-фактов "
              f"{t_facts}, ошибок Transfer.list {len(t_errors)} "
              f"(пример: {json.dumps(t_errors[:1])[:150]}) → ДЕФЕКТ: передачи не "
              f"собираются, HTTP 400 ошибочно тарифицируется как SOURCE_5XX"
              if ok else f"tl={tl_result}; facts={t_facts}")
    except Exception as e:
        check("D8", "golden", "GC-6", "Передачи", "FAIL", f"ошибка: {e}")

    # --- D9: контроль 40 чатов / 317 сообщений (07.11) ----------------------
    try:
        meas = _load_result(os.path.join(
            MESSAGES, "out", "measure_20261107_20261108.json"))
        d7 = next(d for d in meas["days"] if d["day"] == "2026-11-07")
        d8 = next(d for d in meas["days"] if d["day"] == "2026-11-08")
        t7, t8 = d7.get("day_totals", {}), d8.get("day_totals", {})
        ceiling = d7["scan"].get("ceiling_hit")
        # свежесть: Stat.get по 2 сессиям vs history.get
        sids = [25396, 26550]
        st = _live_post("imopenlines.v2.Session.Stat.get", {"sessionId": sids}, ol)
        sess_rows = (st.get("result") or {}).get("sessions", [])
        hist_counts = {}
        for sid in sids:
            h = _live_get("imopenlines.session.history.get", {"SESSION_ID": sid})
            msgs = (h.get("result") or {}).get("message", {})
            hist_counts[sid] = len(msgs)
        stat_map = {r.get("sessionId"): r.get("messagesCount") for r in sess_rows}
        mismatch = {sid: (hist_counts.get(sid), stat_map.get(sid)) for sid in sids
                    if hist_counts.get(sid) != stat_map.get(sid)}
        golden_ok = t7.get("chats") == 40 and t7.get("messages") == 317
        check("D9", "golden", "§5, §9.5-1",
              "Контроль 07.11: 40 чатов / 317 сообщений; свежесть проб живая",
              "PASS" if golden_ok else "FAIL",
              f"07.11: chats={t7.get('chats')}, messages={t7.get('messages')} "
              f"(эталон 40/317, живой дрейф возможен); 08.11: "
              f"{t8.get('chats')}/{t8.get('messages')}; scan ceiling_hit="
              f"{ceiling}; свежесть (history vs Stat.get): {mismatch or 'совпадают'}",
              os.path.join(MESSAGES, "out", "measure_20261107_20261108.json"))
    except Exception as e:
        check("D9", "golden", "§9.5-1", "Контроль 40/317", "FAIL", f"ошибка: {e}")

    # --- D10: тип-баг скоупа user.current -----------------------------------
    try:
        cur = _live_get("user.current", {}, ol)
        uid = (cur.get("result") or {}).get("ID")
        type_bug = isinstance(uid, str) and uid.isdigit()
        merged = _load_result(os.path.join(
            STAGING, "results",
            "integrated_2026-11-09_a555c503-122a-4218-b990-4db5431220e0.json"))["merged"]
        scope = merged.get("coverage", {}).get("msg.webhook_scope", {})
        warned = "webhook_scope" in " ".join(merged.get("warnings", []))
        ok = not (type_bug and warned and str(uid) == "1")
        check("D10", "golden", "§9.5-6",
              "Скоуп ОЛ-вебхука: сравнение типов user_id",
              "PASS" if not warned or not type_bug else "FAIL",
              f"user.current ID={uid!r} (тип {type(uid).__name__}); в live-прогоне "
              f"full_listing_expected={scope.get('full_listing_expected')} при "
              f"владельце=1 → скоуп-варнинг {'есть' if warned else 'нет'}: "
              + ("ДЕФЕКТ: '1'≠1 (строка vs int) → ложный скоуп-варнинг" if ok is False and type_bug and warned
                 else ("воспроизведён тип-баг '1'!=1, см. C12" if type_bug and warned
                       else "ок")))
    except Exception as e:
        check("D10", "golden", "§9.5-6", "Скоуп ОЛ-вебхука", "FAIL", f"ошибка: {e}")

    _LIVE_STATE["log"].close()
    # честность бюджета: пишем счётчик в staging runs.jsonl
    try:
        with open(os.path.join(STAGING, "logs", "runs.jsonl"), "a",
                  encoding="utf-8") as fh:
            fh.write(json.dumps({
                "ts": datetime.now().isoformat(), "runner": "acceptance_admin2",
                "mode": "live", "intent": "golden_probes",
                "http_calls": _LIVE_STATE["calls"]}) + "\n")
    except OSError:
        pass
    print(f"live-вызовов сделано: {_LIVE_STATE['calls']}/{budget}", flush=True)


# ============================================================ SOURCES-набор
# Обновлено 09.11 ~21:40 (мост mw9kv1iszlu4) под состояние ПОСЛЕ фиксов:
# авито-адаптер поставлен (exact-ID), core 0.3.0 с client_dossier,
# history.get LIMIT-схема с эскалациями, потолок offset — честная метка.
def suite_sources():
    art_mgr = os.path.join(STAGING, "results",
                           "integrated_2026-11-09_e2e2-mock-mday.json")
    merged = _load_result(art_mgr)["merged"] if os.path.exists(art_mgr) else {}
    live_verify = os.path.join(MESSAGES, "out", "live_verify_20261109.json")
    lv = _load_result(live_verify) if os.path.exists(live_verify) else {}

    # --- F1: Авито — второй источник реализован и подключён (§5, §11.5) ----
    problems = []
    adapter_dir = os.path.join(V3LITE, "avito_adapter")
    joiner = os.path.join(adapter_dir, "adapter", "joiner.py")
    proto = os.path.join(adapter_dir, "MAPPING_PROTOCOL.md")
    if not (os.path.exists(joiner) and os.path.exists(proto)):
        problems.append("нет адаптера или протокола привязки")
    avito_facts = sum(1 for f in merged.get("facts", [])
                      if "avito" in str(f.get("source", "")))
    if not avito_facts and merged:
        problems.append("в интеграционном прогоне нет авито-фактов")
    avito_live_acc = os.path.join(adapter_dir, "out",
                                  "acceptance_avito_live_20261109-135151.json")
    acc = _load_result(avito_live_acc) if os.path.exists(avito_live_acc) else {}
    check("F1", "sources", "§5, §11.5",
          "Авито: второй источник реализован (avito_adapter, exact-IDs-only)",
          "PASS" if not problems else "FAIL",
          "; ".join(problems) or
          f"адаптер v3 поставлен: joiner exact-IDs-only (fuzzy физически удалён — "
          f"см. E5/E6), MAPPING_PROTOCOL.md действует, живая приёмка 13:51 "
          f"verdict={acc.get('verdict', '?')} (read-only, контаминация 0); в "
          f"интеграции E2E#2 авито-факты в manager_day ({avito_facts} шт.) и "
          f"client_dossier честно UNLINKED/LINKED по доказательству. Ограничение: "
          f"мульти-аккаунт живьём не проверялся (один аккаунт) — перед включением "
          f"каждого нового аккаунта живая приёмка §11.9 обязательна",
          {"adapter": "avito_adapter/adapter/joiner.py",
           "live_acceptance": "acceptance_avito_live_20261109-135151.json"})

    # --- F3: client_dossier — CRM-часть core 0.3.0 работает ------------------
    r = None
    for f in sorted(os.listdir(os.path.join(STAGING, "results")), reverse=True):
        if f.startswith("integrated_2026-11-09_e2e2-mock-dossier"):
            cand = _load_result(os.path.join(STAGING, "results", f))
            if cand.get("request", {}).get("intent") == "client_dossier":
                r = cand
                break
    live_dos = os.path.join(STAGING, "results", "live_dossier_16790_v2.json")
    if os.path.exists(live_dos):
        _ld = _load_result(live_dos)
        ld = _ld.get("merged", _ld)
    else:
        ld = {}
    crm_srcs = sorted({str(f.get("source")) for f in ld.get("facts", [])
                       if str(f.get("source", "")).startswith("crm.")})
    problems = []
    if not r or not r.get("merged", {}).get("facts"):
        problems.append("нет mock-артефакта досье с фактами")
    if not crm_srcs:
        problems.append("живое досье без CRM-фактов — core-часть не работает")
    check("F3", "sources", "SCHEMA_RECONCILIATION п.3",
          "client_dossier: CRM-часть в core 0.3.0 реализована (GC-2/4/5/8/9/10)",
          "PASS" if not problems else "FAIL",
          "; ".join(problems) or
          f"core 0.3.0 (sources/dossier.py): живое досье contact:16790 — "
          f"{len(ld.get('facts', []))} фактов из {crm_srcs}, идентификационный "
          f"гейт GC-4/5 честно не поглощает дубли (кластер 2 контактов, "
          f"contact:8868 перечислен как вероятный дубль); mock-батарея E2E#2 — "
          f"досье deal 301/5 с CRM-фактами. Прежний NOT_IMPLEMENTED снят "
          f"(фикс 12:30, ядро 0.3.0)",
          {"live": "live_dossier_16790_v2.json",
           "mock": "integrated_2026-11-09_e2e2-mock-dossier5.json"})

    # --- F4: потолок offset ОЛ — честная метка и оценка хвоста ---------------
    cov = lv.get("coverage", {}).get("sessions_scan", {}) if lv else {}
    ids = cov.get("ids", {}) if isinstance(cov, dict) else {}
    ok = (cov.get("stop_reason") == "ceiling" and cov.get("truncated")
          and lv.get("status") == "PARTIAL")
    check("F4", "sources", "§6, §4 (честность)",
          "Потолок offset ~10 200: честный PARTIAL + оценка хвоста (фикс F4/D10)",
          "PASS" if ok else ("FAIL" if cov else "SKIP"),
          f"live 09.11 (фикс F4): rows_scanned={cov.get('rows_scanned')}, "
          f"stop_reason={cov.get('stop_reason')}, truncated={cov.get('truncated')}, "
          f"status={lv.get('status')}; потолок НЕ провоцирует 400, хвост оценён по "
          f"плотности id (span={ids.get('span')}, seen={ids.get('seen')}, "
          f"missing={ids.get('missing')}) — недостижимое названо недостижимым, "
          f"потерь данных нет, VERIFIED не притворяется. Полный день листингом "
          f"физически недостижим (~18+ мес истории) — принципиальное ограничение "
          f"портала, а не дефект кода",
          {"artifact": "messages/out/live_verify_20261109.json"})

    # --- F5: пагинация history.get — LIMIT-схема с эскалациями ---------------
    h = lv.get("coverage", {}).get("history", {}) if lv else {}
    uf = h.get("underfetch_cap", {}) or {}
    cm = h.get("count_mismatch", {}) or {}
    ok = (h.get("history_errors") == 0 and uf.get("sessions") == 0
          and h.get("duplicate_global") == 0)
    check("F5", "sources", "§5 ловушка длинных чатов",
          "history.get: недобор устранён (LIMIT+эскалации; было 45/595)",
          "PASS" if ok else ("FAIL" if h else "SKIP"),
          f"live 09.11 (фикс F5): сессий {h.get('sessions')}, ошибок "
          f"{h.get('history_errors')}, сообщений {h.get('messages_total')} "
          f"(= эталон 317 контрольного дня), underfetch {uf.get('sessions')}/"
          f"{uf.get('messages_missing_total')} (было 45 сессий), дублей "
          f"{h.get('duplicate_global')}; count_mismatch {cm.get('sessions')} — "
          f"расхождение СЧЁТЧИКОВ портала (27/29, 10/11), не потеря сообщений: "
          f"названо поимённо, не молча",
          {"artifact": "messages/out/live_verify_20261109.json"})

    # --- F6: Wappi ------------------------------------------------------------
    check("F6", "sources", "§5",
          "Wappi (WhatsApp): ключей нет — вне источников v3", "PASS",
          "по спеке §5 не источник до появления ключей; whatsapp=false в narrator "
          "честно; потерь активности не добавляет (канал и так не виден)")

    # --- F7: voximpl/calls.db -------------------------------------------------
    art_calls = os.path.join(STAGING, "results",
                             "integrated_2026-11-09_9ec54c9f-873c-4cf5-b1ca-1b5149aec7e2.json")
    if os.path.exists(art_calls):
        m = _load_result(art_calls)["merged"]
        vox = sum(1 for f in m.get("facts", [])
                  if str(f.get("source", "")).startswith("voximpl"))
        check("F7", "sources", "§5",
              "Телефония: calls.db RO работает (звонки дня собираются)",
              "PASS" if vox else "FAIL",
              f"calls_day live 07.11: фактов {len(m.get('facts', []))} "
              f"(voximpl-первичных {vox}), статус {m.get('status')}; кросс-чек "
              f"activity TYPE_ID=2 в coverage ответа")
    else:
        skip("F7", "sources", "§5", "Телефония calls.db", "нет артефакта")


# ============================================================ V12 — Release Gate
# Спека v1.2 (§5.1, §7.7, §8, §9.7, §11.7–11.9): запрет fuzzy-склейки,
# честная атрибуция, VERIFIED-cap, негативные фикстуры A2–D2, интеграционные
# артефакты E2E#2 (мост mw9kv0d13rbz), ночная live-батарея (E9).
FIXDIR_V12 = os.path.join(QA, "fixtures_v12_20261109")


def _load_v12(name: str) -> dict:
    with open(os.path.join(FIXDIR_V12, name), encoding="utf-8") as fh:
        return json.load(fh)


def _join_fixture(ds: dict):
    """Прогон join_exact по фикстуре (chat_messages ключи → int)."""
    import msg.join as MJ
    return MJ.join_exact(
        dialog_rows=ds["dialog_rows"],
        chat_messages={int(k): v for k, v in ds["chat_messages"].items()},
        avito_chats=ds["avito_chats"],
        verified_index={k: v for k, v in ds["verified_index"].items()
                        if v is not None},
        users=MJ.normalize_users(ds.get("users_rows") or []),
        exclude_users=set())


def _by_ref(res) -> dict:
    return {m.ref: m for m in res.messages}


def _statuses(res) -> dict:
    return {m.ref: (m.join_status, m.reason) for m in res.messages}


def _erase_content(obj):
    """Затереть ВСЕ тексты и сдвинуть все времена (доказательство нечтения)."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if k == "text":
                out[k] = "░ЗАТЁРТО░"
            elif k == "created" and isinstance(v, (int, float)):
                out[k] = v + 777777
            elif k == "date" and isinstance(v, str):
                out[k] = "2000-01-01T00:00:00+03:00"
            else:
                out[k] = _erase_content(v)
        return out
    if isinstance(obj, list):
        return [_erase_content(x) for x in obj]
    return obj


def suite_v12():
    import msg.join as MJ
    from msg.errors import SecurityError as MsgSecurityError

    AVITO_DIR = os.path.join(V3LITE, "avito_adapter")
    if AVITO_DIR not in sys.path:
        sys.path.insert(0, AVITO_DIR)
    import adapter.joiner as AJ

    # --- E1: §9.7-A2 — fuzzy-ловушка «два клиента, близкий текст, ±10 мин»
    try:
        ds = _load_v12("dataset_neg_A2_two_clients.json")
        res = _join_fixture(ds)
        st = _statuses(res)
        m = _by_ref(res)
        problems = []
        want_link = {"chat101#msg9001": "avito:501:u2iAAA#msg:avmsg-1"}
        for ref, pair in want_link.items():
            if st.get(ref, ("?",))[0] != "LINKED" or m[ref].pair_ref != pair:
                problems.append(f"{ref}: {st.get(ref)} pair={m[ref].pair_ref}")
        for ref in ds["expect"]["unlinked"]:
            if st.get(ref, ("?",))[0] != "UNLINKED":
                problems.append(f"{ref}: {st.get(ref)} (ожидался UNLINKED)")
        # кросс-контаминация: avmsg-2 (клиент B) обязан остаться в чате 202/LEAD 4100
        b = m.get("avito:502:u2iBBB#msg:avmsg-2")
        if not b or b.chat_id != 202 or ("LEAD", 4100) not in b.crm:
            problems.append(f"avmsg-2 контаминирован: chat={b and b.chat_id} crm={b and b.crm}")
        if res.counts["linked"] != 2 or res.counts["ambiguous"] != 0:
            problems.append(f"counts={res.counts}")
        # инвариантность: затереть все тексты + сдвинуть все времена — статусы те же
        res2 = _join_fixture(_erase_content(ds))
        if _statuses(res2) != st:
            problems.append("затирание текстов/сдвиг времён ИЗМЕНИЛ результат — движок читает контент!")
        check("E1", "v12", "§9.7-A2, §5.1",
              "Негатив A2: два клиента, близкие тексты, ±10 мин — fuzzy-ловушка",
              "PASS" if not problems else "FAIL",
              "; ".join(problems) or
              f"единственная сшивка exact CONNECTOR_MID ({want_link}); avmsg-2 (клиент B, "
              f"идентичный текст, Δt=7 мин) остался UNLINKED в чате 202/LEAD 4100; "
              f"затирание текстов и сдвиг времён результат не меняют; "
              f"counts={res.counts}",
              {"fixture": "dataset_neg_A2_two_clients.json",
               "counts": res.counts, "recommended_status": res.recommended_status})
    except Exception as e:
        check("E1", "v12", "§9.7-A2, §5.1",
              "Негатив A2: два клиента, близкие тексты, ±10 мин — fuzzy-ловушка",
              "FAIL", f"ошибка: {e}")

    # --- E2: §9.7-B2 — авито-исходящие без доказанной атрибуции
    try:
        ds = _load_v12("dataset_neg_B2_unattributed.json")
        res = _join_fixture(ds)
        st = _statuses(res)
        m = _by_ref(res)
        problems = []
        if st.get("chat111#msg9100", ("?",))[0] != "LINKED":
            problems.append(f"9100 не LINKED: {st.get('chat111#msg9100')}")
        for ref in ds["expect"]["avito_only"]:
            if st.get(ref, ("?",))[0] != "UNLINKED":
                problems.append(f"{ref}: {st.get(ref)} (ожидался UNLINKED)")
        if any(msg.employee_id is not None for msg in res.messages
               if msg.origin == "avito"):
            problems.append("авито-факт получил employee_id — нарушение директивы")
        if res.employee_counts() != {10: 1}:
            problems.append(f"employee_counts={res.employee_counts()} ≠ {{10: 1}}: "
                            "числовое совпадение senderId засчитано как атрибуция?")
        wcodes = " ".join(str(w.get("code", w) if isinstance(w, dict) else w)
                          for w in res.warnings)
        for code in ("senderid_numeric_overlap", "author_outside_account"):
            if code not in wcodes:
                problems.append(f"нет канарейки {code}")
        check("E2", "v12", "§9.7-B2, §5.1",
              "Негатив B2: исходящие без автора — UNKNOWN, совпадение senderId ≠ атрибуция",
              "PASS" if not problems else "FAIL",
              "; ".join(problems) or
              f"avout-2 (author_id 10 == id сотрудника Б24) и avout-3 (автор 999) — "
              f"UNLINKED без атрибуции; канарейки warning на месте; "
              f"employee_counts={res.employee_counts()} (только b24.author_id); "
              f"статус движка {res.recommended_status} (честный PARTIAL от канарек)",
              {"fixture": "dataset_neg_B2_unattributed.json",
               "employee_counts": {str(k): v for k, v in res.employee_counts().items()}})
    except Exception as e:
        check("E2", "v12", "§9.7-B2, §5.1",
              "Негатив B2: исходящие без автора — UNKNOWN, совпадение senderId ≠ атрибуция",
              "FAIL", f"ошибка: {e}")

    # --- E3: §9.7-C2 — коллизии карты и неверифицированный аккаунт
    try:
        ds = _load_v12("dataset_neg_C2_collisions.json")
        res = _join_fixture(ds)
        st = _statuses(res)
        m = _by_ref(res)
        problems = []
        for ref in ds["expect"]["ambiguous"]:
            if st.get(ref, ("?",))[0] != "AMBIGUOUS":
                problems.append(f"{ref}: {st.get(ref)} (ожидался AMBIGUOUS)")
        for ref in ds["expect"]["unverified_unlinked"]:
            if st.get(ref, ("?",))[:2] != ("UNLINKED", "chat_account_unverified"):
                problems.append(f"{ref}: {st.get(ref)} (ожидался UNLINKED/chat_account_unverified)")
        for ref in ds["expect"]["crm_ambiguous_both"]:
            if m.get(ref) and m[ref].crm_status != "AMBIGUOUS":
                problems.append(f"{ref}: crm_status={m[ref].crm_status} ≠ AMBIGUOUS")
        if res.counts["linked"] != 0:
            problems.append(f"есть LINKED при коллизиях: {res.counts}")
        wtxt = json.dumps(res.warnings, ensure_ascii=False)
        for code in ("chat_binding_collision", "duplicate_lead_crm"):
            if code not in wtxt:
                problems.append(f"нет warning {code}")
        check("E3", "v12", "§9.7-C2, §5.1",
              "Негатив C2: коллизия u2i/CRM и неверифицированный аккаунт — склейки нет",
              "PASS" if not problems else "FAIL",
              "; ".join(problems) or
              f"u2iDUP у чатов 301+302 → AMBIGUOUS даже при точном mid; LEAD 555 у чатов "
              f"401+402 → crm AMBIGUOUS у обоих (досье исключено обоим кандидатам); "
              f"u2iNV без verified_index → UNLINKED fail-closed; linked=0",
              {"fixture": "dataset_neg_C2_collisions.json", "counts": res.counts})
    except Exception as e:
        check("E3", "v12", "§9.7-C2, §5.1",
              "Негатив C2: коллизия u2i/CRM и неверифицированный аккаунт — склейки нет",
              "FAIL", f"ошибка: {e}")

    # --- E4: §9.7-D2 / GC-8 — dangling owner без перепривязки
    try:
        ds = _load_v12("dataset_neg_D2_dangling_owner.json")
        from core.sources.owners import verify_fact_owners

        class _FakeClient:
            def __init__(self, answers):
                self.answers, self.calls = answers, []

            def batch(self, cmds, label=None):
                self.calls.append((label, cmds))
                return [self.answers.get(f"{meth}:{p.get('ID')}",
                                         {"ID": p.get("ID")}) for meth, p in cmds]

        facts = copy.deepcopy(ds["facts"])
        warnings: list = []
        cov: dict = {}
        cnt = verify_fact_owners(_FakeClient(ds["batch_answers"]), facts,
                                 warnings=warnings, coverage=cov)
        problems = []
        if cnt != {"checked": 3, "dangling": 1}:
            problems.append(f"счётчик {cnt} ≠ checked=3 dangling=1")
        dang = [f for f in facts if f["payload"].get("owner_status") == "dangling"]
        if len(dang) != 1 or dang[0]["source_entity_id"] != "activity:1001974":
            problems.append(f"dangling не на 1001974: {[f['source_entity_id'] for f in dang]}")
        if dang and dang[0]["crm_entity"] != {"type": "contact", "id": 17016}:
            problems.append("факт 1001974 перепривязан — нарушение GC-8 (числовое совпадение)")
        if cov.get("owner_check", {}).get("dangling_refs") != ["contact:17016"]:
            problems.append(f"coverage={cov.get('owner_check')}")
        wtxt = " ".join(warnings)
        for token in ds["expect"]["warning_contains"]:
            if token not in wtxt:
                problems.append(f"warning не содержит «{token}»")
        check("E4", "v12", "§9.7-D2, §8, GC-8",
              "Негатив D2: dangling owner — факт сохранён, PARTIAL, перепривязки нет",
              "PASS" if not problems else "FAIL",
              "; ".join(problems) or
              f"contact:17016 не найден → dangling=1, факт 1001974 сохранён и остался на "
              f"contact:17016 (НЕ перепривязан к существующей сделке 17016); deal:17016 и "
              f"deal:9338 проверены и живы; warning поимённый (GC-8, PARTIAL)",
              {"fixture": "dataset_neg_D2_dangling_owner.json",
               "coverage": cov.get("owner_check"), "counter": cnt})
    except Exception as e:
        check("E4", "v12", "§9.7-D2, §8, GC-8",
              "Негатив D2: dangling owner — факт сохранён, PARTIAL, перепривязки нет",
              "FAIL", f"ошибка: {e}")

    # --- E5: API-гвард эвристик — опции нельзя даже передать
    try:
        problems = []
        try:
            MJ.join_exact(dialog_rows=[], chat_messages={}, avito_chats=[],
                          verified_index={}, options={"window_minutes": 10})
            problems.append("msg.join принял window_minutes без SecurityError")
        except MsgSecurityError:
            pass
        try:
            MJ.employee_from_avito(10)
            problems.append("employee_from_avito(10) не отказал")
        except MsgSecurityError:
            pass
        if MJ.ALLOWED_JOIN_OPTIONS:
            problems.append("у msg exact-join есть разрешённые опции")
        # адаптер: fuzzy-опция → SchemaError (offline, stdin→stdout)
        env = {k: v for k, v in os.environ.items() if k != "AVITO_ADAPTER_LIVE"}
        env["AVITO_ADAPTER_INDEX_DB"] = os.path.join(RESULTS, f"_tmp_idx_e5_{TS}.db")
        req = {"intent": "avito_merge", "request_id": "e5-fuzzy-trap",
               "options": {"text_similarity": 0.8}}
        pr = subprocess.run([PY, "run.py"], cwd=AVITO_DIR, env=env,
                            input=json.dumps(req), capture_output=True,
                            text=True, timeout=60)
        out = json.loads(pr.stdout or "{}")
        det = json.dumps(out.get("errors", []), ensure_ascii=False)
        if "ЗАПРЕЩЕНА" not in det or out.get("status") != "FAILED":
            problems.append(f"адаптер не отклонил fuzzy-опцию: {det[:200]}")
        if os.path.exists(env["AVITO_ADAPTER_INDEX_DB"]):
            os.remove(env["AVITO_ADAPTER_INDEX_DB"])
        check("E5", "v12", "§5.1, §3 (запрет опций)",
              "Эвристики сшивки отклоняются на уровне API обоих движков",
              "PASS" if not problems else "FAIL",
              "; ".join(problems) or
              "msg.join: window_minutes → SecurityError; employee_from_avito всегда отказ; "
              "ALLOWED_JOIN_OPTIONS пуст; адаптер: text_similarity → SchemaError "
              "«ЗАПРЕЩЕНА директивой 09.11» (offline, сети нет)")
    except Exception as e:
        check("E5", "v12", "§5.1, §3 (запрет опций)",
              "Эвристики сшивки отклоняются на уровне API обоих движков",
              "FAIL", f"ошибка: {e}")

    # --- E6: физическое отсутствие fuzzy-движка в коде
    try:
        problems = []
        if hasattr(AJ, "_pair_candidates"):
            problems.append("у joiner есть _pair_candidates (fuzzy-движок не удалён)")
        if not AJ.FORBIDDEN_JOIN_OPTIONS:
            problems.append("у joiner пуст FORBIDDEN_JOIN_OPTIONS")
        bad_tokens = ("difflib", "SequenceMatcher", "Levenshtein", "theils")
        for path in (os.path.join(MESSAGES, "msg", "join.py"),
                     os.path.join(AVITO_DIR, "adapter", "joiner.py")):
            src = open(path, encoding="utf-8").read()
            for tok in bad_tokens:
                if tok in src:
                    problems.append(f"{os.path.basename(path)}: найден {tok}")
            for mth in re.findall(r"def (\w*fuzzy\w*|\w*pair_candidat\w*)", src):
                problems.append(f"{os.path.basename(path)}: def {mth}()")
        check("E6", "v12", "§5.1, §7.7 join_guard",
              "Fuzzy-движок физически отсутствует в обоих join-модулях",
              "PASS" if not problems else "FAIL",
              "; ".join(problems) or
              "joiner без _pair_candidates; в msg/join.py и adapter/joiner.py нет "
              "difflib/SequenceMatcher/Levenshtein и fuzzy-функций; "
              "запрещённые опции — только блэклист-константы",
              {"modules": ["messages/msg/join.py", "avito_adapter/adapter/joiner.py"]})
    except Exception as e:
        check("E6", "v12", "§5.1, §7.7 join_guard",
              "Fuzzy-движок физически отсутствует в обоих join-модулях",
              "FAIL", f"ошибка: {e}")

    # --- E7: VERIFIED-cap — UNLINKED/AMBIGUOUS факты запрещают VERIFIED
    try:
        env = {k: v for k, v in os.environ.items() if k != "AVITO_ADAPTER_LIVE"}
        b24 = {"chats": {"111": {
            "users": [{"id": 77, "external_auth_id": "imconnector"}],
            "dialog": {"id": 111, "entity_id": "avito|2|u2iOUT|77"},
            "messages": [{"id": "9100", "author_id": 77,
                          "date": "2026-11-07T11:00:00+03:00",
                          "text": "вопрос клиента",
                          "params": {"CONNECTOR_MID": "avq-1"}}]}}}
        avito = {"u2iOUT": [{"id": "avq-1", "author_id": 90001,
                             "direction": "in", "created": 1762604400,
                             "content": {"text": "вопрос клиента"}}]}
        base = {"intent": "avito_merge", "request_id": "e7-cap",
                "account_user_id": 501, "b24": b24, "avito": avito,
                "mapping": {"111": "u2iOUT"}}

        def _run(req):
            e = dict(env)
            e["AVITO_ADAPTER_INDEX_DB"] = os.path.join(
                RESULTS, f"_tmp_idx_e7_{next(_run._n)}.{TS}.db")
            p = subprocess.run([PY, "run.py"], cwd=AVITO_DIR, env=e,
                               input=json.dumps(req), capture_output=True,
                               text=True, timeout=60)
            o = json.loads(p.stdout or "{}")
            if os.path.exists(e["AVITO_ADAPTER_INDEX_DB"]):
                os.remove(e["AVITO_ADAPTER_INDEX_DB"])
            return o
        _run._n = iter(range(100))

        clean = _run(base)
        problems = []
        if clean.get("status") != "VERIFIED":
            problems.append(f"чистый exact-мерж не VERIFIED: {clean.get('status')} "
                            f"{clean.get('warnings', [])[:2]}")
        kinds = {f.get("evidence", {}).get("join", {}).get("kind")
                 for f in clean.get("facts", [])}
        if kinds - {None, "exact_connector_mid"}:
            problems.append(f"виды склейки кроме exact: {kinds}")
        # с непривязанным чатом — VERIFIED запрещён (§3 протокола привязки)
        capped = _run({**base, "request_id": "e7-cap2",
                       "avito": {**avito, "u2iZZZ": [
                           {"id": "avz-9", "author_id": None, "direction": "in",
                            "created": 1762604500, "content": {"text": "чужой чат"}}]}})
        wtxt = " ".join(capped.get("warnings", []))
        if capped.get("status") != "PARTIAL" or "не выше PARTIAL" not in wtxt:
            problems.append(f"cap не сработал: status={capped.get('status')} "
                            f"warnings={wtxt[:200]}")
        unbound = [f for f in capped.get("facts", [])
                   if f.get("payload", {}).get("join_status") in ("UNLINKED", "AMBIGUOUS")]
        if not unbound:
            problems.append("в capped-прогоне нет UNLINKED фактов — тест пуст")
        check("E7", "v12", "§4 (VERIFIED-cap), §3 протокола привязки",
              "UNLINKED/AMBIGUOUS факты понижают статус до PARTIAL (adaptеr)",
              "PASS" if not problems else "FAIL",
              "; ".join(problems) or
              f"чистый exact-мерж ({len(clean.get('facts', []))} факт, вид "
              f"exact_connector_mid) → VERIFIED; добавление непривязанного чата → "
              f"{len(unbound)} UNLINKED фактов → PARTIAL с cap-warning «не выше PARTIAL»",
              {"clean_status": clean.get("status"), "capped_status": capped.get("status")})
    except Exception as e:
        check("E7", "v12", "§4 (VERIFIED-cap), §3 протокола привязки",
              "UNLINKED/AMBIGUOUS факты понижают статус до PARTIAL (adaptеr)",
              "FAIL", f"ошибка: {e}")

    # --- E8: интеграционная mock-батарея E2E#2 (4 интента + 429) — артефакты
    try:
        sres = os.path.join(STAGING, "results")
        art = {n: json.load(open(os.path.join(
            sres, f"integrated_2026-11-09_e2e2-mock-{n}.json"), encoding="utf-8"))
            for n in ("leads", "calls", "mday", "dossier5", "429ok", "429fail2")}
        problems, notes = [], []
        want = {"leads": ("VERIFIED", 0), "calls": ("PARTIAL", None),
                "mday": ("PARTIAL", None), "dossier5": ("PARTIAL", None),
                "429ok": ("VERIFIED", 0), "429fail2": ("FAILED", None)}
        enum_js = {"LINKED", "UNLINKED", "AMBIGUOUS"}
        for n, (wstat, wwarn) in want.items():
            mg = art[n].get("merged", {})
            facts = mg.get("facts", [])
            if mg.get("status") != wstat:
                problems.append(f"{n}: status={mg.get('status')} ≠ {wstat}")
            if wwarn is not None and len(mg.get("warnings", [])) != wwarn:
                problems.append(f"{n}: warnings={len(mg.get('warnings', []))} ≠ {wwarn}")
            seen = set()
            for f in facts:
                key = (f.get("source"), f.get("source_entity_id"))
                if key in seen:
                    problems.append(f"{n}: дубль факта {key}")
                seen.add(key)
                p = f.get("payload", {}) or {}
                js = p.get("join_status")
                if js is not None and js not in enum_js:
                    problems.append(f"{n}: join_status={js} вне enum")
                kind = (f.get("evidence", {}) or {}).get("join", {}).get("kind")
                if kind is not None and kind != "exact_connector_mid":
                    problems.append(f"{n}: вид склейки {kind}")
                if js == "LINKED" and kind != "exact_connector_mid":
                    problems.append(f"{n}: LINKED без exact-доказательства")
            notes.append(f"{n}:{mg.get('status')}/{len(facts)}ф")
        # Авито-слой в manager_day/dossier: факты есть, все UNLINKED (честно, демо-u2i)
        for n in ("mday", "dossier5"):
            av = [f for f in art[n]["merged"]["facts"]
                  if "avito" in str(f.get("source", ""))]
            if not av:
                problems.append(f"{n}: нет авито-фактов — второй источник не подключён")
            elif any(f.get("payload", {}).get("join_status") not in (None, "UNLINKED")
                     for f in av):
                problems.append(f"{n}: авито-факты без подтверждённого маппинга не UNLINKED")
        # исторический потолок: calls_day PARTIAL с поимёнными warning (dangling)
        cw = art["calls"]["merged"].get("warnings", [])
        if art["calls"]["merged"].get("status") == "PARTIAL" and not cw:
            problems.append("calls: PARTIAL без причин (warning пуст)")
        fl = art["429fail2"]["merged"]
        if fl.get("facts") or not fl.get("errors"):
            problems.append("429-exhaustive: не fail-closed")
        check("E8", "v12", "§11.7, интеграция mw9kv0d13rbz",
              "E2E mock-батарея 4 интентов: статусы честные, exact-ID, дедуп 0-дублей",
              "PASS" if not problems else "FAIL",
              "; ".join(problems) or
              f"все 6 артефактов сходятся: {', '.join(notes)}; "
              f"calls PARTIAL по 3 поимённым warning (dangling — исторический потолок "
              f"честно понижает статус); авито-факты mday/dossier — UNLINKED без "
              f"подтверждённого маппинга (не выдуманы); дубли (source,entity_id) = 0; "
              f"LINKED только с exact_connector_mid; 429-exhaustive — FAILED fail-closed",
              {"artifacts": sorted(art)})
    except Exception as e:
        check("E8", "v12", "§11.7, интеграция mw9kv0d13rbz",
              "E2E mock-батарея 4 интентов: статусы честные, exact-ID, дедуп 0-дублей",
              "FAIL", f"ошибка: {e}")

    # --- E9: ночная live-батарея (00:12 МСК) — живое слияние F1b
    try:
        res_dir = os.path.join(STAGING, "results")
        bats = sorted(os.path.join(res_dir, p) for p in os.listdir(res_dir)
                      if p.startswith("live_battery_e2e2_") and p.endswith(".json"))
        if not bats:
            skip("E9", "v12", "§11.7–11.8 (live-гейт)",
                 "Живая батарея 4 интентов (F1b: живое слияние Авито↔Б24)",
                 "артефактов live_battery_e2e2_*.json нет: суточная live-квота стенда "
                 "исчерпана честно (422/200 за 09.11, портал отдавал 429); батарея "
                 "стоит на таймере 00:12 МСК 10.11 в сессии admin (ранер "
                 "staging/run_live_battery_e2e2.py). Финальный вердикт релиза — "
                 "после её артефактов")
        else:
            data = json.load(open(bats[-1], encoding="utf-8"))
            problems, runs = [], data.get("runs", {})
            for intent in ("leads_day", "calls_day", "manager_day", "client_dossier"):
                r = runs.get(intent) or {}
                mg = r.get("merged", r)
                if mg.get("status") not in ("VERIFIED", "PARTIAL", "FAILED"):
                    problems.append(f"{intent}: нет статуса")
                for f in mg.get("facts", []):
                    p = f.get("payload", {}) or {}
                    if p.get("join_status") == "LINKED":
                        ev = f.get("evidence", {}) or {}
                        if "connector_mid" not in json.dumps(ev):
                            problems.append(f"{intent}: LINKED без connector_mid-доказательства")
            f1b = data.get("checks", {})
            for k, v in f1b.items():
                if v is False:
                    problems.append(f"F1b-проверка {k} не сошлась")
            check("E9", "v12", "§11.7–11.8 (live-гейт)",
                  "Живая батарея 4 интентов (F1b: живое слияние Авито↔Б24)",
                  "PASS" if not problems else "FAIL",
                  "; ".join(problems) or f"батарея {os.path.basename(bats[-1])}: "
                  f"4 интента, LINKED только с connector_mid-доказательством, "
                  f"F1b-чеки {f1b}",
                  {"artifact": bats[-1]})
    except Exception as e:
        check("E9", "v12", "§11.7–11.8 (live-гейт)",
              "Живая батарея 4 интентов (F1b: живое слияние Авито↔Б24)",
              "FAIL", f"ошибка: {e}")

    # --- E10: границы — прод не включён, только read-only
    try:
        problems = []
        av_acc = os.path.join(V3LITE, "avito_adapter", "out",
                              "acceptance_avito_live_20261109-135151.json")
        if os.path.exists(av_acc):
            acc = json.load(open(av_acc, encoding="utf-8"))
            if not acc.get("read_only"):
                problems.append("живая приёмка адаптера не read-only")
            if acc.get("battle_mode_enabled"):
                problems.append("боевой режим адаптера включён — нарушение §11.9")
            if acc.get("A_cross_client_contaminated_facts"):
                problems.append(f"кросс-клиентская контаминация: "
                                f"{acc.get('A_cross_client_contaminated_facts')}")
            notes = (f"живая приёмка адаптера: verdict={acc.get('verdict')}, "
                     f"read_only={acc.get('read_only')}, "
                     f"battle={acc.get('battle_mode_enabled')}, контаминация=0")
        else:
            notes = "артефакт живой приёмки адаптера не найден (проверен 09.11 13:51)"
        if os.environ.get("AVITO_ADAPTER_LIVE") == "1":
            problems.append("AVITO_ADAPTER_LIVE=1 в окружении приёмки")
        check("E10", "v12", "§11.9 (боевой режим только решением владельца)",
              "Прод/боевой режим не включён, все приёмки read-only",
              "PASS" if not problems else "FAIL",
              "; ".join(problems) or notes + "; AVITO_ADAPTER_LIVE в окружении "
              "приёмки не установлен; интеграционные прогоны — staging/mock либо "
              "read-only live")
    except Exception as e:
        check("E10", "v12", "§11.9 (боевой режим только решением владельца)",
              "Прод/боевой режим не включён, все приёмки read-only",
              "FAIL", f"ошибка: {e}")


# ============================================================ вердикт
BLOCKING = {"A1", "A2", "A3", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4",
            "C5", "C6", "C7", "C8", "C9", "C10", "C11", "C12", "C13", "C14",
            "C15", "C16", "D1", "D2", "D3", "D4", "D5", "D6", "D9",
            "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "E9", "E10"}
COVERAGE = {"D7", "D8", "D10", "F1", "F3", "F4", "F5", "F6", "F7"}


def verdict():
    fails = [c for c in CHECKS if c["status"] == "FAIL"]
    block_fails = [c for c in fails if c["id"] in BLOCKING]
    cov_fails = [c for c in fails if c["id"] in COVERAGE]
    skips = [c for c in CHECKS if c["status"] == "SKIP"]
    if block_fails:
        return "FAIL", block_fails, cov_fails, skips
    if cov_fails:
        return "CONDITIONAL", block_fails, cov_fails, skips
    return "PASS", block_fails, cov_fails, skips


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--suite", default="all",
                    choices=["all", "static", "mock", "live", "sources", "v12",
                             "offline"])
    ap.add_argument("--live-budget", type=int, default=35)
    a = ap.parse_args()

    t0 = time.monotonic()
    offline = a.suite in ("all", "offline")
    if a.suite in ("all", "offline", "static"):
        print("── STATIC ──────────────────────────────", flush=True)
        suite_static()
    if a.suite in ("all", "offline", "mock"):
        print("── MOCK ───────────────────────────────", flush=True)
        suite_mock()
    if a.suite == "live" or (a.suite == "all" and a.live_budget > 0):
        print("── LIVE (read-only) ────────────────────", flush=True)
        suite_live(budget=a.live_budget)
    if a.suite in ("all", "offline", "sources"):
        print("── SOURCES ─────────────────────────────", flush=True)
        suite_sources()
    if a.suite in ("all", "offline", "v12"):
        print("── V12 RELEASE GATE (спека v1.2) ───────", flush=True)
        suite_v12()

    v, bf, cf, sk = verdict()
    out = {"ts": datetime.now().isoformat(), "suite": a.suite,
           "verdict": v,
           "summary": {"total": len(CHECKS),
                       "pass": sum(1 for c in CHECKS if c["status"] == "PASS"),
                       "fail": sum(1 for c in CHECKS if c["status"] == "FAIL"),
                       "skip": len(sk)},
           "blocking_fails": [c["id"] for c in bf],
           "coverage_fails": [c["id"] for c in cf],
           "checks": CHECKS,
           "wall_s": round(time.monotonic() - t0, 1)}
    path = os.path.join(RESULTS, f"acceptance_{TS}.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)

    print("\n════════════════════════════════════════════", flush=True)
    print(f"ВЕРДИКТ: {v}  "
          f"(PASS {out['summary']['pass']} / FAIL {out['summary']['fail']} / "
          f"SKIP {out['summary']['skip']})", flush=True)
    if bf:
        print("Блокирующие FAIL:", ", ".join(c["id"] + " " + c["title"] for c in bf),
              flush=True)
    if cf:
        print("Пробелы полноты (FAIL):",
              ", ".join(c["id"] + " " + c["title"] for c in cf), flush=True)
    print(f"Полный отчёт: {path}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
