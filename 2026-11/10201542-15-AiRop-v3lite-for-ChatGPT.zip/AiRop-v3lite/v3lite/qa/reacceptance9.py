#!/usr/bin/env python3
"""reacceptance9.py — переприёмка 9 дефектов v3 Lite после фиксов (admin2, мост mw90ntur4g6r).

Исходный вердикт: FAIL 30/9 (qa/results/acceptance_admin2_20261109_verdict.md).
Зоны фиксов: DEV → C13/D5/F3 (core 0.3.0), dev_agent → F4/F5/D7/D8/D10 (messages),
avito → F1 (avito_adapter), admin → интеграция на стенде.

Принципы (те же, §11.1): PASS только по артефакту/прогону; чужим отчётам не верим —
проверяем их evidense replay'ем живых артефактов + собственными live-пробами.

Режимы:
  python3 qa/reacceptance9.py            — replay-проверки по артефактам (сеть не трогаем)
  python3 qa/reacceptance9.py --live-spot — + 6 независимых read-only проб портала
                                           (budget-гвард, маски, лог live_calls_*.jsonl)

Выход: qa/results/reacceptance9_<ts>.json + таблица в stdout.
ВЕРДИКТ здесь НЕ финальный: пункты, требующие финальной интеграции и live-прогона
всего стенда, помечаются PENDING (переприёмка целиком — после готовности admin).
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
QA = HERE
V3LITE = os.path.dirname(QA)
STAGING = os.path.join(V3LITE, "staging")
RESULTS = os.path.join(QA, "results")
os.makedirs(RESULTS, exist_ok=True)

TS = datetime.now().strftime("%Y%m%d_%H%M%S")

CHECKS: list[dict] = []


def check(cid, title, status, detail, evidence=None):
    CHECKS.append({"id": cid, "title": title, "status": status,
                   "detail": detail, "evidence": evidence})
    print(f"[{status:^7}] {cid} {title}: {detail}", flush=True)


def load(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


A = {  # живые артефакты фиксов (собраны зонами 09.11 12:2x)
    "dossier_v2": os.path.join(STAGING, "results", "live_dossier_16790_v2.json"),
    "dossier_v1": os.path.join(STAGING, "results", "live_dossier_16790.json"),
    "mday_bot": os.path.join(STAGING, "results", "live_manager_day_20116_1107.json"),
    "mday_dangle": os.path.join(STAGING, "results", "live_manager_day_20114_1102.json"),
    "msg_live": os.path.join(V3LITE, "messages", "out", "live_verify_20261109.json"),
    "avito_m1": os.path.join(V3LITE, "avito_adapter", "out",
                             "measure_avito_20261109-124005.json"),
    "avito_m2": os.path.join(V3LITE, "avito_adapter", "out",
                             "measure_avito_20261109-124035.json"),
}


def suite_replay():
    print("== REPLAY: проверка живых артефактов фиксов ==", flush=True)

    # ---------- C13/GC-1: TASKS_TASK бота → BOT, не менеджеру ----------
    try:
        d = load(A["dossier_v2"])
        facts = d["facts"]
        bots = [f for f in facts if (f.get("payload") or {}).get("kind") == "bot_task"]
        ok_bot = [f for f in bots if f.get("author_role") == "BOT"
                  and f.get("author_id") == 15780
                  and f["source_entity_id"] == "activity:999896"]
        humans = [f for f in bots if f["source_entity_id"] == "activity:181820"]
        md = load(A["mday_bot"])
        # manager_day: задача бота (PTI=TODO, AUTHOR=бот) → роль BOT, не менеджеру
        md_bot = [f for f in md["facts"]
                  if (f.get("payload") or {}).get("kind") == "todo"
                  and f.get("author_role") == "BOT"
                  and f.get("author_id") != 20116]
        md_we = [f for f in md["facts"] if f.get("author_role") == "WE"]
        if ok_bot and humans and humans[0].get("author_role") == "WE" \
                and humans[0].get("author_id") == 6788 and md_bot and not md_we:
            check("C13", "TASKS_TASK/TODO бота: бот→BOT, человек→WE (GC-1)", "PASS",
                  f"999896(TASKS_TASK)→15780/BOT; 181820(человек)→6788/WE; "
                  f"manager_day 20116: TODO бота 17316→BOT "
                  f"({md_bot[0]['source_entity_id']}, AUTHOR_ID_raw=17316, "
                  f"RESPONSIBLE=20116 — не менеджеру), фактов WE(менеджер)=0",
                  "live_dossier_16790_v2.json + live_manager_day_20116_1107.json")
        else:
            check("C13", "TASKS_TASK: бот→BOT (GC-1)", "FAIL",
                  f"bots={len(bots)}, ok_bot={len(ok_bot)}, "
                  f"humans={[h.get('author_role') for h in humans]}, md_bot={len(md_bot)}")
    except Exception as e:
        check("C13", "TASKS_TASK (GC-1)", "FAIL", f"артефакт/структура: {e}")

    # ---------- D5/GC-8: dangling owner → warning + PARTIAL ----------
    try:
        d = load(A["mday_dangle"])
        warn = [w for w in d.get("warnings", []) if "owner dangle" in w]
        oc = (d.get("coverage") or {}).get("owner_check") or {}
        dang = [f for f in d["facts"]
                if (f.get("payload") or {}).get("owner_status") == "dangling"]
        refs = set(oc.get("dangling_refs") or [])
        if (d.get("status") == "PARTIAL" and warn and dang and oc.get("checked", 0) >= 9
                and refs >= {"contact:17016"}):
            check("D5", "dangling owner: warning + PARTIAL, факт сохранён (GC-8)", "PASS",
                  f"checked={oc.get('checked')}, dangling={oc.get('dangling')}, "
                  f"refs={sorted(refs)}, фактов с маркером={len(dang)}, "
                  f"эталон activity:1001974→contact:17016 в списке: "
                  f"{any(f['source_entity_id'] == 'activity:1001974' for f in dang)}",
                  "live_manager_day_20114_1102.json")
        else:
            check("D5", "dangling owner (GC-8)", "FAIL",
                  f"status={d.get('status')}, warn={len(warn)}, dang={len(dang)}, oc={oc}")
    except Exception as e:
        check("D5", "dangling owner (GC-8)", "FAIL", f"артефакт/структура: {e}")

    # ---------- F3: client_dossier в core ----------
    try:
        d = load(A["dossier_v2"])
        cov = d.get("coverage") or {}
        cluster = cov.get("cluster") or {}
        stages = [f for f in d["facts"] if f["fact_type"] == "stage_change"]
        gc2 = [w for w in d.get("warnings", []) if "привязка звонков сломана" in w]
        ghost = cov.get("dossier.ghost_activities")
        if (d.get("status") == "PARTIAL" and len(d["facts"]) >= 290
                and cluster and len(stages) >= 100 and len(gc2) >= 2):
            check("F3", "client_dossier: кластер+этапы+этика GC-2/7", "PASS",
                  f"facts={len(d['facts'])}, stage_change={len(stages)}, "
                  f"cluster={json.dumps(cluster, ensure_ascii=False)[:120]}, "
                  f"gc2-warnings={len(gc2)}, ghost={ghost is not None}",
                  "live_dossier_16790_v2.json")
        else:
            check("F3", "client_dossier", "FAIL",
                  f"facts={len(d.get('facts', []))}, stages={len(stages)}, "
                  f"cluster={bool(cluster)}, gc2={len(gc2)}")
    except Exception as e:
        check("F3", "client_dossier", "FAIL", f"артефакт/структура: {e}")

    # ---------- Якорь кластера: 21 звонок эталона → объяснимый дрейф ----------
    try:
        d = load(A["dossier_v2"])
        calls = [f for f in d["facts"] if f["fact_type"] == "call"]
        by = {}
        for f in calls:
            e = f.get("crm_entity") or {}
            by[(e.get("type"), str(e.get("id")))] = by.get(
                (e.get("type"), str(e.get("id"))), 0) + 1
        n = len(calls)
        # эталон приёмки 02:46 = 21 (5+7+9); артефакт = 22
        if n in (21, 22):
            extra = [f for f in calls if isinstance(
                (f.get("crm_entity") or {}).get("id"), int)]
            note = ("21 — совпадает с эталоном" if n == 21 else
                    f"22 = 21 эталон + 1 факт из calls.db "
                    f"(crm_entity.id int: {[f['source_entity_id'] for f in extra]})")
            check("GC-2a", "Кластер «два Михаила»: счёт звонков объясним", "PASS",
                  f"{n} фактов; распределение {by}; {note}",
                  "live_dossier_16790_v2.json (+ calls.db ro)")
        else:
            check("GC-2a", "Кластер: счёт звонков", "FAIL",
                  f"неожиданный счёт {n}; распределение {by}")
    except Exception as e:
        check("GC-2a", "Кластер: счёт звонков", "FAIL", f"артефакт/структура: {e}")

    # ---------- F5: полнота длинных чатов ----------
    try:
        d = load(A["msg_live"])
        h = (d.get("coverage") or {}).get("history") or {}
        cap = h.get("underfetch_cap") or {}
        mismatch = h.get("count_mismatch") or {}
        stat = (d.get("coverage") or {}).get("stat_aux") or {}
        cross = (stat.get("crosscheck") or {})
        # 25396: эталонный длинный чат (143 по Stat, старый недобор 50)
        over = {str(x["session_id"]): x for x in (cross.get("over_detail") or [])}
        s25396 = over.get("25396") or {}
        if (h.get("sessions_ok") and not h.get("truncated_sessions")
                and cap.get("sessions") == 0
                and s25396.get("got", 0) >= s25396.get("expected", 10**9)):
            check("F5", "Длинные чаты: LIMIT-схема добирает (25396: 152≥143)", "PASS",
                  f"sessions_ok={h.get('sessions_ok')}, truncated={h.get('truncated_sessions')}, "
                  f"underfetch={cap.get('sessions')}, 25396={s25396.get('got')}/{s25396.get('expected')}, "
                  f"count_mismatch(счётчики, не потеря)={mismatch.get('sessions')}",
                  "messages/out/live_verify_20261109.json")
        else:
            check("F5", "Длинные чаты", "FAIL",
                  f"h={h.get('sessions_ok')}, trunc={h.get('truncated_sessions')}, "
                  f"cap={cap}, 25396={s25396}")
    except Exception as e:
        check("F5", "Длинные чаты", "FAIL", f"артефакт/структура: {e}")

    # ---------- D8/GC-6: переносы после фикса 400 ----------
    try:
        d = load(A["msg_live"])
        tr = (d.get("coverage") or {}).get("transfers") or {}
        tf = [f for f in d["facts"] if f["fact_type"] == "transfer"]
        post_ok = all("POST" in (f.get("evidence") or {}).get("query", "") for f in tf)
        if (tr.get("errors") == [] and tr.get("transfers", 0) > 0
                and tr.get("calls", 0) > 0 and tf and post_ok):
            check("D8", "Transfer.list POST-массивом: без 400 (GC-6)", "PASS",
                  f"transfers={tr.get('transfers')}, calls={tr.get('calls')}, "
                  f"errors={tr.get('errors')}, в-окне фактов={len(tf)}, "
                  f"out_of_window_dropped={tr.get('out_of_window_dropped')}, "
                  f"evidence={tf[0]['evidence']['query']}",
                  "messages/out/live_verify_20261109.json")
        else:
            check("D8", "Transfer.list (GC-6)", "FAIL", f"tr={tr}, facts={len(tf)}")
    except Exception as e:
        check("D8", "Transfer.list (GC-6)", "FAIL", f"артефакт/структура: {e}")

    # ---------- D7/GC-3/10: поимённые missing_text ----------
    try:
        d = load(A["msg_live"])
        mt = (d.get("coverage") or {}).get("missing_text") or {}
        warn = [w for w in d.get("warnings", []) if w.startswith("missing_text:")]
        named = all("activity " in w for w in warn[:20]) if warn else False
        reasons = mt.get("by_reason") or {}
        # поимённых в warnings — cap MISSING_TEXT_WARN_LIMIT=200 (задокументирован
        # в fetcher.py), полный счёт — в coverage.missing_text.count
        named_expected = min(mt.get("count", 0), 200)
        if (mt.get("count", 0) > 0 and named_expected <= len(warn) <= mt.get("count")
                and named and reasons.get("chat_unresolved", 0) > 100):
            check("D7", "missing_text поимённо + по причинам (GC-3/10)", "PASS",
                  f"count={mt.get('count')} (полный в coverage), by_reason={reasons}, "
                  f"поимённых warnings={len(warn)} (cap 200, задокументирован)",
                  "messages/out/live_verify_20261109.json")
        else:
            check("D7", "missing_text (GC-3/10)", "FAIL",
                  f"mt={mt}, warns={len(warn)}, named={named}")
    except Exception as e:
        check("D7", "missing_text (GC-3/10)", "FAIL", f"артефакт/структура: {e}")

    # ---------- D10/§9.5-6: тип user_id скоупа ----------
    try:
        d = load(A["msg_live"])
        ws = (d.get("coverage") or {}).get("webhook_scope") or {}
        false_w = [w for w in d.get("warnings", [])
                   if "скоупирован" in w or "полный листинг только под владельцем" in w]
        if (ws.get("user_id") == 1 and ws.get("full_listing_expected") is True
                and not false_w):
            check("D10", "user_id нормализован, ложного скоуп-warning нет", "PASS",
                  f"scope={json.dumps(ws, ensure_ascii=False)}, ложных warnings={len(false_w)}",
                  "messages/out/live_verify_20261109.json")
        else:
            check("D10", "скоуп-типы", "FAIL", f"ws={ws}, false_w={false_w[:2]}")
    except Exception as e:
        check("D10", "скоуп-типы", "FAIL", f"артефакт/структура: {e}")

    # ---------- Якорь 317 сообщений 07.11 ----------
    try:
        d = load(A["msg_live"])
        h = (d.get("coverage") or {}).get("history") or {}
        if h.get("messages_total") == 317 and h.get("duplicate_global") == 0:
            check("GC-3a", "07.11: 317 сообщений, дублей 0 (якорь D9)", "PASS",
                  f"messages_total={h.get('messages_total')}, "
                  f"duplicate_global={h.get('duplicate_global')}",
                  "messages/out/live_verify_20261109.json")
        else:
            check("GC-3a", "якорь 317", "FAIL",
                  f"messages_total={h.get('messages_total')}")
    except Exception as e:
        check("GC-3a", "якорь 317", "FAIL", f"артефакт/структура: {e}")

    # ---------- F4: потолок offset — честный PARTIAL ----------
    try:
        d = load(A["msg_live"])
        ss = (d.get("coverage") or {}).get("sessions_scan") or {}
        w_all = " ".join(d.get("warnings", []))
        honest = ("полнота за потолком НЕ заявляется" in w_all
                  and "недоказуем" in w_all)
        false_claim = ("вся активность" in json.dumps(
            d.get("narrator_packet") or {}, ensure_ascii=False).lower()
            and d.get("status") in ("VERIFIED",))
        if (ss.get("ceiling_hit") and ss.get("stop_reason") == "ceiling"
                and d.get("status") == "PARTIAL" and honest and not false_claim):
            check("F4", "Потолок offset: ceiling→PARTIAL, без ложных заявлений", "PASS",
                  f"rows={ss.get('rows_scanned')}, stop={ss.get('stop_reason')}, "
                  f"оценка хвоста={((ss.get('ids') or {}).get('missing_in_span_estimate'))}, "
                  f"статус={d.get('status')}, честные формулировки есть",
                  "messages/out/live_verify_20261109.json")
        else:
            check("F4", "Потолок offset", "FAIL",
                  f"ceiling={ss.get('ceiling_hit')}, stop={ss.get('stop_reason')}, "
                  f"status={d.get('status')}, honest={honest}")
    except Exception as e:
        check("F4", "Потолок offset", "FAIL", f"артефакт/структура: {e}")

    # ---------- F1: Авито v3 адаптер — живая работа и слияние ----------
    try:
        m2 = load(A["avito_m2"])
        v3 = m2.get("v3_messages") or {}
        chats = v3.get("chats") or []
        ok_chats = [c for c in chats if c.get("page1_size")]
        sec_err = [c for c in chats if (c.get("error") or {}).get("code") == "SECURITY"]
        # joiner: офлайн-слияние — pytest-набор адаптера (уникальность merge,
        # CONNECTOR_MID-правило, дедуп, без сети)
        import subprocess
        r = subprocess.run(
            [sys.executable, "-m", "pytest", "tests/", "-q"],
            cwd=os.path.join(V3LITE, "avito_adapter"),
            capture_output=True, text=True, timeout=300)
        selftest_ok = r.returncode == 0 and "failed" not in (r.stdout or "")
        st_line = [l for l in (r.stdout or "").splitlines()
                   if "passed" in l or "failed" in l]
        st = st_line[-1].strip() if st_line else (r.stderr or "")[:120]
        if ok_chats and not sec_err and m2.get("readonly") is True:
            detail = (f"live v3.messages: чатов ок={len(ok_chats)}/{len(chats)}, "
                      f"в окне 09.11 сообщений={((m2.get('window') or {}).get('messages_in_window'))}, "
                      f"readonly={m2.get('readonly')}, офлайн-тесты слияния: {st}")
            # полная live-сливалка с Б24 — после интеграции admin: честно PENDING
            check("F1a", "Авито v3: листинг+истории живут; merge-тесты зелёные",
                  "PASS" if selftest_ok else "FAIL",
                  detail, "avito_adapter/out/measure_avito_20261109-124035.json "
                          "+ avito_adapter/tests (72)")
            check("F1b", "Авито v3: слияние с Б24 в живом прогоне", "PENDING",
                  "адаптер и стык готовы (офлайн-тесты " +
                  ("зелёные: " + st if selftest_ok else "FAIL: " + st) +
                  "); финальная проверка живого слияния/уникальности (CONNECTOR_MID, "
                  "±10 мин, без дублей фактов) — в переприёмке интегрированного "
                  "стенда после сборки admin",
                  "avito_adapter pytest + staging/integrated.py")
        else:
            check("F1a", "Авито v3 live", "FAIL",
                  f"ok={len(ok_chats)}, sec_err={len(sec_err)}, "
                  f"stderr={(r.stderr or '')[:200]}")
    except Exception as e:
        check("F1a", "Авито v3 live", "FAIL", f"артефакт/структура: {e}")

    # ---------- D7-хвост: пробел Авито/Б24 измерим и назван ----------
    try:
        d = load(A["msg_live"])
        mt = (d.get("coverage") or {}).get("missing_text") or {}
        w_all = " ".join(d.get("warnings", []))
        if (mt.get("by_reason") or {}).get("chat_unresolved", 0) >= 100 \
                and "второго источника (Авито messenger v3)" in w_all:
            check("F1c", "Разрыв Авито/Б24 измерен и назван (второй источник)", "PASS",
                  f"chat_unresolved={(mt.get('by_reason') or {}).get('chat_unresolved')} "
                  f"активностей ждут Авито v3", "messages/out/live_verify_20261109.json")
        else:
            check("F1c", "Разрыв Авито/Б24", "FAIL", "не измерен/не назван")
    except Exception as e:
        check("F1c", "Разрыв Авито/Б24", "FAIL", f"артефакт/структура: {e}")


_LIVE = {"calls": 0, "budget": 6, "log": None}


def _hooks():
    spec = importlib.util.spec_from_file_location(
        "staging_secrets_reacc", os.path.join(STAGING, "secrets.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _live_get(method, params, hook, timeout=15):
    if _LIVE["calls"] >= _LIVE["budget"]:
        raise RuntimeError("live-бюджет исчерпан")
    qs = urllib.parse.urlencode(params, doseq=True)
    url = f"{hook.rstrip('/')}/{method}.json?{qs}"
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    t0 = time.monotonic()
    with opener.open(url, timeout=timeout) as r:
        body = r.read()
    ms = round((time.monotonic() - t0) * 1000, 1)
    _LIVE["calls"] += 1
    if _LIVE["log"]:
        _LIVE["log"].write(json.dumps(
            {"ts": datetime.now().isoformat(), "method": method,
             "call": _LIVE["calls"], "latency_ms": ms,
             "params": {k: v for k, v in params.items()
                        if "VALUES" not in k.upper()}}) + "\n")
        _LIVE["log"].flush()
    time.sleep(0.6)
    return json.loads(body)


def suite_live_spot():
    print("== LIVE SPOT: независимые пробы (read-only) ==", flush=True)
    sec = _hooks()
    bx = sec.bx_webhook()
    ol = sec.ol_owner_webhook()
    log_path = os.path.join(RESULTS, f"live_calls_{TS}_reacc9.jsonl")
    _LIVE["log"] = open(log_path, "w", encoding="utf-8")
    print(f"бюджет {_LIVE['budget']} вызовов; лог {log_path}", flush=True)

    # 1) 22-й звонок кластера: activity 1003054 — реальна; объяснение расхождения
    #    21(срез 02:46)→22(досье): активность висит на ПРИЗРАКЕ contact:17016 с
    #    пустыми BINDINGS → невидима для entity-фильтров листинга; досье видит её
    #    через calls.db/телефон кластера. ВНИМАНИЕ: формулировка DEV «появилась в
    #    CRM после среза» неточна (CREATED=03.11) — правильное объяснение выше.
    try:
        r = _live_get("crm.activity.get", {"ID": 1003054}, bx)
        act = (r.get("result") or {})
        bind = act.get("BINDINGS") or []
        created = act.get("CREATED") or ""
        owner = act.get("OWNER_ID")
        ok = bool(act) and str(act.get("TYPE_ID")) == "2" and not bind \
            and str(owner) == "17016"
        if ok:
            check("GC-2b", "22-й звонок 1003054: существует; 21→22 объясним",
                  "PASS",
                  f"CREATED={created} (старше среза!), OWNER_ID={owner} "
                  f"(призрак contact:17016), BINDINGS=[] → в entity-листингах "
                  f"невидима, досье резолвит через calls.db/телефон — легитимно; "
                  f"провайдер={act.get('PROVIDER_ID')}",
                  "crm.activity.get 1003054 (live)")
        elif act:
            check("GC-2b", "22-й звонок 1003054", "FAIL",
                  f"неожиданная форма: CREATED={created}, OWNER={owner}, "
                  f"BINDINGS={bind}")
        else:
            check("GC-2b", "22-й звонок 1003054", "FAIL",
                  f"не найден: {str(r)[:150]}")
    except Exception as e:
        check("GC-2b", "22-й звонок 1003054", "FAIL", f"{e}")

    # 2) dangling: contact 17016 не существует — портал отвечает HTTP 400
    #    (та же сигнатура, что в вердикте 09.11 02:46)
    try:
        try:
            r = _live_get("crm.contact.get", {"ID": 17016}, bx)
            res = r.get("result")
            ghost = res is None or (isinstance(res, dict) and not res)
        except urllib.error.HTTPError as he:
            ghost = he.code == 400
            res = f"HTTP {he.code}"
        if ghost:
            check("D5b", "contact:17016 — призрак подтверждён (GC-8)", "PASS",
                  "crm.contact.get → пусто/HTTP 400 — владельца нет; факты с "
                  "owner_status=dangling корректны",
                  "crm.contact.get 17016 (live)")
        else:
            check("D5b", "contact:17016 — призрак?", "FAIL",
                  f"контакт существует?! {str(res)[:150]}")
    except Exception as e:
        check("D5b", "contact:17016 (GC-8)", "FAIL", f"{e}")

    # 3) user.current: ID строкой (корень D10)
    try:
        r = _live_get("user.current", {}, ol)
        uid = (r.get("result") or {}).get("ID")
        check("D10b", "user.current ID строкой — корень D10 жив", "PASS",
              f"тип ID={type(uid).__name__}, значение={uid!r} (строка → нужна "
              f"нормализация int, фикс применён в messages)",
              "user.current (live, OL-вебхук)")
    except Exception as e:
        check("D10b", "user.current", "FAIL", f"{e}")

    print(f"live-вызовов: {_LIVE['calls']}/{_LIVE['budget']}", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--live-spot", action="store_true",
                    help="независимые live-пробы (6 read-only вызовов)")
    a = ap.parse_args()

    suite_replay()
    if a.live_spot:
        suite_live_spot()

    passed = [c for c in CHECKS if c["status"] == "PASS"]
    failed = [c for c in CHECKS if c["status"] == "FAIL"]
    pending = [c for c in CHECKS if c["status"] == "PENDING"]
    print(f"\nИТОГ replay: {len(passed)} PASS / {len(failed)} FAIL / "
          f"{len(pending)} PENDING", flush=True)
    if failed:
        print("FAIL-пункты:", ", ".join(c["id"] for c in failed), flush=True)

    out = {"ts": TS, "bridge": "mw90ntur4g6r", "summary": {
        "pass": len(passed), "fail": len(failed), "pending": len(pending)},
        "verdict_note": ("НЕ финальный вердикт: F1b (слияние B24+Avito) и "
                         "сквозная интеграция — после сборки admin; финал = "
                         "полный прогон acceptance_admin2.py v2 + этот набор"),
        "checks": CHECKS}
    path = os.path.join(RESULTS, f"reacceptance9_{TS}.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    print("отчёт:", path, flush=True)


if __name__ == "__main__":
    main()
