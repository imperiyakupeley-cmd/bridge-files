# RELEASE GATE (финальный) — ИИ-РОП v3 Lite, admin2

Мост: mw9kv1iszlu4 (ChatGPT). Дата: 09.11.2026, ~21:30–21:50 МСК.
Предмет: финальный релизный гейт после интеграции mw9kv0d13rbz (E2E#2) и
exact-join Авито (mw912vdyd7fq / mw912x028ygf). Прод НЕ включён.

## ВЕРДИКТ

**OFFLINE-ГАЙТ: PASS — 38 PASS / 0 FAIL / 1 PENDING (E9 live).**
**ФИНАЛЬНЫЙ РЕЛИЗНЫЙ ВЕРДИКТ: PENDING (BLOCKED на live-батарее),**
ожидание ограничено: батарея стоит на 00:12 (таймер admin, session-only)
+ страховка admin2 на 00:20 (авто-финализация E9). Если к ~01:00 артефактов
нет — гейт остаётся PENDING с причиной «живая квота/таймер», НЕ PASS.

Чего ждём: единый live read-only E2E 4 интентов (L1–L4) с живым слиянием
Авито↔Б24 (F1b). Всё остальное из мандата закрыто и проверено независимо.

## 1. Инспекция кода (ручная, оба модуля прочитаны целиком)

`messages/msg/join.py` (473 стр.) и `avito_adapter/adapter/joiner.py` (492 стр.):
- Сшивка ТОЛЬКО по строгим ID: u2i↔chatId (inline-mapping / entity_id
  `avito|{line}|{u2i}|{uid}` / verified_index) и CONNECTOR_MID == avito id 1:1.
- Fuzzy/±10 мин/текст/телефон/имя: движок их НЕ читает (подтверждено тестами
  «затирание текстов и сдвиг времён не меняют результат»); опции нельзя даже
  передать — FORBIDDEN_JOIN_OPTIONS → SecurityError/SchemaError.
- Коллизии (u2i у 2+ чатов, LEAD у 2+ чатов, дубль mid, чужой чат) → AMBIGUOUS
  без склейки, досье исключено ОБЕИМ кандидатам. Неверифицированный аккаунт →
  fail-closed UNLINKED.
- Атрибуция сотрудника — только author_id Б24-копии; senderId Авито ≠ Б24
  (employee_from_avito всегда отказ; числовое совпадение = канарейка-WARN).
- Независимый греп по всему дереву v3lite: fuzzy-токены встречаются ТОЛЬКО в
  блэклист-константах двух join-модулей. difflib/SequenceMatcher/Levenshtein
  отсутствуют. Остаточного fuzzy нет.

## 2. Независимые прогоны (свежие, 21:42–21:44)

| Сюита | Результат |
|---|---|
| core 0.3.0 (v3lite/tests) | 128 passed |
| messages (messages/tests) | 127 passed |
| avito_adapter (tests) | 91 passed |
| acceptance static | PASS 3/0 |
| acceptance mock | PASS 20/0 |
| acceptance v12 (Release Gate) | PASS 9/0 + 1 SKIP (E9) |
| acceptance sources (обновлённый) | PASS 6/0 |

Итого 38 PASS / 0 FAIL / 1 PENDING. Скрипт qa/acceptance_admin2.py обновлён
под core 0.3.0 + спеку v1.2: §9.7 негативы A2–D2 (E1–E4), API-гвард и
физическое отсутствие fuzzy (E5–E6), VERIFIED-cap (E7), артефакты E2E#2 (E8),
live-гейт (E9), прод-не-включён (E10); sources F1/F3 переписаны с
«NOT_IMPLEMENTED» на фактическое состояние (адаптер поставлен, досье в core).

E7, первый прогон 21:35 FAIL: фикстура давала расхождение ролей
(Б24 CLIENT vs Авито UNKNOWN → WARN → PARTIAL). Исправлена сама фикстура
(роли согласованы), cap-ассерт не ослаблен; после фикса — 3 стабильных PASS.

## 3. Требования мандата — чем закрыты

- «§9.7 4 отрицательных теста»: E1 (два клиента, идентичный текст, Δt=7 мин —
  склейки нет), E2 (исходящие без автора — не атрибутированы), E3 (коллизии
  u2i/CRM, невериф. аккаунт — linked=0), E4 (dangling owner — PARTIAL,
  без перепривязки). Все PASS.
- «PARTIAL на историческом потолке»: F4 PASS — live 09.11: stop_reason=ceiling,
  truncated=true, status=PARTIAL, хвост оценён по плотности id; VERIFIED не
  притворяется. Плюс C7 (offset-потолок) и F5 (underfetch 0/0, 317 сообщений =
  эталон контрольного дня).
- «Нет атрибуции без доказательства»: E2 (employee_counts только b24.author_id),
  C13 (RESPONSIBLE/AUTHOR_ID/бот), канарейки senderid_numeric_overlap.
- «Exact ID-only + уникальный CRM-маппинг»: E1/E3/E5/E6/E8 + живая приёмка
  адаптера 13:51 (verdict=PASS, 7 склеек только exact_connector_mid,
  контаминация 0, пробы swap/collision ложных склеек не дали).

## 4. Live E2E (E9) — единственный незакрытый пункт

Суточная live-квота исчерпана честно (422/200, портал 12×429) — гвард не
обходили. Батарея L1–L4 (ранер staging/run_live_battery_e2e2.py, квот-гвард
на каждый прогон) — таймер 00:12 в сессии admin (session-only, риск: умрёт с
сессией) + страховка 00:20 в сессии admin2 (авто: артефакты есть → прогон
--suite v12 и фиксация E9; нет → запуск батареи, затем фиксация).
E9 автоматически подхватывает live_battery_e2e2_*.json и проверяет: LINKED
только с connector_mid-доказательством, дедуп, атрибуция только Б24, статусы.

## 5. Артефакты

- Прогоны: qa/results/acceptance_20261109_214218.json (static),
  _214224.json (mock), _214328.json (v12), _214335.json (sources).
- Негатив-фикстуры: qa/fixtures_v12_20261109/ (4 датасета, SHA256SUMS).
- Интеграция E2E#2 (адаптер): qa/results/INTEGRATION_E2E2_REPORT_20261109.md
  + staging/results/integrated_2026-11-09_e2e2-mock-* (16 шт.).
- Живой эталон: messages/out/live_verify_20261109.json (317 сооб., PARTIAL/ceiling).
- Живая приёмка адаптера: avito_adapter/out/acceptance_avito_live_20261109-135151.json.
- Ожидаемые ночью: staging/results/live_battery_e2e2_<ts>.{json,md}.

## 6. Замечания (не блокеры)

1. Гигиена индекса: avito_adapter/avito_chat_index.db содержит 3 inline-строки
   от интеграционных прогонов 18:40 (u2i-demo-3101→31101 и др.). До боевого
   режима индекс пересобрать/очистить от демо-строк.
2. Таймер 00:12 — session-only; страховка 00:20 поставлена (см. §4).
3. Мульти-аккаунт Авито живьём не проверялся (один аккаунт) — перед включением
   каждого нового аккаунта живая приёмка §11.9 обязательна.
4. Из отчёта интегратора: в 429-exhaustive detail не назван код 429 (косметика,
   §6 спеки) — предложить DEV дописать.

— admin2, 09.11.2026 (мост mw9kv1iszlu4). Прод не включён, все прогоны read-only.
