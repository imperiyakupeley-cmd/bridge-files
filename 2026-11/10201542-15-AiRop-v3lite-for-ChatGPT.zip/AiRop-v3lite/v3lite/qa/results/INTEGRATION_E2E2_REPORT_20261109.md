# Отчёт интеграции v3 Lite E2E#2 — staging, только read-only (мост mw9kv0d13rbz)

Дата: 09.11.2026, ~21:20–22:00 МСК. Исполнитель: admin.
Мандат: интеграция ТОЛЬКО в staging (прод/скрипты/CRM/TG не тронуты),
статус запуска не присваивается — решение за владельцем.

## 1. Модули (тестовые наборы, прогонены заново сегодня вечером)

| Модуль | Тесты | Результат |
|---|---|---|
| core 0.3.0 (`~/AiRop/v3lite/tests`) | 128 | **128 passed** |
| messages (`~/AiRop/v3lite/messages/tests`) | 127 | **127 passed** |
| avito_adapter (`~/AiRop/v3lite/avito_adapter/tests`) | 91 | **91 passed** (выросло с 74 — патч exact-ID принёс +17 тестов) |

## 2. Exact-ID патч Авито: вердикт «fuzzy удалён» — ПОДТВЕРЖДЁН

- `adapter/joiner.py` — движок exact-IDs-only: ключи сшивки ТОЛЬКО
  `params.CONNECTOR_MID` (1:1 в обе стороны) и подтверждённый маппинг
  `u2i ↔ chatId` (inline / entity_id / персистентный индекс). Коллизия →
  AMBIGUOUS без склейки, авторство — только author_id Б24-копии.
- Fuzzy-опции (`window_minutes`, `match_by_*`, `text_similarity`, `fuzzy`,
  …) отклоняются на уровне API (SchemaError) — `FORBIDDEN_JOIN_OPTIONS`;
  тесты `test_join_pair.py::test_fuzzy_trap_identical_text_time_is_NOT_merged`,
  `test_cli.py::test_merge_rejects_fuzzy_options` — зелёные.
- Виды склейки fuzzy_text_time/system_mirror из движка удалены физически
  (`assert not hasattr(joiner, "_pair_candidates"` — тест).
- **Блокера нет: адаптер подключён как второй источник в staging.**

## 3. Mock-батарея 4 интентов (integrated.py, все 3 слоя: core+messages+avito)

| Прогон | Статус | Факты | Примечание |
|---|---|---|---|
| leads_day | VERIFIED | 6 | контракт §3: даты строго ISO-8601 c офсетом (спека v1.2) |
| calls_day | PARTIAL | 39 | честно: 3 warning (висячие owner в фикстуре), fail-closed |
| manager_day (401) | PARTIAL | 11 | все 3 слоя; авито-факты UNLINKED честно (нет подтверждённого маппинга у демо-u2i) |
| client_dossier (deal 301) | PARTIAL | 2 | CRM-часть core работает (2 CRM-факта + тексты messages) |

Спец-проверки mock:
- **429 recoverable** (2×429 на метод): 3 ретрая с backoff → VERIFIED, данные получены.
- **429 exhaustive** (999×429): 4 попытки (1+3 ретрая) → fail-closed FAILED,
  0 фактов, `crm.lead.list` в errors, filter_canary=ERROR (§6 соблюдён;
  косметика: в detail не назван код 429 — см. §6 замечаний).
- **duplicate_guard**: 0 нарушений (source, source_entity_id) во всех merged.
- **source coverage**: в каждом ответе (4–20 источников на интент).

Фикстуры: создана новая датированная `dataset_client_dossier_v3_20261109.json`
(политика immutable-фикстур соблюдена: SHA256 в SHA256SUMS.addons-20261109,
444+uchg). Причина: старый датасет не имел `crm.contact.get`/`crm.deal.get`/
`crm.deal.list`, которые поток core 0.3.0 зовёт для досье. Это закрывало
mock-путь досье (в live не проявляется — портал отвечает на все методы).

## 4. Live-батарея: перенос на 00:12 (после сброса квоты)

Суточная live-квота стенда исчерпана честным счётчиком: **422/200**
(msg_api_calls + http_calls live-прогонов за 09.11 — день забит прогонами
dev и admin2; портал сегодня отдавал 12×429). Гвард не обходил — защита
портала важнее скорости. Батарея из 4 live-прогонов (по одному на интент:
leads 07.11 / calls 07.11 / manager_day 20116 07.11 / dossier contact 16790)
поставлена на таймер 00:12 МСК, ранер: `staging/run_live_battery_e2e2.py`,
артефакты: `results/live_battery_e2e2_<ts>.{json,md}`. В ранере — квот-гвард
перед каждым прогоном (остаток ≤20 → SKIP) и авто-проверки F1b (дедуп
merged-фактов, LINKED только с точным ключом, живое слияние Авито↔Б24),
GC-1 (TASKS_TASK→бот), D5 (dangling owner), GC-2 (кластер ~22 звонка), COV.

## 5. Статусы проверок переприёмки (по задачам моста)

| Проверка | Статус | Основание |
|---|---|---|
| 317 сообщений контрольного дня (07.11), дублей 0 | PASS | replay admin2 GC-3a по `messages/out/live_verify_20261109.json`; перепроверится в live-батарее |
| Кластер звонков ~22 (GC-2, «два Михаила») | PASS (replay) | `live_dossier_16790_v2.json`: 22 = 21 CRM + 1 calls.db; live-батарея L4 перепроверит |
| TASKS_TASK-бот → BOT, не менеджер (GC-1/C13) | PASS (replay) | `live_manager_day_20116_1107.json`; live-батарея L3 перепроверит |
| Dangling owner → warning+PARTIAL (D5/GC-8) | PASS (replay) | 3 dangling из 9 checked, эталон activity:1001974→contact:17016 в списке |
| 429-политика (3 ретрая, fail-closed) | PASS (mock) | см. §3 |
| Source coverage | PASS (mock) | см. §3 |
| F1b живое слияние Авито↔Б24 | **PENDING → live 00:12** | офлайн-часть закрыта (91 тест); живая — батарея L3/L4 |

## 6. Замечания (не блокеры)

1. Датасет досье устарел к core 0.3.0 — закрыто новой фикстурой (§3).
2. В 429-exhaustive detail не назван код 429 («канарейка фильтра: источник
   не ответил») — предлагаю DEV'у дописать код ответа в detail (§6 спеки).
3. integrated.py не нормализует голые даты (`--from 2026-11-07` → SCHEMA);
   спека требует ISO с офсетом — можно добавить авто-дополнение офсета,
   чтобы не ловить SCHEMA на человеческой записи даты.

## 7. Границы соблюдены

- Только staging: новые файлы — fixtures/dataset_client_dossier_v3_20261109.json,
  staging/run_live_battery_e2e2.py; чужие исходники не правились.
- Прод-скрипты, CRM, Telegram — не тронуты; все live-обращения read-only.
- Статус запуска НЕ присваивается — финальная приёмка за admin2,
   решение за владельцем.

— admin, 09.11.2026 (мост mw9kv0d13rbz)
