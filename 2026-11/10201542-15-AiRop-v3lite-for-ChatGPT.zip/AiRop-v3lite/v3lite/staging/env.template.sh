# Шаблон окружения стенда v3 Lite (для разработчиков DEV/dev_agent).
# НЕ содержит секретов: значения подтягиваются в рантайме из существующих
# хранилищ (см. staging/secrets.py). Копировать как env.local.sh и править
# под свой сценарий; env.local.sh в git/отчёты не попадает.

# --- режимы ---
# MOCK: не выставлять V3_WEBHOOK — тогда запускайте через airop_staging.py run --mode mock
#        (CLI сам поднимет mock-сервер и пропишет оба вебхука на localhost).
# LIVE (read-only, только после приёмки admin2 и с квот-гардом стендa):
#   V3_WEBHOOK     — НЕ СТАВИМ: core читает прод-вебхук Анны сам из ~/AiRop/.env
#   V3_OL_WEBHOOK  — вебхук владельца ОЛ; получать так (не копировать в файлы!):
#     python3 -c "import sys; sys.path.insert(0,'~/AiRop/v3lite/staging'.replace('~','/Users/aleksej')); import secrets; print(secrets.ol_owner_webhook())"
#     либо: OL_HOOK=$(python3 ~/AiRop/v3lite/staging/secrets_status.py 2>/dev/null); export V3_OL_WEBHOOK="$OL_HOOK"

# --- обязательное для стендовых прогонов ---
export V3_CACHE=0                    # стенд не трогает v3_cache.db (не мешаем DEV-прогонам)

# --- квоты/лимиты стенда (опционально) ---
# export STAGING_LIVE_DAILY_MAX=200  # гард живых REST-вызовов через стенд за сутки

# --- a2a-адаптер (по умолчанию ВЫКЛЮЧЕН, не экспортируйте A2A_ENABLE) ---
# export A2A_ENABLE=1                # только по решению владельца
# export A2A_TARGET_AGENT=airop      # целевой агент ИИ-РОП в реестре МАВИ
# export A2A_BRIDGE=http://127.0.0.1:49924

# Быстрая проверка окружения:
#   python3 -I ~/AiRop/v3lite/staging/airop_staging.py secrets-status
#   python3 -I ~/AiRop/v3lite/staging/airop_staging.py selftest
