# Отчёт: блокеры C13/D5 + client_dossier (F3) — core 0.3.0

Дата: 2026-11-09 · Зона: ~/AiRop/v3lite/core (+ точечные фиксы staging/messages по согласованию)
Задача моста: mw90np97603s · Исходный вердикт приёмки: FAIL (30 PASS / 9 FAIL)

## 1. C13 / GC-1 — задачи бота TASKS_TASK (ИСПРАВЛЕНО)
`core/sources/activities.py`, `core/sources/dossier.py`
- Новая категория `kind="bot_task"` (fact_type=task_todo): различение ТОЛЬКО по
  PROVIDER — префиксы `TASKS_TASK` / `CRM_WEBDAV_TASK` (PROVIDER_TYPE_ID или
  PROVIDER_ID при пустом PTI).
- Автор — AUTHOR_ID (бот), роль `BOT` при author ∈ exclude_users. TODO (PTI=TODO)
  и сообщения (CONFIGURABLE) не смешиваются с bot_task: `classification`
  разводит kinds, provider_id виден в payload (PASS-критерий GC-1).
- Live-подтверждение (dossier 16790): activity:999896 TASKS_TASK → author 15780
  (dogrev), роль BOT; activity:181820 TASKS_TASK автора 6788 (человек) → WE.
  Live manager_day 20116@07.11: TODO бота 17316 → BOT, не менеджеру.

## 2. D5 / GC-8 — dangling OWNER (ИСПРАВЛЕНО)
`core/sources/owners.py` (новый), подключения в activities/calls/dossier.
- Батч crm.{lead,contact,deal}.get по уникальным crm_entity фактов при эмите.
  Владелец не найден → факт СОХРАНЯЕТСЯ с payload.owner_status=dangling +
  evidence.owner_dangle; warning «owner dangle: N ссылок…» → PARTIAL, не VERIFIED.
  Батч недоступен → fail-closed warning «существование владельцев не подтверждено».
- coverage.owner_check = {checked, dangling, dangling_refs, …}.
- Live-подтверждение (manager_day 20114@02.11): dangling 3 — contact:16972,
  contact:17010, contact:17016 (эталонная activity 1001974 «Исходящий звонок
  Михаилу (13 мин)», OWNER contact:17016 при живой сделке 17016). Факт сохранён
  с dangling-маркером, статус PARTIAL.

## 3. F3 — client_dossier в core (РЕАЛИЗОВАН)
`core/sources/dossier.py` (~600 строк), dispatch в `core/collect.py`.
- Идентификация GC-4: только точный type+ID; echo `contact:16790`; призрак →
  FAILED NOT_FOUND без автоподбора; имя — не ключ (SCHEMA).
- Кластер GC-2/GC-5: findbycomm по ≤5 номерам + conv_links; карточки батчем;
  суждения дублей: 2+ ключа (phone+im_profile) → «вероятный дубль», 1 ключ →
  «возможный дубль…не сливаются»; истории дублей НЕ переименовываются; warning
  о неоднозначности («досье строго по echo»).
- Телефония: voximpl первичен через calls.db (READ-ONLY mode=ro, потолок 2000);
  пары voximpl+activity = один факт (инцидент 05.08), activity в evidence;
  «призрачные» звонки calls.db дочитываются crm.activity.get (только TYPE_ID=2).
- Таймлайн: owner-обход ≤12 членов (OWNER, не BINDINGS — GC-3); сделка без
  звонков при звонках в кластере → warning «привязка звонков сломана…НЕ обвинение
  менеджера» (GC-2/GC-7); этапы сделок (GC-9: без причин/сроков, автор
  недоступен → CONNECTOR); тексты — стаб core (text=None, SUBJECT не парсится,
  GC-10), NOT_IMPLEMENTED снимается интеграцией при стыке с messages.
- Live-подтверждение (contact 16790): кластер {16790, 8868, lead 9080, сделки
  9338+17016}; звонки по кластеру 5+7+10=22 (эталон admin2 5+7+9=21 — десятый
  звонок 1003054 появился в CRM ПОСЛЕ среза приёмки 09.11, проверено по
  calls.db/CRM); обе сделки 17016 и 9338 в deals_without_calls с этичным
  warning; дубль 8868 = «вероятный дубль (2+ ключа)»; 100 фактов stage_change.
- [ФАКТ, live] crm.stagehistory.list на боевом портале: camelCase
  (entityTypeId/entityId), ответ result.items, CREATED_TIME ISO → фикс в
  core+whitelist с UPPER-fallback.

## 4. Бонус-фиксы по пути
- `messages/msg/client.py`: batch result_error в форме LIST (PHP packed array,
  падение ВСЕХ команд) нормализуется в карту per-cmd (`_cmd_map`) — ошибки
  больше не теряются молча; + 6 тестов (`messages/tests/test_batch_list.py`).
- `core/config.py`: exclude_users теперь int (строки .env не совпадали с int
  AUTHOR_ID — бот не опознавался в live); V3_CALLS_DB — стендовая подмена
  обезличенной копии calls.db.
- `core/facts.py`: author_id коэрсия int|None во всех ветках (§4).
- `staging/mock_b24.py`: ID-фильтр/скаляризация для crm.*.get в батчах,
  values_by_key по скалярному ключу; `staging/integrated.py`: result-блок core
  прокидывается в объединённый ответ; merge-сообщение для client_dossier честное
  («CRM-часть собрана core v0.3.0»).
- CORE_VERSION 0.3.0 — кэш v3_cache.db старых ответов инвалидирован.

## 5. Тесты
- core: **128 passed** (было 103; +25: GC-1 бот-задачи, GC-8 dangle, GC-4/2/5/9/10
  досье, author_id-int).
- messages: **90 passed** (включая мои 6 batch-LIST; блокеры F4/F5 коллега
  докрутил параллельно в своей зоне до зелёного).
- staging selftest PASS; mock-прогоны 4 интентов: leads VERIFIED / manager
  PARTIAL / calls PARTIAL / dossier PARTIAL 26 фактов (21 кластер + 1 dangle,
  бот BOT, дубль 2+ ключа, этапы, тексты-стаб, маска ****0001, calls.db RO).

## 6. Live read-only пробы (бюджет соблюдён: 52 вызова из ~60)
Лог: `qa/results/live_calls_20261109_core03.jsonl` (формат admin2, без токенов,
телефоны в маске). Артефакты в `staging/results/`:
- live_manager_day_20116_1107.json (4 REST) — бот 17316 → BOT
- live_dossier_16790.json (19 REST) — кластер, дубли, deals_without_calls
- live_manager_day_20114_1102.json (4 REST) — GC-8 dangle×3, PARTIAL
- live_dossier_16790_v2.json (19 REST) — stage_change 100, cluster 22
- + 6 прямых проб (activity 1001974, stagehistory int/str/camel)

## 7. Остаточные риски (НЕ входили в мою задачу / чужие зоны)
- F1 Авито (модуль messages), F4 OL offset-потолок, F5 history недобор — зона
  dev_agent; на момент финального прогона тесты messages зелёные (90), но
  приёмку F4/F5 не пере гонял — за владельцем модуля.
- D7/D8/D10 (описание в вердикте admin2) — не входили в «ПЕРЕДЕЛАТЬ» моей зоны.
- F3 в `qa/acceptance_admin2.py` захардкожен в FAIL — скрипту приёмки нужен
  апдейт под core 0.3.0 при переприёмке.
- stagehistory: читается ОДНА страница на сделку (потолок page_limit) — при
  сверхдлинной истории этапов усечение отмечено в coverage.note.
- calls.db неполный по старым звонкам (эталон 1001974 в нём отсутствует) —
  dangle-ловушка срабатывает только если активность дошла до owner-обхода
  (manager_day/кластер); «висящие в никуда» активности вне обхода остаются
  невидимыми — это свойство данных, не ядра.

## 8. Готовность к интеграции
Core 0.3.0 готов для переприёмки и интеграции главному админу: блокеры C13/D5
закрыты, F3 реализован, кэш инвалидирован, стенд (mock) и live проверены.
Файлы зон не конфликтовавших с параллельной работой не тронуты; боевой РОП/CRM/
вебхуки/права не изменялись (только чтение REST).
