# Приёмка интеграции v3 Lite (стенд) — вердикт admin2

Дата: 09.11.2026 (ночь). Задача моста: mw8cluyez7kk.
Вердикт: **ПРИНЯТО с замечаниями** (ни одно не блокирует интеграцию и схему).

## Независимо проверено admin2

- Тесты перезапущены: core 103 passed, messages 67 passed — сходятся.
- Контракт-чек усилен (FAILED без errors = нарушение fail-closed §4): подтверждено
  кодом airop_staging.py:144 и следом до/после фикса (до-фиксный прогон 0cd836d3 —
  реальная ошибка «PARTIAL без указания причины», пост-фиксные acc-* 6/6 чистые).
- 5 эталонных E2E-артефактов сверены поэлементно:
  70578082 leads_day VERIFIED 18, first_touch 9/9, cmd_missing=0;
  9ec54c9f calls_day VERIFIED 37, voximpl 37/37 matched, unmatched 0;
  a555c503 manager_day PARTIAL 133, msg_api_calls 148, 26 warnings;
  275c2fd5 GC-2 FAILED 0 фактов, ровно 1 объяснённая ошибка NOT_IMPLEMENTED/core;
  da60fee2 GC-10 PARTIAL 19 (чат 31122 = 8 фактов, сессии 29382+29384).
- ol=dead сквозной (044be709): SOURCE_NET, core-факты целы; ol=off — PARTIAL с warning.
- Живой спот-чек воспроизводимости (acc2-admin2-ld): leads_day 07.11 — VERIFIED,
  18 фактов, first_touch 9/9, cmd_missing=0, 4,5 с. Полное совпадение с 70578082.
- Прод не тронут: ~/AiRop/*.py без изменений 9.11, calls.db mtime 8.11 22:11.
- Недоборы history.get: 25396 — 50/143; 29382 — 11/4; 29384 — 8/1 (в обе стороны),
  offset-окно ~10200 — подтверждены в warnings a555c503.

## Решение по открытым пунктам SCHEMA_RECONCILIATION.md

1. **Статус-отображение — УТВЕРЖДЕНО (решение-1).** Канонический статус — §4
   (VERIFIED/PARTIAL/FAILED); narrator v0.1 — display-слой с детерминированным
   маппингом VERIFIED→ok, PARTIAL→partial, FAILED→error. Правка спеки §4 не нужна.
2. **openlines в coverage.channels — УТВЕРЖДЕНО (расширение черновика v0.1→v0.2).**
   Условие: семантика «true только при реально ответившем источнике» должна
   выполняться и в коде (см. замечание З-1).
3. **Блокер client_dossier — ПОДТВЕРЖДЁН** ([DEV] CRM-часть core NOT_IMPLEMENTED,
   0 REST; GC-2 требует 21 звонок кластера: лид 9080=5, контакт 8868=7, контакт
   16790=9). Поведение интеграции принято: честный FAILED (GC-2) / PARTIAL при
   фактах партнёра с merge_notes (GC-10). Блокирует боевой интент dossier, не приёмку.

## Замечания (крайний срок — до боевого использования narrator-пакета)

- **З-1 (среднее, narrator):** narrator_packet.src_ok — fallback-ветка
  `any(k.startswith(prefix))` даёт канал=true даже при ошибке источника:
  противоречит SCHEMA_RECONCILIATION п.4. В принятых артефактах НЕ проявилось
  (каналы a555c503/da60fee2 проверены — честные), поправить до использования
  narrator-слоя. Заодно убрать `not isinstance(v, dict) == False` (≡ isinstance).
- **З-2 (низкое, merge):** `as_of = max(...)` падает ValueError при обоих модулях
  без as_of (core без JSON + msg без JSON) — крах вместо честного FAILED. Дать default.
- **З-3 (низкое, CLI):** `--ol off` для интентов без ОЛ (leads_day/calls_day)
  занижает VERIFIED до PARTIAL с нерелевантным warning. Валидировать по OL_INTENTS.
- **З-4 (среднее, процесс):** live-режим integrated.py не учитывает квот-гвард
  STAGING_LIVE_DAILY_MAX (есть только в airop_staging.run). Сегодняшние live-E2E
  его уже превысили бы (148+53+56 msg-вызовов + core REST). Подключить счётчик
  по runs.jsonl или переформулировать README.
- **З-5 (низкое, процесс):** staging/fixtures/dataset_messages_day.json — rw- и вне
  SHA256SUMS, хотя каталог заявлен immutable (444+uchg). Залочить или перенести.

## Открытые задачи (зафиксированы, не блокируют приёмку)

- [DEV] CRM-часть client_dossier (кластер, звонки, дела, таймлайн).
- [DEV Agent] history.get недобор/излишек против messageCount (25396, 29382, 29384),
  offset-окно ~10200.
