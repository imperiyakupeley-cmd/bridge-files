#!/usr/bin/env python3
"""Тестовый CLI стенда v3 Lite (инфраструктура, не лезет в прод).

Команды:
  secrets-status                  — доступность секретов (masked, без значений)
  selftest                        — бут mock-сервера + один синтетический вызов
  run [--mock|--live] ...         — полный цикл: запрос → run.py → контракт-чек → логи
  ping-live [--ol]                — 1 read-only вызов в Б24 (квот-гвард, lock)
  contract-check FILE             — валидация ответа против спеки §4
  integration                     — сценарный интеграционный прогон (mock+db-ro)
  quota                           — счётчики 429/500/NET за сегодня + квот-лимиты

Правила стенда: lock на прогон, таймаут на подпроцесс, логирование каждого
HTTP-вызова (mock: пер-вызов; live: пер-источник из coverage/errors),
квот-гвард живых вызовов (default 200/сутки, env STAGING_LIVE_DAILY_MAX).
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import subprocess
import sys
import time
import urllib.request
import uuid
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
V3LITE = os.path.dirname(HERE)
RUN_PY = os.path.join(V3LITE, "run.py")
PY = sys.executable or "/opt/homebrew/bin/python3"
LOGS = os.path.join(HERE, "logs")
RESULTS = os.path.join(HERE, "results")
RUNS_LOG = os.path.join(LOGS, "runs.jsonl")
LOCK = os.path.join(HERE, "lock")
FIXTURES = os.path.join(HERE, "fixtures")
LIVE_DAILY_MAX = int(os.environ.get("STAGING_LIVE_DAILY_MAX", "200"))

sys.path.insert(0, HERE)
import secrets as staging_secrets  # noqa: E402
from mock_b24 import MockB24       # noqa: E402

STATUSES = {"VERIFIED", "PARTIAL", "FAILED"}


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds") + "+03:00"


def today_key() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def append_runs(rec: dict):
    os.makedirs(LOGS, exist_ok=True)
    rec["ts"] = now_iso()
    with open(RUNS_LOG, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, ensure_ascii=False) + "\n")


class StagingLock:
    """Один прогон стенда одновременно (flock, боевые процессы не затрагиваются)."""

    def __init__(self):
        self.fh = None

    def __enter__(self):
        os.makedirs(LOGS, exist_ok=True)
        self.fh = open(LOCK, "w")
        fcntl.flock(self.fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        self.fh.write(f"{os.getpid()} {now_iso()}\n")
        self.fh.flush()
        return self

    def __exit__(self, *exc):
        fcntl.flock(self.fh, fcntl.LOCK_UN)
        self.fh.close()
        return False


# ------------------------------------------------------------- контракт §3
def build_request(a) -> dict:
    req = {"intent": a.intent, "request_id": a.request_id or str(uuid.uuid4()),
           "tz": "Europe/Moscow"}
    if a.from_date:
        req["from"] = a.from_date
    if a.to_date:
        req["to"] = a.to_date
    if a.employee_id:
        req["employee_id"] = int(a.employee_id)   # §3: целое
    if a.entity_type or a.entity_id:
        req["entity"] = {"type": a.entity_type, "id": a.entity_id}
    if a.options:
        req["options"] = json.loads(a.options)
    return req


def local_schema_check(req: dict) -> list[str]:
    """Обязательность полей §3 (до похода куда-либо)."""
    errs = []
    intent = req.get("intent")
    if intent not in {"leads_day", "calls_day", "manager_day", "client_dossier"}:
        return [f"SCHEMA: неизвестный intent {intent!r}"]
    has_from, has_to = bool(req.get("from")), bool(req.get("to"))
    has_emp, has_ent = "employee_id" in req, "entity" in req
    if intent in {"leads_day", "calls_day"}:
        if not (has_from and has_to):
            errs.append("SCHEMA: from/to обязательны")
        if has_emp or has_ent:
            errs.append("SCHEMA: employee_id/entity запрещены для дневных интентов")
    if intent == "manager_day":
        if not (has_from and has_to and has_emp):
            errs.append("SCHEMA: from/to + employee_id обязательны")
        if has_ent:
            errs.append("SCHEMA: entity запрещён для manager_day")
    if intent == "client_dossier":
        if not has_ent:
            errs.append("SCHEMA: entity обязателен")
        if has_emp:
            errs.append("SCHEMA: employee_id запрещён для client_dossier")
    return errs


# ------------------------------------------------------------- контракт §4
def contract_check(resp: dict, req: dict | None = None) -> list[str]:
    errs = []
    for key in ("request_id", "intent", "status", "as_of", "facts", "coverage",
                "warnings", "errors"):
        if key not in resp:
            errs.append(f"§4: нет ключа {key!r}")
    if resp.get("status") not in STATUSES:
        errs.append(f"§4: status {resp.get('status')!r} не из {sorted(STATUSES)}")
    if req and resp.get("request_id") != req.get("request_id"):
        errs.append("§4: request_id не эхо запроса")
    if not isinstance(resp.get("facts", []), list):
        errs.append("§4: facts не список")
    st = resp.get("status")
    if st == "VERIFIED" and (resp.get("warnings") or resp.get("errors")):
        errs.append("§4: VERIFIED при непустых warnings/errors — нечестно")
    if st == "PARTIAL" and not (resp.get("warnings") or resp.get("errors")):
        errs.append("§4: PARTIAL без указания причины")
    if st == "FAILED" and not resp.get("errors"):
        errs.append("§4: FAILED без errors — отказ не объяснён (fail-closed)")
    for i, f in enumerate(resp.get("facts", []) or []):
        for key in ("fact_type", "source", "source_entity_id", "timestamp"):
            if key not in f:
                errs.append(f"§4: facts[{i}] нет {key!r}")
    return errs


# ------------------------------------------------------------------- run
def cmd_run(a) -> int:
    req = build_request(a)
    schema_errs = local_schema_check(req)
    if schema_errs and not a.expect_schema_fail:
        print(json.dumps({"staging": "local_schema_reject", "errors": schema_errs},
                         ensure_ascii=False))
        append_runs({"request_id": req.get("request_id"), "mode": a.mode,
                     "intent": a.intent, "exit_code": 2, "response_status": None,
                     "schema_reject": schema_errs})
        return 2

    mock = None
    env = dict(os.environ)
    env["V3_CACHE"] = "0"                      # не трогаем v3_cache.db DEV
    http_log = os.path.join(LOGS, f"http_{req['request_id']}.jsonl")
    os.makedirs(LOGS, exist_ok=True)

    if a.mode == "mock":
        ds_path = a.dataset or os.path.join(FIXTURES, f"dataset_{a.intent}.json")
        with open(ds_path, encoding="utf-8") as fh:
            ds = json.load(fh)
        if a.faults:
            ds.setdefault("faults", {}).update(json.loads(a.faults))
        mock = MockB24(ds, http_log)
        port = mock.start()
        hook = f"http://127.0.0.1:{port}/stage/{req['request_id']}/rest/mock"
        env["V3_WEBHOOK"] = hook
        env["V3_OL_WEBHOOK"] = hook
    else:  # live: секреты из существующих хранилищ, в env — только значения
        if live_calls_today() >= LIVE_DAILY_MAX:
            print(json.dumps({"staging": "QUOTA_EXCEEDED",
                              "live_calls_today": live_calls_today(),
                              "max": LIVE_DAILY_MAX}, ensure_ascii=False))
            return 3
        env["V3_OL_WEBHOOK"] = staging_secrets.ol_owner_webhook()
        # V3_WEBHOOK не ставим: core сам читает ~/AiRop/.env (BX_WEBHOOK Анны)

    timeout = a.timeout or (120 if a.mode == "mock" else 300)
    t0 = time.monotonic()
    timed_out = False
    try:
        proc = subprocess.run([PY, "-I", RUN_PY], input=json.dumps(req),
                              capture_output=True, text=True, timeout=timeout,
                              env=env, cwd=V3LITE)
        out, exit_code, stderr = proc.stdout, proc.returncode, proc.stderr
    except subprocess.TimeoutExpired as e:
        timed_out, exit_code = True, 124
        out = ""
        stderr = f"staging: таймаут {timeout}s"
    finally:
        if mock:
            mock.stop()

    wall_ms = round((time.monotonic() - t0) * 1000, 1)
    resp, cerrs = None, []
    try:
        resp = json.loads(out)
        cerrs = contract_check(resp, req)
    except (json.JSONDecodeError, TypeError):
        cerrs = [f"ответ не JSON (первые 200 знаков): {out[:200]!r}"]

    os.makedirs(RESULTS, exist_ok=True)
    res_path = os.path.join(RESULTS, f"{today_key()}_{req['request_id']}.json")
    with open(res_path, "w", encoding="utf-8") as fh:
        json.dump({"request": req, "response": resp, "contract_errors": cerrs,
                   "wall_ms": wall_ms, "exit_code": exit_code,
                   "timed_out": timed_out, "mode": a.mode,
                   "stderr_tail": stderr[-500:]}, fh, ensure_ascii=False, indent=1)

    stats = http_stats(http_log) if a.mode == "mock" else live_source_status(resp)
    append_runs({"request_id": req["request_id"], "mode": a.mode,
                 "intent": a.intent, "wall_ms": wall_ms, "exit_code": exit_code,
                 "timed_out": timed_out,
                 "response_status": resp.get("status") if resp else None,
                 "http_calls": stats.get("calls", 0),
                 "http_429": stats.get("429", 0), "http_5xx": stats.get("5xx", 0),
                 "sources": stats.get("sources"),
                 "result_file": res_path})
    print(json.dumps({"request_id": req["request_id"], "mode": a.mode,
                      "status": resp.get("status") if resp else None,
                      "facts": len(resp.get("facts", [])) if resp else 0,
                      "wall_ms": wall_ms, "contract_errors": cerrs,
                      "http": {k: v for k, v in stats.items() if k != "sources"},
                      "result_file": res_path}, ensure_ascii=False, indent=1))
    return 0 if (resp and not cerrs) else 1


def http_stats(path: str) -> dict:
    stats = {"calls": 0, "200": 0, "429": 0, "5xx": 0, "other": 0, "sources": {}}
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except json.JSONDecodeError:
                    continue
                stats["calls"] += 1
                s = str(r.get("call_status"))
                if s == "200":
                    stats["200"] += 1
                elif s == "429":
                    stats["429"] += 1
                elif s.startswith("5"):
                    stats["5xx"] += 1
                else:
                    stats["other"] += 1
                src = r.get("source", "?")
                stats["sources"][src] = stats["sources"].get(src, 0) + 1
    except FileNotFoundError:
        pass
    return stats


def live_source_status(resp: dict | None) -> dict:
    """Live: пер-источник из coverage/errors (пер-вызов логирует только mock)."""
    if not resp:
        return {"sources": {}}
    srcs = {k: "ok" for k in (resp.get("coverage") or {})}
    for e in resp.get("errors") or []:
        srcs[e.get("source", "?")] = f"err:{e.get('code', '?')}"
    return {"sources": srcs}


def live_calls_today() -> int:
    n = 0
    try:
        with open(RUNS_LOG, encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if r.get("ts", "").startswith(today_key()) and r.get("mode") == "live":
                    n += r.get("http_calls") or (1 if r.get("intent") == "ping" else 0)
    except FileNotFoundError:
        pass
    return n


# ------------------------------------------------------------ ping/quota
def cmd_ping_live(a) -> int:
    with StagingLock():
        if live_calls_today() >= LIVE_DAILY_MAX:
            print(json.dumps({"staging": "QUOTA_EXCEEDED"}, ensure_ascii=False))
            return 3
        if a.ol:
            hook = staging_secrets.ol_owner_webhook()
            method = "imopenlines.v2.Session.list"
            params = {"start": 0}
        else:
            hook = staging_secrets.bx_webhook()
            method = "crm.lead.list"
            params = {"order[ID]": "DESC", "start": 0}
        if not hook:
            print(json.dumps({"staging": "no_webhook", "ol": a.ol}))
            return 2
        url = f"{hook.rstrip('/')}/{method}.json?" + "&".join(
            f"{k}={v}" for k, v in params.items())
        t0 = time.monotonic()
        code, kind = None, "net_err"
        try:
            with urllib.request.urlopen(url, timeout=10) as r:
                code = r.status
                kind = "ok" if r.status == 200 else str(r.status)
        except urllib.error.HTTPError as e:
            code, kind = e.code, str(e.code)
        except Exception as e:
            kind = f"net_err:{type(e).__name__}"
        ms = round((time.monotonic() - t0) * 1000, 1)
        append_runs({"request_id": f"ping-{uuid.uuid4().hex[:8]}", "mode": "live",
                     "intent": "ping", "http_calls": 1, "call_status": kind,
                     "latency_ms": ms, "target": method})
        print(json.dumps({"target": method, "call_status": kind,
                          "http_code": code, "latency_ms": ms,
                          "webhook": staging_secrets.mask(hook)},
                         ensure_ascii=False))
        return 0 if kind == "ok" else 1


def cmd_quota(a) -> int:
    day = today_key()
    totals = {"429": 0, "5xx": 0, "live_calls": 0, "runs": 0}
    per_src = {}
    try:
        with open(RUNS_LOG, encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not r.get("ts", "").startswith(day):
                    continue
                totals["runs"] += 1
                if r.get("mode") == "live":
                    totals["live_calls"] += r.get("http_calls") or 0
                totals["429"] += r.get("http_429") or 0
                totals["5xx"] += r.get("http_5xx") or 0
                for src, st in (r.get("sources") or {}).items():
                    if isinstance(st, str) and st.startswith("err:"):
                        per_src[src] = per_src.get(src, 0) + 1
    except FileNotFoundError:
        pass
    alerts = []
    if totals["429"]:
        alerts.append(f"429 за сегодня: {totals['429']} (проверить rate-limit/backoff)")
    if totals["5xx"]:
        alerts.append(f"5xx за сегодня: {totals['5xx']}")
    if totals["live_calls"] >= LIVE_DAILY_MAX * 0.8:
        alerts.append(f"live-вызовы {totals['live_calls']}/{LIVE_DAILY_MAX} — близко к лимиту стенда")
    alert_path = os.path.join(LOGS, "alerts.json")
    os.makedirs(LOGS, exist_ok=True)
    with open(alert_path, "w", encoding="utf-8") as fh:
        json.dump({"day": day, "totals": totals, "per_source_errors": per_src,
                   "alerts": alerts}, fh, ensure_ascii=False, indent=1)
    print(json.dumps({"day": day, **totals, "per_source_errors": per_src,
                      "alerts": alerts,
                      "bridge_limits": {
                          "mcp_bridge_result_chars": 16000,
                          "a2a_dispatch_timeout_s": 600}},
                     ensure_ascii=False, indent=1))
    return 0


def cmd_selftest(a) -> int:
    ds = {"methods": {"crm.lead.list": {"rows": [
        {"ID": "1", "TITLE": "Обезличенный лид", "DATE_CREATE": "07.11.2026 10:00:00"},
        {"ID": "2", "TITLE": "Вне окна", "DATE_CREATE": "06.11.2026 10:00:00"}]}}}
    m = MockB24(ds, None)
    port = m.start()
    ok = True
    try:
        url = (f"http://127.0.0.1:{port}/stage/selftest/rest/mock/crm.lead.list.json"
               f"?FILTER%5B%3E%3DDATE_CREATE%5D=07.11.2026%2000%3A00%3A00")
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(url, timeout=5) as r:
            body = json.loads(r.read())
        rows = body.get("result", [])
        ok = (len(rows) == 1 and rows[0]["ID"] == "1" and body.get("total") == 1)
        print(json.dumps({"selftest": "PASS" if ok else "FAIL", "port": port,
                          "rows": len(rows), "total": body.get("total")}))
    finally:
        m.stop()
    return 0 if ok else 1


def cmd_secrets_status(a) -> int:
    print(json.dumps(staging_secrets.status_report(), ensure_ascii=False, indent=1))
    return 0


def cmd_contract_check(a) -> int:
    with open(a.file, encoding="utf-8") as fh:
        data = json.load(fh)
    resp = data.get("response", data)
    req = data.get("request")
    errs = contract_check(resp, req)
    print(json.dumps({"file": a.file, "contract_errors": errs,
                      "status": resp.get("status")}, ensure_ascii=False, indent=1))
    return 0 if not errs else 1


def cmd_integration(a) -> int:
    """Сценарный прогон: happy-path, 429-fault, схема-мусор, calls_day(db-ro)."""
    scenarios = [
        {"name": "leads_day_happy", "args": ["run", "--mode", "mock",
         "--intent", "leads_day", "--from", "2026-11-07T00:00:00+03:00",
         "--to", "2026-11-08T00:00:00+03:00"]},
        {"name": "leads_day_429x2", "args": ["run", "--mode", "mock",
         "--intent", "leads_day", "--from", "2026-11-07T00:00:00+03:00",
         "--to", "2026-11-08T00:00:00+03:00",
         "--faults", '{"crm.activity.list":{"status":429,"times":2}}']},
        {"name": "manager_day_mock", "args": ["run", "--mode", "mock",
         "--intent", "manager_day", "--employee-id", "401",
         "--from", "2026-11-07T00:00:00+03:00",
         "--to", "2026-11-08T00:00:00+03:00"]},
        {"name": "calls_day_db_ro", "args": ["run", "--mode", "mock",
         "--intent", "calls_day", "--from", "2026-11-07T00:00:00+03:00",
         "--to", "2026-11-08T00:00:00+03:00"]},
        {"name": "bad_schema_local_reject", "args": ["run", "--mode", "mock",
         "--intent", "manager_day", "--from", "2026-11-07T00:00:00+03:00",
         "--to", "2026-11-08T00:00:00+03:00",
         "--options", '{"мусорный_ключ": 1}'], "expect": "SCHEMA_REJECT"},
        {"name": "schema_fail_via_core", "args": ["run", "--mode", "mock",
         "--intent", "client_dossier", "--entity-type", "lead",
         "--entity-id", "1", "--request-id", "schema-probe-1"],
         "expect": "FAILED_OR_PARTIAL"},
    ]
    summary = []
    rc = 0
    for sc in scenarios:
        p = subprocess.run([PY, "-I", os.path.abspath(__file__)] + sc["args"],
                           capture_output=True, text=True, timeout=400)
        try:
            out = json.loads(p.stdout)
        except json.JSONDecodeError:
            out = {"raw": p.stdout[-300:]}
        st = out.get("status")
        name = sc["name"]
        if sc.get("expect") == "SCHEMA_REJECT":
            ok = p.returncode == 2 or st is None
        elif sc.get("expect") == "FAILED_OR_PARTIAL":
            ok = st in {"FAILED", "PARTIAL"}
        else:
            ok = st in {"VERIFIED", "PARTIAL"} and not out.get("contract_errors")
        if name == "leads_day_happy":
            ok = ok and st == "VERIFIED"
        summary.append({"scenario": name, "ok": bool(ok), "status": st,
                        "facts": out.get("facts"),
                        "http": {k: out.get(k) for k in
                                 ("http_calls", "http_429", "http_5xx", "wall_ms")},
                        "contract_errors": out.get("contract_errors"),
                        "rc": p.returncode})
        rc = rc or (0 if ok else 1)
    path = os.path.join(RESULTS, f"integration_{today_key()}.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"ts": now_iso(), "summary": summary}, fh, ensure_ascii=False, indent=1)
    print(json.dumps({"integration": "PASS" if rc == 0 else "FAIL",
                      "scenarios": summary, "file": path},
                     ensure_ascii=False, indent=1))
    return rc


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("secrets-status").set_defaults(func=cmd_secrets_status)
    sub.add_parser("selftest").set_defaults(func=cmd_selftest)

    p = sub.add_parser("run")
    p.add_argument("--mode", choices=["mock", "live"], default="mock")
    p.add_argument("--intent", required=True)
    p.add_argument("--from", dest="from_date")
    p.add_argument("--to", dest="to_date")
    p.add_argument("--employee-id")
    p.add_argument("--entity-type")
    p.add_argument("--entity-id", type=int)
    p.add_argument("--request-id")
    p.add_argument("--options", help="JSON для поля options")
    p.add_argument("--dataset", help="свой датасет mock (по умолчанию fixtures/dataset_<intent>.json)")
    p.add_argument("--faults", help='JSON: {"метод":{"status":429,"times":N}}')
    p.add_argument("--timeout", type=int)
    p.add_argument("--expect-schema-fail", action="store_true")
    p.set_defaults(func=cmd_run)

    p = sub.add_parser("ping-live")
    p.add_argument("--ol", action="store_true")
    p.set_defaults(func=cmd_ping_live)

    p = sub.add_parser("contract-check")
    p.add_argument("file")
    p.set_defaults(func=cmd_contract_check)

    sub.add_parser("quota").set_defaults(func=cmd_quota)
    sub.add_parser("integration").set_defaults(func=cmd_integration)

    args = ap.parse_args()
    if args.cmd == "run":
        with StagingLock():
            return args.func(args)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
