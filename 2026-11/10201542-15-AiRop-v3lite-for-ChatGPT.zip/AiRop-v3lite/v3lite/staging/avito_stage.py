"""Третий слой интеграции: Авито messenger v3 (F1, спека §5) — стык в staging.

Пайплайн (задача моста mw90nse1i7j9, 09.11):
  core → messages (B24 ОЛ) → avito_adapter(avito_merge + collect) → merge §4

Что делает этот модуль (только staging, ничьи исходники не трогаются):
1. facts→rows: факты сообщений модуля messages конвертируются в b24-вход
   joiner'а (adapter/joiner.py): {chat_id: {users, messages}}. Роли не
   выдумываются — users-блок строится ПО разрешённой роли факта
   (CLIENT→connector, BOT→bot, WE→пустой), поэтому b24_role() возвращает
   ровно ту же роль и resolved=True (без ложных warnings).
2. Чаты линии Авито (line.id=2 [ФАКТ sessions.py] или есть u2i в боевом
   индексе night-bot) идут в joiner; прочие линии (TG/VK/MAX/WA) остаются
   как есть — их факты не заменяются (замена = только для чатов, прошедших
   склейку двух источников).
3. mapping chat↔u2i — read-only импорт боевого openline_index.json
   (~/Avito/night-bot/openline_index.json, тот же файл читает адаптер).
4. Прогон avito_adapter/run.py intent=avito_merge:
   - live: collect за окно (read-only, AVITO_ADAPTER_LIVE=1), chat_ids=
     u2i чатов менеджера (для manager_day) или без ограничения;
   - mock: без сети — avito-строки передаются инлайн из фикстуры стенда.
5. apply_avito(): замена message-фактов вошедших чатов на склеенные
   (merged/b24.ol/avito.v3), transfer-факты и факты невошедших чатов
   сохраняются; payload исходных фактов дописывается в склеенные (только
   аддитивные ключи session_id/line/has_files — данные не теряются).
   Статус: worst(core, messages, avito); VERIFIED при warnings запрещён §4.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
V3LITE = os.path.dirname(HERE)
AVITO_RUN = os.path.join(V3LITE, "avito_adapter", "run.py")
AVITO_CWD = os.path.join(V3LITE, "avito_adapter")
BOT_INDEX = os.path.expanduser("~/Avito/night-bot/openline_index.json")
AVITO_LINE_ID = 2           # линия «Авито» в v2.Session.list [ФАКТ sessions.py]
MSG_SOURCE = "imopenlines.session.history.get"

# ключи payload msg-факта, которые дописываем в склеенные факты (не терять)
_ADDITIVE = ("session_id", "line", "has_files")


def load_bot_index() -> dict[int, str]:
    """{chatId: u2i} из боевого индекса ночного бота (read-only)."""
    try:
        with open(BOT_INDEX, encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return {}
    out: dict[int, str] = {}
    for u2i, chat in (data.get("map") or {}).items():
        try:
            out[int(chat)] = str(u2i)
        except (TypeError, ValueError):
            continue
    return out


def _chat_of(fact: dict) -> int | None:
    p = fact.get("payload") or {}
    cid = p.get("chat_id")
    if cid is None:
        seid = str(fact.get("source_entity_id") or "")
        if seid.startswith("chat") and "#msg" in seid:
            try:
                cid = int(seid[4:seid.index("#")])
            except ValueError:
                return None
        else:
            return None
    try:
        return int(cid)
    except (TypeError, ValueError):
        return None


def _msg_id_of(fact: dict) -> str | None:
    seid = str(fact.get("source_entity_id") or "")
    return seid.split("#msg", 1)[1] if "#msg" in seid else None


def facts_to_b24_chats(msg_facts: list[dict], index: dict[int, str]):
    """Факты messages → (chats, meta). Только fact_type=message с chat_id.

    meta: {"chats": {chat_id: {"u2i", "line_id"}}, "replaced_keys": set(),
           "kept_facts": [...]} — replaced = ключи source_entity_id вошедших
    чатов (сообщения), kept = transfer-факты и факты чужих линий.
    """
    chats: dict[str, dict] = {}
    meta_chats: dict[int, dict] = {}
    replaced: set[str] = set()
    kept: list[dict] = []
    for f in msg_facts or []:
        if f.get("fact_type") != "message" or f.get("source") != MSG_SOURCE:
            kept.append(f)                      # transfer-факты и пр. — как есть
            continue
        cid = _chat_of(f)
        mid = _msg_id_of(f)
        if cid is None or mid is None:
            kept.append(f)
            continue
        p = f.get("payload") or {}
        line_id = (p.get("line") or {}).get("id")
        u2i = index.get(cid)
        # в склейку идут только чаты Авито: линия 2 или известный u2i
        if not (u2i or line_id == AVITO_LINE_ID):
            kept.append(f)
            continue
        role = f.get("author_role")
        chat = chats.setdefault(str(cid), {"users": [], "messages": []})
        users, seen_ids = chat["users"], chat.setdefault("_uids", set())
        aid = f.get("author_id")
        if p.get("system") or role == "CONNECTOR":
            row_auth = 0
        elif aid is not None:
            row_auth = aid
            a = str(aid)
            if a not in seen_ids:
                seen_ids.add(a)
                u = {"id": aid}
                if role == "CLIENT":
                    u["connector"] = True
                elif role == "BOT":
                    u["bot"] = True
                users.append(u)
        else:
            row_auth = 0
        row = {"id": mid, "author_id": row_auth,
               "date": f.get("timestamp"), "text": p.get("text")}
        cmid = p.get("connector_mid")
        if cmid:
            row["params"] = {"CONNECTOR_MID": cmid}
        chat.pop("_uids", None)
        chats[str(cid)]["messages"].append(row)
        replaced.add(str(f.get("source_entity_id")))
        meta_chats[cid] = {"u2i": u2i, "line_id": line_id}
    return chats, {"chats": meta_chats, "replaced_keys": replaced,
                   "kept_facts": kept}


def avito_request_for(msg_response: dict | None, req: dict, *, mode: str,
                      fixture_rows: dict | None = None,
                      bot_index: dict[int, str] | None = None):
    """Запрос для avito_adapter/run.py (intent=avito_merge) + meta.

    None → авито-слой не нужен (нет сообщений / нет чатов Авито).
    live: collect за окно [from,to); manager_day ограничиваем chat_ids
    (u2i чатов менеджера из b24-входа — точечно, без лишнего листинга).
    mock: avito-строки из фикстуры инлайн (сеть выключена — оффлайн адаптера).
    """
    if not msg_response or msg_response.get("status") == "FAILED":
        return None
    facts = msg_response.get("facts") or []
    if not facts:
        return None
    index = bot_index if bot_index is not None else load_bot_index()
    chats, meta = facts_to_b24_chats(facts, index)
    if not chats:
        return None
    mapping = {str(cid): info["u2i"] for cid, info in meta["chats"].items()
               if info.get("u2i")}
    out = {"intent": "avito_merge", "request_id": req["request_id"] + "-av",
           "b24": {"chats": chats}, "mapping": mapping}
    if mode == "live" and req.get("from") and req.get("to"):
        # collect только с окном; досье без окна — склейка по mapping/index
        collect = {"from": req["from"], "to": req["to"], "options": {}}
        if req["intent"] == "manager_day":
            u2is = sorted({u for u in mapping.values()})
            if u2is:
                collect["options"] = {"chat_ids": u2is}
        out["collect"] = collect
    elif fixture_rows:
        # демо-фикстура стенда: {"avito": {u2i: [rows]}, "mapping": {chat: u2i}}
        rows = fixture_rows.get("avito", fixture_rows)             if isinstance(fixture_rows, dict) else fixture_rows
        if rows:
            out["avito"] = rows
        for k, v in (fixture_rows.get("mapping") or {}).items()                 if isinstance(fixture_rows, dict) else []:
            mapping[str(k)] = str(v)
    return out, meta


def run_avito(request: dict, *, mode: str, timeout: int, env: dict) -> dict:
    """Подпроцесс avito_adapter/run.py (аналог run_module integrated.py)."""
    env = dict(env)
    if mode == "live":
        env["AVITO_ADAPTER_LIVE"] = "1"      # боевой read-only сбор Авито
    else:
        env.pop("AVITO_ADAPTER_LIVE", None)  # оффлайн: сеть адаптера выключена
    t0 = time.monotonic()
    try:
        proc = subprocess.run([sys.executable or "/opt/homebrew/bin/python3",
                               "-I", AVITO_RUN],
                              input=json.dumps(request), capture_output=True,
                              text=True, timeout=timeout, env=env, cwd=AVITO_CWD)
        out, rc, err, timed_out = proc.stdout, proc.returncode, proc.stderr, False
    except subprocess.TimeoutExpired:
        out, rc, err, timed_out = "", 124, "staging: avito timeout", True
    resp = None
    try:
        resp = json.loads(out)
    except (json.JSONDecodeError, TypeError):
        pass
    return {"response": resp, "wall_ms": round((time.monotonic() - t0) * 1000, 1),
            "exit_code": rc, "timed_out": timed_out, "stderr_tail": err[-400:]}


def apply_avito(merged: dict, avito: dict | None, meta: dict,
                timings: dict) -> dict:
    """Наложить авито-слой на объединённый ответ integrated.merge().

    avito=None/FAILED → факты messages остаются как есть, ошибка слоя
    добавляется (fail-closed: потери нет, полнота честно понижена).
    Успех → message-факты вошедших чатов заменены склеенными; transfer и
    прочие линии сохранены; статус worst(core, messages, avito).
    """
    modules = dict(merged.get("module_statuses") or {})
    coverage = dict(merged.get("coverage") or {})
    warnings = list(merged.get("warnings") or [])
    errors = [dict(e) for e in merged.get("errors") or []]
    detectors = dict(merged.get("detectors") or {})
    rank = {"VERIFIED": 0, "PARTIAL": 1, "FAILED": 2}

    resp = (avito or {}).get("response")
    ok = bool(resp) and resp.get("status") in ("VERIFIED", "PARTIAL")
    if resp:
        modules["avito"] = resp.get("status")
        for k, v in (resp.get("coverage") or {}).items():
            coverage["avito." + k] = v
        warnings += [f"[avito] {w}" for w in resp.get("warnings") or []]
        detectors["avito"] = resp.get("detectors") or {}
    else:
        modules["avito"] = "FAILED"
        errors.append({"code": "AVITO_NO_JSON", "source": "avito",
                       "module": "avito",
                       "detail": (avito or {}).get("stderr_tail")
                       or "avito-слой не вернул JSON"})
    if not ok:
        # слой упал: ничего не заменяем, факты messages не теряем
        merged = dict(merged)
        merged.update({"module_statuses": modules, "coverage": coverage,
                       "warnings": warnings, "errors": errors,
                       "detectors": detectors})
        merged["status"] = max((merged.get("status") or "FAILED",
                                "PARTIAL"), key=lambda s: rank.get(s, 2))
        merged.setdefault("merge_notes", []).append(
            "avito-слой недоступен: сообщения ОЛ даны только Б24-стороной "
            "(исходящие Авито/прогрев не проверены — F1)")
        merged["timings_ms"] = timings
        return merged

    # успех: замена message-фактов вошедших чатов склеенными
    replaced = meta.get("replaced_keys") or set()
    avito_facts = resp.get("facts") or []
    enriched = []
    orig_by_key = {str(f.get("source_entity_id")): f
                   for f in (merged.get("facts") or [])}
    for f in avito_facts:
        ev = f.get("evidence") or {}
        b24_key = (ev.get("b24") or {}).get("source_entity_id")
        if b24_key:
            orig = orig_by_key.get(str(b24_key))
            if orig:
                p = f.setdefault("payload", {})
                for k in _ADDITIVE:
                    if k in (orig.get("payload") or {}) and k not in p:
                        p[k] = orig["payload"][k]
        enriched.append(f)
    kept_facts = [f for f in (merged.get("facts") or [])
                  if str(f.get("source_entity_id")) not in replaced]
    merged = dict(merged)
    merged["facts"] = kept_facts + enriched
    merged.update({"module_statuses": modules, "coverage": coverage,
                   "warnings": warnings, "errors": errors,
                   "detectors": detectors, "timings_ms": timings})
    status = max((merged.get("status") or "FAILED", resp.get("status")),
                 key=lambda s: rank.get(s, 2))
    if warnings and status == "VERIFIED":
        status = "PARTIAL"                    # §4: VERIFIED при warnings запрещён
    merged["status"] = status
    cov = resp.get("coverage") or {}
    merged.setdefault("merge_notes", []).append(
        f"авито-слой: чатов склеено {len((cov.get('merge') or {}))}, "
        f"заменено message-фактов {len(replaced)}, добавлено "
        f"авито-фактов {len(enriched)} (F1, §5)")
    return merged
