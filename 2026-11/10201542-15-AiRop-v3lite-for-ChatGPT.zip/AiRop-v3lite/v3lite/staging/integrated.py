#!/usr/bin/env python3
"""Интегрированный CLI стенда v3 Lite: core (DEV) + messages (DEV Agent) → один
ответ контракта §3–§4 по 4 интентам (задача моста mw8cluyez7kk, 09.11).

Только staging: пишет исключительно в staging/{results,logs}; DEV-файлы core/
и messages/ не редактирует; боевой РОП, права, вебхуки — не трогает.

Интенты:
  leads_day      → core
  calls_day      → core
  manager_day    → core (звонки/TODO/activity-индекс) + messages_period
                  (sender_ids=[employee_id]) — стык §10 закрывается здесь
  client_dossier → core (кластер/звонки/дела) + messages_cluster

Опции источника ОЛ (--ol):
  auto — по умолчанию: messages-модуль запускается (mock: общий MockB24,
         live: существующий вебхук владельца ОЛ, новых прав нет);
  off  — ОЛ-источник отключён: warning + статус не выше PARTIAL
         (демо «PARTIAL при недоступном источнике»);
  dead — вебхук ОЛ указывает на закрытый порт: SOURCE_NET после ретраев,
         ядро-факты остаются, статус PARTIAL (fail-closed насквозь).

Схема narrator (--narrator): к ответу добавляется narrator_packet по черновику
~/AiRop/stand/rop-narrator-protocol.md v0.1 (status ok/partial/error) —
детерминированное отображение VERIFIED/PARTIAL/FAILED (см. SCHEMA_RECONCILIATION.md).

Выход: JSON на stdout (краткая сводка), полный артефакт в results/.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
V3LITE = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import airop_staging as st          # noqa: E402  (MockB24, contract_check, secrets, runs)
from mock_b24 import MockB24        # noqa: E402
import avito_stage as avi     # noqa: E402  (третий слой: Авито v3, F1)

PY = sys.executable or "/opt/homebrew/bin/python3"
CORE_RUN = os.path.join(V3LITE, "run.py")
MSG_RUN = os.path.join(V3LITE, "messages", "run.py")
FIXTURES = os.path.join(HERE, "fixtures")
DEAD_OL_HOOK = "http://127.0.0.1:9/rest/1/0000000000000000000000000000000x/dead"

STATUS_RANK = {"VERIFIED": 0, "PARTIAL": 1, "FAILED": 2}
NARRATOR_CHECK_TYPE = {"leads_day": "leads", "calls_day": "calls",
                       "manager_day": "manager_day", "client_dossier": "client_dossier"}
NARRATOR_STATUS = {"VERIFIED": "ok", "PARTIAL": "partial", "FAILED": "error"}
OL_INTENTS = {"manager_day", "client_dossier"}


# ------------------------------------------------------------------ запросы
def build_request(a) -> dict:
    rid = a.request_id or str(uuid.uuid4())
    req = {"intent": a.intent, "request_id": rid, "tz": "Europe/Moscow"}
    if a.from_date or a.to_date:
        req["from"], req["to"] = a.from_date, a.to_date
    if a.employee_id is not None:
        req["employee_id"] = a.employee_id
    if a.entity_type or a.entity_id:
        req["entity"] = {"type": a.entity_type, "id": a.entity_id}
    if a.options:
        req["options"] = json.loads(a.options)
    return req


def msg_request_for(req: dict) -> dict | None:
    """Отображение интента core → интент messages (стык §10)."""
    rid = req["request_id"] + "-msg"
    if req["intent"] == "manager_day":
        out = {"intent": "messages_period", "request_id": rid,
               "from": req["from"], "to": req["to"],
               "options": {"sender_ids": [req["employee_id"]]}}
    elif req["intent"] == "client_dossier":
        ents = [{"type": req["entity"]["type"], "id": req["entity"]["id"]}]
        out = {"intent": "messages_cluster", "request_id": rid,
               "cluster": {"entities": ents},
               "options": {"max_text_len": 1000}}
        if req.get("from"):
            out["from"], out["to"] = req["from"], req["to"]
    else:
        return None
    out["tz"] = "Europe/Moscow"
    return out


# ----------------------------------------------------------------- подпроцессы
def run_module(py_file: str, cwd: str, request: dict, env: dict,
               timeout: int) -> dict:
    t0 = time.monotonic()
    try:
        proc = subprocess.run([PY, "-I", py_file], input=json.dumps(request),
                              capture_output=True, text=True, timeout=timeout,
                              env=env, cwd=cwd)
        out, rc, err = proc.stdout, proc.returncode, proc.stderr
        timed_out = False
    except subprocess.TimeoutExpired:
        out, rc, err, timed_out = "", 124, "staging: timeout", True
    wall_ms = round((time.monotonic() - t0) * 1000, 1)
    resp = None
    try:
        resp = json.loads(out)
    except (json.JSONDecodeError, TypeError):
        pass
    return {"response": resp, "wall_ms": wall_ms, "exit_code": rc,
            "timed_out": timed_out, "stderr_tail": err[-400:]}


# -------------------------------------------------------------------- слияние
def worst_status(*statuses) -> str:
    live = [s for s in statuses if s in STATUS_RANK]
    return max(live, key=lambda s: STATUS_RANK[s]) if live else "FAILED"


def merge(core: dict, msg: dict | None, ol_mode: str, ol_error: str | None,
          timings: dict) -> dict:
    facts = list(core.get("facts") or [])
    seen = {(f.get("source"), f.get("source_entity_id")) for f in facts}
    if msg:
        for f in msg.get("facts") or []:
            key = (f.get("source"), f.get("source_entity_id"))
            if key not in seen:
                seen.add(key)
                facts.append(f)

    coverage = dict(core.get("coverage") or {})
    if msg:
        for k, v in (msg.get("coverage") or {}).items():
            coverage["msg." + k] = v

    warnings = list(core.get("warnings") or [])
    errors = [dict(e) for e in core.get("errors") or []]
    msg_ok = bool(msg) and msg.get("status") != "FAILED"
    if msg:
        # стык закрыт: заглушка core NOT_IMPLEMENTED (тексты = зона dev_agent)
        # снимается, если messages-модуль реально отработал
        if msg_ok:
            had_stub = any(e.get("code") == "NOT_IMPLEMENTED"
                           and e.get("source") == "openlines.messages"
                           for e in errors)
            errors = [e for e in errors
                      if e.get("code") != "NOT_IMPLEMENTED"
                      and e.get("source") != "openlines.messages"]
            if had_stub:
                if core.get("intent") == "client_dossier":
                    warnings.append(
                        "стык §10 закрыт модулем messages (тексты ОЛ получены); "
                        "CRM-часть досье собрана core (v0.3.0): идентификация, "
                        "кластер, таймлайн, телефония, этапы; NOT_IMPLEMENTED "
                        "снят — см. merge_notes")
                else:
                    warnings.append(
                        "стык §10 закрыт модулем messages (тексты ОЛ получены); "
                        "CRM-часть этого интента в core на стадии реализации "
                        "(NOT_IMPLEMENTED снят, покрытие неполно — см. merge_notes)")
                if core.get("status") == "FAILED" and not [
                        e for e in errors if e.get("module") != "messages"]:
                    # заглушка была единственной ошибкой core: снять её и
                    # оставить core FAILED нельзя — отказ станет необъяснимым
                    # (§4 fail-closed). Возвращаем явную ошибку-заглушку
                    # уровня core, а не openlines.
                    errors.append({
                        "code": "NOT_IMPLEMENTED",
                        "source": "core." + str(core.get("intent") or "intent"),
                        "detail": "CRM-часть интента в core не реализована "
                                  "(блокер DEV): собственные данные core не "
                                  "собирались; заглушка openlines.messages "
                                  "снята — тексты ОЛ дал модуль messages"})
        for e in msg.get("errors") or []:
            e = dict(e)
            e["module"] = "messages"
            errors.append(e)
    if ol_error:
        errors.append({"code": "SOURCE_NET", "source": "messages-ol-webhook",
                       "detail": ol_error, "module": "messages"})

    if msg:
        warnings += [f"[msg] {w}" for w in msg.get("warnings") or []]
    if ol_mode == "off" and core.get("intent") in OL_INTENTS:
        warnings.append("OL-источник отключён (--ol off): сообщения ОЛ не "
                        "собирались — покрытие неполно")

    detectors = {"core": core.get("detectors") or {}}
    if msg:
        detectors["messages"] = msg.get("detectors") or {}

    # З-2 (приёмка admin2): оба модуля без as_of → None, не ValueError
    _as_of = [x for x in (core.get("as_of"), (msg or {}).get("as_of")) if x]
    as_of = max(_as_of) if _as_of else None

    if (ol_mode == "off" and core.get("intent") in OL_INTENTS) or ol_error:
        status = "PARTIAL"
    else:
        status = worst_status(core.get("status"), msg.get("status") if msg else None)
        if status == "FAILED" and facts:
            status = "PARTIAL"   # у одного модуля есть факты — не FAILED
    if warnings and status == "VERIFIED":
        status = "PARTIAL"       # спека §4: VERIFIED при warnings запрещён
    notes = []
    if core.get("status") == "FAILED" and status != "FAILED":
        notes.append("core FAILED (module_statuses): статус объединённого "
                     "ответа понижен до PARTIAL, а не FAILED — факты другого "
                     "модуля есть; причина core — в его raw-ответе/coverage")
    if msg and msg.get("status") == "FAILED" and status != "FAILED":
        notes.append("messages FAILED (module_statuses): то же — ядро-факты "
                     "сохранены, покрытие неполно")

    return {"request_id": core.get("request_id"),
            "intent": core.get("intent"),
            "status": status,
            "module_statuses": {"core": core.get("status"),
                                "messages": msg.get("status") if msg else None},
            "as_of": as_of,
            # result-блок core (client_dossier: identification/cluster/
            # calls_summary/texts) — прокидываем в объединённый ответ;
            # интенты без result-блока его просто не имеют
            "result": core.get("result"),
            "facts": facts,
            "coverage": coverage,
            "warnings": warnings,
            "errors": errors,
            "detectors": detectors,
            "merge_notes": notes,
            "timings_ms": timings}


# ------------------------------------------------------------------ narrator
def narrator_packet(merged: dict, req: dict) -> dict:
    facts_in = merged.get("facts") or []
    facts, evidence = [], []
    for i, f in enumerate(facts_in, 1):
        fid = f"F{i}"
        pay = f.get("payload") or {}
        claim = (f"{f.get('fact_type')} | {f.get('source')} | "
                 f"{f.get('timestamp')} | {f.get('source_entity_id')}")
        ent = f.get("crm_entity") or {"type": f.get("source"), "id": None}
        facts.append({"id": fid, "claim": claim, "entity": ent,
                      "confidence": "verified", "basis": None})
        quote = pay.get("text") or pay.get("subject") or ""
        evidence.append({"fact_id": fid, "kind": "record",
                         "ref": f.get("source_entity_id"),
                         "quote": str(quote)[:200], "url": None})
    cov = merged.get("coverage") or {}
    errors = merged.get("errors") or []

    def src_ok(prefix):
        # З-1 (приёмка admin2): канал true ТОЛЬКО если источник реально
        # отвечал и без ошибок/потерь (SCHEMA_RECONCILIATION п.4)
        for k, v in cov.items():
            if not k.startswith(prefix):
                continue
            if isinstance(v, dict):
                return not (v.get("error") or v.get("missing"))
            return True          # скаляр/счётчик — источник отвечал
        return False

    telephony = src_ok("voximpl") or src_ok("calls.db")
    activity = src_ok("crm.activity.list")
    openlines = bool(any(k.startswith("msg.") and k != "msg.api_calls"
                         for k in cov)) and not any(
        e.get("module") == "messages" for e in errors)
    channels = {"telephony": bool(telephony), "crm_activities": bool(activity),
                "openlines": bool(openlines),
                "whatsapp": False, "telegram": False, "email": False}
    gaps = [w for w in merged.get("warnings") or []][:20]
    gaps += [f"{e.get('source', '?')}: {e.get('code')}" for e in errors][:20]
    det = merged.get("detectors") or {}
    dup_ok = all(d.get("duplicate_guard_dropped", 0) == 0
                 for d in det.values() if isinstance(d, dict))
    return {"check_type": NARRATOR_CHECK_TYPE.get(req["intent"], req["intent"]),
            "status": NARRATOR_STATUS[merged["status"]],
            "as_of": merged.get("as_of"),
            "request": {"question": None,
                        "entity_ids": [req.get("entity", {}).get("id")] if req.get("entity") else [],
                        "manager_id": req.get("employee_id"),
                        "period": {"from": req.get("from"), "to": req.get("to")}},
            "facts": facts,
            "evidence": evidence,
            "coverage": {"period": {"from": req.get("from"), "to": req.get("to")},
                         "channels": channels,
                         "duplicates": {"resolved": dup_ok, "merged_ids": [],
                                        "match_key": None},
                         "entities_scanned": {k: (v.get("rows") if isinstance(v, dict) else None)
                                              for k, v in list(cov.items())[:12]},
                         "gaps": gaps},
            "errors": [{"code": e.get("code"), "scope": e.get("source"),
                        "detail": e.get("detail")} for e in errors],
            "ambiguity": None,
            "schema_note": "display layer поверх контракта §4; исходник — "
                           "поле module_statuses/coverage объединённого ответа"}


# ----------------------------------------------------------------------- CLI
def cmd_run(a) -> int:
    req = build_request(a)
    rid = req["request_id"]

    env = dict(os.environ)
    env["V3_CACHE"] = "0"
    mock = None
    if a.mode == "mock":
        ds_path = a.dataset_core or os.path.join(FIXTURES, f"dataset_{a.intent}.json")
        with open(ds_path, encoding="utf-8") as fh:
            ds = json.load(fh)
        if a.core_faults:
            ds.setdefault("faults", {}).update(json.loads(a.core_faults))
        ds_msg_path = a.dataset_msg or os.path.join(FIXTURES, "dataset_messages_day.json")
        if os.path.exists(ds_msg_path):
            with open(ds_msg_path, encoding="utf-8") as fh:
                ds_msg = json.load(fh)
            if a.msg_faults:
                ds_msg.setdefault("faults", {}).update(json.loads(a.msg_faults))
            # Правило слияния датасетов:
            #  * OL-методы (v2.Session.list, history.get, Stat.get,
            #    config.list, user.current) существуют только в формате
            #    messages — коллизию решает фикстура messages;
            #  * общие методы (user.get, crm.activity.list) — конкатенация
            #    rows с дедупом по ID (нужны обоим модулям).
            msg_m = ds_msg.get("methods", {})
            for m, spec in msg_m.items():
                cur = ds["methods"].get(m)
                if (cur and isinstance(cur, dict) and isinstance(spec, dict)
                        and "rows" in cur and "rows" in spec
                        and m in ("user.get", "crm.activity.list")):
                    seen = {str(r.get("ID")) for r in cur["rows"]}
                    ds["methods"][m] = {"rows": cur["rows"] + [
                        r for r in spec["rows"] if str(r.get("ID")) not in seen]}
                else:
                    ds["methods"][m] = spec
            ds.setdefault("faults", {}).update(ds_msg.get("faults", {}))
        http_log = os.path.join(st.LOGS, f"http_{rid}.jsonl")
        mock = MockB24(ds, http_log)
        port = mock.start()
        hook = f"http://127.0.0.1:{port}/stage/{rid}/rest/mock"
        env["V3_WEBHOOK"] = hook
        env["V3_OL_WEBHOOK"] = hook
    else:
        if a.ol != "off":
            env["V3_OL_WEBHOOK"] = st.staging_secrets.ol_owner_webhook()
        # V3_WEBHOOK не ставим: core/messages сами читают ~/AiRop/.env

    mreq = msg_request_for(req) if a.intent in OL_INTENTS and a.ol == "auto" else None
    if a.ol == "dead":
        env["V3_OL_WEBHOOK"] = DEAD_OL_HOOK
        mreq = msg_request_for(req) if a.intent in OL_INTENTS else None

    # З-4 (приёмка admin2): live-квот-гвард как в airop_staging.run —
    # считаем все REST-вызовы live-прогонов за сегодня (core REST ~ по 1 на
    # строку runs + msg_api_calls messages-модуля + http_calls стенда)
    if a.mode == "live":
        used = 0
        try:
            with open(st.RUNS_LOG, encoding="utf-8") as fh:
                for line in fh:
                    try:
                        r = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if r.get("mode") != "live":
                        continue
                    if not str(r.get("ts", "")).startswith(st.today_key()):
                        continue
                    used += (r.get("msg_api_calls") or 0) + (r.get("http_calls") or 0) \
                        + (1 if r.get("runner") == "integrated" else 0)
        except FileNotFoundError:
            pass
        if used >= st.LIVE_DAILY_MAX:
            print(json.dumps({"error": "live-квота суток исчерпана",
                              "used_est": used, "limit": st.LIVE_DAILY_MAX}))
            st.append_runs({"runner": "integrated", "request_id": rid,
                            "mode": "live", "intent": a.intent,
                            "quota_reject": used})
            return 2

    timeout = a.timeout or (120 if a.mode == "mock" else 300)
    try:
        core = run_module(CORE_RUN, V3LITE, req, env, timeout)
        msg, ol_error = None, None
        if mreq:
            msg = run_module(MSG_RUN, os.path.join(V3LITE, "messages"),
                             mreq, env, timeout)
            if msg["response"] is None and not msg["timed_out"]:
                ol_error = "messages-модуль не вернул JSON"
        timings = {"core_ms": core["wall_ms"],
                   "messages_ms": msg["wall_ms"] if msg else None,
                   "total_ms": round(core["wall_ms"] + (msg["wall_ms"] if msg else 0), 1)}
        merged = merge(core["response"] or
                       {"request_id": rid, "intent": a.intent, "status": "FAILED",
                        "facts": [], "coverage": {}, "warnings": [],
                        "errors": [{"code": "SOURCE_NET", "source": "core",
                                    "detail": core["stderr_tail"]}],
                        "detectors": {}},
                       msg["response"] if msg else None,
                       a.ol, ol_error, timings)
        # ── авито-слой (F1, §5): склейка Б24-сообщений с Авито v3 ──────────
        avito_res, avito_meta = None, None
        if (getattr(a, "avito", "auto") == "auto" and a.intent in OL_INTENTS
                and msg and msg["response"]
                and msg["response"].get("status") != "FAILED"):
            fixture_rows = None
            if a.mode == "mock":
                fpath = os.path.join(FIXTURES, "avito_rows_demo.json")
                if os.path.exists(fpath):
                    with open(fpath, encoding="utf-8") as fh:
                        fixture_rows = json.load(fh)
            built = avi.avito_request_for(msg["response"], req, mode=a.mode,
                                          fixture_rows=fixture_rows)
            if built:
                avito_req, avito_meta = built
                avito_res = avi.run_avito(avito_req, mode=a.mode,
                                          timeout=timeout, env=env)
                timings["avito_ms"] = avito_res["wall_ms"]
                timings["total_ms"] = round(
                    timings["core_ms"]
                    + (msg["wall_ms"] if msg else 0)
                    + timings["avito_ms"], 1)
        if avito_meta:
            merged = avi.apply_avito(merged, avito_res, avito_meta, timings)

        if core["response"] is None:
            merged["errors"].append({"code": "CORE_NO_JSON", "source": "core",
                                     "detail": core["stderr_tail"]})
            merged["status"] = "FAILED"
        cerrs = st.contract_check(
            {k: merged.get(k) for k in ("request_id", "intent", "status", "as_of",
                                        "facts", "coverage", "warnings", "errors",
                                        "detectors")}, req)
        if a.narrator:
            merged["narrator_packet"] = narrator_packet(merged, req)

        msg_calls = None
        if msg and msg["response"]:
            api = (msg["response"].get("coverage") or {}).get("api_calls") or {}
            msg_calls = sum(v for v in api.values() if isinstance(v, int))
        res = {"request": req, "messages_request": mreq, "mode": a.mode,
               "ol": a.ol, "merged": merged,
               "module_raw": {"core": {k: core[k] for k in
                                       ("wall_ms", "exit_code", "timed_out", "stderr_tail")},
                              "messages": ({k: msg[k] for k in
                                            ("wall_ms", "exit_code", "timed_out", "stderr_tail")}
                                           if msg else None),
                              "avito": ({k: avito_res[k] for k in
                                         ("wall_ms", "exit_code", "timed_out", "stderr_tail")}
                                        if avito_res else None)},
               "contract_errors": cerrs,
               "msg_api_calls": msg_calls}
        res_path = os.path.join(st.RESULTS, f"integrated_{st.today_key()}_{rid}.json")
        os.makedirs(st.RESULTS, exist_ok=True)
        with open(res_path, "w", encoding="utf-8") as fh:
            json.dump(res, fh, ensure_ascii=False, indent=1)
        st.append_runs({"runner": "integrated", "request_id": rid, "mode": a.mode,
                        "intent": a.intent, "ol": a.ol,
                        "status": merged["status"],
                        "statuses": merged["module_statuses"],
                        "facts": len(merged["facts"]),
                        "wall_ms": timings["total_ms"],
                        "msg_api_calls": msg_calls,
                        "timed_out": core["timed_out"] or (msg["timed_out"] if msg else False),
                        "contract_errors": cerrs, "result_file": res_path})
        print(json.dumps({"request_id": rid, "mode": a.mode, "ol": a.ol,
                          "intent": a.intent, "status": merged["status"],
                          "module_statuses": merged["module_statuses"],
                          "facts": len(merged["facts"]),
                          "errors": len(merged["errors"]),
                          "warnings": len(merged["warnings"]),
                          "msg_api_calls": msg_calls,
                          "wall_ms": timings["total_ms"],
                          "contract_errors": cerrs, "result_file": res_path},
                         ensure_ascii=False, indent=1))
        return 0 if (merged["status"] in {"VERIFIED", "PARTIAL"} and not cerrs) else 1
    finally:
        if mock:
            mock.stop()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("run")
    p.add_argument("--mode", choices=["mock", "live"], default="mock")
    p.add_argument("--intent", required=True,
                   choices=["leads_day", "calls_day", "manager_day", "client_dossier"])
    p.add_argument("--from", dest="from_date")
    p.add_argument("--to", dest="to_date")
    p.add_argument("--employee-id", type=int)
    p.add_argument("--entity-type", choices=["lead", "deal", "contact"])
    p.add_argument("--entity-id", type=int)
    p.add_argument("--request-id")
    p.add_argument("--options")
    p.add_argument("--ol", choices=["auto", "off", "dead"], default="auto")
    p.add_argument("--avito", choices=["auto", "off"], default="auto",
                   help="авито-слой F1 (склейка Б24+Авито v3) для OL-интентов")
    p.add_argument("--narrator", action="store_true")
    p.add_argument("--dataset-core")
    p.add_argument("--dataset-msg")
    p.add_argument("--core-faults")
    p.add_argument("--msg-faults")
    p.add_argument("--timeout", type=int)
    p.set_defaults(func=cmd_run)
    args = ap.parse_args()
    if args.cmd == "run":
        with st.StagingLock():
            return args.func(args)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
