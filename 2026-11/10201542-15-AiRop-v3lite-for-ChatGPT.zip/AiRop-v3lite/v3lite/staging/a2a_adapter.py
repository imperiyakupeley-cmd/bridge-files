#!/usr/bin/env python3
"""Адаптер «готовые facts v3 → ИИ-РОП» через межагентный a2a-мост МАВИ.

СТАТУС: НЕ ВКЛЮЧЁН. Отправка физически невозможна без двух переключателей
одновременно (см. send()), плюс действует правило Алексея от 04.10.2026:
прямой вызов другого агента — только по прямой команде владельца.
Включение = отдельное решение Алексея + фиксация в журнал.

Возможности моста (проверено 03–04.10.2026, живой прогон):
  POST http://127.0.0.1:49924/api/agents/<agent_id>/send  (access-key из
  ~/.mavii-agents/host/access-key, ключ НЕ печатать) — синхронный ответ
  вызываемого агента (claude -p), история отдельной веткой (@a2a), пуши
  людям не идут. Диспетч таймаут 600 с. Вложения: POST /api/files (до 36 МБ).
  Реестр агентов: ~/.mavii-agents/host/agents.json — целевой агент 'airop'.

Формат передачи (предложение, утверждать admin2/владельцу):
  1) дайджест в тексте: request_id/intent/status/as_of/счётчики фактов/
     warnings/errors — чтобы РОП сразу видел суть без чтения файла;
  2) полный ответ v3 — артефактом results/<день>_<request_id>.json,
     при необходимости через /api/files (не копировать в текст);
  3) ответ РОПа синхронно возвращается вызывающему (интеграция on-demand).

CLI:
  python3 a2a_adapter.py digest results/2026-11-08_<rid>.json   # только текст
  python3 a2a_adapter.py send   results/... --agent airop        # НИЧЕГО не шлёт без A2A_ENABLE=1
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import secrets as staging_secrets  # noqa: E402

BRIDGE = os.environ.get("A2A_BRIDGE", "http://127.0.0.1:49924")
TARGET_AGENT = os.environ.get("A2A_TARGET_AGENT", "airop")
DIGEST_MAX = 3500          # дайджест ≤ 3.5 КБ — далеко до лимитов моста
SEND_TIMEOUT_S = 620       # > dispatch-таймаута моста (600 с)


def build_digest(response_file: str) -> str:
    with open(response_file, encoding="utf-8") as fh:
        data = json.load(fh)
    resp = data.get("response", data)
    req = data.get("request", {})
    counts: dict[str, int] = {}
    for f in resp.get("facts", []) or []:
        counts[f.get("fact_type", "?")] = counts.get(f.get("fact_type", "?"), 0) + 1
    lines = [
        "[v3-facts] Готовая выборка ИИ-РОП v3 Lite",
        f"request_id: {resp.get('request_id')}",
        f"intent: {resp.get('intent')} (эхо запроса: {req.get('intent')})",
        f"status: {resp.get('status')}   as_of: {resp.get('as_of')}",
        f"фактов всего: {len(resp.get('facts') or [])}  по типам: "
        + json.dumps(counts, ensure_ascii=False),
        f"покрытие: {json.dumps({k: v for k, v in (resp.get('coverage') or {}).items()}, ensure_ascii=False)[:600]}",
    ]
    warns = resp.get("warnings") or []
    errs = resp.get("errors") or []
    if warns:
        lines.append(f"warnings ({len(warns)}): " + "; ".join(str(w) for w in warns[:5]))
    if errs:
        lines.append(f"errors ({len(errs)}): " + "; ".join(
            f"{e.get('source')}: {e.get('code')}" for e in errs[:5]))
    det = resp.get("detectors")
    if det:
        lines.append(f"детекторы: {json.dumps(det, ensure_ascii=False)[:400]}")
    lines.append(f"полный ответ (файл, не копировать в чат): {os.path.abspath(response_file)}")
    text = "\n".join(lines)
    if len(text) > DIGEST_MAX:
        text = text[:DIGEST_MAX] + "\n…(дайджест усечён адаптером, полный ответ в файле)"
    return text


def send(response_file: str, agent: str, really: bool) -> int:
    """Двойной гвард: --really И env A2A_ENABLE=1. Иначе — только показать конверт."""
    text = build_digest(response_file)
    key = staging_secrets.mavii_access_key()
    if not (really and os.environ.get("A2A_ENABLE") == "1"):
        print(json.dumps({"mode": "DRY-RUN (адаптер не включён)",
                          "would_call": f"POST {BRIDGE}/api/agents/{agent}/send",
                          "access_key_present": bool(key),
                          "payload_preview": text[:800]}, ensure_ascii=False, indent=1))
        print("\nВключение: решение владельца + A2A_ENABLE=1 + --really "
              "(правило 04.10: прямой вызов агента — по команде Алексея).",
              file=sys.stderr)
        return 0
    if not key:
        print(json.dumps({"error": "нет access-key моста"}))
        return 2
    body = json.dumps({"text": text}).encode()
    req = urllib.request.Request(
        f"{BRIDGE}/api/agents/{agent}/send", data=body, method="POST",
        headers={"Content-Type": "application/json", "access-key": key})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # localhost без прокси
    with opener.open(req, timeout=SEND_TIMEOUT_S) as r:
        print(r.read().decode()[:4000])
    return 0


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("digest")
    p.add_argument("file")
    p = sub.add_parser("send")
    p.add_argument("file")
    p.add_argument("--agent", default=TARGET_AGENT)
    p.add_argument("--really", action="store_true",
                   help="фактическая отправка (плюс A2A_ENABLE=1)")
    a = ap.parse_args()
    if a.cmd == "digest":
        print(build_digest(a.file))
        return 0
    return send(a.file, a.agent, a.really)


if __name__ == "__main__":
    sys.exit(main())
