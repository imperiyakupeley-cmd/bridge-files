# Стенд v3 Lite (staging) — изолированная среда интеграции ИИ-РОП

Создан 08.11.2026 (задача моста mw8a2ac6adrb, зона: инфраструктура/staging).
Спека: `~/AiRop/spec_v3lite_admin2.md` (контракт §3–4 — источник истины).

## Границы (железные)

- Боевой ИИ-РОП (`~/AiRop/*.py`, `run_pipeline.py`, launchd, calls.db writer),
  звонковый пайплайн, CRM-данные и обработчики вебхуков — НЕ трогаются.
- Стенд пишет ТОЛЬКО внутрь `~/AiRop/v3lite/staging/` (logs/, results/, lock).
- Прогоны ядра идут с `V3_CACHE=0` → кэш/идемпотентность DEV (`v3_cache.db`)
  не затрагивается, параллельная работа DEV не блокируется.
- calls.db открывается ядром только в режиме READ-ONLY (mode=ro, спека §10).
- Секреты НЕ копируются: подтягиваются в рантайме `secrets.py` из
  `~/AiRop/.env` (прод-вебхук Анны), `~/CRM/build_report.py` (вебхук владельца
  ОЛ), `~/.mavii-agents/host/access-key` (a2a). В логах/отчётах — только masked.
- Новые вебхуки не создаются, права не расширяются. Все запросы — GET/read-only.

## Быстрый старт

```bash
cd ~/AiRop/v3lite/staging
python3 -I airop_staging.py secrets-status   # секреты доступны? (masked)
python3 -I airop_staging.py selftest         # mock-сервер жив?
python3 -I airop_staging.py integration      # 6 сценариев (см. «Замеры»)
python3 -I airop_staging.py quota            # 429/5xx/live-квоты за сегодня
```

Одиночный прогон (mock, основной режим):

```bash
python3 -I airop_staging.py run --mode mock --intent leads_day \
  --from 2026-11-07T00:00:00+03:00 --to 2026-11-08T00:00:00+03:00
python3 -I airop_staging.py run --mode mock --intent manager_day --employee-id 401 \
  --from 2026-11-07T00:00:00+03:00 --to 2026-11-08T00:00:00+03:00 \
  --faults '{"crm.activity.list":{"status":429,"times":2}}'   # инжект сбоев
```

Live (read-only, только после приёмки admin2): `--mode live` — тот же конвейер,
но V3_WEBHOOK не подменяется (core читает прод-вебхук сам), V3_OL_WEBHOOK
передаётся значением из существующего хранилища. Квот-гвард: 200 live-вызовов/
сутки (`STAGING_LIVE_DAILY_MAX`). Разовое подключение: `ping-live [--ol]`.

Шаблон окружения: `env.template.sh` (без секретов, копировать в env.local.sh).

## Состав

| Файл | Назначение |
|---|---|
| `airop_staging.py` | тестовый CLI: run/selftest/integration/quota/ping-live/contract-check/secrets-status |
| `mock_b24.py` | HTTP-эмулятор Bitrix REST (боевой формат ответов, batch result.result, пагинация 50, фильтры, инжект 429/500, Retry-After). Порт случайный, только 127.0.0.1 |
| `secrets.py` | рантайм-доступ к существующим хранилищам секретов + mask() |
| `fixtures/` | immutable-датасеты и эталонные запросы (chmod 444 + uchg + SHA256SUMS) |
| `a2a_adapter.py` | передача facts в ИИ-РОП через a2a-мост МАВИ — **ВЫКЛЮЧЕН** (dry-run) |
| `logs/` | `runs.jsonl` (прогоны), `http_<rid>.jsonl` (каждый HTTP-вызов: ts/request_id/source/call_status/latency), `alerts.json` |
| `results/` | артефакты: запрос+ответ+контракт-чек+wall_ms на каждый прогон |
| `lock` | flock — один прогон стенда одновременно (боевые процессы не затрагиваются) |
| `ROLLBACK.md` | план отката |

## Логирование

Каждый HTTP-вызов (mock-режим, сквозной request_id вшит в webhook-URL):
`{"ts","request_id","source":"crm.lead.list","call_status":200,"latency_ms","fault"}`
Live-режим логирует пер-источник (coverage/errors ответа) + счётчики в runs.jsonl.
Схема едина: request_id / time / source / call_status.

## Надёжность: таймауты, повторы, квоты, мониторинг

- Подпроцесс ядра: таймаут 120s (mock) / 300s (live), kill → `timed_out` в логе.
- Ретраи/429/backoff — в ядре DEV (3 попытки, cap 30s); стенд инжектирует сбои
  и проверяет их насквозь (сценарий `leads_day_429x2` — PASS).
- Квот-гард live: 200/сутки; порог предупреждения 80% (`quota` → alerts.json).
- Мониторинг 429/500: `quota` (счётчики за день, per-source ошибки, лимиты
  моста: результат задачи ≤16000 знаков, a2a dispatch 600s).
- Lock: `run`/`ping-live` под flock — конкурентные прогоны очередью, не валкой.

## Замеры (08.11.2026, Mac mini, интеграционный прогон №2)

| Сценарий | Статус | Факты | HTTP | Wall |
|---|---|---|---|---|
| leads_day (happy) | VERIFIED | 3 | 6×200 | 1.10 s |
| leads_day + 429×2 | VERIFIED (ретраи съели сбои) | 3 | +2×429→200 | ~1.2 s |
| manager_day (401) | PARTIAL (OL: NOT_IMPLEMENTED — честно, модуль dev_agent) | 4 | 3×200 | 0.57 s |
| calls_day (calls.db RO) | PARTIAL | 39 | 0 REST | 0.57 s |
| bad schema | локальный SCHEMA-отказ (до REST) | — | 0 | <0.1 s |
| client_dossier (битый entity) | FAILED (SCHEMA от ядра) | 0 | 0 | 0.50 s |
| ping-live прод-вебхук | 200 OK | — | 1 | 0.86 s |
| ping-live OL-владелец | 200 OK | — | 1 | 0.20 s |

Полный отчёт: `results/integration_2026-11-08.json`, артефакты по прогонам в `results/`.

## Находки интеграции (для DEV/admin2, код DEV не менялся)

1. **batch-парсер не совпадает с боевым форматом.** `core/client.py:batch()`
   читает `data["result"]` как per-cmd словарь, а реальный сервер (и спека §5
   [ФАКТ], и mock) отдаёт `result.result`, причём числовые cmd-ключи — СПИСОК.
   Следствие: каждая команда batch = `MISSING_IN_BATCH`; в leads_day first_touch
   молча теряется (`without_any_activity: 3` при трёх активностях в окне), а
   ответ остаётся VERIFIED — нарушение fail-closed §4.5 (ошибки источника
   ушли в coverage-заметку, не в errors). Воспроизведение:
   `results/2026-11-08_integ-ld-1.json` (секция coverage.first_touch).
2. Ядро строго требует `employee_id` целым (§3) — стенд ловит на границе (было
   поймано и поправлено в билдере запросов стенда).
3. calls_day на реальном calls.db: 39 звонков за 07.11, честный PARTIAL —
   сверка с voximpl-метриками требует live-активности (после приёмки).

## Интегрированный E2E core+messages (09.11, задача моста mw8cluyez7kk)

Слияние модулей: `integrated.py` (4 интента, --ol auto/off/dead, --narrator,
merge по правилам SCHEMA_RECONCILIATION.md). Тесты модулей на момент прогона:
core 103 passed, messages 67 passed (перепроверены 02:3x).

| Сценарий | Режим | Статус | core/messages | Факты | Wall | Артефакт |
|---|---|---|---|---|---|---|
| leads_day 07.11 | live | VERIFIED | VERIFIED/– | 18 | 5.7 s | integrated_…_70578082…json |
| calls_day 07.11 | live | VERIFIED | VERIFIED/– | 37 | 0.7 s | integrated_…_9ec54c9f…json |
| manager_day 401=11898 07.11 | live | PARTIAL | PARTIAL/PARTIAL | 133 | 119.5 s | integrated_…_a555c503…json |
| client_dossier GC-2 (contact 16790) | live | FAILED (честно) | FAILED-заглушка/PARTIAL | 0 | 35.7 s | integrated_…_275c2fd5…json |
| client_dossier GC-10 (lead 20232) | live | PARTIAL | FAILED-заглушка/PARTIAL | 19 | 37.6 s | integrated_…_da60fee2…json |
| manager_day ol=off | mock | PARTIAL | –/– | 4 | 0.1 s | (демо отключения источника) |
| manager_day ol=dead | mock | PARTIAL | core цел/FAILED NET | 4 | 19.2 s | (SOURCE_NET насквозь) |
| client_dossier lead 101 | mock | PARTIAL | FAILED-заглушка/PARTIAL | 4 | ~3 s | integrated_…_e9341535…json |

### Приёмка admin2 (09.11, ~03:0x): ПРИНЯТО с замечаниями
Протокол: `results/ACCEPTANCE_2026-11-09_admin2.md` (независимая проверка по
артефактам и коду + собственный live спот-чек leads_day: VERIFIED/18/4.5с —
полное совпадение). Утверждены: статус-отображение §4 (narrator = display-слой),
openlines в coverage.channels (narrator v0.1→v0.2), блокер client_dossier → DEV.
Замечания З-1…З-5 — ИСПРАВЛЕНЫ в staging в тот же час:
- З-1 src_ok: канал true только при ответившем источнике (fallback-баг убран);
- З-2 merge as_of: default None вместо ValueError;
- З-3 --ol off: применяется только к ОЛ-интентам (leads_day/calls_day не занижаются);
- З-4 live-квот-гвард STAGING_LIVE_DAILY_MAX подключён к integrated.run (счётчик runs.jsonl);
- З-5 fixtures/dataset_messages_day.json + addons-SHA: 444+uchg, shasum OK.
Регресс после фиксов: integration 6/6 PASS; dossier mock PARTIAL/4, narrator-каналы честные.

Ключевые доказательства:
- **Инцидент integ-ld-1 закрыт на живом**: leads_day first_touch — leads=9,
  with_any_activity=9, cmd_error=0, cmd_missing=0, without_any_activity=0
  (до фикса: 3 потерянных касания при ложном VERIFIED). 3 REST-вызова.
- **GC-10**: Авито-чат 31122 найден сканом сессий (8 фактов chat31122, линия
  «Авито», 19 сообщений из 2 сессий), хотя getlastid его не резолвит — слепая
  зона QA закрыта подходом v2.Session.list→history.get.
- **GC-2**: core client_dossier = заглушка (0 REST) + чаты кластера Михаила —
  Авито-коннектор вне ОЛ → честный FAILED с объяснённой ошибкой. Блокер DEV.
- manager_day: 148 REST у messages; honest-PARTIAL предупреждения (окно
  offset ~10200, history.get недобор против messageCount: сессии 25396 50/143,
  29598 и др.; Transfer.list 6 ошибок aux) — задачи DEV Agent.

## a2a-адаптер (не включён)

Изучены текущие возможности МАВИ: `POST /api/agents/<id>/send` (127.0.0.1:49924,
access-key, синхронный ответ, история @a2a отдельной веткой, без пушей людям),
диспетч 600s, вложения до 36 МБ; в реестре есть агент `airop`. Предложенный
формат: дайджест в тексте (request_id/intent/status/счётчики/warnings/errors) +
полный ответ артефактом-файлом; ответ РОПа возвращается синхронно.
Включение = двойной гвард (`A2A_ENABLE=1` + `--really`) И прямое решение
владельца (правило Алексея 04.10.2026: прямой вызов агента — только по команде).
До того — `digest`/dry-run без каких-либо отправок.

## Для разработчиков (DEV/dev_agent)

- Точка входа контракта: `~/AiRop/v3lite/run.py` (stdin JSON → stdout JSON).
- Свои сценарии: `--dataset путь.json` (формат см. fixtures) + `--faults`.
- Контракт-чек своего ответа: `contract-check results/<файл>.json`.
- Правки fixtures — только новыми файлами + перегенерация SHA256SUMS (см. fixtures/README.md).
- Общие файлы dev/dev_agent и боевые скрипты — вне стенда, не трогать.
