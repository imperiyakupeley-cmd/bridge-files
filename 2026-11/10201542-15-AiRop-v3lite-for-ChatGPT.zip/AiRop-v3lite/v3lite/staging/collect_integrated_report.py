#!/usr/bin/env python3
"""Сводка интеграционных прогонов integrated.py за сегодня (задача mw8cluyez7kk)."""
import json, os, sys
from collections import Counter
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(HERE, "logs", "runs.jsonl")
today = datetime.now().strftime("%Y-%m-%d")

rows = []
with open(RUNS, encoding="utf-8") as fh:
    for line in fh:
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            continue
        if r.get("runner") == "integrated" and r.get("ts", "").startswith(today):
            rows.append(r)

print(f"integrated-прогонов за {today}: {len(rows)}")
live_calls = sum((r.get("msg_api_calls") or 0) + 4 for r in rows if r.get("mode") == "live")
print(f"оценка live REST-вызовов (msg api_calls + ~4 на core-прогон + пинги): ~{live_calls + 2}")
for r in rows:
    st = r.get("statuses") or {}
    print(f"- {r['ts'][11:19]} {r['mode']:4s} {r['intent']:14s} ol={r['ol']:4s} "
          f"→ {r['status']:8s} (core={st.get('core')}, msg={st.get('messages')}) "
          f"факты={r.get('facts')} ms={r.get('wall_ms')} "
          f"cerr={len(r['contract_errors']) if r.get('contract_errors') else 0} "
          f"{os.path.basename(r.get('result_file', ''))}")
