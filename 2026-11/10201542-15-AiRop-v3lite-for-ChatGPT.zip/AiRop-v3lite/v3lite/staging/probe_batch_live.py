#!/usr/bin/env python3
"""Read-only проба РЕАЛЬНОГО batch-конверта Bitrix24 (спека §5, [ФАКТ]).

Задача пробы: снять с боевого портала точную форму envelope `batch`-ответа
(список vs dict при числовых cmd-ключах; форма result_error) и прогнать эти
тела через ТЕКУЩИЙ парсер core.client.BitrixClient.batch — без доп. сети
(replay-транспорт). Печатает ТОЛЬКО структуру (типы/ключи/счётчики) и
задержки; персональные данные и payload не печатаются. Сырые тела пишутся в
logs/batch_live_*.json (локально, как и http-логи mock).

2 live-вызова (квот-гвард: считаем себя в runs.jsonl).
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
V3LITE = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, V3LITE)

import secrets as staging_secrets          # noqa: E402
from airop_staging import StagingLock, append_runs, now_iso  # noqa: E402

from core.client import BitrixClient       # noqa: E402
from core.config import Config             # noqa: E402
from core.transport import HttpResult, Transport  # noqa: E402


class ReplayTransport(Transport):
    """Отдаёт заранее снятые тела — сеть не трогаем."""

    name = "replay"

    def __init__(self, body: bytes):
        self.body = body

    def get(self, url: str, timeout: float) -> HttpResult:
        return HttpResult(200, {}, self.body)


def shape(x, depth=0):
    """Структурная сводка значения: типы/ключи/длины, без содержимого."""
    if isinstance(x, dict):
        return {str(k): shape(v, depth + 1) for k, v in list(x.items())[:12]} \
            if depth < 3 else {"_type": "dict", "_len": len(x)}
    if isinstance(x, list):
        return {"_type": "list", "_len": len(x),
                "_item0": shape(x[0], depth + 1) if x else None}
    return {"_type": type(x).__name__}


def call_batch(hook: str, cmds: dict, tag: str, bodies: dict) -> dict:
    qs = "&".join(
        f"cmd%5B{i}%5D={m}%3F" + "%26".join(
            f"{k.replace('[', '%5B').replace(']', '%5D')}={v}"
            for k, v in p.items())
        for i, (m, p) in enumerate(cmds))
    url = f"{hook.rstrip('/')}/batch.json?{qs}"
    t0 = time.monotonic()
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(url, timeout=15) as r:
            raw = r.read()
            ms = round((time.monotonic() - t0) * 1000, 1)
    except Exception as e:  # noqa: BLE001
        return {"tag": tag, "http": f"net_err:{type(e).__name__}"}
    bodies[tag] = raw
    data = json.loads(raw)
    envelope = {"top_keys": sorted(data),
                "payload_keys": sorted(data.get("result", {}))
                if isinstance(data.get("result"), dict)
                else f"<{type(data.get('result')).__name__}>"}
    res = data.get("result", {})
    inner = res.get("result") if isinstance(res, dict) else None
    rerr = res.get("result_error") if isinstance(res, dict) else None
    envelope["inner_result_type"] = type(inner).__name__
    if isinstance(inner, dict):
        envelope["inner_result_keys"] = sorted(inner)[:12]
    elif isinstance(inner, list):
        envelope["inner_result_len"] = len(inner)
    envelope["result_error_type"] = type(rerr).__name__
    if isinstance(rerr, dict):
        envelope["result_error_keys"] = sorted(rerr)[:12]
    elif isinstance(rerr, list):
        envelope["result_error_len"] = len(rerr)
    return {"tag": tag, "http": 200, "latency_ms": ms, "envelope": envelope}


def classify(tag: str, body: bytes, cmds: list) -> dict:
    """Прогон снятого тела через ТЕКУЩИЙ batch() — сколько ok/error/missing."""
    cfg = Config(webhook="https://replay.invalid/rest/0/probe",
                 exclude_users=set(), rate_rps=10_000.0, retries_max=0,
                 calls_db="/tmp/v3probe_calls.db", cache_db="/tmp/v3probe_cache.db")
    c = BitrixClient(cfg, transport=ReplayTransport(body))
    out = c.batch(cmds, label=f"probe_{tag}")
    ok = sum(1 for o in out if not (isinstance(o, dict) and o.get("error")))
    err = sum(1 for o in out if isinstance(o, dict) and o.get("error")
              and o.get("error") != "MISSING_IN_BATCH")
    missing = sum(1 for o in out if isinstance(o, dict)
                  and o.get("error") == "MISSING_IN_BATCH")
    return {"tag": tag, "parser": "current", "items": len(out), "ok": ok,
            "error": err, "missing": missing,
            "coverage": c.coverage.get(f"batch:probe_{tag}")}


def main() -> int:
    hook = staging_secrets.bx_webhook()
    if not hook:
        print(json.dumps({"probe": "no_webhook"}))
        return 2
    with StagingLock():
        bodies: dict[str, bytes] = {}
        live = [
            ("packed_ok", [
                ("crm.lead.list", {"order[ID]": "DESC", "start": 0}),
                ("user.get", {"ID": 1}),
                ("crm.activity.list", {"start": 0}),
            ]),
            ("sparse_err", [
                ("crm.lead.list", {"order[ID]": "DESC", "start": 0}),
                ("crm.lead.get", {"ID": 424242424}),   # NOT_FOUND → per-key error
                ("user.get", {"ID": 1}),
            ]),
        ]
        report = {"ts": now_iso(), "webhook": staging_secrets.mask(hook),
                  "cases": []}
        for tag, cmds in live:
            report["cases"].append(call_batch(hook, cmds, tag, bodies))
            time.sleep(0.7)   # вежливость к порталу
        logdir = os.path.join(HERE, "logs")
        os.makedirs(logdir, exist_ok=True)
        raw_path = os.path.join(logdir, f"batch_live_{report['ts'][:16]}.json")
        with open(raw_path, "w", encoding="utf-8") as fh:
            json.dump({t: json.loads(b) for t, b in bodies.items()}, fh,
                      ensure_ascii=False, indent=1)
        report["raw_saved"] = raw_path
        report["classification"] = [
            classify(tag, bodies[tag], cmds)
            for tag, cmds in live if tag in bodies]
        append_runs({"request_id": f"probe-batch-{report['ts'][11:16]}",
                     "mode": "live", "intent": "probe_batch",
                     "http_calls": len(bodies), "call_status": "200"})
        print(json.dumps(report, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
