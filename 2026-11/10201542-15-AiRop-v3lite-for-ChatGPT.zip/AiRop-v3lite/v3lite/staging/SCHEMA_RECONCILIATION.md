# Согласование схем core / messages / rop-narrator (задача моста mw8cluyez7kk)

Дата: 09.11.2026. Статус: решение интеграции (стенд), на утверждение admin2.

## Исходные схемы

| Слой | Файл | status | Интенты |
|---|---|---|---|
| core (DEV) | spec §4, v3lite/core | VERIFIED / PARTIAL / FAILED | leads_day, calls_day, manager_day, client_dossier, resolve_* |
| messages (DEV Agent) | v3lite/messages (контракт повторяет §4) | VERIFIED / PARTIAL / FAILED | messages_period, messages_cluster |
| rop-narrator v0.1 (черновик) | ~/AiRop/stand/rop-narrator-protocol.md | ok / partial / error | leads, calls, manager_day, client_dossier (check_type) |

## Решение

1. **Канонический статус — спека §4** (заморожена admin2 v1.0/1.1): VERIFIED / PARTIAL / FAILED.
   Слой narrator v0.1 — ПРЕЗЕНТАЦИОННЫЙ: отображается детерминированно, без потерь:
   `VERIFIED→ok, PARTIAL→partial, FAILED→error`.
   Обоснование: §4 семантически строже (fail-closed определён поведением, а не словом);
   переучивать два готовых модуля (161 тест) под черновик — риск без выгоды. Черновик
   narrator при этом не ломается: его правила (1–8) оперируют фактами/coverage, не именем статуса.
2. **check_type ↔ intent**: leads_day→leads, calls_day→calls, manager_day→manager_day,
   client_dossier→client_dossier. Отображение 1:1, словарь в integrated.py (NARRATOR_CHECK_TYPE).
3. **facts → F-факты narrator**: факт коллектора уже атомарен и с уликами
   (source, source_entity_id, timestamp, payload, evidence) → F# = «verified»
   (basis=null: коллектор inferred-фактов не эмитит — §4.5 «не додумывать»).
   claim = «fact_type | source | timestamp | source_entity_id»; quote ≤200 знаков из payload.
4. **coverage.channels** narrator v0.1 перечисляет telephony/crm_activities/whatsapp/telegram/email.
   Расширено полем `openlines` (чаты ОЛ — основной канал портала; приравнивание к
   telegram/whatsapp было бы ложью). Канал true ТОЛЬКО если соответствующий источник
   реально отвечал (coverage без ошибок); whatsapp/email = false всегда — коннекторов нет
   [ФАКТ спеки §5: Wappi без ключей]. Это СТРОГОЕ подмножество правды: канал не
   «включён», пока источник не подтверждён ответом.
5. **gaps** narrator = warnings + «source: code» из errors (топ-20). При partial раздел
   «Что неизвестно» обязателен — конвертация гарантирует непустоту (правило 7 narrator).
6. **ambiguity**: на уровне коллектора всегда null — сборщик работает по ТОЧНОМУ ID (§3),
   неоднозначность «какой Анна?» возникает на уровне ВОПРОСА (narrator/RAG, тест 5.4
   черновика), а не пакета. Досье по ID двусмысленным не бывает.
7. **duplicates.resolved** = duplicate_guard детекторов обоих модулей (0 выброшенных дублей);
   merged_ids/match_key заполняются, когда core resolve_client отдаёт кластер (сейчас —
   в warnings core; после реализации dossier-сборки — структурно).

## Правила слияния core + messages (integrated.py)

- coverage: ключи messages префиксуются `msg.` (коллизий с core-ключами нет);
  `msg.api_calls` — счётчик REST-вызовов модуля (для квот).
- facts: конкатенация + дедуп по (source, source_entity_id) — §7.5.
- errors: заглушка core `NOT_IMPLEMENTED/openlines.messages` снимается ТОЛЬКО если
  messages-модуль реально покрыл сообщения (status≠FAILED и есть факты/coverage
  истории); при снятии добавляется warning о неполной CRM-части — сигнал не теряется.
- status: worst(core, messages); FAILED+факты у партнёра → PARTIAL (merge_notes
  объясняет понижение); VERIFIED при непустых warnings запрещён (§4).

- module_statuses + merge_notes обязательны в объединённом ответе — приёмка admin2
  видит вклад каждого модуля без разбора сырья.
- **Дополнение v2 (09.11, после live GC-2):** снятие заглушки NOT_IMPLEMENTED/
  openlines.messages НЕ должно оставлять core-FAILED без объяснения. Если заглушка
  была единственной ошибкой core — в объединённый ответ возвращается явная ошибка
  `NOT_IMPLEMENTED / core.<intent>` («CRM-часть интента в core не реализована,
  собственные данные core не собирались; тексты ОЛ дал модуль messages»).
  Контракт-чек стенда усилен: `FAILED без errors` = ошибка контракта (fail-closed §4).
  Пример: GC-2 (contact 16790) — core 0 REST, ОЛ-скан 0 сессий (чаты кластера —
  Авито-коннектор) → 0 фактов → честный FAILED с 1 объяснённой ошибкой;
  GC-10 (lead 20232) — 19 фактов сообщений → PARTIAL (понижение FAILED→PARTIAL
  по правилу «факты у партнёра есть», merge_notes + ошибка-заглушка объясняют).

## Открытые пункты для admin2 — РЕШЕНЫ приёмкой 09.11 (ACCEPTANCE_2026-11-09_admin2.md)
1. Статус-отображение — УТВЕРЖДЕНО решение-1 (§4 канон, narrator display-слой).
2. openlines в coverage.channels — УТВЕРЖДЕНО (narrator v0.1→v0.2); семантика
   «true только при реально ответившем источнике» закреплена кодом (З-1 fixed).
3. client_dossier — ПОДТВЕРЖДЁН блокер DEV; поведение интеграции принято как есть.

## Исходные открытые пункты (до приёмки)

1. Утвердить статус-отображение §решение-1 (или потребовать ok/partial/error насквозь —
   тогда это правка спеки §4 v1.2, а не интеграции).
2. Поле `openlines` в coverage.channels narrator (расширение черновика v0.1 → v0.2).
3. client_dossier: CRM-часть в core пока NOT_IMPLEMENTED (только resolve_client) —
   блокер DEV, интеграция возвращает PARTIAL с явным warning до её реализации.
