"""Секреты стендa v3 Lite — ТОЛЬКО рантайм-чтение из существующих хранилищ.

Правила (задача mw8a2ac6adrb):
- не копируем токены в файлы стенда, в логи, в отчёты;
- не создаём новых вебхуков и не расширяем права: используем ровно те же
  секреты, что и боевые скрипты;
- в логах допустим только masked-вид: хост + первые/последние символы.

Источники:
  BX_WEBHOOK (прод-вебхук Анны, read-only)  -> ключ BX_WEBHOOK в ~/AiRop/.env
  Вебхук владельца ОЛ v2                    -> regex-извлечение из ~/CRM/build_report.py
                                                (тот же способ, что в пробах admin2 08.11)
  Access-key моста МАВИ (a2a)               -> ~/.mavii-agents/host/access-key
"""
from __future__ import annotations

import os
import re

PROD_ENV = os.path.expanduser("~/AiRop/.env")
CRM_REPORT_SRC = os.path.expanduser("~/CRM/build_report.py")
MAVII_KEY = os.path.expanduser("~/.mavii-agents/host/access-key")

_OL_RE = re.compile(r"(https?://[^\"'\s]+/rest/1/[a-z0-9]+)")


def _env_dict(path: str) -> dict:
    out = {}
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    out[k.strip()] = v.strip()
    except FileNotFoundError:
        pass
    return out


def bx_webhook() -> str:
    """Прод-вебхук Анны (crm.*, user.get, activity) — read-only использование."""
    return _env_dict(PROD_ENV).get("BX_WEBHOOK", "")


def ol_owner_webhook() -> str:
    """Вебхук владельца портала для ОЛ v2 (только чтение, спека §10).

    Хранится только в ~/CRM/build_report.py; на стенд не копируется.
    """
    try:
        with open(CRM_REPORT_SRC, encoding="utf-8", errors="replace") as fh:
            m = _OL_RE.search(fh.read())
        return m.group(1) if m else ""
    except FileNotFoundError:
        return ""


def mavii_access_key() -> str:
    """Ключ моста МАВИ для a2a-адаптера (не включён, печатать запрещено)."""
    try:
        with open(MAVII_KEY, encoding="utf-8") as fh:
            return fh.read().strip()
    except FileNotFoundError:
        return ""


def mask(secret: str) -> str:
    """Безопасное представление для логов/отчётов."""
    if not secret:
        return "<отсутствует>"
    tail = secret.rsplit("/", 1)[-1] if "/" in secret else secret
    host = secret.split("//", 1)[-1].split("/", 1)[0] if "//" in secret else ""
    return f"{host}/…{tail[:2]}***(скрыто)"


def status_report() -> dict:
    """Диагностика доступности секретов БЕЗ значений (для CLI/selftest)."""
    bx, ol, key = bx_webhook(), ol_owner_webhook(), mavii_access_key()
    return {
        "bx_webhook": {"ok": bool(bx), "view": mask(bx), "source": PROD_ENV},
        "ol_owner_webhook": {"ok": bool(ol), "view": mask(ol), "source": CRM_REPORT_SRC},
        "mavii_access_key": {"ok": bool(key), "view": "<файл есть, значение скрыто>" if key else "<нет>",
                             "source": MAVII_KEY},
    }
