#!/usr/bin/env python3
"""Mock-сервер Bitrix REST для интеграционных прогонов стенда v3 Lite.

Уровень — HTTP (транспорт целиком боевой: ретраи/429/пагинация/rate-limit
работают по-настоящему). Датасет — обезличенные фикстуры staging/fixtures/.

Webhook для ядра:  http://127.0.0.1:PORT/stage/<request_id>/rest/mock
  request_id попадает в URL → пер-вызовое логирование сквозным идентификатором.

Датасет (JSON):
  {"methods": {"<method>": {"rows":[...]} | {"value": {...}}},
   "faults":  {"<method>": {"status":429,"times":2,"retry_after":1}}}   # опц.

Поддержка: FILTER[>=f]/[>f]/[<=f]/[<f]/[f], select[], order[...], start,
batch.json (cmd[i]), user.get (ID/ID[]), crm.duplicate.findbycomm (TYPE+VALUES[]).
Неподдерживаемый метод → 400 ERROR_METHOD_NOT_FOUND → ядро честно отдаст
SOURCE_ERROR (проверка fail-closed на стенде).

Патч 09.11 (задача моста mw8cluyez7kk, интеграция core+messages) — аддитивно,
существующие датасеты/сценарии не затронуты:
  * POST-методы модуля messages: imopenlines.v2.Session.list (offset/limit →
    {sessions, hasNextPage}), imopenlines.v2.Session.Stat.get (sessionId[]),
    batch с JSON-телом {"cmd": {...}} (тот же PHP-packed конверт, что у GET);
  * GET-массивы sessionId[]/ID[];
  * "values_by_key" в спеке метода: ответ по ключу SESSION_ID/ID (для
    imopenlines.session.history.get по каждой сессии);
  * проброс SESSION_ID/sessionId внутрь команд batch.

Лог каждого вызова (JSONL): ts, request_id, source=метод, call_status,
latency_ms, fault — файл задаётся --log.
"""
from __future__ import annotations

import argparse
import json
import re
import threading
import time
import urllib.parse
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PAGE = 50
_DATE_FMTS = ("%d.%m.%Y %H:%M:%S", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d")
_KEY_METHODS = {  # методы-«значения»: result без total/next
    "imopenlines.crm.chat.getlastid", "imopenlines.crm.chat.get",
    "imopenlines.session.history.get", "crm.duplicate.findbycomm",
}


def parse_val(v):
    """Значение строки-фильтра → datetime | int/float | str."""
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip()
    for fmt in _DATE_FMTS:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        pass
    try:
        return float(s) if "." in s else int(s)
    except ValueError:
        return s


def cell(row: dict, field: str):
    return row.get(field)


def keep(row: dict, key: str, want) -> bool:
    have = cell(row, key)
    if have is None:
        return False
    a, b = parse_val(have), parse_val(want)
    if isinstance(a, datetime) != isinstance(b, datetime):
        return False
    if isinstance(a, datetime):
        return a == b
    return str(a) == str(b)


def apply_filters(rows: list, flt: dict) -> list:
    out = []
    for r in rows:
        ok = True
        for raw_k, want in flt.items():
            m = re.match(r"^(>=|<=|>|<)?(.+)$", raw_k)
            op, key = m.group(1) or "", m.group(2)
            if op == "":
                vals = want if isinstance(want, list) else [want]
                if not any(keep(r, key, v) for v in vals):
                    ok = False
                    break
                continue
            have = cell(r, key)
            if have is None:
                ok = False
                break
            a, b = parse_val(have), parse_val(want)
            if isinstance(a, datetime) != isinstance(b, datetime):
                ok = False
                break
            try:
                ok &= {">=": a >= b, "<=": a <= b, ">": a > b, "<": a < b}[op]
            except TypeError:
                ok = False
            if not ok:
                break
        if ok:
            out.append(r)
    return out


class MockB24:
    def __init__(self, dataset: dict, log_path: str | None = None):
        self.methods = dataset.get("methods", {})
        self.faults = {k: dict(v) for k, v in dataset.get("faults", {}).items()}
        self.lock = threading.Lock()
        self.log_path = log_path
        self.calls = []          # счётчики для selftest
        self.server = None

    # ------------------------------------------------------------- лог
    def _log(self, rec: dict):
        rec["ts"] = datetime.now().isoformat(timespec="milliseconds") + "+03:00"
        self.calls.append(rec)
        if self.log_path:
            with self.lock, open(self.log_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")

    # ----------------------------------------------------- один вызов
    def invoke(self, method: str, params: dict):
        """Возврат: (http_status, body_dict)."""
        t0 = time.monotonic()
        f = self.faults.get(method)
        status, body = 200, None
        if f and f.get("times", 0) > 0:
            f["times"] -= 1
            status = int(f.get("status", 429))
            body = {"error": "QUERY_LIMIT_EXCEEDED" if status == 429 else "INTERNAL_SERVER_ERROR",
                    "error_description": f"mock fault injection ({status})"}
        elif method == "batch":
            body = self._batch(params)
        elif method not in self.methods:
            status = 400
            body = {"error": "ERROR_METHOD_NOT_FOUND",
                    "error_description": f"mock: метод {method} отсутствует в датасете"}
        else:
            spec = self.methods[method]
            # GET-слой доносит одиночные параметры списком (parse_qs) —
            # нормализуем ключ/ID к скаляру
            def _scalar(x):
                return (x[0] if x else None) if isinstance(x, list) else x
            if "values_by_key" in spec:
                key = _scalar(params.get("SESSION_ID") or params.get("sessionId")
                              or params.get("ID"))
                body = {"result": spec["values_by_key"].get(
                    str(key) if key is not None else "")}
            elif "value" in spec or method in _KEY_METHODS:
                body = {"result": spec.get("value", {})}
            else:
                rows = apply_filters(spec.get("rows", []), params.get("FILTER", {}))
                # одиночное чтение по ID (crm.*.get в батчах owner-check и
                # crm.activity.get «призрачных» звонков досье): фильтр по ID
                rid = _scalar(params.get("ID"))
                if rid is not None and not isinstance(rid, list):
                    rows = [r for r in rows if str(r.get("ID")) == str(rid)]
                for k, direction in (params.get("order") or {}).items():
                    try:
                        rows = sorted(rows, key=lambda r: str(parse_val(cell(r, k))),
                                      reverse=(str(direction).upper() == "DESC"))
                    except TypeError:
                        pass
                if method == "user.get":  # ID / ID[]
                    ids = params.get("ID")
                    if ids is not None:
                        want = ids if isinstance(ids, list) else [ids]
                        rows = [r for r in rows if str(r.get("ID")) in
                                {str(x) for x in want}]
                    body = {"result": rows}
                else:
                    if method.endswith(".get") and rid is not None:
                        # форма одиночного чтения: dict-строка или NOT_FOUND
                        # (битриксовый crm.*.get отсутствующей сущности)
                        if rows:
                            body = {"result": rows[0]}
                        else:
                            body = {"error": "NOT_FOUND",
                                    "error_description": "mock: сущность не найдена"}
                    else:
                        start = int(params.get("start", 0) or 0)
                        page = rows[start:start + PAGE]
                        body = {"result": page, "total": len(rows)}
                        if start + PAGE < len(rows):
                            body["next"] = start + PAGE
        self._log({"request_id": params.get("_request_id", ""),
                   "source": method,
                   "call_status": status,
                   "latency_ms": round((time.monotonic() - t0) * 1000, 1),
                   "fault": bool(f and status != 200)})
        return status, body

    def invoke_post(self, method: str, params: dict):
        """POST-ветка: OL v2 (Session.list/Stat.get), batch с JSON-телом.

        Форма ответов — как в бою [ФАКТ, пробы 08–09.11]:
          v2.Session.list → result.{sessions, hasNextPage};
          Stat.get       → result.sessions (POST {"sessionId": [...]});
          batch          → PHP-packed конверт result.result/result_error.
        """
        t0 = time.monotonic()
        f = self.faults.get(method)
        status, body = 200, None
        if f and f.get("times", 0) > 0:
            f["times"] -= 1
            status = int(f.get("status", 429))
            body = {"error": "QUERY_LIMIT_EXCEEDED" if status == 429
                    else "INTERNAL_SERVER_ERROR",
                    "error_description": f"mock fault injection ({status})"}
        elif method == "batch":
            body = self._batch({"cmd": params.get("cmd", {})})
        elif method == "imopenlines.v2.Session.list":
            spec = self.methods.get(method, {})
            rows = spec.get("rows", [])
            off = int(params.get("offset", 0) or 0)
            lim = int(params.get("limit", 50) or 50)
            page = rows[off:off + lim]
            body = {"result": {"sessions": page,
                               "hasNextPage": off + lim < len(rows)}}
        elif method == "imopenlines.v2.Session.Stat.get":
            spec = self.methods.get(method, {})
            ids = params.get("sessionId", [])
            if not isinstance(ids, list):
                ids = [ids]
            want = {str(x) for x in ids}
            rows = [r for r in spec.get("rows", [])
                    if str(r.get("sessionId")) in want]
            body = {"result": {"sessions": rows}}
        elif method not in self.methods:
            status = 400
            body = {"error": "ERROR_METHOD_NOT_FOUND",
                    "error_description": f"mock: POST-метод {method} отсутствует"}
        else:
            spec = self.methods[method]
            body = {"result": spec.get("value", {})}
        self._log({"request_id": params.get("_request_id", ""),
                   "source": method, "call_status": status,
                   "latency_ms": round((time.monotonic() - t0) * 1000, 1),
                   "fault": bool(f and status != 200)})
        return status, body

    @staticmethod
    def _idx(s: str) -> int:
        m = re.search(r"\d+", s)
        return int(m.group()) if m else -1

    def _batch(self, params: dict):
        if isinstance(params.get("cmd"), dict):
            cmds = dict(params["cmd"])          # POST: голые ключи команд
        else:
            cmds = {k: v for k, v in params.items()
                    if re.fullmatch(r"cmd(\[\d+\])?", k)}
        result, result_error = {}, {}
        for key in sorted(cmds, key=self._idx):
            raw = cmds[key]
            raw = raw[0] if isinstance(raw, list) else raw
            method, _, qs = raw.partition("?")
            sub = {"FILTER": {}, "order": {}}
            for k, v in urllib.parse.parse_qs(qs, keep_blank_values=True).items():
                m = re.match(r"^FILTER\[(.+)\]$", k)
                om = re.match(r"^order\[(.+)\]$", k)
                if m:
                    sub["FILTER"][m.group(1)] = v[0] if len(v) == 1 else v
                elif om:
                    sub["order"][om.group(1)] = v[0]
                elif k == "start":
                    sub["start"] = v[0]
                elif k == "ID":
                    sub["ID"] = v
                elif k in ("SESSION_ID", "sessionId"):
                    sub[k] = v[0] if len(v) == 1 else v
            st, body = self.invoke(method, sub)
            # боевой сервер зеркалит КЛЮЧИ ЗАПРОСА без префикса cmd[]:
            # cmd[0] → "0" (числовые), cmd[h5001] → "h5001" (строчные) [ФАКТ §5]
            mk = re.fullmatch(r"cmd\[(.+)\]", key)
            idx = mk.group(1) if mk else key
            if st == 200:
                result[idx] = body.get("result")
            else:
                result_error[idx] = body
        # Боевая сериализация PHP [ФАКТ: live-проба 09.11, спека §5]:
        # плотные числовые ключи 0..n-1 → LIST, разреженные (есть ошибки
        # команд) → dict, пустой map → []. До фикса разреженный {"0","2"}
        # схлопывался в список → терялась привязка индексов к командам.
        def _packed(m: dict):
            if not m:
                return []
            if sorted(m) == [str(i) for i in range(len(m))]:
                return [m[str(i)] for i in range(len(m))]
            return dict(m)

        return {"result": {"result": _packed(result),
                           "result_error": _packed(result_error),
                           "result_total": {}, "result_next": {},
                           "result_time": {}}}

    # -------------------------------------------------- жизненный цикл
    def start(self) -> int:
        outer = self

        class H(BaseHTTPRequestHandler):
            def do_POST(self):  # noqa: N802 — HTTP-семантика (messages-модуль)
                parts = urllib.parse.urlsplit(self.path)
                m = re.match(r"^/stage/([^/]+)/rest/.*?/([A-Za-z0-9_.]+)\.json$",
                             parts.path)
                if not m:
                    self._send(404, {"error": "ERROR mocked path"})
                    return
                request_id, method = m.group(1), m.group(2)
                n = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(n) if n else b""
                try:
                    payload = json.loads(raw or b"{}")
                except json.JSONDecodeError:
                    self._send(400, {"error": "ERROR mocked json"})
                    return
                params = dict(payload)
                params["_request_id"] = request_id
                for k, v in urllib.parse.parse_qs(parts.query,
                                                  keep_blank_values=True).items():
                    params.setdefault(k, v[0] if len(v) == 1 else v)
                status, body = outer.invoke_post(method, params)
                self._send(status, body)

            def do_GET(self):  # noqa: N802 — HTTP-семантика
                parts = urllib.parse.urlsplit(self.path)
                m = re.match(r"^/stage/([^/]+)/rest/.*?/([A-Za-z0-9_.]+)\.json$",
                             parts.path)
                if not m:
                    self._send(404, {"error": "ERROR mocked path"})
                    return
                request_id, method = m.group(1), m.group(2)
                params = {"FILTER": {}, "order": {}, "_request_id": request_id}
                for k, v in urllib.parse.parse_qs(parts.query,
                                                  keep_blank_values=True).items():
                    fm = re.match(r"^FILTER\[(.+)\]$", k)
                    om = re.match(r"^order\[(.+)\]$", k)
                    if fm:
                        params["FILTER"][fm.group(1)] = v[0] if len(v) == 1 else v
                    elif om:
                        params["order"][om.group(1)] = v[0]
                    elif re.fullmatch(r"cmd(\[\d+\])?", k):
                        params[k] = v[0] if len(v) == 1 else v
                    elif k == "ID":
                        params["ID"] = v
                    elif k in ("sessionId[]", "sessionId", "ID[]"):
                        params.setdefault("sessionId" if "sessionId" in k
                                          else "ID", []).extend(v)
                    elif k == "VALUES[]":
                        params.setdefault("VALUES", []).extend(v)
                    elif k == "select[]":
                        params.setdefault("select", []).extend(v)
                    else:
                        params[k] = v[0]
                status, body = outer.invoke(method, params)
                self._send(status, body)

            def _send(self, status, body):
                payload = json.dumps(body, ensure_ascii=False).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                if status in (429, 500):
                    self.send_header("Retry-After", "1")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def log_message(self, *_):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        return self.server.server_address[1]

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server = None


def main():
    ap = argparse.ArgumentParser(description="standalone mock Bitrix REST")
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--log", default="")
    args = ap.parse_args()
    with open(args.dataset, encoding="utf-8") as fh:
        ds = json.load(fh)
    mock = MockB24(ds, args.log or None)
    port = mock.start()
    print(json.dumps({"port": port, "dataset": args.dataset}))
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        mock.stop()


if __name__ == "__main__":
    main()
