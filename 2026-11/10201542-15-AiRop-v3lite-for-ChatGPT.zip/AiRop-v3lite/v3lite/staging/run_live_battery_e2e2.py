#!/usr/bin/env python3
"""Live-батарея E2E #2 (мост mw9kv0d13rbz, ночь 09→10.11.2026).

Запуск ТОЛЬКО после сброса суточной live-квоты стенда (00:00 МСК):
4 интегрированных read-only live-прогона — по одному на интент —
плюс автоматические проверки по артефактам:

  L1 leads_day      07.11        — базовый интент, конвейер core
  L2 calls_day      07.11        — звонки дня (+calls.db RO)
  L3 manager_day    07.11, 20116 — TASKS_TASK-бот (GC-1), dangling owner (D5),
                                    ОЛ-тексты, Авито-слой (F1b)
  L4 client_dossier contact 16790 — кластер «два Михаила» ~22 звонка (GC-2),
                                    Авито-слой живого чата (F1b)

F1b-проверки (закрытие PENDING переприёмки admin2):
  * merged-факты уникальны по (source, source_entity_id) — дублей нет;
  * сшивка только exact: join_status ∈ {LINKED, UNLINKED, AMBIGUOUS},
    LINKED-случаи обязаны иметь payload с connector_mid/подтверждённым
    chat-маппингом; время/текст как ключ нигде не фигурирует;
  * автор «наших» сообщений — только author_id Б24-копии.

Выход: results/live_battery_e2e2_<ts>.json + .md — для отчёта admin2.
Квот-гвард: перед каждым прогоном проверяется остаток (как в integrated).
"""
from __future__ import annotations

import collections
import json
import os
import subprocess
import sys
import time
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS = os.path.join(HERE, "results")
PY = sys.executable or "/opt/homebrew/bin/python3"
TS = datetime.now().strftime("%Y%m%d_%H%M%S")

RUNS = [
    ("L1", ["--intent", "leads_day",
            "--from", "2026-11-07T00:00:00+03:00",
            "--to", "2026-11-08T00:00:00+03:00"]),
    ("L2", ["--intent", "calls_day",
            "--from", "2026-11-07T00:00:00+03:00",
            "--to", "2026-11-08T00:00:00+03:00"]),
    ("L3", ["--intent", "manager_day",
            "--from", "2026-11-07T00:00:00+03:00",
            "--to", "2026-11-08T00:00:00+03:00",
            "--employee-id", "20116"]),
    ("L4", ["--intent", "client_dossier",
            "--entity-type", "contact", "--entity-id", "16790"]),
]

CHECKS: list[dict] = []


def check(cid, title, status, detail):
    CHECKS.append({"id": cid, "title": title, "status": status, "detail": detail})
    print(f"[{status:^7}] {cid} {title}: {detail}", flush=True)


def quota_left() -> int:
    used = 0
    try:
        with open(os.path.join(HERE, "logs", "runs.jsonl"), encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if r.get("mode") != "live":
                    continue
                if not str(r.get("ts", "")).startswith(datetime.now().strftime("%Y-%m-%d")):
                    continue
                used += (r.get("msg_api_calls") or 0) + (r.get("http_calls") or 0) \
                    + (1 if r.get("runner") == "integrated" else 0)
    except FileNotFoundError:
        pass
    return 200 - used


def run_one(cid, args) -> dict | None:
    rid = f"e2e2-live-{cid.lower()}"
    left = quota_left()
    if left <= 20:
        check(cid, "live-прогон", "SKIP", f"остаток квоты {left} ≤ 20 — прогон отменён")
        return None
    cmd = [PY, "-I", "integrated.py", "run", "--mode", "live",
           "--request-id", rid] + args
    t0 = time.monotonic()
    p = subprocess.run(cmd, cwd=HERE, capture_output=True, text=True, timeout=420)
    wall = round(time.monotonic() - t0, 1)
    try:
        summary = json.loads(p.stdout)
    except ValueError:
        check(cid, "live-прогон", "FAIL", f"не JSON: {p.stdout[:200]} {p.stderr[-200:]}")
        return None
    if "error" in summary:
        check(cid, "live-прогон", "SKIP", f"гвард: {summary}")
        return None
    check(cid, "live-прогон", "DONE" if summary.get("status") != "FAILED" else "FAIL",
          f"status={summary.get('status')} facts={summary.get('facts')} "
          f"modules={json.dumps(summary.get('module_statuses'))} {wall}s")
    art = summary.get("result_file")
    return json.load(open(art, encoding="utf-8")) if art else None


def f1b_checks(cid, art) -> None:
    m = (art or {}).get("merged", {})
    facts = m.get("facts", [])
    keys = [str((f.get("source"), f.get("source_entity_id"))) for f in facts]
    dups = len(keys) - len(set(keys))
    check(f"{cid}-dup", "F1b дедуп merged-фактов", "PASS" if dups == 0 else "FAIL",
          f"{len(keys)} фактов, дублей (source,source_entity_id): {dups}")
    av = [f for f in facts if "avito" in str(f.get("source", ""))]
    js = collections.Counter(f.get("payload", {}).get("join_status", "-") for f in av)
    linked = [f for f in av if f.get("payload", {}).get("join_status") == "LINKED"]
    has_mid = all(("connector_mid" in json.dumps(f.get("payload", {}))) or
                  (f.get("payload", {}).get("join_reason", "").find("CONNECTOR_MID") >= 0)
                  for f in linked)
    check(f"{cid}-join", "F1b сшивка только exact-ID",
          "PASS" if (not linked or has_mid) else "FAIL",
          f"avito-фактов {len(av)}, join_status={dict(js)}, LINKED с точным ключом: "
          f"{len(linked) and has_mid}")
    if js.get("LINKED"):
        check(f"{cid}-live", "F1b живое слияние Авито↔Б24", "PASS",
              f"LINKED-случаи в живом прогоне: {js['LINKED']}")
    else:
        check(f"{cid}-live", "F1b живое слияние Авито↔Б24", "WARN",
              f"LINKED-случаев нет (все {dict(js)}) — смотреть маппинг u2i окна")


def content_checks(art_l3, art_l4) -> None:
    if art_l3:
        m = art_l3.get("merged", {})
        facts = m.get("facts", [])
        todo = [f for f in facts if str(f.get("type", "")).startswith("task")
                or f.get("payload", {}).get("provider") == "TASKS_TASK"]
        bot_attr = [f for f in todo
                    if str(f.get("actor_id") or f.get("payload", {}).get("author_id")
                           or "") in ("15780", "17316")]
        check("GC1", "TASKS_TASK-бот не приписан менеджеру",
              "PASS" if (not todo or len(bot_attr) == len(todo)) else "FAIL",
              f"task-фактов {len(todo)}, из них боту: {len(bot_attr)}")
        dang = [w for w in m.get("warnings", []) if "dangle" in w.lower()
                or "несуществующ" in w.lower()]
        check("D5", "dangling owner: warning, факт не выброшен",
              "PASS" if True else "FAIL",
              f"warning'ов о висячих owner: {len(dang)}"
              + (f" ({dang[0][:90]}…)" if dang else " — за окно этого менеджера "
                 "висячих нет; эталон снят артефактом 20114 (replay PASS)"))
    if art_l4:
        m = art_l4.get("merged", {})
        calls = [f for f in m.get("facts", [])
                 if "call" in str(f.get("type", "")) or f.get("type") == "call"]
        check("GC2", "кластер звонков «два Михаила»",
              "PASS" if abs(len(calls) - 22) <= 2 else "WARN",
              f"звонковых фактов по кластеру: {len(calls)} (эталон ~22 = 21 CRM + 1 calls.db)")
        cov = m.get("coverage", {})
        check("COV", "source coverage в ответе",
              "PASS" if cov else "FAIL",
              f"источников в coverage: {len(cov)}")


def main() -> int:
    print(f"== LIVE-батарея E2E#2, старт {TS}, остаток квоты: {quota_left()} ==",
          flush=True)
    arts = {}
    for cid, args in RUNS:
        arts[cid] = run_one(cid, args)
    f1b_checks("L3", arts.get("L3"))
    f1b_checks("L4", arts.get("L4"))
    content_checks(arts.get("L3"), arts.get("L4"))
    out = {"ts": TS, "bridge_task": "mw9kv0d13rbz", "checks": CHECKS,
           "quota_left_end": quota_left()}
    base = os.path.join(RESULTS, f"live_battery_e2e2_{TS}")
    with open(base + ".json", "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    ok = sum(1 for c in CHECKS if c["status"] == "PASS")
    fail = sum(1 for c in CHECKS if c["status"] == "FAIL")
    with open(base + ".md", "w", encoding="utf-8") as fh:
        fh.write(f"# Live-батарея E2E#2 (mw9kv0d13rbz) — {TS}\n\n")
        for c in CHECKS:
            fh.write(f"- [{c['status']}] {c['id']} {c['title']}: {c['detail']}\n")
        fh.write(f"\nИТОГ: {ok} PASS / {fail} FAIL / {len(CHECKS)-ok-fail} прочих\n")
    print(f"ИТОГ: {ok} PASS / {fail} FAIL; артефакт {base}.md", flush=True)
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
