#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Независимый эталонный контур ожиданий приёмки ANA-DEV-18 (мост mwrjhno55yxh).

Это НЕ код ANA и НЕ его сборка. Контур кодирует ожидаемую семантику защиты от
ложного PLAN_GAP по критериям A1/A2/B1/C1/D1/E1 (см. SPEC.md) и проверяет
самосогласованность ожиданий кейсов cases.json. Прогон полностью офлайн.

Выход: таблица «кейс → вердикт эталона / ожидание / совпадение», итог PASS/FAIL.
"""
import json
import sys
from datetime import date

def D(s: str) -> date:
    return date.fromisoformat(s)

def evaluate(c: dict) -> dict:
    per = c["period"]
    plan = int(c["plan_amount"])
    start, end, as_of_raw = D(per["start"]), D(per["end"]), D(per["as_of"])
    as_of = min(as_of_raw, end)
    full = as_of_raw >= end

    evidence_deals = [x for x in c["deals"] if x.get("has_evidence", False)]

    confirmed = 0        # подтверждённые поступления в окне [start, as_of]
    unconfirmed = 0      # неподтверждённые поступления (окно не режем: доказательства нет)
    signed = 0           # зачёт подписанных договоров по правилу частичного аванса
    for x in c["deals"]:
        for p in x.get("payments", []):
            if p.get("confirmed"):
                if start <= D(p["date"]) <= as_of:
                    confirmed += int(p["amount"])
            else:
                unconfirmed += int(p["amount"])
        cpa = x.get("coordinated_partial_advance")
        first_conf = sum(int(p["amount"]) for p in x.get("payments", [])
                         if p.get("confirmed") and start <= D(p["date"]) <= as_of)
        if cpa and first_conf >= int(cpa["min_confirmed_first"]):
            signed += 1  # ровно один зачёт на договор; повторные платежи счёт не двигают

    out = {
        "revenue_confirmed": confirmed,
        "revenue_unconfirmed": unconfirmed,
        "signed_contracts": signed,
        "period_fraction": None,
        "verdict": None,
        "reason": "",
    }

    # D1: нет ни одного доказательного события → fail-closed, ноль не утверждаем
    if not evidence_deals:
        out["verdict"] = "NO_DATA"
        out["reason"] = "неполная история: доказательных событий нет, факт=0 недоказуем"
        return out

    if not full:
        # B1: финальный PLAN_GAP в неполном периоде не выносится
        frac = (as_of - start).days / max((end - start).days, 1)
        expected_now = plan * frac
        out["period_fraction"] = round(frac, 4)
        if confirmed >= expected_now:
            out["verdict"] = "ON_TRACK"
            out["reason"] = f"подтверждённые {confirmed} ≥ ожидаемых на срез {expected_now:.0f}"
        elif confirmed + unconfirmed >= expected_now:
            out["verdict"] = "ON_TRACK_UNPROVEN"
            out["reason"] = (f"динамика есть только с неподтверждёнными "
                             f"({confirmed}+{unconfirmed} ≥ {expected_now:.0f})")
        else:
            out["verdict"] = "INSUFFICIENT_PERIOD"
            out["reason"] = (f"provisional дефицит на срезе: {confirmed} из {expected_now:.0f}; "
                             f"финальный вердикт невозможен, период пройден на {frac:.0%}")
        return out

    # Полный период
    if confirmed >= plan:
        out["verdict"] = "NO_GAP"                                   # E1
        out["reason"] = f"подтверждённый факт {confirmed} ≥ план {plan}"
    elif confirmed + unconfirmed >= plan:
        out["verdict"] = "PLAN_UNPROVEN"                            # A1
        out["reason"] = (f"разрыв {plan - confirmed} устраняется неподтверждёнными "
                         f"{unconfirmed} → доказанного разрыва нет")
    else:
        out["verdict"] = "PLAN_GAP"                                 # A2
        out["reason"] = (f"разрыв {plan - confirmed} не устраняется даже неподтверждёнными "
                         f"({confirmed}+{unconfirmed} < {plan})")
    return out

def main(path: str) -> int:
    data = json.load(open(path, encoding="utf-8"))
    fails = 0
    print(f"Эталонный контур ANA-DEV-18, кейсов: {len(data['cases'])}")
    print(f"{'id':4} {'вердикт эталона':20} {'rev.conf':>9} {'signed':>6}  "
          f"{'ожидание':20} {'совп.':6} причина эталона")
    print("-" * 118)
    for c in data["cases"]:
        got = evaluate(c)
        exp = c["expected"]
        ok = (got["verdict"] == exp["verdict"]
              and got["revenue_confirmed"] == exp["revenue_confirmed"]
              and got["signed_contracts"] == exp["signed_contracts"])
        if not ok:
            fails += 1
        print(f"{c['id']:4} {got['verdict']:20} {got['revenue_confirmed']:>9} "
              f"{got['signed_contracts']:>6}  {exp['verdict']:20} "
              f"{'OK' if ok else 'FAIL':6} {got['reason']}")
    print("-" * 118)
    print("ИТОГ:", "PASS — ожидания кейсов самосогласованы" if fails == 0
          else f"FAIL — рассинхрон в {fails} кейсах")
    return 0 if fails == 0 else 1

if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "cases.json"))
