# ab_glm_scope_20261115 — Task B: scope_engine (A/B бенчмарк отделов)

Задача mwh450obg741 (базовая, мост ChatGPT) с дельтами override mwhjgt3d6ie6 /
ручной диспетчеризации mwhjguoag108 от 15.11.2026. Офлайн, Python3 stdlib,
синтетические данные, без сети/CRM/PROD/секретов. Реализация независимая,
код ChatGPT/Work не смотрел (по условию задачи).

## Файлы
- `scope_engine.py` — единственная публичная функция `build_report(...)`.
- `test_scope_engine.py` — 16 unittest-тестов.
- `REPORT.md` — отчёт прогона (paths, sha256, test counts, кредиты).

## Запуск тестов
```
python3 -m unittest discover -s <эта_папка> -p 'test_*.py' -v
```

## Контракт build_report

```
build_report(events, assignments, principal, period_from, period_to,
             department_id=None, manager_id=None) -> dict
```

- Все timestamps — ISO8601 с явным смещением (+03:00). Период и интервалы
  назначений полуоткрытые `[from, to)`.
- `principal = {role: OWNER|ROP, department_id: D1|D2|None}`:
  - ROP — только свой отдел; чужой отдел или вся компания → `PermissionError`;
    недопустимая role → `PermissionError`.
  - OWNER — компания (`department_id=None`) или D1/D2; неизвестный отдел
    (например D3) → `ValueError`.
  - Некорректный период (from ≥ to, не-ISO8601, без смещения) → `ValueError`.
- `assignments = {manager_id, department_id, valid_from, valid_to}`;
  `valid_to=None` — открытый интервал. Отдел продажи = однозначное назначение
  менеджера на `recognized_at`; 0 или ≥2 покрывающих записей → UNASSIGNED.
- `manager_id`: менеджер должен иметь назначение, пересекающееся с периодом
  (иначе `ValueError`), и оно должно попадать в доступный отдел
  (иначе `PermissionError`).
- Dedup: продажи по `contract_id`, платежи по `payment_id`. Идентичные дубли
  (совпадают сумма/дата/менеджер/evidence/атрибуция) схлопываются молча —
  `event_id` в сигнатуру дубли намеренно не входит. Противоречивые группы
  исключаются ЦЕЛИКОМ (случайная запись не выбирается), дают warning
  (`SALES_CONFLICT:...` / `PAYMENTS_CONFLICT:...`) и переводят затронутый
  денежный KPI в PARTIAL.
- Отдел платежа — ТОЛЬКО явный `attributed_department_id` при
  `attribution_verified=True`. Неатрибутированные подтверждённые платежи входят
  в общий итог компании и в `unassigned`, но не в D1/D2.
- Денежный KPI `{value, status, verified_subtotal}`:
  - все события VERIFIED → `value` = сумме, статус VERIFIED;
  - есть недоказанные или конфликты → `value=null`, статус PARTIAL,
    `verified_subtotal` = сумма VERIFIED-событий;
  - только UNKNOWN-evidence → статус UNKNOWN, `value=null` (НЕ 0),
    `verified_subtotal=0`;
  - пустое доказанное множество → `0 / VERIFIED`.
- При `manager_id` платёжные KPI всегда `UNKNOWN/null` с причиной
  `NO_MANAGER_PAYMENT_ATTRIBUTION` (платежи не имеют доказанной персональной
  атрибуции), `payments_count=0`.
- Выход: `{scope, sales_total, sales_count, payments_total, payments_count,
  unassigned:{sales_count,payments_total}, warnings, mode:SYNTHETIC,
  vat_basis:GROSS_INCL_VAT_5, period}`. Входы не мутируются. Warnings не
  содержат чужие для скоупа ключи/ID (ROP не видит следов конфликтов чужого
  отдела).

## Зафиксированные интерпретации (в спеке не задано явно)
1. `unassigned`-бакет вычисляется только на уровне компании; для отдела/менеджера — нули.
2. Платёж, верифицированно атрибутированный вне D1/D2 (условный «D3»), входит в итог компании, но не в D1/D2 и не в unassigned.
3. «Противоречие по id» трактуется как противоречие внутри группы одного `contract_id`/`payment_id`; разные `event_id` при прочей идентичности — идентичный дубль.
4. Менеджер без назначений в периоде → `ValueError`; менеджер с назначениями только в недоступном отделе → `PermissionError`.
5. RBAC здесь — scope чистой функции; это не claim на production-безопасность.
