#!/usr/bin/env python3
"""scope_engine.py — Task B (mwh450obg741, ред. с дельтами override 15.11.2026).

Офлайновый stdlib-only движок скоупинга отделов/менеджеров для A/B-бенчмарка
AiRop (SYNTHETIC). Единственная публичная функция:

    build_report(events, assignments, principal, period_from, period_to,
                 department_id=None, manager_id=None) -> dict

Контракт (кратко; полное описание решений — README.md):
- Все timestamps ISO8601 с явным смещением (+03:00). Период и интервалы
  назначений полуоткрытые [from, to).
- RBAC: ROP — только свой отдел (чужой отдел или вся компания -> PermissionError);
  OWNER — компания (None) или D1/D2; неизвестный отдел -> ValueError.
- Отдел продажи = однозначная запись назначения менеджера на recognized_at
  (0 или >=2 покрывающих записей -> UNASSIGNED).
- Отдел платежа = ТОЛЬКО явный attributed_department_id при attribution_verified=True.
- Dedup: продажи по contract_id, платежи по payment_id. Идентичные дубли
  схлопываются молча; противоречивые группы исключаются ЦЕЛИКОМ (без случайного
  выбора), дают warning и переводят затронутый KPI в PARTIAL.
- Денежный KPI: {value, status, verified_subtotal}. value=None, пока агрегат
  не доказан целиком; пустое доказанное множество = 0/VERIFIED; только UNKNOWN
  = UNKNOWN/None (не 0). При manager_id платёжные KPI всегда UNKNOWN c причиной
  NO_MANAGER_PAYMENT_ATTRIBUTION.
- Входы не мутируются. mode=SYNTHETIC, vat_basis=GROSS_INCL_VAT_5.
- RBAC здесь — scope чистой функции, а не claim на production-безопасность.
"""

__all__ = ["build_report"]

from datetime import datetime

DEPARTMENTS = ("D1", "D2")
EVIDENCE_STATUSES = ("VERIFIED", "PARTIAL", "UNKNOWN")
MODE = "SYNTHETIC"
VAT_BASIS = "GROSS_INCL_VAT_5"
NO_MANAGER_PAYMENT_ATTRIBUTION = "NO_MANAGER_PAYMENT_ATTRIBUTION"


# ---------------------------------------------------------------- helpers ---

def _parse_ts(value, what):
    """Строгий разбор ISO8601 со смещением; иначе ValueError."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError("%s: timestamp must be a non-empty ISO8601 string" % what)
    try:
        dt = datetime.fromisoformat(value)
    except ValueError:
        raise ValueError("%s: invalid ISO8601 timestamp %r" % (what, value)) from None
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError("%s: timestamp %r must carry an explicit UTC offset" % (what, value))
    return dt


def _is_money(value):
    return isinstance(value, int) and not isinstance(value, bool) and value >= 0


def _norm_id(value):
    return isinstance(value, str) and value.strip() != ""


def _normalize_events(events, warnings):
    """Копирует и валидирует события; битые пропускает с warning (без id-утечек)."""
    sales, payments = [], []
    if events is None:
        return sales, payments
    for i, ev in enumerate(events):
        if not isinstance(ev, dict):
            warnings.append("EVENT_MALFORMED:index=%d:not a mapping, skipped" % i)
            continue
        etype = ev.get("type")
        if etype == "sale":
            reason = None
            if not _norm_id(ev.get("event_id")):
                reason = "missing event_id"
            elif not _norm_id(ev.get("contract_id")):
                reason = "missing contract_id"
            elif not _is_money(ev.get("gross_rub")):
                reason = "gross_rub must be int >= 0"
            elif ev.get("evidence_status") not in EVIDENCE_STATUSES:
                reason = "bad evidence_status"
            else:
                try:
                    dt = _parse_ts(ev.get("recognized_at"), "sale.recognized_at")
                except ValueError as exc:
                    reason = str(exc)
            if reason:
                warnings.append("EVENT_MALFORMED:index=%d:%s, skipped" % (i, reason))
                continue
            sales.append({
                "type": "sale",
                "event_id": ev["event_id"],
                "contract_id": ev["contract_id"],
                "_dt": dt,
                "gross_rub": ev["gross_rub"],
                "manager_id": ev.get("manager_id"),
                "evidence_status": ev["evidence_status"],
            })
        elif etype == "payment":
            reason = None
            if not _norm_id(ev.get("event_id")):
                reason = "missing event_id"
            elif not _norm_id(ev.get("payment_id")):
                reason = "missing payment_id"
            elif not _is_money(ev.get("gross_rub")):
                reason = "gross_rub must be int >= 0"
            elif not isinstance(ev.get("attribution_verified"), bool):
                reason = "attribution_verified must be bool"
            elif ev.get("evidence_status") not in EVIDENCE_STATUSES:
                reason = "bad evidence_status"
            else:
                try:
                    dt = _parse_ts(ev.get("received_at"), "payment.received_at")
                except ValueError as exc:
                    reason = str(exc)
            if reason:
                warnings.append("EVENT_MALFORMED:index=%d:%s, skipped" % (i, reason))
                continue
            payments.append({
                "type": "payment",
                "event_id": ev["event_id"],
                "payment_id": ev["payment_id"],
                "_dt": dt,
                "gross_rub": ev["gross_rub"],
                "attributed_department_id": ev.get("attributed_department_id"),
                "attribution_verified": ev["attribution_verified"],
                "evidence_status": ev["evidence_status"],
            })
        else:
            warnings.append("EVENT_MALFORMED:index=%d:unknown type %r, skipped" % (i, etype))
    return sales, payments


def _normalize_assignments(assignments, warnings):
    """Копирует назначения; valid_to=None = открытый интервал; идентичные схлопывает."""
    out = []
    if assignments is None:
        return out
    for i, a in enumerate(assignments):
        if not isinstance(a, dict):
            warnings.append("ASSIGNMENT_MALFORMED:index=%d:not a mapping, skipped" % i)
            continue
        reason = None
        try:
            vf = _parse_ts(a.get("valid_from"), "assignment.valid_from")
            vt = None if a.get("valid_to") is None else _parse_ts(a.get("valid_to"), "assignment.valid_to")
        except ValueError as exc:
            reason = str(exc)
        if reason is None and vt is not None and vt <= vf:
            reason = "valid_to <= valid_from"
        if reason:
            warnings.append("ASSIGNMENT_MALFORMED:index=%d:%s, skipped" % (i, reason))
            continue
        out.append({
            "manager_id": a.get("manager_id"),
            "department_id": a.get("department_id"),
            "valid_from": vf,
            "valid_to": vt,
        })
    seen, uniq = set(), []
    for a in out:
        key = (a["manager_id"], a["department_id"], a["valid_from"], a["valid_to"])
        if key not in seen:
            seen.add(key)
            uniq.append(a)
    return uniq


def _dept_at(assignments, manager_id, dt):
    """Однозначный отдел менеджера в момент dt; иначе None (UNASSIGNED)."""
    hits = [a["department_id"] for a in assignments
            if a["manager_id"] == manager_id
            and a["valid_from"] <= dt
            and (a["valid_to"] is None or dt < a["valid_to"])]
    if len(hits) == 1 and isinstance(hits[0], str):
        return hits[0]
    return None


def _record_sig(r):
    """Семантическая сигнатура для дедупа (event_id сознательно НЕ входит)."""
    if r["type"] == "sale":
        return (r["contract_id"], r["_dt"], r["gross_rub"], r["manager_id"], r["evidence_status"])
    return (r["payment_id"], r["_dt"], r["gross_rub"],
            r["attributed_department_id"], r["attribution_verified"], r["evidence_status"])


def _dedup(records, key_field):
    """Идентичные дубли схлопнуть; противоречия -> вся группа в конфликты."""
    groups, order = {}, []
    for r in records:
        k = r[key_field]
        if k not in groups:
            groups[k] = []
            order.append(k)
        groups[k].append(r)
    kept, conflicts = [], []
    for k in order:
        g = groups[k]
        sig = _record_sig(g[0])
        if all(_record_sig(r) == sig for r in g[1:]):
            kept.append(g[0])
        else:
            conflicts.append(g)
    return kept, conflicts


def _kpi(included, conflicts_seen=False, forced_reason=None):
    """{value, status, verified_subtotal}: VERIFIED целиком / PARTIAL / UNKNOWN."""
    if forced_reason:
        return {"value": None, "status": "UNKNOWN", "verified_subtotal": 0, "reason": forced_reason}
    ver_sum = sum(r["gross_rub"] for r in included if r["evidence_status"] == "VERIFIED")
    all_verified = bool(included) and all(r["evidence_status"] == "VERIFIED" for r in included)
    has_partial_ev = any(r["evidence_status"] == "PARTIAL" for r in included)
    if not included and not conflicts_seen:
        return {"value": 0, "status": "VERIFIED", "verified_subtotal": 0}
    if all_verified and not conflicts_seen:
        return {"value": ver_sum, "status": "VERIFIED", "verified_subtotal": ver_sum}
    if ver_sum > 0 or has_partial_ev or conflicts_seen:
        return {"value": None, "status": "PARTIAL", "verified_subtotal": ver_sum}
    return {"value": None, "status": "UNKNOWN", "verified_subtotal": 0}


def _pay_attributed(p):
    return p["attributed_department_id"] is not None and p["attribution_verified"] is True


# ------------------------------------------------------------ main entry ---

def build_report(events, assignments, principal,
                 period_from, period_to,
                 department_id=None, manager_id=None):
    """Сводный отчёт по скоупу за период [period_from, period_to). Не мутирует входы."""
    # 1) Период.
    pf = _parse_ts(period_from, "period_from")
    pt = _parse_ts(period_to, "period_to")
    if pf >= pt:
        raise ValueError("period_from must be strictly before period_to (half-open [from,to))")

    # 2) Principal и RBAC-проверки.
    if not isinstance(principal, dict):
        raise PermissionError("principal must be a mapping {role, department_id}")
    role = principal.get("role")
    p_dept = principal.get("department_id")
    if role not in ("OWNER", "ROP"):
        raise PermissionError("invalid role %r (expected OWNER or ROP)" % (role,))
    if p_dept is not None and p_dept not in DEPARTMENTS:
        raise ValueError("unknown department %r in principal" % (p_dept,))
    if role == "ROP":
        if p_dept is None:
            raise PermissionError("ROP principal must carry its own department_id")
        if department_id is None:
            raise PermissionError("ROP cannot request company-wide scope")
        if department_id != p_dept:
            raise PermissionError("ROP of %s cannot access department %r" % (p_dept, department_id))
    elif department_id is not None and department_id not in DEPARTMENTS:
        raise ValueError("unknown department %r" % (department_id,))

    warnings = []

    # 3) Нормализация (глубокие копии; вход не трогаем).
    sales_all, payments_all = _normalize_events(events, warnings)
    asg = _normalize_assignments(assignments, warnings)

    # 4) Дедуп и конфликты.
    sales_kept, sales_conf = _dedup(sales_all, "contract_id")
    payments_kept, payments_conf = _dedup(payments_all, "payment_id")

    # 5) Запрос по менеджеру: только внутри доступного отдела и периода.
    if manager_id is not None:
        overlapping = [a for a in asg
                       if a["manager_id"] == manager_id
                       and a["valid_from"] < pt
                       and (a["valid_to"] is None or a["valid_to"] > pf)]
        if not overlapping:
            raise ValueError("manager %r has no assignment overlapping the requested period" % (manager_id,))
        if department_id is not None and not any(a["department_id"] == department_id for a in overlapping):
            raise PermissionError("manager %r is not in the accessible department %r within the period"
                                  % (manager_id, department_id))

    # 6) Правила видимости записей для запрошенного скоупа.
    def sale_visible(s):
        if not (pf <= s["_dt"] < pt):
            return False
        d = _dept_at(asg, s["manager_id"], s["_dt"])
        if manager_id is not None:
            if s["manager_id"] != manager_id:
                return False
            return department_id is None or d == department_id
        if department_id is not None:
            return d == department_id
        return True

    def pay_visible(p):
        if not (pf <= p["_dt"] < pt):
            return False
        if manager_id is not None:
            return False  # платёж не имеет доказанной персональной атрибуции
        if department_id is not None:
            return p["attribution_verified"] is True and p["attributed_department_id"] == department_id
        return True

    inc_sales = [s for s in sales_kept if sale_visible(s)]
    inc_payments = [] if manager_id is not None else [p for p in payments_kept if pay_visible(p)]

    # 7) Конфликтные группы: предупреждения только по затронутому скоупу
    #    (никаких чужих event_id/ключей в output ROP).
    sales_conf_vis = [g for g in sales_conf if any(sale_visible(s) for s in g)]
    payments_conf_vis = [g for g in payments_conf if any(pay_visible(p) for p in g)]
    for g in sales_conf_vis:
        warnings.append("SALES_CONFLICT:contract_id=%s:%d contradictory records excluded, "
                        "cluster dropped (no random pick)" % (g[0]["contract_id"], len(g)))
    for g in payments_conf_vis:
        warnings.append("PAYMENTS_CONFLICT:payment_id=%s:%d contradictory records excluded, "
                        "cluster dropped (no random pick)" % (g[0]["payment_id"], len(g)))

    # 8) Unassigned: только на уровне компании (ROP/отдел их не видит).
    if manager_id is None and department_id is None:
        una_sales = [s for s in inc_sales if _dept_at(asg, s["manager_id"], s["_dt"]) is None]
        una_payments = [p for p in inc_payments if not _pay_attributed(p)]
        una_pay_conf_vis = [g for g in payments_conf_vis
                            if any(not _pay_attributed(p) for p in g)]
    else:
        una_sales, una_payments, una_pay_conf_vis = [], [], []

    # 9) KPI.
    sales_total = _kpi(inc_sales, bool(sales_conf_vis))
    if manager_id is None:
        payments_total = _kpi(inc_payments, bool(payments_conf_vis))
        unassigned_payments = _kpi(una_payments, bool(una_pay_conf_vis))
    else:
        payments_total = _kpi([], False, forced_reason=NO_MANAGER_PAYMENT_ATTRIBUTION)
        unassigned_payments = _kpi([], False, forced_reason=NO_MANAGER_PAYMENT_ATTRIBUTION)

    return {
        "scope": {"department_id": department_id, "manager_id": manager_id},
        "sales_total": sales_total,
        "sales_count": len(inc_sales),
        "payments_total": payments_total,
        "payments_count": len(inc_payments),
        "unassigned": {
            "sales_count": len(una_sales),
            "payments_total": unassigned_payments,
        },
        "warnings": list(warnings),
        "mode": MODE,
        "vat_basis": VAT_BASIS,
        "period": {"from": period_from, "to": period_to},
    }
