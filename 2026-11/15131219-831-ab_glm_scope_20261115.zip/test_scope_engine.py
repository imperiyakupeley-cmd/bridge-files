#!/usr/bin/env python3
"""test_scope_engine.py — unittest для scope_engine (Task B, mwh450obg741).

17 тестов, только stdlib: OWNER KPI, изоляция ROP, переводы M1 D1->D2, dedup,
VERIFIED-конфликты -> PARTIAL, unassigned-платежи, чужой менеджер, UNKNOWN!=0,
полуоткрытый период [from,to), немутируемость входов, ValueError-кейсы.
Запуск: python3 -m unittest -v test_scope_engine
"""

import copy
import unittest

from scope_engine import build_report, NO_MANAGER_PAYMENT_ATTRIBUTION

PF = "2026-11-01T00:00:00+03:00"
PT = "2026-11-30T00:00:00+03:00"
OWNER = {"role": "OWNER", "department_id": None}
ROP_D1 = {"role": "ROP", "department_id": "D1"}
ROP_D2 = {"role": "ROP", "department_id": "D2"}


def sale(eid, cid, at, gross, mid, ev="VERIFIED"):
    return {"type": "sale", "event_id": eid, "contract_id": cid, "recognized_at": at,
            "gross_rub": gross, "manager_id": mid, "evidence_status": ev}


def pay(eid, pid, at, gross, dept, verified=True, ev="VERIFIED"):
    return {"type": "payment", "event_id": eid, "payment_id": pid, "received_at": at,
            "gross_rub": gross, "attributed_department_id": dept,
            "attribution_verified": verified, "evidence_status": ev}


def asg(mid, dept, vf, vt):
    return {"manager_id": mid, "department_id": dept, "valid_from": vf, "valid_to": vt}


WHOLE = [(asg("M1", "D1", PF, PT), asg("M2", "D2", PF, PT))]


class BaseFixture(unittest.TestCase):
    """M1 в D1, M2 в D2 на весь период + базовый набор событий."""

    def setUp(self):
        self.assignments = [asg("M1", "D1", PF, PT), asg("M2", "D2", PF, PT)]
        self.events = [
            sale("e1", "c1", "2026-11-05T10:00:00+03:00", 100, "M1"),
            sale("e2", "c2", "2026-11-06T10:00:00+03:00", 200, "M2"),
            sale("e3", "c3", "2026-11-07T10:00:00+03:00", 50, "M1", ev="PARTIAL"),
            pay("e4", "pm1", "2026-11-08T10:00:00+03:00", 300, "D1", verified=True),
            pay("e5", "pm2", "2026-11-09T10:00:00+03:00", 40, None, verified=False),
        ]


class TestOwnerKpi(BaseFixture):
    def test_owner_company_totals(self):
        r = build_report(self.events, self.assignments, OWNER, PF, PT)
        self.assertEqual(r["scope"], {"department_id": None, "manager_id": None})
        # 100+200 VERIFIED + 50 PARTIAL => полный value недоказуем
        self.assertEqual(r["sales_total"], {"value": None, "status": "PARTIAL", "verified_subtotal": 300})
        self.assertEqual(r["sales_count"], 3)
        # оба платежа VERIFIED-evidence => доказанный итог 340
        self.assertEqual(r["payments_total"], {"value": 340, "status": "VERIFIED", "verified_subtotal": 340})
        self.assertEqual(r["payments_count"], 2)
        # все продажи атрибутированы; платёж pm2 без верифицированной атрибуции -> unassigned
        self.assertEqual(r["unassigned"]["sales_count"], 0)
        self.assertEqual(r["unassigned"]["payments_total"], {"value": 40, "status": "VERIFIED", "verified_subtotal": 40})
        self.assertEqual(r["warnings"], [])
        self.assertEqual(r["mode"], "SYNTHETIC")
        self.assertEqual(r["vat_basis"], "GROSS_INCL_VAT_5")
        self.assertEqual(r["period"], {"from": PF, "to": PT})

    def test_owner_department_scope(self):
        r = build_report(self.events, self.assignments, OWNER, PF, PT, department_id="D1")
        self.assertEqual(r["sales_count"], 2)  # e1, e3 (обе M1/D1); e2 (D2) не видна
        self.assertEqual(r["sales_total"], {"value": None, "status": "PARTIAL", "verified_subtotal": 100})
        self.assertEqual(r["payments_count"], 1)  # только pm1 -> D1
        self.assertEqual(r["payments_total"], {"value": 300, "status": "VERIFIED", "verified_subtotal": 300})
        self.assertEqual(r["unassigned"], {"sales_count": 0,
                                           "payments_total": {"value": 0, "status": "VERIFIED", "verified_subtotal": 0}})
        self.assertEqual(r["scope"]["department_id"], "D1")


class TestRopIsolation(BaseFixture):
    def test_rop_isolation_and_no_warning_leak(self):
        # конфликтный D2-платёж: не должен просачиваться к ROP D1 даже в warnings
        events = self.events + [
            pay("e6", "pm9", "2026-11-10T10:00:00+03:00", 10, "D2", verified=True),
            pay("e7", "pm9", "2026-11-10T10:00:00+03:00", 20, "D2", verified=True),
        ]
        r1 = build_report(events, self.assignments, ROP_D1, PF, PT, department_id="D1")
        self.assertEqual(r1["sales_count"], 2)
        self.assertEqual(r1["sales_total"]["verified_subtotal"], 100)
        self.assertEqual(r1["payments_count"], 1)
        self.assertEqual(r1["payments_total"]["value"], 300)
        self.assertEqual(r1["warnings"], [])  # никаких следов D2-конфликта

        r2 = build_report(events, self.assignments, ROP_D2, PF, PT, department_id="D2")
        self.assertEqual(r2["sales_count"], 1)  # e2
        self.assertEqual(r2["sales_total"], {"value": 200, "status": "VERIFIED", "verified_subtotal": 200})
        self.assertEqual(r2["payments_count"], 0)  # конфликтный pm9 исключён целиком
        self.assertEqual(r2["payments_total"], {"value": None, "status": "PARTIAL", "verified_subtotal": 0})
        self.assertEqual(len(r2["warnings"]), 1)
        self.assertIn("PAYMENTS_CONFLICT:payment_id=pm9", r2["warnings"][0])

        r_owner = build_report(events, self.assignments, OWNER, PF, PT)
        self.assertEqual(len(r_owner["warnings"]), 1)

    def test_rop_and_role_permission_errors(self):
        cases = [
            (ROP_D1, "D2"),   # чужой отдел
            (ROP_D1, None),   # вся компания
            (ROP_D2, "D1"),
            ({"role": "ADMIN", "department_id": None}, None),  # недопустимая role
            ({}, None),       # role отсутствует
        ]
        for principal, dept in cases:
            with self.subTest(principal=principal, dept=dept):
                with self.assertRaises(PermissionError):
                    build_report(self.events, self.assignments, principal, PF, PT, department_id=dept)


class TestValidation(unittest.TestCase):
    def test_owner_unknown_department_value_error(self):
        events, assignments = [], []
        with self.assertRaises(ValueError):
            build_report(events, assignments, OWNER, PF, PT, department_id="D3")
        with self.assertRaises(ValueError):  # D3 в самом principal
            build_report(events, assignments, {"role": "ROP", "department_id": "D3"}, PF, PT, department_id="D3")

    def test_invalid_period_value_errors(self):
        events, assignments = [], []
        for pf, pt in [
            (PF, PF),                                    # from == to
            ("2026-11-30T00:00:00+03:00", PF),           # from > to
            ("2026-11-01T00:00:00", PT),                 # без смещения
            (PF, "not-a-date"),                          # мусор
        ]:
            with self.subTest(pf=pf, pt=pt):
                with self.assertRaises(ValueError):
                    build_report(events, assignments, OWNER, pf, pt)


class TestManagerTransfer(unittest.TestCase):
    def setUp(self):
        self.assignments = [
            asg("M1", "D1", PF, "2026-11-15T00:00:00+03:00"),
            asg("M1", "D2", "2026-11-15T00:00:00+03:00", "2026-12-01T00:00:00+03:00"),
            # M9: два перекрывающихся назначения -> неоднозначность
            asg("M9", "D1", PF, PT),
            asg("M9", "D2", PF, PT),
            # M8: без назначений
        ]
        self.events = [
            sale("e1", "c1", "2026-11-14T12:00:00+03:00", 100, "M1"),   # ещё D1
            sale("e2", "c2", "2026-11-15T00:00:00+03:00", 200, "M1"),   # ровно граница -> D2
            sale("e3", "c3", "2026-11-10T00:00:00+03:00", 70, "M9"),    # неоднозначно
            sale("e4", "c4", "2026-11-11T00:00:00+03:00", 30, "M8"),    # нет назначений
        ]

    def test_sales_follow_assignment_at_recognition(self):
        r1 = build_report(self.events, self.assignments, ROP_D1, PF, PT, department_id="D1")
        self.assertEqual(r1["sales_count"], 1)
        self.assertEqual(r1["sales_total"]["value"], 100)
        r2 = build_report(self.events, self.assignments, ROP_D2, PF, PT, department_id="D2")
        self.assertEqual(r2["sales_count"], 1)  # граница 15.11 00:00 уже D2
        self.assertEqual(r2["sales_total"]["value"], 200)
        ro = build_report(self.events, self.assignments, OWNER, PF, PT)
        self.assertEqual(ro["sales_count"], 4)
        self.assertEqual(ro["sales_total"]["value"], 400)
        self.assertEqual(ro["unassigned"]["sales_count"], 2)  # M9-неоднозначность и M8


class TestDedupAndConflicts(BaseFixture):
    def test_identical_duplicates_collapsed(self):
        events = [
            sale("e1", "c1", "2026-11-05T10:00:00+03:00", 100, "M1"),
            sale("e1", "c1", "2026-11-05T10:00:00+03:00", 100, "M1"),  # точный дубль
            sale("e1", "c1", "2026-11-05T10:00:00+03:00", 100, "M1"),  # ещё раз
            sale("e9", "c1", "2026-11-05T10:00:00+03:00", 100, "M1"),  # тот же смысл, другой event_id
            pay("e4", "pm1", "2026-11-08T10:00:00+03:00", 300, "D1"),
            pay("e4", "pm1", "2026-11-08T10:00:00+03:00", 300, "D1"),
        ]
        r = build_report(events, self.assignments, OWNER, PF, PT)
        self.assertEqual(r["sales_count"], 1)
        self.assertEqual(r["sales_total"], {"value": 100, "status": "VERIFIED", "verified_subtotal": 100})
        self.assertEqual(r["payments_count"], 1)
        self.assertEqual(r["payments_total"]["value"], 300)
        self.assertEqual(r["warnings"], [])  # идентичные дубли — молча

    def test_verified_conflicts_excluded_partial(self):
        events = [
            sale("e1", "c1", "2026-11-05T10:00:00+03:00", 100, "M1"),
            sale("e2", "c1", "2026-11-05T10:00:00+03:00", 150, "M1"),  # VERIFIED-противоречие по сумме
            sale("e3", "c2", "2026-11-06T10:00:00+03:00", 70, "M1"),   # чистая продажа
            pay("e4", "pm1", "2026-11-08T10:00:00+03:00", 300, "D1"),
            pay("e5", "pm1", "2026-11-08T10:00:00+03:00", 350, "D1"),  # VERIFIED-противоречие
        ]
        r = build_report(events, self.assignments, OWNER, PF, PT)
        self.assertEqual(r["sales_count"], 1)  # кластер c1 исключён целиком, без случайного выбора
        self.assertEqual(r["sales_total"], {"value": None, "status": "PARTIAL", "verified_subtotal": 70})
        self.assertEqual(r["payments_count"], 0)
        self.assertEqual(r["payments_total"], {"value": None, "status": "PARTIAL", "verified_subtotal": 0})
        self.assertEqual(len(r["warnings"]), 2)
        self.assertTrue(any(w.startswith("SALES_CONFLICT:contract_id=c1") for w in r["warnings"]))
        self.assertTrue(any(w.startswith("PAYMENTS_CONFLICT:payment_id=pm1") for w in r["warnings"]))


class TestUnassignedPayments(unittest.TestCase):
    def setUp(self):
        self.assignments = [asg("M1", "D1", PF, PT)]
        self.events = [
            pay("e1", "pm1", "2026-11-05T10:00:00+03:00", 40, None, verified=False),  # без атрибуции
            pay("e2", "pm2", "2026-11-06T10:00:00+03:00", 30, "D1", verified=False),  # флаг не верифицирован
            pay("e3", "pm3", "2026-11-07T10:00:00+03:00", 55, "D3", verified=True),   # атрибутирован вне D1/D2
            pay("e4", "pm4", "2026-11-08T10:00:00+03:00", 60, "D1", verified=True),   # чистый D1
        ]

    def test_unattributed_payments_company_and_departments(self):
        ro = build_report(self.events, self.assignments, OWNER, PF, PT)
        self.assertEqual(ro["payments_count"], 4)
        self.assertEqual(ro["payments_total"], {"value": 185, "status": "VERIFIED", "verified_subtotal": 185})
        # общий итог компании + unassigned, но не D1/D2
        self.assertEqual(ro["unassigned"]["payments_total"], {"value": 70, "status": "VERIFIED", "verified_subtotal": 70})
        r1 = build_report(self.events, self.assignments, ROP_D1, PF, PT, department_id="D1")
        self.assertEqual(r1["payments_count"], 1)
        self.assertEqual(r1["payments_total"]["value"], 60)
        self.assertEqual(r1["unassigned"]["payments_total"]["value"], 0)

    def test_payment_requires_verified_attribution_flag(self):
        events = [pay("e1", "pm2", "2026-11-06T10:00:00+03:00", 30, "D1", verified=False)]
        r1 = build_report(events, self.assignments, ROP_D1, PF, PT, department_id="D1")
        self.assertEqual(r1["payments_count"], 0)  # claimed D1, но attribution_verified=False
        ro = build_report(events, self.assignments, OWNER, PF, PT)
        self.assertEqual(ro["payments_count"], 1)  # в компании есть, но unassigned
        self.assertEqual(ro["unassigned"]["payments_total"]["value"], 30)


class TestManagerScope(unittest.TestCase):
    def setUp(self):
        self.assignments = [
            asg("M1", "D1", PF, "2026-11-15T00:00:00+03:00"),
            asg("M1", "D2", "2026-11-15T00:00:00+03:00", "2026-12-01T00:00:00+03:00"),
            asg("M2", "D2", PF, PT),
        ]
        self.events = [
            sale("e1", "c1", "2026-11-05T10:00:00+03:00", 100, "M1"),  # M1 в D1
            sale("e2", "c2", "2026-11-20T10:00:00+03:00", 200, "M1"),  # M1 в D2
            sale("e3", "c3", "2026-11-06T10:00:00+03:00", 50, "M2"),   # чужой менеджер (D2)
            pay("e4", "pm1", "2026-11-08T10:00:00+03:00", 300, "D1"),
        ]

    def test_rop_cannot_select_foreign_manager(self):
        with self.assertRaises(PermissionError):  # M2 не в доступном отделе ROP D1
            build_report(self.events, self.assignments, ROP_D1, PF, PT, department_id="D1", manager_id="M2")
        with self.assertRaises(ValueError):  # менеджера нет вовсе
            build_report(self.events, self.assignments, OWNER, PF, PT, manager_id="M99")

    def test_manager_scope_payments_unknown(self):
        r = build_report(self.events, self.assignments, ROP_D1, PF, PT, department_id="D1", manager_id="M1")
        self.assertEqual(r["scope"], {"department_id": "D1", "manager_id": "M1"})
        self.assertEqual(r["sales_count"], 1)  # только D1-время M1
        self.assertEqual(r["sales_total"], {"value": 100, "status": "VERIFIED", "verified_subtotal": 100})
        unknown = {"value": None, "status": "UNKNOWN", "verified_subtotal": 0,
                   "reason": NO_MANAGER_PAYMENT_ATTRIBUTION}
        self.assertEqual(r["payments_total"], unknown)  # нет доказанной персональной атрибуции платежей
        self.assertEqual(r["payments_count"], 0)
        self.assertEqual(r["unassigned"]["payments_total"], unknown)
        ro = build_report(self.events, self.assignments, OWNER, PF, PT, manager_id="M1")
        self.assertEqual(ro["sales_count"], 2)  # вся история M1: D1-время + D2-время
        self.assertEqual(ro["sales_total"]["value"], 300)
        self.assertEqual(ro["payments_total"], unknown)


class TestUnknownKpi(BaseFixture):
    def test_unknown_kpi_value_is_null_not_zero(self):
        events = [
            sale("e1", "c1", "2026-11-05T10:00:00+03:00", 100, "M1", ev="UNKNOWN"),
            sale("e2", "c2", "2026-11-06T10:00:00+03:00", 100, "M1", ev="UNKNOWN"),
            pay("e3", "pm1", "2026-11-07T10:00:00+03:00", 300, "D1", ev="UNKNOWN"),
        ]
        r = build_report(events, self.assignments, OWNER, PF, PT)
        self.assertEqual(r["sales_count"], 2)                      # события есть
        self.assertIsNone(r["sales_total"]["value"])               # но value = null, НЕ 0
        self.assertNotEqual(r["sales_total"]["value"], 0)
        self.assertEqual(r["sales_total"]["status"], "UNKNOWN")
        self.assertEqual(r["sales_total"]["verified_subtotal"], 0)
        self.assertIsNone(r["payments_total"]["value"])
        self.assertEqual(r["payments_total"]["status"], "UNKNOWN")


class TestPeriodAndImmutability(BaseFixture):
    def test_half_open_period_bounds(self):
        events = [
            sale("e1", "c1", PF, 100, "M1"),  # ровно from -> входит
            sale("e2", "c2", PT, 200, "M1"),  # ровно to -> НЕ входит
        ]
        r = build_report(events, self.assignments, OWNER, PF, PT)
        self.assertEqual(r["sales_count"], 1)
        self.assertEqual(r["sales_total"]["value"], 100)

    def test_inputs_are_not_mutated(self):
        events = copy.deepcopy(self.events)
        assignments = copy.deepcopy(self.assignments)
        principals = [OWNER, ROP_D1, ROP_D2]
        principal_copies = copy.deepcopy(principals)
        build_report(tuple(events), tuple(assignments), OWNER, PF, PT)
        build_report(events, assignments, ROP_D1, PF, PT, department_id="D1")
        build_report(events, assignments, ROP_D1, PF, PT, department_id="D1", manager_id="M1")
        self.assertEqual(events, self.events)
        self.assertEqual(assignments, self.assignments)
        self.assertEqual(principals, principal_copies)


if __name__ == "__main__":
    unittest.main()
