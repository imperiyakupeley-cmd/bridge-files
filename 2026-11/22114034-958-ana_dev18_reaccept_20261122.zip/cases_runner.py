#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Независимый прогон 9 приёмочных кейсов K1–K9 (задача mwrjhno55yxh) на реальном
коде ANA из сборки AI_ROP_ANA_DEV_18_PRIORITY_2026-11-22.zip (v13 + применённый
патч unconfirmed-payment). Запуск:

  PYTHONPATH=<extract>/v13 python3 -B cases_runner.py

Синтетика, офлайн, без CRM/банка/production.
Кейсы построены на каркасе examples.make_owner_demo.build_demo (библиотечный
вход пакета), содержимое заменено на минимальные сценарии.
"""
import sys

from examples.make_owner_demo import build_demo, t
from airop_diagnostics.owner_report import build_report


def fresh(open_period=False):
    """Каркас demo без демо-лидов, событий, платежей и планов."""
    d = build_demo(open_period)
    d["opportunities"], d["events"], d["payments"], d["plans"] = [], [], [], []
    d.pop("forecast", None)  # demo-прогноз ссылается на удалённых лидов
    return d


def opp(d, lid, at, product="Купели", manager="Менеджер A"):
    d["opportunities"].append({"id": lid, "product": product, "channel": "Авито",
                               "segment": "Частный", "created_at": at, "target": True,
                               "source": "synthetic", "ref": lid})
    d["events"].append({"id": f"{lid}-own", "opportunity_id": lid, "kind": "owner_assigned",
                        "at": at, "source": "synthetic", "ref": f"{lid}-own",
                        "verified": True, "actor": manager})


def contract(d, lid, at, amount, advance_required):
    d["events"].append({"id": f"{lid}-sign", "opportunity_id": lid, "kind": "contract_signed",
                        "at": at, "source": "synthetic", "ref": f"{lid}-sign", "verified": True,
                        "contract_id": f"c-{lid}", "amount": amount,
                        "advance_required": advance_required})


def pay(d, lid, kind, at, amount, verified=True):
    key = f"{lid}-pay-{len(d['payments']) + 1}"
    d["payments"].append({"id": key, "opportunity_id": lid, "kind": kind, "at": at,
                          "amount": amount, "source": "synthetic", "ref": key,
                          "verified": verified, "contract_id": f"c-{lid}"})


def plan(d, target, basis="gross_receipts_rub", scope="company"):
    d["plans"].append({"basis": basis, "scope": scope, "target": target,
                       "start": d["period"]["start"], "end": d["period"]["end"],
                       "approved": True, "approved_at": t(9, 30), "version": "case-1",
                       "source": "synthetic", "ref": f"plan-{basis}-{scope}"})


def run(tag, data, expect_gap, note):
    r = build_report(data)
    fin = r["diagnosis"]["finance"]["current"]
    rows = [p for p in r["planning"]["plan_fact"] if p["basis"] == "gross_receipts_rub"]
    row = rows[0] if rows else {}
    gaps = [x for x in r["recommendations"]["priorities"] if x["code"] == "PLAN_GAP"]
    got_gap = bool(gaps)
    trace = (f"L{sys.argv[1] if len(sys.argv) > 1 else ''}" if False else "")
    line = {
        "кейс": tag,
        "period_closed": row.get("period_closed"),
        "план": row.get("target"),
        "факт": row.get("actual"),
        "статус": row.get("status"),
        "PLAN_GAP": "ДА" if got_gap else "нет",
        "sales": fin["sales_count"],
        "signed": fin["signed_count"],
        "gross": fin["gross_receipts_rub"],
        "ожидался_GAP": "ДА" if expect_gap else "нет",
        "итог": "MATCH" if got_gap == expect_gap else "DIFF",
        "примечание": note,
    }
    return line, r


def main():
    cases = []

    # K1: полный период; подтверждено 30k, неподтверждено 80k; план 100k → ложный PLAN_GAP запрещён
    d = fresh()
    opp(d, "K1", t(10, 1)); contract(d, "K1", t(10, 2), "180000.00", "30000.00")
    pay(d, "K1", "advance", t(10, 3), "30000.00")
    pay(d, "K1", "final", t(10, 5), "80000.00", verified=False)
    plan(d, "100000.00")
    cases.append(("K1", d, False, "разрыв исчезает при неподтверждённых 80k"))

    # K2: открытый период (as_of 10.10); неподтверждено 80k, подтверждённого нет
    d = fresh(True)
    opp(d, "K2", t(10, 1)); contract(d, "K2", t(10, 2), "180000.00", "30000.00")
    pay(d, "K2", "final", t(10, 6), "80000.00", verified=False)
    plan(d, "100000.00")
    cases.append(("K2", d, False, "неполн. период + неподтверждённый платёж"))

    # K3: открытый период; подтверждено 30k против плана 100k → рано выносить вердикт
    d = fresh(True)
    opp(d, "K3", t(10, 1)); contract(d, "K3", t(10, 2), "180000.00", "30000.00")
    pay(d, "K3", "advance", t(10, 3), "30000.00")
    plan(d, "100000.00")
    cases.append(("K3", d, False, "период 9/14 пройден, финальный GAP запрещён"))

    # K4: аванс 20k из порога 60k, полный период, план 100k → правомерный PLAN_GAP
    d = fresh()
    opp(d, "K4", t(10, 1)); contract(d, "K4", t(10, 2), "60000.00", "60000.00")
    pay(d, "K4", "advance", t(10, 3), "20000.00")
    plan(d, "100000.00")
    cases.append(("K4", d, True, "деньги по зачислению 20k; разрыв не спасается"))

    # K5: аванс 20k из 60k, открытый период → не PLAN_GAP
    d = fresh(True)
    opp(d, "K5", t(10, 1)); contract(d, "K5", t(10, 2), "60000.00", "60000.00")
    pay(d, "K5", "advance", t(10, 3), "20000.00")
    plan(d, "100000.00")
    cases.append(("K5", d, False, "частичный аванс, период не закрыт"))

    # K6: два транша 20k+10k ниже порога 60k → gross строго 30k, без двойного счёта
    d = fresh()
    opp(d, "K6", t(10, 1)); contract(d, "K6", t(10, 2), "60000.00", "60000.00")
    pay(d, "K6", "advance", t(10, 3), "20000.00")
    pay(d, "K6", "advance", t(10, 6), "10000.00")
    plan(d, "60000.00")
    cases.append(("K6", d, True, "транши не повторяют стоимость договора"))

    # K7: неполная история источника cash → факт не подтверждён, ноль не утверждается
    d = fresh()
    opp(d, "K7", t(10, 1)); contract(d, "K7", t(10, 2), "180000.00", "30000.00")
    pay(d, "K7", "advance", t(10, 3), "30000.00")
    d["coverage"]["cash"]["complete"] = False
    plan(d, "100000.00")
    cases.append(("K7", d, False, "coverage.cash=false → fail-closed"))

    # K8: план перевыполнен подтверждёнными 120k → NO_GAP
    d = fresh()
    opp(d, "K8", t(10, 1)); contract(d, "K8", t(10, 2), "120000.00", "60000.00")
    pay(d, "K8", "advance", t(10, 3), "120000.00")
    plan(d, "100000.00")
    cases.append(("K8", d, False, "положительный контроль защиты"))

    # K9: ровно 60k из 60k двумя траншами → одна продажа, порог закрыт, NO_GAP
    d = fresh()
    opp(d, "K9", t(10, 1)); contract(d, "K9", t(10, 2), "60000.00", "60000.00")
    pay(d, "K9", "advance", t(10, 3), "20000.00")
    pay(d, "K9", "advance", t(10, 6), "40000.00")
    plan(d, "60000.00")
    cases.append(("K9", d, False, "порог достигнут, продажа ровно одна"))

    header = ["кейс", "period_closed", "план", "факт", "статус", "PLAN_GAP",
              "sales", "signed", "gross", "ожидался_GAP", "итог", "примечание"]
    print(" | ".join(header))
    print("-" * 150)
    diffs = 0
    for tag, data, expect_gap, note in cases:
        line, _ = run(tag, data, expect_gap, note)
        if line["итог"] == "DIFF":
            diffs += 1
        print(" | ".join(str(line[h]) for h in header))
    print("-" * 150)
    print("ИТОГ:", "PASS — фактические вердикты ANA совпали с ожиданиями по PLAN_GAP во всех 9 кейсах"
          if diffs == 0 else f"DIFF в {diffs} кейсах")


if __name__ == "__main__":
    main()
